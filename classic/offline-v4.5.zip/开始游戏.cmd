@echo off
chcp 65001 >nul
start "" "%~dp0星跃远征.html"
