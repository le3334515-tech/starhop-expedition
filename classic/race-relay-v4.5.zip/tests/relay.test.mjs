import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import worker from '../worker/index.js';

function database(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(readFileSync(new URL('../drizzle/0000_race_rooms.sql',import.meta.url),'utf8').replaceAll('--> statement-breakpoint',''));
 const prepare=sql=>({values:[],bind(...values){this.values=values;return this;},async run(){const result=sqlite.prepare(sql).run(...this.values);return{success:true,meta:result};},async all(){return{success:true,results:sqlite.prepare(sql).all(...this.values)};},sql});
 return{prepare,async batch(statements){sqlite.exec('BEGIN');try{const out=[];for(const s of statements){if(/^\s*SELECT/i.test(s.sql))out.push(await s.all());else{await s.run();out.push({success:true,results:[]});}}sqlite.exec('COMMIT');return out;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
}
test('two public clients exchange snapshots and use one server-clock countdown; tokens, race order and reset are enforced',async()=>{
 const DB=database();const realNow=Date.now;let now=100000;Date.now=()=>now;
 const call=async body=>{const response=await worker.fetch(new Request('https://race.example/api/race',{method:'POST',body:JSON.stringify(body)}),{DB});return{status:response.status,...await response.json()};};
 try{
  const created=await call({action:'create',clientId:'host-client-1',name:'房主',config:{seed:42,modifier:'standard',weapon:'ember'}});
  assert.equal(created.status,200);assert.equal(created.selfId,'host');assert.equal(created.room.status,'waiting');
  const roomId=created.room.id,host=created.token;
  const joined=await call({action:'join',roomId,clientId:'guest-client-1',name:'好友'});assert.equal(joined.status,200);const guest=joined.token;
  assert.equal((await call({action:'join',roomId,clientId:'third-client-1'})).status,409);
  assert.equal((await call({action:'join',roomId,clientId:'host-client-1'})).token,host);
  assert.equal((await call({action:'state',roomId,token:'wrong'})).status,401);
  assert.equal((await call({action:'ready',roomId,token:host})).room.startAt,null);
  now+=400;const ready=await call({action:'ready',roomId,token:guest});assert.equal(ready.room.startAt,now+5000);assert.equal(ready.room.status,'countdown');
  assert.equal((await call({action:'state',roomId,token:host})).room.startAt,ready.room.startAt);
  const cancelled=await call({action:'ready',roomId,token:guest,ready:false});assert.equal(cancelled.room.startAt,null);
  const again=await call({action:'ready',roomId,token:guest});const start=again.room.startAt;
  assert.equal((await call({action:'state',roomId,token:host,frame:{seq:1,roomIndex:7,finished:true,won:true}})).status,409);
  now=start+30;
  assert.equal((await call({action:'ready',roomId,token:host})).status,409);
  let frame={seq:2,roomIndex:0,x:310,y:412,phase:'playing',animation:.4,weapon:'ember'};
  await call({action:'state',roomId,token:host,frame});
  const other=await call({action:'state',roomId,token:guest,frame:{...frame,seq:1,x:420,weapon:'disc'}});
  assert.equal(other.room.host.frame.x,310);assert.equal(other.room.host.frame.phase,'playing');assert.equal(other.room.guest.frame.x,420);
  const stale=await call({action:'state',roomId,token:host,frame:{...frame,seq:1,x:1}});assert.equal(stale.room.host.frame.x,310);
  assert.equal((await call({action:'reset',roomId,token:host})).status,409);
  assert.equal((await call({action:'state',roomId,token:host,frame:{...frame,seq:3,roomIndex:1}})).status,200);
  assert.equal((await call({action:'state',roomId,token:host,frame:{...frame,seq:4,roomIndex:0}})).status,409);
  now+=20000;await call({action:'state',roomId,token:host,frame:{...frame,seq:5,roomIndex:7,finished:true,won:true}});
  now+=200;const finished=await call({action:'state',roomId,token:guest,frame:{...frame,seq:5,roomIndex:7,finished:true,won:true}});
  assert.equal(finished.room.status,'finished');assert.equal(finished.room.guest.finishedAt-finished.room.host.finishedAt,200);
  const reset=await call({action:'reset',roomId,token:host});assert.equal(reset.room.startAt,null);assert.equal(reset.room.epoch,1);assert.equal(reset.room.host.frame,null);
  const lateFinish=await call({action:'state',roomId,token:guest,epoch:0,frame:{...frame,seq:99,roomIndex:7,finished:true,won:true}});
  assert.equal(lateFinish.status,200);assert.equal(lateFinish.room.epoch,1);
  assert.equal(lateFinish.room.guest.frame,null);assert.equal(lateFinish.room.guest.finishedAt,null);
  assert.equal(lateFinish.room.startAt,null);
  assert.equal((await call({action:'state',roomId,token:guest,epoch:1,frame:{...frame,seq:1,roomIndex:7,finished:true,won:true}})).status,409);
  await call({action:'ready',roomId,token:host});
  const nextReady=await call({action:'ready',roomId,token:guest});now=nextReady.room.startAt+20;
  const newRun=await call({action:'state',roomId,token:guest,epoch:1,frame:{...frame,seq:1,roomIndex:0,x:140}});
  assert.equal(newRun.status,200);assert.equal(newRun.room.guest.frame.x,140);assert.equal(newRun.room.guest.frame.roomIndex,0);
  const oldRun=await call({action:'state',roomId,token:guest,epoch:0,frame:{...frame,seq:100,roomIndex:7,finished:true,won:true}});
  assert.equal(oldRun.room.guest.frame.x,140);assert.equal(oldRun.room.guest.finishedAt,null);
  await call({action:'leave',roomId,token:guest});await call({action:'leave',roomId,token:host});
  const freshRound=await call({action:'reset',roomId,token:host});assert.equal(freshRound.room.epoch,2);
  const left=await call({action:'leave',roomId,token:guest});assert.equal(left.room.guest,null);assert.equal(left.room.host.readyAt,null);
  const replacement=await call({action:'join',roomId,clientId:'new-guest-client'});assert.equal(replacement.status,200);
  now+=7200001;assert.equal((await call({action:'state',roomId,token:host})).status,410);
 }finally{Date.now=realNow;}
});
