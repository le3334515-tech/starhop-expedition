import type { SoundName } from './types';

type Bus = 'music' | 'effects';
type Source = OscillatorNode | AudioBufferSourceNode;

/** Original, entirely synthesized chiptune music and effects. No audio downloads. */
export class GameAudio {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private effectsBus: GainNode | null = null;
  private sources = new Map<Source, Bus>();
  private noiseBuffer: AudioBuffer | null = null;
  private musicTimer: ReturnType<typeof setInterval> | null = null;
  private nextStepAt = 0;
  private step = 0;
  private musicWanted = false;
  private _muted = false;
  private disposed = false;
  private lastEffectAt = new Map<SoundName, number>();

  constructor() {
    try { this._muted = localStorage.getItem('starhop.audioMuted.v1') === '1'; } catch { /* Optional preference. */ }
  }

  get muted(): boolean { return this._muted; }

  async unlock(): Promise<void> {
    if (this.disposed) return;
    try {
      if (!this.context) {
        const AudioContextClass = globalThis.AudioContext || (globalThis as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AudioContextClass) return;
        this.context = new AudioContextClass();
        this.master = this.context.createGain();
        this.master.gain.value = this._muted ? 0 : 0.65;
        const compressor = this.context.createDynamicsCompressor();
        compressor.threshold.value = -15;
        compressor.knee.value = 16;
        compressor.ratio.value = 5;
        this.master.connect(compressor);
        compressor.connect(this.context.destination);
        this.musicBus = this.context.createGain();
        this.musicBus.gain.value = 0.2;
        this.effectsBus = this.context.createGain();
        this.effectsBus.gain.value = 0.65;
        this.musicBus.connect(this.master);
        this.effectsBus.connect(this.master);
        this.noiseBuffer = this.context.createBuffer(1, Math.ceil(this.context.sampleRate * 0.5), this.context.sampleRate);
        const samples = this.noiseBuffer.getChannelData(0);
        for (let i = 0; i < samples.length; i++) samples[i] = Math.random() * 2 - 1;
      }
      if (this.context.state === 'suspended') await this.context.resume();
      if (this.musicWanted && this.context.state === 'running') this.startMusic();
    } catch { /* Audio is decorative: browsers without it can still play. */ }
  }

  setMuted(value: boolean): void {
    this._muted = value;
    try { localStorage.setItem('starhop.audioMuted.v1', value ? '1' : '0'); } catch { /* Optional preference. */ }
    if (this.context && this.master) this.master.gain.setTargetAtTime(value ? 0 : 0.65, this.context.currentTime, 0.015);
  }

  setMusic(active: boolean): void {
    this.musicWanted = active;
    if (active) this.startMusic();
    else this.stopMusic();
  }

  private startMusic(): void {
    if (!this.context || this.context.state !== 'running' || this.musicTimer !== null || this.disposed) return;
    this.step = 0;
    this.nextStepAt = this.context.currentTime + 0.05;
    this.scheduleMusic();
    this.musicTimer = setInterval(() => this.scheduleMusic(), 35);
  }

  private stopMusic(): void {
    if (this.musicTimer !== null) clearInterval(this.musicTimer);
    this.musicTimer = null;
    for (const [source, bus] of this.sources) {
      if (bus === 'music') {
        try { source.stop(); } catch { /* Already ended. */ }
        this.sources.delete(source);
      }
    }
  }

  private scheduleMusic(): void {
    if (!this.context || !this.musicWanted || this.context.state !== 'running') return;
    // Four-bar original pentatonic phrase; sixteen subdivisions per bar.
    const melody = [72, 0, 79, 0, 76, 0, 0, 74, 72, 0, 67, 0, 69, 0, 0, 0,
      72, 0, 76, 0, 79, 0, 81, 0, 79, 0, 76, 74, 72, 0, 0, 0,
      69, 0, 72, 0, 76, 0, 0, 74, 72, 0, 69, 0, 67, 0, 0, 0,
      67, 0, 71, 0, 74, 0, 79, 0, 76, 0, 74, 0, 72, 0, 0, 0];
    const bass = [48, 45, 41, 43];
    let scheduled = 0;
    while (this.nextStepAt < this.context.currentTime + 0.16 && scheduled++ < 8) {
      const step = this.step % 64;
      const time = Math.max(this.nextStepAt, this.context.currentTime);
      if (melody[step]) this.tone(this.note(melody[step]), time, 0.2, 'triangle', 0.22, 'music');
      if (step % 4 === 0) this.tone(this.note(bass[Math.floor(step / 16)]), time, 0.22, 'triangle', 0.26, 'music');
      if (step % 8 === 0) this.tone(90, time, 0.11, 'sine', 0.32, 'music', 38);
      if (step % 8 === 4) this.noise(time, 0.055, 0.12, 'music', 1400);
      if (step % 2 === 1) this.noise(time, 0.018, 0.045, 'music', 6500);
      this.nextStepAt += 0.15;
      this.step++;
    }
    // Avoid a queued burst when the browser resumes a throttled tab.
    if (this.nextStepAt < this.context.currentTime - 0.1) this.nextStepAt = this.context.currentTime + 0.03;
  }

  play(name: SoundName): void {
    const ctx = this.context;
    if (!ctx || ctx.state !== 'running' || this._muted || this.disposed) return;
    const t = ctx.currentTime;
    const contactInterval = name === 'hit' ? .026 : name === 'critical' ? .045 : name === 'heavy' ? .055 : name === 'guardBreak' ? .12 : 0;
    if (contactInterval && t - (this.lastEffectAt.get(name) ?? -10) < contactInterval) return;
    this.lastEffectAt.set(name, t);
    try {
      switch (name) {
        case 'jump': this.tone(300, t, 0.13, 'square', 0.11, 'effects', 650); break;
        case 'doubleJump': this.tone(520, t, 0.12, 'triangle', 0.2, 'effects', 980); this.tone(780, t + 0.05, 0.1, 'sine', 0.1, 'effects', 1300); break;
        case 'attack': this.noise(t, 0.045, 0.075, 'effects', 2900); this.tone(250, t, 0.055, 'triangle', 0.07, 'effects', 105); break;
        case 'fire': this.tone(850, t, 0.12, 'sawtooth', 0.055, 'effects', 220); break;
        case 'coin': this.tone(988, t, 0.07, 'square', 0.09, 'effects'); this.tone(1319, t + 0.065, 0.1, 'square', 0.075, 'effects'); break;
        case 'hurt': this.tone(140, t, 0.22, 'sawtooth', 0.14, 'effects', 45); this.noise(t, 0.1, 0.15, 'effects', 900); break;
        case 'hit':
          this.noise(t, .035, .24, 'effects', 2700);
          this.tone(175, t, .085, 'sine', .23, 'effects', 52);
          this.tone(470, t, .045, 'triangle', .11, 'effects', 150);
          break;
        case 'critical':
          this.noise(t, .055, .25, 'effects', 3800);
          this.tone(150, t, .12, 'sine', .28, 'effects', 42);
          this.tone(1280, t, .095, 'triangle', .15, 'effects', 540);
          this.tone(1920, t + .018, .12, 'sine', .09, 'effects', 960);
          break;
        case 'heavy':
          this.noise(t, .1, .28, 'effects', 1600);
          this.tone(135, t, .18, 'sine', .34, 'effects', 36);
          this.tone(310, t, .09, 'triangle', .18, 'effects', 70);
          this.noise(t + .045, .055, .1, 'effects', 4700);
          break;
        case 'guardBreak':
          this.noise(t, .17, .26, 'effects', 1900);
          this.noise(t + .075, .08, .16, 'effects', 4200);
          this.tone(195, t, .25, 'sawtooth', .15, 'effects', 47);
          this.tone(92, t, .3, 'sine', .28, 'effects', 29);
          this.tone(1480, t + .03, .19, 'triangle', .12, 'effects', 370);
          break;
        case 'perfectDodge':
          this.noise(t, .085, .13, 'effects', 5200);
          this.tone(880, t, .1, 'sine', .15, 'effects', 1760);
          this.tone(1320, t + .04, .16, 'triangle', .1, 'effects');
          break;
        case 'kill':
          this.tone(170, t, .14, 'sine', .23, 'effects', 48);
          this.noise(t, .07, .14, 'effects', 2300);
          this.tone(660, t + .025, .12, 'triangle', .15, 'effects', 330);
          this.tone(990, t + .06, .095, 'triangle', .08, 'effects');
          break;
        case 'upgrade': this.arpeggio([72, 76, 79, 84], t, 0.085, 0.16); break;
        case 'portal': this.arpeggio([60, 67, 72, 79, 84], t, 0.065, 0.12); break;
        case 'boss': this.tone(66, t, 0.42, 'sawtooth', 0.13, 'effects', 35); this.tone(92, t, .45, 'sine', .25, 'effects', 28); this.noise(t, 0.3, 0.18, 'effects', 600); break;
        case 'win': this.arpeggio([72, 76, 79, 84, 79, 84, 88], t, 0.12, 0.16); this.tone(this.note(48), t, 1.1, 'triangle', 0.15, 'effects'); break;
        case 'lose': this.arpeggio([72, 69, 65, 60, 48], t, 0.14, 0.14); break;
        case 'dash': this.noise(t, 0.11, 0.15, 'effects', 3600); this.tone(210, t, 0.1, 'sine', 0.12, 'effects', 90); break;
        case 'select': this.tone(880, t, 0.055, 'triangle', 0.14, 'effects'); break;
        case 'awaken':
          this.arpeggio([48, 60, 67, 72, 76, 79, 84, 88], t, 0.045, 0.16);
          this.tone(115, t, 0.48, 'sine', 0.3, 'effects', 38);
          this.noise(t, 0.22, 0.18, 'effects', 950);
          this.tone(this.note(72), t + 0.32, 0.5, 'triangle', 0.12, 'effects');
          this.tone(this.note(79), t + 0.32, 0.5, 'triangle', 0.09, 'effects');
          break;
        case 'synergy':
          this.arpeggio([76, 79, 84, 88], t, 0.09, 0.13);
          this.tone(this.note(72), t + 0.27, 0.48, 'sine', 0.12, 'effects');
          this.tone(this.note(79), t + 0.27, 0.48, 'triangle', 0.08, 'effects');
          break;
      }
    } catch { /* A suspended or closed audio device never interrupts a run. */ }
  }

  private note(midi: number): number { return 440 * 2 ** ((midi - 69) / 12); }

  private arpeggio(notes: number[], time: number, interval: number, volume: number): void {
    notes.forEach((note, index) => this.tone(this.note(note), time + index * interval, 0.23, 'triangle', volume, 'effects'));
  }

  private tone(frequency: number, time: number, duration: number, type: OscillatorType, volume: number, bus: Bus, endFrequency?: number): void {
    const ctx = this.context;
    const destination = bus === 'music' ? this.musicBus : this.effectsBus;
    if (!ctx || !destination) return;
    const oscillator = ctx.createOscillator();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, time);
    if (endFrequency) oscillator.frequency.exponentialRampToValueAtTime(endFrequency, time + duration);
    const envelope = ctx.createGain();
    envelope.gain.setValueAtTime(0.0001, time);
    envelope.gain.exponentialRampToValueAtTime(Math.max(0.001, volume), time + 0.006);
    envelope.gain.exponentialRampToValueAtTime(0.0001, time + duration);
    oscillator.connect(envelope);
    envelope.connect(destination);
    this.sources.set(oscillator, bus);
    oscillator.onended = () => { this.sources.delete(oscillator); oscillator.disconnect(); envelope.disconnect(); };
    oscillator.start(time);
    oscillator.stop(time + duration + 0.02);
  }

  private noise(time: number, duration: number, volume: number, bus: Bus, frequency: number): void {
    const ctx = this.context;
    const destination = bus === 'music' ? this.musicBus : this.effectsBus;
    if (!ctx || !this.noiseBuffer || !destination) return;
    const source = ctx.createBufferSource();
    source.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = frequency > 2000 ? 'highpass' : 'bandpass';
    filter.frequency.value = frequency;
    const envelope = ctx.createGain();
    envelope.gain.setValueAtTime(volume, time);
    envelope.gain.exponentialRampToValueAtTime(0.0001, time + duration);
    source.connect(filter);
    filter.connect(envelope);
    envelope.connect(destination);
    this.sources.set(source, bus);
    source.onended = () => { this.sources.delete(source); source.disconnect(); filter.disconnect(); envelope.disconnect(); };
    source.start(time);
    source.stop(time + duration + 0.01);
  }

  dispose(): void {
    this.disposed = true;
    this.musicWanted = false;
    this.stopMusic();
    for (const source of this.sources.keys()) { try { source.stop(); } catch { /* Already stopped. */ } }
    this.sources.clear();
    this.lastEffectAt.clear();
    void this.context?.close().catch(() => {});
    this.context = null;
  }
}
