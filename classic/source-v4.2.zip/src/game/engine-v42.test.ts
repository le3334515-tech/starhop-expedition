import { describe, expect, it } from 'vitest';
import { BOSS_MAX_HP, GameEngine, UPGRADES } from './engine';
import { EMPTY_INPUT, type Boss, type Enemy, type InputState, type WeaponId } from './types';

const keys = (patch: Partial<InputState> = {}): InputState => ({ ...EMPTY_INPUT, ...patch });
const enemy = (x: number, id = 70): Enemy => ({ id, kind: 'sentry', x, y: 406, w: 32, h: 42, vx: 0, vy: 0, hp: 10, maxHp: 10, facing: -1, timer: 0, hurt: 0, dead: false, originX: x, originY: 406, attackCooldown: 99 });
function arena(weapon: WeaponId = 'blade', seed = 42) {
  const game = new GameEngine(); game.start({ seed, weapon, modifier: 'standard' });
  const s = game.state;
  s.room.platforms = [{ x: 0, y: 448, w: s.room.width, h: 120, kind: 'ground' }];
  s.room.hazards = []; s.pickups = []; s.enemies = [enemy(1900)];
  Object.assign(s.hero, { x: 300, y: 412, grounded: true, facing: 1, critChance: 0, invincible: 0 });
  return game;
}
function advance(game: GameEngine, seconds: number) {
  for (let i = 0; i < Math.ceil(seconds * 120); i++) game.update(1 / 120, keys());
}

describe('v4.2 readable combat and recovery', () => {
  it('buffers a tapped attack during recovery and permits a jump out of a dash', () => {
    const game = arena(), h = game.state.hero;
    h.attackCooldown = .1;
    game.update(1 / 120, keys({ attackPressed: true }));
    expect(h.attackStep).toBe(0);
    advance(game, .12);
    expect(h.attackStep).toBe(1);
    game.update(1 / 120, keys({ dashPressed: true }));
    expect(h.dashTimer).toBeGreaterThan(0);
    game.update(1 / 120, keys({ jumpPressed: true, jumpHeld: true }));
    expect(h.dashTimer).toBe(0); expect(h.vy).toBeLessThan(-400);
    expect(h.invincible).toBeGreaterThan(0);
  });

  it('parries a frontal attack once and awards a counter, without spending health or a shield', () => {
    const game = arena(), s = game.state;
    s.enemies = [enemy(316)]; s.hero.shield = 1;
    game.update(1 / 120, keys({ guardPressed: true }));
    expect(s.hero.hp).toBe(5); expect(s.hero.shield).toBe(1);
    expect(s.hero.counterTimer).toBeGreaterThan(1);
    expect(s.hero.guardTimer).toBe(0); expect(s.hero.guardCooldown).toBeGreaterThan(.5);
    expect(s.resonance).toBe(16);
  });

  it('requires the player to face the attack and does not parry spike floors', () => {
    const back = arena(); back.state.enemies = [enemy(285)];
    back.update(1 / 120, keys({ guardPressed: true }));
    expect(back.state.hero.hp).toBe(4);
    const spikes = arena(); spikes.state.room.hazards = [{ x: 310, y: 430, w: 40, h: 18, kind: 'spikes' }];
    spikes.update(1 / 120, keys({ guardPressed: true }));
    expect(spikes.state.hero.hp).toBe(4);
  });

  it('lets the parry window expire instead of granting indefinite guard', () => {
    const game = arena();
    game.update(1 / 120, keys({ guardPressed: true })); advance(game, .28);
    game.state.enemies = [enemy(316)];
    game.update(1 / 120, keys());
    expect(game.state.hero.hp).toBe(4);
    expect(game.state.hero.counterTimer).toBe(0);
  });

  it('interrupts a Boss charge and damages its guard when contact is parried', () => {
    const game = arena(), s = game.state;
    s.room.isBoss = true; s.enemies = [];
    const boss: Boss = { x: 325, y: 330, w: 104, h: 118, hp: BOSS_MAX_HP, maxHp: BOSS_MAX_HP, phase: 1, mode: 'charge', timer: .5, vx: -420, vy: 0, facing: -1, hurt: 0, attackCount: 1, active: true, intent: 'charge', targetX: 300, chain: 0, guard: 30, maxGuard: 30, exposed: 0 };
    // The encounter bounds start at x=410, so meet the charge inside the arena.
    s.hero.x = 700; boss.x = 724; s.boss = boss;
    game.update(1 / 120, keys({ guardPressed: true }));
    expect(s.hero.hp).toBe(5); expect(boss.guard).toBe(20);
    expect(boss.mode).toBe('recover'); expect(boss.exposed).toBeGreaterThan(0);
  });

  it('heals after any upgrade, while vigor retains its larger recovery', () => {
    const game = arena(), s = game.state;
    s.hero.hp = 2; s.phase = 'upgrade'; s.upgradeChoices = [UPGRADES.find(u => u.id === 'edge')!];
    game.chooseUpgrade('edge'); expect(s.hero.hp).toBe(3);
    s.phase = 'upgrade'; s.upgradeChoices = [UPGRADES.find(u => u.id === 'vigor')!];
    game.chooseUpgrade('vigor'); expect(s.hero.maxHp).toBe(6); expect(s.hero.hp).toBe(5);
  });

  it('gives the staff a real area burst against clustered enemies', () => {
    const game = arena('ember'), s = game.state;
    s.enemies = [enemy(410, 70), enemy(450, 71)];
    game.update(1 / 120, keys({ attackPressed: true })); advance(game, .25);
    expect(s.enemies[0].hp).toBeLessThan(9);
    expect(s.enemies[1].hp).toBeLessThan(10);
    expect(s.projectiles.filter(p => p.kind === 'ember')).toHaveLength(0);
  });

  it('makes ordinary disc return hits stronger than outgoing hits', () => {
    const game = arena('disc');
    game.update(1 / 120, keys({ attackPressed: true }));
    const disc = game.state.projectiles[0]; const outward = disc.damage;
    advance(game, .65);
    expect(disc.returning).toBe(true); expect(disc.damage).toBeCloseTo(outward * 1.45);
  });

  it('retains random recovery drops for wounded players, reproducible by seed', () => {
    const found: number[] = [];
    for (let seed = 1; seed <= 60; seed++) {
      const game = arena('blade', seed), s = game.state;
      s.hero.hp = 2; const target = enemy(350); target.hp = .1;
      s.enemies = [target, enemy(1900, 71)];
      game.update(1 / 120, keys({ attackPressed: true }));
      if (s.pickups.some(p => p.kind === 'heart')) found.push(seed);
    }
    expect(found.length).toBeGreaterThan(8); expect(found.length).toBeLessThan(48);
  });
});
