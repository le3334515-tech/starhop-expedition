import { EXPEDITION_ROOM_COUNT, type Decoration, type Enemy, type Hazard, type Pickup, type Platform, type Room } from './types';
export { EXPEDITION_ROOM_COUNT } from './types';

/** Mulberry32. Seeds in challenge links always reproduce the same room layouts. */
export function seededRandom(seed: number): () => number {
  let value = seed >>> 0;
  return () => {
    value += 0x6d2b79f5;
    let n = Math.imul(value ^ (value >>> 15), 1 | value);
    n ^= n + Math.imul(n ^ (n >>> 7), 61 | n);
    return ((n ^ (n >>> 14)) >>> 0) / 4294967296;
  };
}

export interface RoomContents { room: Room; enemies: Enemy[]; pickups: Pickup[] }

/** Check the complete standing rectangle, including the actor's width and spike tips. */
export function isSafeFloorPoint(room: Pick<Room, 'platforms' | 'hazards'>, x: number, actorWidth = 28): boolean {
  return room.platforms.some(platform => platform.kind === 'ground' && x >= platform.x + 32 && x + actorWidth <= platform.x + platform.w - 32)
    && !room.hazards.some(hazard => hazard.kind === 'spikes' && x + actorWidth + 24 > hazard.x && x - 24 < hazard.x + hazard.w);
}

export const EXPEDITION_TITLES = [
  ['雾竹山门', 'MISTBAMBOO GATE'],
  ['朱灯旧街', 'VERMILION STREET'],
  ['回风栈道', 'WINDWARD WALKWAY'],
  ['沉钟地宫', 'SUNKEN BELL CRYPT'],
  ['琉璃水庭', 'GLAZED WATER COURT'],
  ['丹炉机坊', 'CINNABAR FOUNDRY'],
  ['天仪中枢', 'CELESTIAL ENGINE'],
  ['余烬神殿', 'EMBER SANCTUM'],
] as const;

type EnemySpec = [Enemy['kind'], number, number];
interface Route {
  platforms: Array<[number, number, number]>;
  gaps: Array<[number, number]>;
  spikes: Array<[number, number]>;
  springs: number[];
  enemies: EnemySpec[];
  heartX: number;
}

// Each route is authored as a complete, safe layout. Seed selection changes the
// route itself, rather than scattering hazards and enemies at arbitrary offsets.
const ROUTES: Route[][] = [
  [
    { platforms: [[290, 348, 152], [560, 276, 156], [960, 348, 176], [1290, 308, 176], [1640, 344, 156], [1870, 268, 140]],
      gaps: [], spikes: [], springs: [], heartX: 1570,
      enemies: [['slime', 520, 420], ['slime', 1010, 420], ['bat', 1370, 310], ['sentry', 1800, 406]] },
    { platforms: [[260, 360, 160], [480, 286, 144], [720, 240, 180], [1040, 304, 180], [1450, 352, 164], [1720, 280, 164], [1990, 340, 144]],
      gaps: [], spikes: [], springs: [1290], heartX: 1620,
      enemies: [['slime', 490, 420], ['bat', 980, 306], ['sentry', 1410, 406], ['slime', 1920, 420]] },
    { platforms: [[330, 322, 220], [730, 366, 128], [1000, 288, 220], [1400, 356, 176], [1680, 280, 200], [1990, 348, 130]],
      gaps: [], spikes: [], springs: [620], heartX: 1350,
      enemies: [['slime', 650, 420], ['sentry', 1030, 406], ['bat', 1540, 298], ['slime', 1920, 420]] },
  ],
  [
    { platforms: [[290, 348, 152], [560, 276, 156], [960, 348, 240], [1290, 308, 176], [1640, 344, 156], [1870, 268, 140]],
      gaps: [[1040, 1160]], spikes: [[1480, 56]], springs: [730], heartX: 1570,
      enemies: [['slime', 470, 420], ['bat', 790, 298], ['slime', 1270, 420], ['sentry', 1660, 406], ['bat', 1990, 318]] },
    { platforms: [[300, 352, 180], [540, 284, 150], [700, 340, 230], [1030, 260, 190], [1360, 336, 170], [1610, 340, 250], [2020, 284, 170]],
      gaps: [[760, 872], [1680, 1790]], spikes: [[1120, 70]], springs: [1430], heartX: 1920,
      enemies: [['bat', 480, 306], ['slime', 1030, 420], ['sentry', 1350, 406], ['slime', 1950, 420], ['bat', 2140, 304]] },
    { platforms: [[320, 340, 190], [670, 280, 180], [970, 352, 160], [1240, 340, 280], [1640, 264, 180], [1870, 344, 200]],
      gaps: [[1340, 1460]], spikes: [[920, 56], [1930, 56]], springs: [1130], heartX: 1580,
      enemies: [['slime', 480, 420], ['sentry', 790, 406], ['bat', 1170, 298], ['slime', 1710, 420], ['bat', 2080, 314]] },
  ],
  [
    { platforms: [[290, 348, 152], [560, 276, 156], [750, 344, 240], [1100, 280, 190], [1420, 348, 180], [1680, 336, 240], [2070, 276, 180]],
      gaps: [[820, 932], [1760, 1860]], spikes: [[1480, 84]], springs: [650], heartX: 1990,
      enemies: [['sentry', 480, 406], ['slime', 690, 420], ['bat', 1100, 294], ['sentry', 1350, 406], ['slime', 1640, 420], ['bat', 2160, 310]] },
    { platforms: [[300, 356, 180], [590, 284, 180], [950, 340, 280], [1320, 268, 180], [1620, 344, 160], [1920, 332, 280], [2240, 280, 150]],
      gaps: [[1040, 1160], [2020, 2120]], spikes: [[1360, 70], [1770, 56]], springs: [740], heartX: 1880,
      enemies: [['sentry', 450, 406], ['slime', 800, 420], ['bat', 1220, 302], ['sentry', 1510, 406], ['slime', 1850, 420], ['bat', 2270, 306]] },
    { platforms: [[290, 340, 160], [580, 344, 240], [950, 268, 190], [1290, 348, 180], [1400, 332, 240], [1780, 268, 190], [2120, 348, 160]],
      gaps: [[660, 772], [1450, 1562]], spikes: [[1070, 56], [1910, 70]], springs: [900, 1700], heartX: 1650,
      enemies: [['sentry', 450, 406], ['slime', 950, 420], ['bat', 1250, 294], ['sentry', 1740, 406], ['slime', 2080, 420], ['bat', 2260, 310]] },
  ],
  // The crypt alternates broad bell plinths and low passages with a safe floor route.
  [
    { platforms: [[250, 360, 240], [620, 284, 210], [940, 352, 210], [1260, 276, 200], [1570, 352, 240], [1930, 284, 210]],
      gaps: [[1030, 1140]], spikes: [[1490, 56]], springs: [510], heartX: 1850,
      enemies: [['sentry', 420, 406], ['bat', 840, 282], ['slime', 1230, 420], ['sentry', 1680, 406], ['bat', 2070, 310]] },
    { platforms: [[300, 344, 250], [650, 268, 170], [920, 340, 300], [1330, 264, 190], [1620, 344, 210], [1970, 292, 180]],
      gaps: [], spikes: [[580, 56], [1550, 56]], springs: [1240], heartX: 1870,
      enemies: [['slime', 380, 420], ['sentry', 810, 406], ['bat', 1160, 282], ['sentry', 1770, 406], ['bat', 2110, 304]] },
    { platforms: [[270, 356, 170], [510, 288, 230], [880, 350, 240], [1250, 276, 230], [1590, 352, 160], [1880, 284, 230]],
      gaps: [[950, 1060]], spikes: [[1360, 70]], springs: [770], heartX: 1790,
      enemies: [['sentry', 460, 406], ['bat', 850, 308], ['slime', 1160, 420], ['sentry', 1680, 406], ['bat', 2030, 296]] },
  ],
  // The water court uses paired stepping islands and long upper bridges.
  [
    { platforms: [[260, 360, 190], [570, 292, 200], [830, 344, 300], [1280, 280, 210], [1610, 348, 300], [2020, 284, 180]],
      gaps: [[910, 1020], [1720, 1830]], spikes: [], springs: [470, 1510], heartX: 1940,
      enemies: [['slime', 430, 420], ['bat', 790, 296], ['sentry', 1330, 406], ['slime', 1990, 420]] },
    { platforms: [[290, 344, 210], [600, 272, 190], [920, 348, 310], [1330, 276, 200], [1660, 348, 280], [2070, 284, 150]],
      gaps: [[1030, 1150], [1780, 1890]], spikes: [], springs: [1550], heartX: 1960,
      enemies: [['bat', 450, 294], ['slime', 820, 420], ['sentry', 1360, 406], ['slime', 2030, 420]] },
    { platforms: [[280, 356, 160], [540, 284, 240], [870, 344, 300], [1300, 272, 170], [1610, 344, 290], [2020, 280, 190]],
      gaps: [[980, 1090], [1730, 1840]], spikes: [], springs: [700, 1500], heartX: 1920,
      enemies: [['slime', 470, 420], ['bat', 820, 304], ['sentry', 1380, 406], ['bat', 2010, 308]] },
  ],
  // The foundry offers elevated gantries above short furnace vents.
  [
    { platforms: [[260, 344, 240], [600, 264, 200], [900, 348, 240], [1240, 280, 240], [1590, 352, 220], [1930, 280, 180]],
      gaps: [[1010, 1120]], spikes: [[1450, 70], [1840, 56]], springs: [810], heartX: 2170,
      enemies: [['sentry', 430, 406], ['slime', 690, 420], ['bat', 1180, 286], ['sentry', 1680, 406], ['slime', 2030, 420]] },
    { platforms: [[310, 352, 180], [610, 276, 240], [940, 344, 260], [1320, 264, 210], [1660, 340, 220], [1980, 284, 220]],
      gaps: [], spikes: [[540, 56], [1230, 70], [1890, 56]], springs: [1570], heartX: 2120,
      enemies: [['sentry', 420, 406], ['bat', 820, 294], ['slime', 1040, 420], ['sentry', 1710, 406], ['bat', 2130, 300]] },
    { platforms: [[280, 352, 220], [640, 280, 180], [920, 344, 280], [1330, 272, 210], [1640, 352, 200], [1930, 284, 230]],
      gaps: [[1010, 1120]], spikes: [[560, 70], [1520, 56]], springs: [1240], heartX: 2180,
      enemies: [['slime', 400, 420], ['sentry', 740, 406], ['bat', 1190, 302], ['sentry', 1730, 406], ['bat', 2120, 306]] },
  ],
  // The celestial engine stacks orbiting terraces above a split, readable ground route.
  [
    { platforms: [[260, 352, 180], [510, 280, 210], [790, 216, 190], [1050, 344, 290], [1450, 268, 210], [1770, 344, 260], [2130, 280, 140]],
      gaps: [[1170, 1290], [1870, 1980]], spikes: [[1490, 56]], springs: [980], heartX: 2080,
      enemies: [['sentry', 450, 406], ['bat', 830, 256], ['slime', 1080, 420], ['sentry', 1680, 406], ['bat', 2130, 294]] },
    { platforms: [[280, 344, 210], [590, 272, 180], [850, 208, 180], [1110, 344, 300], [1500, 272, 210], [1820, 344, 270], [2170, 280, 150]],
      gaps: [[1220, 1330]], spikes: [[1740, 56]], springs: [1020], heartX: 2110,
      enemies: [['bat', 470, 294], ['sentry', 780, 406], ['slime', 1120, 420], ['sentry', 1590, 406], ['bat', 2160, 290]] },
    { platforms: [[270, 352, 180], [530, 280, 220], [820, 216, 180], [1100, 348, 280], [1480, 272, 210], [1810, 340, 280], [2180, 280, 140]],
      gaps: [[1200, 1310], [1920, 2030]], spikes: [[1530, 56]], springs: [1020], heartX: 2110,
      enemies: [['sentry', 440, 406], ['bat', 790, 286], ['slime', 1110, 420], ['sentry', 1740, 406], ['bat', 2180, 298]] },
  ],
];

const BOSS_PLATFORMS: Array<Array<[number, number, number]>> = [
  [[430, 340, 156], [900, 340, 156], [1260, 340, 140]],
  [[540, 348, 180], [860, 296, 156], [1190, 348, 180]],
  [[450, 324, 180], [780, 356, 180], [1120, 304, 200]],
];

export function createRoom(seed: number, index: number): RoomContents {
  const random = seededRandom((seed ^ Math.imul(index + 1, 0x9e3779b1)) >>> 0);
  if (!Number.isInteger(index) || index < 0 || index >= EXPEDITION_ROOM_COUNT) throw new RangeError('Unknown expedition room');
  const bossRoom = index === EXPEDITION_ROOM_COUNT - 1;
  const width = [2250, 2370, 2490, 2300, 2400, 2340, 2400, 1660][index];
  const platforms: Platform[] = [];
  const hazards: Hazard[] = [];
  const decorations: Decoration[] = [];
  const enemies: Enemy[] = [];
  const pickups: Pickup[] = [];
  const theme = index;
  const variant = Math.floor(random() * 3);
  const route = bossRoom ? null : ROUTES[index][variant];
  const gaps = route?.gaps ?? [];
  let groundStart = 0;
  for (const [a, b] of gaps) {
    platforms.push({ x: groundStart, y: 448, w: a - groundStart, h: 120, kind: 'ground' });
    hazards.push({ x: a, y: 520, w: b - a, h: 50, kind: 'lava' });
    groundStart = b;
  }
  platforms.push({ x: groundStart, y: 448, w: width - groundStart, h: 120, kind: 'ground' });

  if (bossRoom) {
    for (const [x, y, w] of BOSS_PLATFORMS[variant]) platforms.push({ x, y, w, h: 22, kind: 'stone', oneWay: true });
    decorations.push({ x: 1260, y: 448, kind: 'ruin', scale: 2 }, { x: 780, y: 448, kind: 'crystal', scale: 1.8 });
  } else {
    route!.platforms.forEach(([x, y, w], n) => platforms.push({ x, y, w, h: 24, kind: n % 3 === 0 ? 'wood' : 'stone', oneWay: true }));
    // Optional upper paths sit above an existing landing, never across the only
    // route to the exit. A seed changes their side as well as the main route.
    const highAnchor = [...route!.platforms].sort((a, b) => a[1] - b[1])[0];
    const shelfY = Math.max(168, highAnchor[1] - 76);
    const shelfX = highAnchor[0] + (variant === 1 ? -54 : 58);
    const shelfWidth = [156, 184, 140, 176, 160, 192, 152][index];
    platforms.push({ x: shelfX, y: shelfY, w: shelfWidth, h: 20, kind: index % 2 ? 'wood' : 'stone', oneWay: true });
    platforms.push({ x: shelfX + shelfWidth + 48, y: shelfY + 40, w: 104, h: 20, kind: 'stone', oneWay: true });
    decorations.push({ x: shelfX + 22, y: shelfY, kind: 'crystal', scale: .55 });
    for (const x of route!.springs) platforms.push({ x, y: 424, w: 48, h: 24, kind: 'spring' });
    for (const [x, w] of route!.spikes) hazards.push({ x, y: 430, w, h: 18, kind: 'spikes' });
    route!.enemies.forEach(([kind, x, y], n) => {
      const offset = Math.round(random() * 24 - 12);
      const candidate = x + offset;
      const safeGround = kind === 'bat' || platforms.some(p => p.kind === 'ground' && candidate >= p.x + 50 && candidate + 32 <= p.x + p.w - 50);
      // Use the authored location when jitter approaches a ledge, then search
      // locally if a future authored route puts that location inside a hazard.
      let position = safeGround ? candidate : x;
      if (kind !== 'bat' && !isSafeFloorPoint({ platforms, hazards }, position, 32)) {
        const nearby = Array.from({ length: 25 }, (_, n) => x + (n % 2 ? 1 : -1) * Math.ceil(n / 2) * 16);
        position = nearby.find(point => isSafeFloorPoint({ platforms, hazards }, point, 32)) ?? x;
      }
      const hp = kind === 'sentry' ? 3 : 2;
      enemies.push({ id: index * 100 + n + 1, kind, x: position, y, w: kind === 'bat' ? 30 : 32, h: kind === 'sentry' ? 42 : 28,
        vx: 0, vy: 0, hp, maxHp: hp, facing: -1, timer: random() * 2, hurt: 0, dead: false,
        originX: position, originY: y, attackCooldown: 1 + random() });
    });
  }

  let pickupId = index * 1000;
  const addCoin = (x: number, y: number) => pickups.push({ id: ++pickupId, x, y, w: 13, h: 16, kind: 'coin', value: 1, vy: 0, bob: random() * 6.28, collected: false });
  if (!bossRoom) {
    for (let x = 220; x < width - 180; x += 100) {
      if (!gaps.some(([a, b]) => x > a - 12 && x < b + 12) && !route!.spikes.some(([a, w]) => x > a - 10 && x < a + w + 10)) addCoin(x, 404);
    }
    for (const platform of platforms.filter(p => p.oneWay)) {
      for (let x = platform.x + 24; x < platform.x + platform.w - 12; x += 36) addCoin(x, platform.y - 38);
    }
    pickups.push({ id: ++pickupId, x: route!.heartX, y: 395, w: 18, h: 18, kind: 'heart', value: 1, vy: 0, bob: 1, collected: false });
    const rewardShelf = platforms.find(platform => platform.oneWay && platform.y < 250)!;
    // Exploration now earns a second healing pickup, including on a clean run:
    // full-health hearts remain in the map for the return trip.
    pickups.push({ id: ++pickupId, x: rewardShelf.x + rewardShelf.w - 38, y: rewardShelf.y - 27, w: 18, h: 18, kind: 'heart', value: 1, vy: 0, bob: 2.4, collected: false });
  }
  for (let x = 100; x < width - 80; x += 130 + Math.floor(random() * 90)) {
    if (gaps.some(([a, b]) => x > a - 20 && x < b + 20)) continue;
    const kinds: Decoration['kind'][] = [['tree', 'grass', 'lamp'], ['ruin', 'lamp', 'lamp', 'tree'], ['tree', 'ruin', 'grass'], ['ruin', 'crystal', 'lamp'], ['tree', 'crystal', 'grass'], ['ruin', 'lamp', 'crystal'], ['ruin', 'crystal', 'lamp'], ['ruin', 'lamp', 'crystal']][theme] as Decoration['kind'][];
    decorations.push({ x, y: 448, kind: kinds[Math.floor(random() * kinds.length)], scale: .7 + random() * .6 });
  }
  const room: Room = {
    index, name: EXPEDITION_TITLES[index][0], subtitle: `${EXPEDITION_TITLES[index][1]} · ROUTE ${'ABC'[variant]}`, width, height: 640, theme,
    platforms, hazards, decorations, spawn: { x: 100, y: 410 },
    exit: { x: width - 116, y: 352, w: 64, h: 96 }, checkpoint: { x: 100, y: 410 }, isBoss: bossRoom,
  };
  return { room, enemies, pickups };
}
