import type { Boss, Decoration, Enemy, GameState, Hero, Impact, Pickup, Platform, Projectile, Room } from './types';
import { drawArtBackground, drawArtPlatform, drawArtDecoration } from './environment-art';
import { drawArtHero, drawArtEnemy, drawArtBoss } from './actor-art';
import { drawArtImpact, drawArtSlash } from './effect-art';

const W = 960;
const H = 540;
const TAU = Math.PI * 2;
const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));
const hash = (x: number, y = 0) => {
  let n = Math.imul(x + 1, 374761393) + Math.imul(y + 1, 668265263);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
};

type Palette = { sky: string[]; moon: string; far: string; middle: string; near: string; stone: string; edge: string; moss: string; glow: string };
const PALETTES: Palette[] = [
  { sky: ['#101c21', '#29454a', '#6b8c83'], moon: '#e8e0bf', far: '#334d50', middle: '#2b4c49', near: '#183b37', stone: '#29423e', edge: '#596c5b', moss: '#91a98a', glow: '#9ce4c1' },
  { sky: ['#201b25', '#47333b', '#886457'], moon: '#e8ca9b', far: '#44373e', middle: '#4e3b40', near: '#332c32', stone: '#493c3b', edge: '#85745e', moss: '#c4a478', glow: '#ffc789' },
  { sky: ['#19252d', '#3b5962', '#90a49d'], moon: '#eee5c9', far: '#49606a', middle: '#3d5960', near: '#293e46', stone: '#36494b', edge: '#7e8c7c', moss: '#a4b69c', glow: '#c4e3cd' },
  { sky: ['#111c25', '#253c47', '#526461'], moon: '#b8c5b3', far: '#293d49', middle: '#2d454d', near: '#1e343d', stone: '#2c4247', edge: '#5e7271', moss: '#9ba997', glow: '#b6d9bc' },
  { sky: ['#142b32', '#35656b', '#9fb7a3'], moon: '#f1e6c4', far: '#477a7b', middle: '#3b6a69', near: '#254d4c', stone: '#355854', edge: '#728e78', moss: '#bfd1a1', glow: '#c0f0d1' },
  { sky: ['#241d21', '#543733', '#967251'], moon: '#efd3a2', far: '#594540', middle: '#624b40', near: '#3d3431', stone: '#4d4540', edge: '#8d795c', moss: '#c19b6a', glow: '#ffc482' },
  { sky: ['#15212c', '#2a4253', '#657f82'], moon: '#e8ddba', far: '#354c5c', middle: '#365763', near: '#243e49', stone: '#344951', edge: '#748b89', moss: '#b7bca0', glow: '#c8eee3' },
  { sky: ['#271c24', '#51353c', '#97715b'], moon: '#f3d1a0', far: '#503a42', middle: '#594044', near: '#362a31', stone: '#4a3a3d', edge: '#93765e', moss: '#c4a276', glow: '#ffd2a0' },
];

/** Credited sprite artwork and original combat overlays; never changes simulation state. */
export class GameRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private skies: HTMLCanvasElement[] = [];
  private tiles = new Map<string, HTMLCanvasElement>();
  private time = 0;
  private palette = PALETTES[0];
  private awakeningStrength = 0;
  private previousFrame = 0;
  private viewportX = 0;
  private theme = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('当前浏览器无法创建游戏画面。');
    this.ctx = ctx;
    this.resize();
    this.makeSkies();
  }

  resize() {
    if (this.canvas.width !== W) this.canvas.width = W;
    if (this.canvas.height !== H) this.canvas.height = H;
    this.ctx.imageSmoothingEnabled = false;
  }

  render(state: GameState, now: number) {
    this.time = now;
    this.theme = clamp(state.room.theme, 0, 7);
    this.palette = PALETTES[this.theme] || PALETTES[0];
    const c = this.ctx;
    c.save();
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.globalAlpha = 1;
    if (state.phase === 'menu') {
      this.viewportX = 0;
      this.awakeningStrength = 0;
      this.previousFrame = now;
      this.menuScene(state, now);
      c.restore();
      return;
    }
    const camera = Math.round(state.cameraX || 0);
    this.viewportX = camera;
    this.background(camera, state.room.theme, now, state.room.isBoss);
    const elapsed = this.previousFrame ? clamp(now - this.previousFrame, 0, .1) : 1 / 60;
    this.previousFrame = now;
    const awakeningTarget = clamp(state.overdrive / 1.15, 0, 1);
    this.awakeningStrength += (awakeningTarget - this.awakeningStrength) * Math.min(1, elapsed * 7);
    const awakening = this.awakeningStrength;
    if (awakening > 0) this.awakeningBackdrop(camera, now, awakening);
    const shake = Math.min(6, Math.max(0, state.shake));
    c.translate(Math.round(Math.sin(now * 87) * shake), Math.round(Math.cos(now * 91) * shake * .6));
    c.save();
    c.translate(-camera, 0);
    this.worldDecor(state.room.decorations, camera, 'back');
    this.routeMarkers(state.room, camera, now);
    this.portal(state.room.exit, state.roomCleared && !state.room.isBoss, now, state.room.isBoss);
    for (const platform of state.room.platforms) {
      if (platform.x + platform.w >= camera - 40 && platform.x <= camera + W + 40) this.platform(platform, state.room.theme);
    }
    for (const hazard of state.room.hazards) {
      if (hazard.x + hazard.w < camera || hazard.x > camera + W) continue;
      if (hazard.kind === 'spikes') this.spikes(hazard.x, hazard.y, hazard.w, hazard.h);
      else this.lava(hazard.x, hazard.y, hazard.w, hazard.h, now);
    }
    for (const p of state.pickups) if (!p.collected && p.x > camera - 30 && p.x < camera + W + 30) this.pickup(p, now);
    for (const enemy of state.enemies) if (!enemy.dead && enemy.x > camera - 100 && enemy.x < camera + W + 100) this.enemy(enemy, now);
    if (state.boss) {
      if (state.boss.mode === 'dead') drawArtBoss(c, state.boss, now);
      else this.boss(state.boss, state.hero, now, state.room.width);
    }
    if (state.hero.guardTimer > 0) this.guardArc(state.hero);
    this.hero(state.hero, now, 1, state.overdrive > 0);
    for (const projectile of state.projectiles) this.projectile(projectile, now);
    for (const impact of state.impacts) this.impact(impact);
    this.worldDecor(state.room.decorations, camera, 'front');
    for (const particle of state.particles) {
      c.globalAlpha = clamp(particle.life / particle.maxLife, 0, 1);
      c.fillStyle = particle.color;
      const size = Math.max(1, Math.round(particle.size));
      c.fillRect(Math.round(particle.x), Math.round(particle.y), size, size);
    }
    c.globalAlpha = 1;
    for (const text of state.floatingTexts) {
      c.save();
      c.globalAlpha = clamp(text.life / Math.min(.4, text.maxLife), 0, 1);
      const emphatic = /暴击|破甲|终结|反击|精准/.test(text.text);
      const age = text.maxLife - text.life;
      const pop = age < .11 ? 1 + (.11 - age) * (emphatic ? 2.6 : 1.4) : 1;
      c.translate(Math.round(text.x), Math.round(text.y));
      c.scale(pop, pop);
      c.font = `bold ${emphatic ? 18 : 14}px "Microsoft YaHei", sans-serif`;
      c.textAlign = 'center';
      c.lineWidth = 4;
      c.strokeStyle = '#10242d';
      c.strokeText(text.text, 0, 0);
      c.fillStyle = text.color;
      c.fillText(text.text, 0, 0);
      c.restore();
    }
    c.restore();
    this.ambient(camera, now, state.room.theme);
    if (state.flash > 0) {
      c.fillStyle = `rgba(255,139,113,${Math.min(.18, state.flash * .45)})`;
      c.fillRect(0, 0, W, H);
    }
    if (state.transition > 0) {
      c.fillStyle = `rgba(10,24,31,${Math.min(.7, state.transition * .9)})`;
      c.fillRect(0, 0, W, H);
    }
    // Very light bottom vignette gives the ground a storybook silhouette.
    const vignette = c.createLinearGradient(0, 485, 0, H);
    vignette.addColorStop(0, '#071d2400');
    vignette.addColorStop(1, '#07131c88');
    c.fillStyle = vignette;
    c.fillRect(0, 480, W, 60);
    c.restore();
  }

  private makeSkies() {
    this.skies = PALETTES.map((palette) => {
      const canvas = document.createElement('canvas');
      canvas.width = W;
      canvas.height = H;
      const c = canvas.getContext('2d')!;
      const g = c.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, palette.sky[0]);
      g.addColorStop(.64, palette.sky[1]);
      g.addColorStop(1, palette.sky[2]);
      c.fillStyle = g;
      c.fillRect(0, 0, W, H);
      // Sparse, stable grain breaks up the large sky without visual noise.
      for (let i = 0; i < 1300; i++) {
        c.fillStyle = `rgba(163,211,196,${.015 + hash(i, 32) * .023})`;
        c.fillRect(Math.floor(hash(i, 13) * W), Math.floor(hash(i, 7) * H), 1, 1);
      }
      return canvas;
    });
  }

  private background(camera: number, theme: number, now: number, bossRoom = false) {
    const c = this.ctx, p = this.palette;
    if (drawArtBackground(c, camera, theme, now)) return;
    c.drawImage(this.skies[clamp(theme, 0, 7)], 0, 0);
    const subterranean = theme === 3 || theme === 5;
    if (!subterranean) {
      this.moon(754 - camera * .014, 103, theme === 7 ? 47 : 36, now);
      for (let i = 0; i < 22; i++) {
        const x = ((hash(i, 1) * 1180 - camera * .025) % 1180 + 1180) % 1180 - 80;
        c.globalAlpha = .12 + hash(i, 3) * .2; c.fillStyle = p.moon;
        c.fillRect(x, 24 + hash(i, 2) * 160, 1, 1);
      }
      c.globalAlpha = 1;
    }
    // Long, quiet mountain silhouettes and a veil of fog keep the combat plane crisp.
    for (let layer = 0; layer < 3; layer++) {
      this.inkMountains(camera * (.045 + layer * .065), 292 + layer * 42, [p.far, p.middle, p.near][layer], layer);
    }
    c.save(); c.globalAlpha = .64;
    if (theme === 0) {
      for (let i = -1; i < 12; i++) this.bamboo(i * 121 - camera * .22 % 121, 448, .75 + hash(i, 42) * .8, p.near, .7);
      this.pavilion(627 - camera * .12, 350, 1.16, p.middle, p.edge, false);
      this.gate(215 - camera * .2, 421, .92, false);
    } else if (theme === 1) {
      for (let i = -1; i < 6; i++) {
        const x = i * 245 - camera * .17 % 245;
        this.pavilion(x, 406 - i % 2 * 26, .95 + hash(i, 5) * .3, p.near, p.edge, true);
        this.lantern(x + 90, 251 + i % 2 * 26, .8, now, true);
      }
      c.strokeStyle = '#b9a07950'; c.lineWidth = 1;
      c.beginPath(); c.moveTo(-20, 215); c.quadraticCurveTo(440, 290, 980, 210); c.stroke();
      for (let i = 0; i < 8; i++) this.lantern(i * 147 - camera * .09 % 147, 234 + Math.sin(i * .6) * 19, .5, now, true);
    } else if (theme === 2) {
      for (let i = -1; i < 5; i++) {
        const x = i * 370 - camera * .21 % 370;
        c.fillStyle = p.near; c.beginPath(); c.moveTo(x, 540); c.lineTo(x + 18, 300); c.lineTo(x + 54, 222); c.lineTo(x + 94, 271); c.lineTo(x + 130, 540); c.fill();
        c.strokeStyle = '#c6c8ad77'; c.lineWidth = 2;
        c.beginPath(); c.moveTo(x + 45, 260); c.quadraticCurveTo(x + 240, 380, x + 421, 260); c.stroke();
        c.strokeStyle = '#6f7564'; c.lineWidth = 5;
        c.beginPath(); c.moveTo(x + 45, 303); c.quadraticCurveTo(x + 240, 396, x + 421, 303); c.stroke();
        for (let j = 0; j < 12; j++) { const t = j / 12; const dy = Math.sin(t * Math.PI) * 42; c.lineWidth = 1; c.beginPath(); c.moveTo(x + 48 + t * 370, 271 + dy); c.lineTo(x + 48 + t * 370, 309 + dy); c.stroke(); }
      }
    } else if (theme === 3) {
      c.fillStyle = '#101f2c'; c.fillRect(0, 0, W, 58);
      for (let i = -1; i < 7; i++) {
        const x = i * 197 - camera * .14 % 197;
        c.fillStyle = p.near; c.fillRect(x, 40, 38, 410);
        c.fillStyle = p.edge; c.globalAlpha = .3; c.fillRect(x + 3, 42, 3, 390); c.globalAlpha = .64;
        this.rune(x + 19, 182, 15, '#adba9a', .3);
      }
      this.bell(648 - camera * .12, 180, 1.85, now);
      this.bell(170 - camera * .2, 140, .83, now);
      for (let i = 0; i < 5; i++) this.talisman(i * 221 - camera * .18 % 221, 86, .85, now);
    } else if (theme === 4) {
      c.fillStyle = '#478c8d40'; c.fillRect(0, 381, W, 78);
      for (let i = 0; i < 28; i++) {
        const x = ((i * 83 - camera * .18) % 1040 + 1040) % 1040;
        c.fillStyle = i % 3 ? '#c0d5b62a' : '#d2d7ac51'; c.fillRect(x, 388 + i % 6 * 11, 18 + hash(i, 88) * 58, 1);
      }
      this.pavilion(685 - camera * .14, 383, 1.2, p.near, '#a3ad87', false);
      for (let i = -1; i < 9; i++) this.lotus(i * 153 - camera * .24 % 153, 410 + i % 2 * 12, .8 + hash(i, 4), now);
      for (let i = -1; i < 6; i++) this.bamboo(i * 283 - camera * .27 % 283, 448, .8, p.near, .7);
    } else if (theme === 5) {
      for (let i = -1; i < 5; i++) {
        const x = i * 314 - camera * .18 % 314;
        this.furnace(x + 62, 411, .9 + hash(i, 4) * .35, now);
        this.pipe(x + 144, 172, 145, 216, p.edge);
        c.fillStyle = '#b88b6244'; c.fillRect(x + 140, 145, 150, 8);
        this.talisman(x + 153, 156, .75, now);
      }
    } else if (theme === 6) {
      this.celestial(685 - camera * .09, 210, 132, now, .65);
      this.celestial(147 - camera * .17, 268, 70, -now, .28);
      for (let i = -1; i < 6; i++) {
        const x = i * 226 - camera * .23 % 226;
        c.fillStyle = p.near; c.fillRect(x, 275, 31, 180); c.fillRect(x - 12, 271, 55, 9);
        this.rune(x + 15, 310, 13, '#c4d1b2', .4);
        c.strokeStyle = '#d0b87966'; c.lineWidth = 1; c.beginPath(); c.moveTo(x + 15, 170); c.lineTo(x + 15, 270); c.stroke();
      }
    } else {
      this.pavilion(575 - camera * .10, 430, 2.1, p.near, '#aa9271', true);
      this.gate(800 - camera * .19, 443, 1.35, true);
      this.celestial(635 - camera * .10, 208, 105, now * .32, .21);
      for (let i = -1; i < 8; i++) this.lantern(i * 172 - camera * .25 % 172, 287, .75, now, true);
    }
    c.restore();
    // Horizontal washes suggest painted mist rather than large luminous game effects.
    for (let i = 0; i < 3; i++) {
      const y = 285 + i * 61;
      const fog = c.createLinearGradient(0, y - 24, 0, y + 40);
      fog.addColorStop(0, '#cbd8c000'); fog.addColorStop(.5, theme === 5 || theme === 7 ? '#e5c49c0a' : '#d9e2c712'); fog.addColorStop(1, '#d1dbc000');
      c.fillStyle = fog; c.fillRect(0, y - 24, W, 64);
    }
    if (bossRoom) { c.save(); c.globalAlpha = .12; this.rune(550 - camera * .07, 189, 85, '#f2d9a3', 1); c.restore(); }
  }

  private inkMountains(offset: number, base: number, color: string, layer: number) {
    const c = this.ctx; c.fillStyle = color; c.beginPath(); c.moveTo(-110, H);
    for (let i = -2; i < 12; i++) {
      const x = i * 133 - offset % 133, h = 55 + hash(i + Math.floor(offset / 133), 21 + layer) * 120;
      c.lineTo(x - 35, base); c.bezierCurveTo(x - 12, base - h * .45, x + 2, base - h, x + 29, base - h);
      c.bezierCurveTo(x + 47, base - h * 1.06, x + 51, base - h * .6, x + 63, base - h * .64); c.lineTo(x + 108, base);
    }
    c.lineTo(W + 110, H); c.closePath(); c.fill();
  }

  private roof(x: number, y: number, half: number, rise: number, color: string, trim: string) {
    const c = this.ctx; c.fillStyle = color; c.beginPath();
    c.moveTo(x - half - 13, y - 8); c.quadraticCurveTo(x - half * .72, y + 6, x, y - rise);
    c.quadraticCurveTo(x + half * .72, y + 6, x + half + 13, y - 8); c.lineTo(x + half + 2, y + 6);
    c.quadraticCurveTo(x, y - rise + 17, x - half - 2, y + 6); c.closePath(); c.fill();
    c.strokeStyle = trim; c.lineWidth = 2; c.beginPath(); c.moveTo(x - half - 12, y - 8); c.quadraticCurveTo(x - half * .66, y + 8, x, y - rise); c.quadraticCurveTo(x + half * .66, y + 8, x + half + 12, y - 8); c.stroke();
    c.fillStyle = trim; c.fillRect(x - 2, y - rise - 9, 4, 11);
  }

  private pavilion(x: number, ground: number, scale: number, body: string, trim: string, lit: boolean) {
    const c = this.ctx; c.save(); c.translate(x, ground); c.scale(scale, scale);
    c.fillStyle = body; c.fillRect(-89, -113, 178, 113); c.fillRect(-100, -5, 200, 6);
    c.strokeStyle = trim; c.lineWidth = 3;
    for (const px of [-75, -29, 29, 75]) { c.beginPath(); c.moveTo(px, -109); c.lineTo(px, -2); c.stroke(); }
    for (let i = -2; i <= 2; i++) {
      c.fillStyle = lit ? '#db9e5c33' : '#9eb6a51c'; c.fillRect(i * 32 - 9, -80, 18, 46);
      c.strokeStyle = trim; c.lineWidth = .8; c.strokeRect(i * 32 - 9, -80, 18, 46); c.beginPath(); c.moveTo(i * 32, -80); c.lineTo(i * 32, -34); c.moveTo(i * 32 - 9, -57); c.lineTo(i * 32 + 9, -57); c.stroke();
    }
    this.roof(0, -117, 103, 42, body, trim); this.roof(0, -171, 63, 30, body, trim);
    c.fillStyle = body; c.fillRect(-46, -169, 92, 32); c.fillStyle = trim; c.fillRect(-40, -158, 80, 2);
    c.restore();
  }

  private gate(x: number, ground: number, scale: number, red: boolean) {
    const c = this.ctx; c.save(); c.translate(x, ground); c.scale(scale, scale);
    const body = red ? '#63423e' : '#3e5c52', trim = red ? '#b79870' : '#8aa282';
    c.fillStyle = '#162d2c'; c.fillRect(-69, -161, 16, 164); c.fillRect(55, -161, 16, 164);
    c.fillStyle = body; c.fillRect(-65, -159, 10, 157); c.fillRect(57, -159, 10, 157); c.fillRect(-72, -151, 144, 9);
    this.roof(0, -164, 83, 28, '#243e3b', trim);
    c.fillStyle = trim; c.fillRect(-64, -141, 3, 130); c.fillRect(58, -141, 3, 130); c.fillRect(-35, -161, 70, 21);
    c.fillStyle = body; c.fillRect(-31, -158, 62, 15); this.rune(0, -149, 7, '#e5d6a5', .8);
    this.lantern(-55, -129, .65, this.time, true); this.lantern(58, -129, .65, this.time, true);
    c.restore();
  }

  private bamboo(x: number, ground: number, scale: number, color = '#254c43', alpha = 1) {
    const c = this.ctx; c.save(); c.globalAlpha *= alpha; c.translate(x, ground); c.scale(scale, scale);
    for (let stem = 0; stem < 3; stem++) {
      const sx = stem * 18 - 18, lean = stem % 2 ? 12 : -9, height = 205 - stem * 24;
      c.strokeStyle = color; c.lineWidth = 5 - stem; c.beginPath(); c.moveTo(sx, 0); c.quadraticCurveTo(sx + lean * .25, -110, sx + lean, -height); c.stroke();
      for (let j = 1; j < 6; j++) {
        const y = -j * 33, px = sx + lean * j / 6;
        c.fillStyle = this.palette.edge; c.globalAlpha *= .85; c.fillRect(px - 3, y, 6, 2); c.globalAlpha /= .85;
        if (j % 2 === 0) for (let leaf = 0; leaf < 4; leaf++) {
          const side = j === 4 ? -1 : 1, ex = px + side * (18 + leaf * 9), ey = y - 18 + leaf * 4;
          c.fillStyle = color; c.beginPath(); c.moveTo(px, y); c.quadraticCurveTo(ex, ey - 8, ex + side * 14, ey - 5); c.quadraticCurveTo(ex, ey + 4, px, y); c.fill();
        }
      }
    }
    c.restore();
  }

  private lantern(x: number, y: number, scale: number, now: number, red = false) {
    const c = this.ctx; c.save(); c.translate(x + Math.sin(now * 1.3 + x) * 1.3, y); c.scale(scale, scale);
    c.strokeStyle = '#b9a47a'; c.lineWidth = 1; c.beginPath(); c.moveTo(0, -22); c.lineTo(0, -8); c.stroke();
    this.glow(0, 8, 35, '#ffbb73', .13);
    c.fillStyle = '#231e21'; c.beginPath(); c.ellipse(0, 8, 15, 21, 0, 0, TAU); c.fill();
    c.fillStyle = red ? '#b95541' : '#c79b5f'; c.beginPath(); c.ellipse(0, 8, 12, 19, 0, 0, TAU); c.fill();
    c.fillStyle = red ? '#e0a36e' : '#eed6a3'; c.beginPath(); c.ellipse(-3, 6, 6, 15, 0, 0, TAU); c.fill();
    c.strokeStyle = '#773e37'; c.lineWidth = 1; for (const xx of [-5, 3, 8]) {c.beginPath(); c.moveTo(xx, -8); c.quadraticCurveTo(xx + 4, 8, xx, 25); c.stroke();}
    c.fillStyle = '#e3bc7d'; c.fillRect(-8, -11, 16, 4); c.fillRect(-7, 26, 14, 3); c.fillRect(-1, 30, 2, 12); c.fillRect(-3, 40, 6, 3);
    c.restore();
  }

  private rune(x: number, y: number, size: number, color: string, alpha: number) {
    const c = this.ctx; c.save(); c.translate(x, y); c.globalAlpha *= alpha; c.strokeStyle = color; c.lineWidth = Math.max(1, size / 15);
    c.strokeRect(-size * .46, -size * .46, size * .92, size * .92); c.beginPath();
    c.moveTo(-size * .3, -size * .16); c.lineTo(size * .3, -size * .16); c.moveTo(0, -size * .38); c.lineTo(0, size * .36);
    c.moveTo(-size * .29, size * .17); c.lineTo(size * .29, size * .17); c.moveTo(-size * .16, -size * .3); c.lineTo(size * .16, size * .3); c.stroke(); c.restore();
  }

  private talisman(x: number, y: number, scale: number, now: number) {
    const c = this.ctx; c.save(); c.translate(x, y); c.rotate(Math.sin(now * 1.5 + x) * .04); c.scale(scale, scale);
    c.fillStyle = '#d3b77c'; c.beginPath(); c.moveTo(-9, 0); c.lineTo(9, 0); c.lineTo(7, 51); c.lineTo(-8, 55); c.closePath(); c.fill();
    this.rune(0, 14, 11, '#a84d3d', 1); c.strokeStyle = '#a84d3d'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(-3, 26); c.lineTo(4, 33); c.lineTo(-4, 40); c.lineTo(4, 47); c.stroke(); c.restore();
  }

  private bell(x: number, y: number, scale: number, now: number) {
    const c = this.ctx; c.save(); c.translate(x, y); c.scale(scale, scale);
    c.strokeStyle = '#8c9c87'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -120); c.lineTo(0, -32); c.stroke();
    c.fillStyle = '#4f6258'; c.beginPath(); c.moveTo(-24, -30); c.quadraticCurveTo(-28, 4, -45, 36); c.lineTo(45, 36); c.quadraticCurveTo(28, 4, 24, -30); c.closePath(); c.fill();
    c.strokeStyle = '#a7ad86'; c.lineWidth = 2; c.stroke(); c.fillStyle = '#1d3538'; c.fillRect(-45, 33, 90, 7);
    c.strokeStyle = '#b9bb9566'; c.lineWidth = 1; c.beginPath(); c.moveTo(-24, -12); c.lineTo(24, -12); c.moveTo(-30, 17); c.lineTo(30, 17); c.stroke();
    this.rune(0, 7, 20, '#c9c39c', .8); this.glow(0, 41, 47, '#a4dcc0', .1 + Math.sin(now) * .015); c.restore();
  }

  private lotus(x: number, y: number, scale: number, now: number) {
    const c = this.ctx; c.save(); c.translate(x, y + Math.sin(now + x) * 1.3); c.scale(scale, scale);
    c.fillStyle = '#4f8b7b'; c.beginPath(); c.ellipse(0, 5, 26, 5, 0, 0, TAU); c.fill();
    for (const a of [-.75, 0, .75]) { c.save(); c.rotate(a); c.fillStyle = '#dfd1b6'; c.beginPath(); c.moveTo(0, 1); c.quadraticCurveTo(-11, -6, 0, -22); c.quadraticCurveTo(11, -6, 0, 1); c.fill(); c.restore(); }
    c.fillStyle = '#ead09b'; c.fillRect(-3, -4, 6, 5); c.restore();
  }

  private pipe(x: number, y: number, width: number, height: number, color: string) {
    const c = this.ctx; c.strokeStyle = '#1e2a2b'; c.lineWidth = 13; c.beginPath(); c.moveTo(x, y + height); c.lineTo(x, y); c.lineTo(x + width, y); c.stroke();
    c.strokeStyle = color; c.lineWidth = 8; c.stroke(); c.strokeStyle = '#c8b68b44'; c.lineWidth = 2; c.stroke();
    for (let i = 1; i < 5; i++) { c.fillStyle = color; c.fillRect(x - 9, y + i * height / 5, 18, 4); }
  }

  private furnace(x: number, y: number, scale: number, now: number) {
    const c = this.ctx; c.save(); c.translate(x, y); c.scale(scale, scale);
    c.fillStyle = '#2d302c'; c.fillRect(-42, -136, 84, 136); c.fillRect(-51, -118, 102, 22); c.fillRect(-34, -178, 68, 48);
    c.fillStyle = '#79664c'; c.fillRect(-38, -129, 76, 124); c.fillStyle = '#a98a5e'; c.fillRect(-40, -119, 80, 6); c.fillRect(-34, -15, 68, 7);
    c.fillStyle = '#2c2d2a'; c.beginPath(); c.ellipse(0, -74, 27, 37, 0, 0, TAU); c.fill();
    this.glow(0, -70, 55, '#f4a66e', .17); c.fillStyle = '#c67b43'; c.beginPath(); c.ellipse(0, -69, 19, 27, 0, 0, TAU); c.fill();
    for (let i = -1; i <= 1; i++) {c.fillStyle = '#e5b77a'; c.fillRect(i * 10 - 2, -88, 4, 42);}
    this.rune(0, -154, 18, '#d4bd8a', .8);
    for (let i = 0; i < 3; i++) {c.globalAlpha = .04; c.fillStyle = '#e2cfaa'; c.beginPath(); c.ellipse(Math.sin(now * .4 + i) * 13, -190 - i * 24, 24 + i * 10, 15, 0, 0, TAU); c.fill();}
    c.restore();
  }

  private celestial(x: number, y: number, radius: number, now: number, alpha: number) {
    const c = this.ctx; c.save(); c.translate(x, y); c.globalAlpha *= alpha;
    this.glow(0, 0, radius * 1.4, '#c7dbb0', .08);
    c.strokeStyle = '#c5ba8b'; c.lineWidth = 2;
    for (let ring = 0; ring < 3; ring++) {
      c.save(); c.rotate(now * .025 * (ring % 2 ? -1 : 1) + ring * .7); c.beginPath(); c.ellipse(0, 0, radius, radius * (.32 + ring * .27), .2, 0, TAU); c.stroke();
      c.lineWidth = 1; for (let i = 0; i < 16; i++) {const a = i / 16 * TAU; c.beginPath(); c.moveTo(Math.cos(a) * (radius - 6), Math.sin(a) * (radius - 6)); c.lineTo(Math.cos(a) * (radius + 3), Math.sin(a) * (radius + 3)); c.stroke();} c.restore();
    }
    c.fillStyle = '#c9c7a3'; c.beginPath(); c.arc(0, 0, 9, 0, TAU); c.fill(); c.restore();
  }

  private moon(x: number, y: number, radius: number, now: number) {
    const c = this.ctx;
    const halo = c.createRadialGradient(x, y, radius * .5, x, y, radius * 3.2);
    halo.addColorStop(0, '#c8e6bc25');
    halo.addColorStop(.3, '#c8e6bc10');
    halo.addColorStop(1, '#c8e6bc00');
    c.fillStyle = halo;
    c.fillRect(x - radius * 3.3, y - radius * 3.3, radius * 6.6, radius * 6.6);
    c.fillStyle = this.palette.moon;
    // Stepped raster circle rather than a smooth vector disc.
    for (let row = -radius; row < radius; row += 3) {
      const half = Math.floor(Math.sqrt(radius * radius - row * row) / 3) * 3;
      c.fillRect(Math.round(x) - half, Math.round(y) + row, half * 2, 3);
    }
    c.globalAlpha = .09;
    c.fillStyle = this.palette.sky[0];
    c.fillRect(Math.round(x - 17), Math.round(y - 12), 13, 7);
    c.fillRect(Math.round(x - 20), Math.round(y - 8), 18, 10);
    c.fillRect(Math.round(x + 10), Math.round(y + 8), 7, 9);
    c.fillRect(Math.round(x + 4), Math.round(y + 13), 13, 6);
    c.globalAlpha = 1;
    if (Math.sin(now * .2) > .8) {
      c.fillStyle = '#fff4d2';
      c.fillRect(Math.round(x + radius + 14), Math.round(y - 19), 2, 2);
    }
  }

  private ridge(offset: number, base: number, color: string, layer: number) {
    const c = this.ctx;
    c.fillStyle = color;
    c.beginPath();
    c.moveTo(-100, H);
    const step = 56;
    const shift = Math.floor(offset / step);
    for (let i = -3; i < 23; i++) {
      const x = i * step - (offset % step);
      const y = base - hash(i + shift, 20 + layer) * (layer ? 75 : 95);
      c.lineTo(Math.round(x), Math.round(y));
      c.lineTo(Math.round(x + step * .45), Math.round(y));
    }
    c.lineTo(W + 100, H);
    c.closePath();
    c.fill();
  }

  private cloud(x: number, y: number, scale: number, color: string, alpha: number) {
    const c = this.ctx;
    c.save();
    c.translate(Math.round(x), Math.round(y));
    c.scale(scale, scale);
    c.fillStyle = color;
    c.globalAlpha = alpha;
    c.fillRect(0, 10, 140, 8);
    c.fillRect(18, 3, 95, 9);
    c.fillRect(41, -3, 45, 8);
    c.fillRect(-24, 16, 190, 4);
    c.restore();
  }

  private pine(x: number, ground: number, height: number, color: string, alpha = 1) {
    const c = this.ctx;
    c.save();
    c.globalAlpha *= alpha;
    c.fillStyle = color;
    c.fillRect(Math.round(x - 4), Math.round(ground - height * .7), 8, Math.round(height * .7));
    for (let j = 0; j < 6; j++) {
      const y = ground - height + j * height * .13;
      const half = height * (.08 + j * .04);
      c.beginPath();
      c.moveTo(Math.round(x), Math.round(y));
      c.lineTo(Math.round(x + half), Math.round(y + height * .25));
      c.lineTo(Math.round(x + half * .55), Math.round(y + height * .25));
      c.lineTo(Math.round(x + half * .75), Math.round(y + height * .31));
      c.lineTo(Math.round(x - half * .75), Math.round(y + height * .31));
      c.lineTo(Math.round(x - half * .55), Math.round(y + height * .25));
      c.lineTo(Math.round(x - half), Math.round(y + height * .25));
      c.closePath();
      c.fill();
    }
    c.restore();
  }

  private tree(x: number, ground: number, scale: number, color?: string, alpha = 1, leaves = true) {
    const c = this.ctx;
    c.save();
    c.translate(Math.round(x), Math.round(ground));
    c.scale(scale, scale);
    c.globalAlpha *= alpha;
    c.fillStyle = color || '#203b3b';
    c.beginPath();
    c.moveTo(-20, 0); c.lineTo(-10, -32); c.lineTo(-11, -90); c.lineTo(-27, -111); c.lineTo(-40, -143);
    c.lineTo(-32, -146); c.lineTo(-15, -118); c.lineTo(-10, -117); c.lineTo(-11, -170); c.lineTo(-2, -202);
    c.lineTo(4, -201); c.lineTo(4, -164); c.lineTo(10, -130); c.lineTo(30, -153); c.lineTo(42, -157);
    c.lineTo(31, -140); c.lineTo(15, -113); c.lineTo(12, -54); c.lineTo(18, -12); c.lineTo(28, 0);
    c.closePath(); c.fill();
    if (!color) {
      c.fillStyle = '#3a5350';
      c.fillRect(-6, -165, 3, 120);
      c.fillRect(1, -93, 3, 80);
      c.fillStyle = '#496959';
      c.fillRect(-9, -67, 6, 3);
      c.fillRect(-7, -44, 7, 3);
    }
    if (leaves) {
      c.fillStyle = color || '#24534b';
      c.fillRect(-61, -192, 115, 32);
      c.fillRect(-43, -217, 79, 32);
      c.fillRect(-26, -229, 39, 20);
      c.fillRect(-78, -174, 76, 23);
      c.fillRect(6, -178, 64, 22);
      if (!color) {
        c.fillStyle = '#376e58';
        c.fillRect(-43, -218, 77, 7);
        c.fillRect(-62, -194, 55, 6);
        c.fillRect(13, -193, 39, 5);
        c.fillStyle = '#4d8762';
        c.fillRect(-25, -229, 38, 4);
        c.fillRect(-44, -215, 25, 3);
      }
    }
    c.restore();
  }

  private tile(kind: Platform['kind'], theme: number, variation: number) {
    const key = `${kind}-${theme}-${variation}`;
    const cached = this.tiles.get(key);
    if (cached) return cached;
    const canvas = document.createElement('canvas');
    canvas.width = 32; canvas.height = 32;
    const c = canvas.getContext('2d')!;
    const p = PALETTES[theme] || PALETTES[0];
    if (kind === 'wood') {
      c.fillStyle = '#523f39'; c.fillRect(0, 0, 32, 32);
      c.fillStyle = '#795c45'; c.fillRect(1, 1, 30, 10); c.fillRect(1, 13, 30, 10);
      c.fillStyle = '#a17a50'; c.fillRect(1, 1, 30, 2); c.fillRect(1, 13, 30, 2);
      c.fillStyle = '#3d3934'; c.fillRect(4, 5, 2, 2); c.fillRect(26, 17, 2, 2);
      c.fillStyle = '#634a3b'; c.fillRect(8, 6, 15, 1); c.fillRect(5, 19, 16, 1);
    } else {
      c.fillStyle = p.stone; c.fillRect(0, 0, 32, 32);
      c.fillStyle = '#0a1d2333'; c.fillRect(0, 30, 32, 2); c.fillRect(31, 0, 1, 32);
      c.fillStyle = `${p.edge}85`; c.fillRect(1, 1, 29, 1); c.fillRect(1, 3, 1, 24);
      c.fillStyle = '#203a3d'; c.fillRect(3, 25, 25, 3); c.fillRect(26, 5, 3, 20);
      for (let i = 0; i < 9; i++) {
        const x = Math.floor(hash(i + variation * 37, 19) * 23) + 4;
        const y = Math.floor(hash(i + variation * 13, 21) * 22) + 4;
        c.fillStyle = i % 2 ? '#ffffff07' : '#071b260d';
        c.fillRect(x, y, 2 + (i % 3), 1 + (i % 2));
      }
      if (variation === 1 || variation === 3) {
        c.fillStyle = '#142e33';
        c.fillRect(14, 3, 2, 8); c.fillRect(11, 11, 4, 2); c.fillRect(10, 12, 2, 8);
      }
      if (variation === 2) {
        c.fillStyle = '#69877533';
        c.fillRect(8, 10, 15, 2); c.fillRect(8, 10, 2, 11); c.fillRect(8, 19, 15, 2);
        c.fillRect(21, 15, 2, 6); c.fillRect(14, 14, 8, 2);
      }
    }
    this.tiles.set(key, canvas);
    return canvas;
  }

  private platform(platform: Platform, theme: number) {
    const c = this.ctx;
    if (drawArtPlatform(c, platform, theme, this.viewportX)) return;
    const p = PALETTES[theme] || PALETTES[0];
    const x = Math.round(platform.x), y = Math.round(platform.y), w = Math.round(platform.w), h = Math.round(platform.h);
    c.save();
    c.beginPath(); c.rect(x, y, w, h); c.clip();
    const firstTile = Math.max(0, Math.floor((this.viewportX - x - 32) / 32) * 32);
    const lastTile = Math.min(w, this.viewportX + W - x + 32);
    for (let tx = firstTile; tx < lastTile; tx += 32) {
      for (let ty = 0; ty < h; ty += 32) {
        const variation = Math.floor(hash(Math.floor(x / 32) + tx / 32, ty / 32) * 4);
        c.drawImage(this.tile(platform.kind, theme, variation), x + tx, y + ty);
      }
    }
    c.restore();
    if (platform.kind === 'ground' || platform.kind === 'stone') {
      c.fillStyle = '#182f32'; c.fillRect(x - 1, y, w + 2, 5);
      c.fillStyle = p.moss; c.fillRect(x, y, w, 4);
      c.fillStyle = p.moss; c.fillRect(x + 2, y, Math.max(0, w - 4), 1);
      c.fillStyle = theme === 5 || theme === 6 || theme === 7 ? p.edge : '#416d55';
      const firstGrass = Math.max(0, Math.floor((this.viewportX - x - 9) / 9) * 9);
      const lastGrass = Math.min(w, this.viewportX + W - x + 9);
      for (let j = firstGrass; j < lastGrass; j += 9) {
        const size = 2 + Math.floor(hash(x + j, 83) * 5);
        c.fillRect(x + j, y + 4, Math.min(5, w - j), size);
        if (theme !== 1 && theme !== 3 && theme < 5 && hash(x + j, 82) > .6) {
          c.fillStyle = p.moss;
          c.fillRect(x + j + 1, y - 4, 2, 5); c.fillRect(x + j + 3, y - 2, 2, 3);
          c.fillStyle = theme === 5 || theme === 6 || theme === 7 ? p.edge : '#416d55';
        }
      }
      if (platform.kind === 'stone' && h <= 40) {
        c.fillStyle = '#132b31'; c.fillRect(x + 3, y + h, w - 6, 3);
        c.fillStyle = '#32605a';
        for (let j = 12; j < w; j += 40) {
          c.fillRect(x + j, y + h, 2, 13 + Math.floor(hash(j, x) * 12));
          c.fillRect(x + j - 3, y + h + 9, 4, 2);
        }
      }
    } else if (platform.kind === 'spring') {
      c.fillStyle = '#f5c483'; c.fillRect(x, y, w, 4);
      c.fillStyle = '#e58c60'; c.fillRect(x + 1, y + 4, w - 2, 5);
      c.fillStyle = '#593f3b'; c.fillRect(x + 4, y + h - 4, w - 8, 4);
      c.strokeStyle = '#e7bc8b'; c.lineWidth = 2;
      c.beginPath();
      for (let j = 0; j < 4; j++) {
        c.lineTo(x + w * (j % 2 ? .7 : .3), y + 9 + j * Math.max(2, (h - 13) / 4));
      }
      c.stroke();
    } else {
      c.fillStyle = '#b7986c'; c.fillRect(x, y, w, 2);
      if (w > 60) {
        c.fillStyle = '#423c32'; c.fillRect(x + 9, y + h, 4, 22); c.fillRect(x + w - 13, y + h, 4, 22);
      }
    }
  }

  private worldDecor(decorations: Decoration[], camera: number, layer: 'back' | 'front') {
    for (const decor of decorations) {
      if (decor.x < camera - 180 || decor.x > camera + W + 180) continue;
      const foreground = decor.kind === 'grass' || decor.kind === 'mushroom';
      if ((layer === 'front') !== foreground) continue;
      this.decoration(decor);
    }
  }

  private routeMarkers(room: Room, camera: number, now: number) {
    const c = this.ctx;
    c.save();
    // Trail flags identify optional high paths without changing the existing art.
    for (const platform of room.platforms) {
      if (!platform.oneWay || platform.y > 250 || platform.x < camera - 160 || platform.x > camera + W) continue;
      const x = platform.x + platform.w - 12;
      c.fillStyle = '#8e9b7d'; c.fillRect(x, platform.y - 32, 2, 32);
      const sway = Math.round(Math.sin(now * 2.2 + platform.x) * 2);
      c.fillStyle = room.theme === 1 || room.theme === 5 || room.theme === 7 ? '#ae634b' : '#6e917c';
      c.beginPath(); c.moveTo(x + 2, platform.y - 31); c.lineTo(x + 19 + sway, platform.y - 28); c.lineTo(x + 14 + sway, platform.y - 19); c.lineTo(x + 2, platform.y - 19); c.closePath(); c.fill();
      c.fillStyle = '#dec993'; c.fillRect(x + 7, platform.y - 27, 2, 5);
    }
    // Previously the lava appeared only at the bottom of the screen. Warm edge
    // stones make each floor opening legible before the player steps into it.
    for (const hazard of room.hazards) {
      if (hazard.kind !== 'lava') continue;
      for (const edge of [hazard.x - 10, hazard.x + hazard.w + 3]) {
        c.fillStyle = '#8b6548'; c.fillRect(edge, 442, 7, 6);
        c.fillStyle = '#e8bd77'; c.fillRect(edge + 1, 439, 5, 3);
      }
      c.strokeStyle = '#bc886b44'; c.lineWidth = 1;
      c.beginPath(); c.moveTo(hazard.x, 475); c.quadraticCurveTo(hazard.x + hazard.w / 2, 484 + Math.sin(now) * 3, hazard.x + hazard.w, 475); c.stroke();
    }
    if (room.checkpoint.x > room.spawn.x + 100) {
      const x = Math.round(room.checkpoint.x + 8);
      c.fillStyle = '#849d87'; c.fillRect(x, 425, 2, 23);
      c.fillStyle = '#9bc6a2'; c.fillRect(x + 2, 425, 10, 7);
      c.fillStyle = '#d6ddac'; c.fillRect(x + 3, 426, 2, 2);
    }
    c.restore();
  }

  private guardArc(hero: Hero) {
    const c = this.ctx, facing = hero.facing || 1;
    c.save(); c.translate(Math.round(hero.x + hero.w / 2), Math.round(hero.y + hero.h / 2));
    c.scale(facing, 1);
    c.lineWidth = 3; c.strokeStyle = '#f2dc9d'; c.fillStyle = '#efdba125';
    c.beginPath(); c.moveTo(8, -28);
    for (let n = 0; n <= 8; n++) { const angle = -1.18 + n * 2.36 / 8; c.lineTo(Math.round(Math.cos(angle) * 33), Math.round(Math.sin(angle) * 29)); }
    c.lineTo(8, 28); c.stroke(); c.closePath(); c.fill();
    c.fillStyle = '#fff1bc'; c.fillRect(30, -2, 5, 5);
    c.restore();
  }

  private decoration(d: Decoration) {
    const c = this.ctx;
    if (drawArtDecoration(c, d, this.theme, this.time)) return;
    const s = d.scale || 1;
    switch (d.kind) {
      case 'tree':
        if (this.theme === 0 || this.theme === 4) this.bamboo(d.x, d.y, s, this.theme === 4 ? '#34675b' : '#2a5545');
        else if (this.theme === 5 || this.theme === 6) { c.save(); c.globalAlpha = .6; this.pipe(d.x, d.y - 142 * s, 61 * s, 142 * s, this.palette.edge); c.restore(); }
        else this.tree(d.x, d.y, s, this.palette.near, .74, this.theme === 2);
        break;
      case 'ruin': this.ruin(d.x, d.y, s); break;
      case 'lamp': this.lamp(d.x, d.y, s, this.time); break;
      case 'mushroom': {
        if (this.theme === 4) { this.lotus(d.x, d.y - 2, s * .65, this.time); break; }
        c.save(); c.translate(Math.round(d.x), Math.round(d.y)); c.scale(s, s);
        c.fillStyle = '#c4c7a4'; c.fillRect(-2, -11, 4, 11);
        c.fillStyle = '#768a74'; c.fillRect(0, -9, 2, 9);
        c.fillStyle = this.theme === 5 ? '#af8160' : '#a58e6d'; c.fillRect(-8, -15, 16, 5); c.fillRect(-5, -18, 10, 4);
        c.fillStyle = '#ffd6a0'; c.fillRect(-4, -17, 3, 2); c.fillRect(3, -14, 2, 2);
        c.restore(); break;
      }
      case 'grass': {
        c.save(); c.translate(Math.round(d.x), Math.round(d.y)); c.scale(s, s);
        const sway = Math.round(Math.sin(this.time * 1.5 + d.x) * 2);
        c.fillStyle = '#477860'; c.fillRect(-2, -10, 2, 10); c.fillRect(2, -7, 2, 7);
        c.fillRect(-6 + sway, -12, 2, 5); c.fillRect(-4, -8, 2, 6); c.fillRect(5 + sway, -11, 2, 6);
        c.fillStyle = '#80a679'; c.fillRect(-1, -13, 2, 4); c.fillRect(6 + sway, -13, 2, 3);
        c.restore(); break;
      }
      case 'crystal': {
        c.save(); c.translate(Math.round(d.x), Math.round(d.y)); c.scale(s, s);
        this.glow(0, -15, 29, this.palette.glow, .13);
        c.fillStyle = '#173b43'; c.fillRect(-9, -17, 15, 15);
        c.fillStyle = '#75cbb7'; this.pixelDiamond(-3, -17, 8, 22);
        c.fillStyle = '#d0f5d6'; c.fillRect(-5, -25, 2, 12);
        c.fillStyle = '#438d8e'; this.pixelDiamond(6, -8, 5, 13);
        c.restore(); break;
      }
    }
  }

  private ruin(x: number, ground: number, scale: number) {
    const c = this.ctx, p = this.palette;
    c.save(); c.translate(Math.round(x), Math.round(ground)); c.scale(scale, scale);
    c.fillStyle = '#182c2e'; c.fillRect(-24, -106, 48, 106); c.fillRect(-32, -7, 64, 7);
    c.fillStyle = p.stone; c.fillRect(-21, -105, 42, 99); c.fillStyle = p.edge; c.fillRect(-21, -103, 3, 95); c.fillRect(-27, -10, 54, 3);
    this.roof(0, -112, 34, 17, p.near, p.moss);
    c.fillStyle = '#142a2d'; c.fillRect(-14, -93, 28, 48); c.strokeStyle = '#9aab7f66'; c.lineWidth = 1; c.strokeRect(-13.5, -92.5, 27, 47);
    this.rune(0, -70, 15, p.glow, .7); this.talisman(3, -41, .48, this.time);
    c.strokeStyle = p.edge; c.lineWidth = 3; c.beginPath(); c.moveTo(23, -79); c.lineTo(33, -79); c.lineTo(33, -29); c.lineTo(24, -29); c.stroke();
    c.fillStyle = '#bf9f66'; c.fillRect(26, -76, 4, 3); c.fillRect(26, -32, 4, 3);
    c.restore();
  }

  private lamp(x: number, ground: number, scale: number, now: number) {
    const c = this.ctx;
    c.save(); c.translate(Math.round(x), Math.round(ground)); c.scale(scale, scale);
    c.fillStyle = '#263b38'; c.fillRect(-3, -72, 6, 72); c.fillRect(-9, -5, 18, 5);
    c.fillStyle = '#8b9772'; c.fillRect(-2, -70, 2, 64); c.fillRect(-3, -72, 28, 3);
    c.strokeStyle = '#bba67b'; c.lineWidth = 1; c.beginPath(); c.moveTo(2, -66); c.lineTo(19, -72); c.stroke();
    this.lantern(23, -45, .62, now, true);
    c.restore();
  }

  private portal(exit: Room['exit'], active: boolean, now: number, bossRoom = false) {
    if (bossRoom) return;
    const c = this.ctx;
    const x = Math.round(exit.x), y = Math.round(exit.y), w = Math.max(42, exit.w), h = Math.max(65, exit.h);
    c.save(); c.translate(x + w / 2, y + h);
    c.fillStyle = '#102d34'; c.fillRect(-w / 2 - 9, -h + 17, w + 18, h - 17);
    c.fillRect(-w / 2 - 3, -h + 7, w + 6, 17); c.fillRect(-w / 2 + 8, -h, w - 16, 12);
    c.fillStyle = active ? '#467d70' : '#38534f';
    c.fillRect(-w / 2 - 5, -h + 19, 9, h - 19); c.fillRect(w / 2 - 4, -h + 19, 9, h - 19);
    c.fillRect(-w / 2 + 3, -h + 10, 9, 12); c.fillRect(w / 2 - 12, -h + 10, 9, 12);
    c.fillRect(-w / 2 + 10, -h + 3, w - 20, 8);
    c.fillStyle = '#284841';
    for (let i = 0; i < 3; i++) {
      c.fillRect(-w / 2 - 4, -20 - i * 20, 8, 2); c.fillRect(w / 2 - 4, -20 - i * 20, 8, 2);
    }
    if (active) {
      this.glow(0, -h / 2, h * .85, '#72e4bc', .17);
      const g = c.createLinearGradient(0, -h, 0, 0);
      g.addColorStop(0, '#83edc973'); g.addColorStop(.5, '#44b9ad55'); g.addColorStop(1, '#c1f2bf8a');
      c.fillStyle = g; c.fillRect(-w / 2 + 6, -h + 20, w - 12, h - 21);
      for (let i = 0; i < 14; i++) {
        const px = -w / 2 + 8 + hash(i, 50) * (w - 18);
        const py = -((now * (13 + hash(i, 52) * 10) + i * 9) % (h - 24));
        c.globalAlpha = .3 + hash(i, 53) * .6;
        c.fillStyle = '#c9ffe0'; c.fillRect(Math.round(px), Math.round(py), 2, 4);
      }
      c.globalAlpha = 1;
      c.fillStyle = '#b2ebca'; c.fillRect(-w / 2 - 2, -h + 23, 2, 11); c.fillRect(w / 2, -h + 23, 2, 11);
      c.fillStyle = '#142e36'; c.fillRect(-23, 9, 46, 20);
      c.strokeStyle = '#8bd3b1'; c.lineWidth = 1; c.strokeRect(-22.5, 9.5, 45, 19);
      c.font = 'bold 11px "Microsoft YaHei", sans-serif'; c.textAlign = 'center';
      c.fillStyle = '#d7f2d4'; c.fillText('E  下一站', 0, 23);
    } else {
      c.fillStyle = '#132f36'; c.fillRect(-w / 2 + 7, -h + 21, w - 14, h - 23);
      c.fillStyle = '#456963';
      c.fillRect(-6, -h / 2 - 6, 12, 2); c.fillRect(-1, -h / 2 - 11, 2, 12);
      c.fillStyle = '#7b9a7f'; c.fillRect(-3, -h + 8, 6, 5);
    }
    c.restore();
  }

  private spikes(x: number, y: number, w: number, h: number) {
    const c = this.ctx;
    c.fillStyle = '#263c42'; c.fillRect(x, y + h - 4, w, 4);
    for (let i = 0; i < w; i += 14) {
      c.fillStyle = '#b7b7a2';
      c.beginPath(); c.moveTo(x + i, y + h - 3); c.lineTo(x + i + 6, y + 1); c.lineTo(x + i + 12, y + h - 3); c.closePath(); c.fill();
      c.fillStyle = '#dee2be'; c.fillRect(x + i + 5, y + 4, 2, Math.max(3, h - 11));
      c.fillStyle = '#6b8180'; c.fillRect(x + i + 8, y + h - 9, 2, 6);
    }
  }

  private lava(x: number, y: number, w: number, h: number, now: number) {
    const c = this.ctx;
    c.fillStyle = '#d96546'; c.fillRect(x, y + 4, w, h - 4);
    c.fillStyle = '#ffbd6e'; c.fillRect(x, y + 3, w, 4);
    for (let i = 0; i < w; i += 13) {
      const dy = Math.round(Math.sin(now * 2 + i * .12) * 2);
      c.fillStyle = '#ffe0a0'; c.fillRect(x + i, y + dy, Math.min(9, w - i), 4);
      c.fillStyle = '#a74940'; c.fillRect(x + i + 3, y + 12 + (i % 9), 6, 3);
    }
  }

  private hero(h: Hero, now: number, menuScale = 1, awakened = false) {
    const c = this.ctx;
    if (drawArtHero(c, h, now, menuScale, awakened)) {
      drawArtSlash(c, h, now);
      return;
    }
    const x = Math.round(h.x + h.w / 2), foot = Math.round(h.y + h.h);
    const running = Math.abs(h.vx) > 15 && h.grounded;
    const walk = Math.sin(h.animation * 14 || now * 14);
    const bob = h.grounded ? (running ? Math.abs(walk) * -2 : Math.sin(now * 2) * .7) : 0;
    this.shadow(x, foot + 1, h.grounded ? 16 : 11, .23);
    if (h.dashTimer > 0) {
      for (let i = 3; i > 0; i--) {
        c.save(); c.globalAlpha = (4 - i) * .09;
        c.fillStyle = '#81ead1'; c.fillRect(x - h.facing * i * 13 - 12, foot - 33, 24, 29);
        c.restore();
      }
    }
    c.save();
    if (h.invincible > 0 && Math.sin(now * 43) > .25) c.globalAlpha = .48;
    c.translate(x, foot + Math.round(bob)); c.scale((h.facing || 1) * menuScale, menuScale);
    if (h.attackTimer > 0 && h.weapon === 'blade') {
      const power = h.attackStep === 3 ? 1 : .4;
      const progress = 1 - clamp(h.attackTimer / (h.attackStep === 3 ? .28 : .18), 0, 1);
      c.translate(Math.sin(progress * Math.PI) * power * 4, 0);
      c.rotate(Math.sin(progress * Math.PI) * .08 * power);
    }
    if (awakened) {
      // The awakening halo is drawn before the sprite so the face and projectiles
      // remain readable against the celestial blue.
      c.save();
      c.globalAlpha = .22 + Math.sin(now * 6) * .03;
      c.fillStyle = '#7fe5ff';
      c.fillRect(-22, -52, 44, 4);
      c.fillRect(-30, -43, 60, 4);
      c.fillRect(-36, -32, 72, 4);
      c.restore();
    }
    // An ivory ritual mask and a vermilion sash remain legible at the 28px hitbox.
    const scarf = Math.sin(now * 7 + h.x * .01) * 2;
    c.fillStyle = '#122a2c'; c.beginPath(); c.moveTo(-10, -29); c.lineTo(-22, -12); c.lineTo(-11, -3); c.lineTo(3, -10); c.lineTo(10, -24); c.closePath(); c.fill();
    c.fillStyle = '#d5c9aa'; c.beginPath(); c.moveTo(-8, -28); c.lineTo(-17, -11); c.lineTo(-9, -6); c.lineTo(-2, -13); c.lineTo(6, -25); c.closePath(); c.fill();
    c.fillStyle = '#a74e3d'; c.beginPath(); c.moveTo(-9, -27); c.quadraticCurveTo(-24, -29 + scarf, -33, -23 + scarf); c.lineTo(-27, -20 + scarf); c.lineTo(-35, -17 + scarf); c.quadraticCurveTo(-17, -19, -8, -23); c.closePath(); c.fill();
    c.strokeStyle = '#e4b47e'; c.lineWidth = 1; c.beginPath(); c.moveTo(-10, -26); c.quadraticCurveTo(-24, -27 + scarf, -31, -23 + scarf); c.stroke();
    const stride = running ? Math.round(walk * 4) : 0;
    const leftLift = !h.grounded ? -4 : Math.max(0, stride), rightLift = !h.grounded ? 0 : Math.max(0, -stride);
    c.fillStyle = '#18282d'; c.fillRect(-8 + stride, -12 - leftLift, 6, 11); c.fillRect(3 - stride, -12 - rightLift, 6, 11);
    c.fillStyle = '#a9aa93'; c.fillRect(-7 + stride, -11 - leftLift, 4, 5); c.fillRect(4 - stride, -11 - rightLift, 4, 5);
    c.fillStyle = '#243c3e'; c.fillRect(-10 + stride, -5 - leftLift, 10, 5); c.fillRect(3 - stride, -5 - rightLift, 10, 5);
    c.fillStyle = '#c6ad7c'; c.fillRect(-9 + stride, -2 - leftLift, 9, 1); c.fillRect(4 - stride, -2 - rightLift, 9, 1);
    c.fillStyle = '#10272d'; c.beginPath(); c.moveTo(-9, -28); c.lineTo(9, -27); c.lineTo(13, -10); c.lineTo(-11, -9); c.closePath(); c.fill();
    c.fillStyle = '#38666a'; c.beginPath(); c.moveTo(-6, -27); c.lineTo(7, -26); c.lineTo(9, -13); c.lineTo(-8, -12); c.closePath(); c.fill();
    c.fillStyle = '#aab69e'; c.fillRect(-6, -25, 3, 12); c.strokeStyle = '#d6c6a1'; c.lineWidth = 1; c.beginPath(); c.moveTo(-5, -24); c.lineTo(4, -15); c.stroke();
    c.fillStyle = '#803e36'; c.fillRect(-11, -15, 24, 4); c.fillStyle = '#d9ba7e'; c.fillRect(-1, -15, 5, 4);
    c.fillStyle = '#263b3d'; c.fillRect(-9, -39, 18, 13); c.fillRect(-5, -42, 11, 5); c.fillRect(-4, -45, 6, 4);
    c.fillStyle = '#496362'; c.fillRect(-8, -39, 5, 11); c.fillStyle = '#b65e43'; c.fillRect(-6, -41, 14, 3);
    c.fillStyle = '#121f29'; c.beginPath(); c.moveTo(-6, -38); c.lineTo(8, -39); c.lineTo(14, -32); c.lineTo(10, -22); c.lineTo(-4, -24); c.lineTo(-8, -30); c.closePath(); c.fill();
    c.fillStyle = '#e6d8b5'; c.beginPath(); c.moveTo(-4, -37); c.lineTo(7, -38); c.lineTo(12, -32); c.lineTo(9, -24); c.lineTo(-3, -25); c.lineTo(-6, -30); c.closePath(); c.fill();
    c.fillStyle = '#f6edcf'; c.beginPath(); c.moveTo(1, -36); c.lineTo(7, -36); c.lineTo(10, -32); c.lineTo(6, -29); c.lineTo(1, -30); c.closePath(); c.fill();
    c.strokeStyle = '#a95942'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(0, -36); c.lineTo(1, -33); c.lineTo(-1, -31); c.moveTo(8, -29); c.lineTo(7, -26); c.stroke();
    c.fillStyle = '#182b2d'; c.fillRect(5, -33, 5, 2); c.fillStyle = '#edaa6e'; c.fillRect(8, -33, 2, 1);
    c.fillStyle = '#b45840'; c.fillRect(-10, -26, 21, 4); c.fillStyle = '#e0b47b'; c.fillRect(-8, -26, 17, 1);
    const arm = running ? Math.round(walk * -2) : 0;
    c.fillStyle = '#1a353b'; c.fillRect(9, -23 + arm, 5, 10); c.fillStyle = '#6a8c81'; c.fillRect(10, -22 + arm, 4, 4);
    c.fillStyle = '#d8c8a2'; c.fillRect(11, -16 + arm, 5, 5);
    this.heldWeapon(h.weapon, h.attackTimer, now, h.attackStep, awakened);
    if (h.swapBoost > 0 || h.counterTimer > 0) {
      c.save();
      c.globalAlpha = .45 + Math.sin(now * 18) * .12;
      c.strokeStyle = h.counterTimer > 0 ? '#ffde91' : '#b7b4ff'; c.lineWidth = 2;
      c.beginPath(); c.arc(0, -22, 25, -2.3, -.8); c.stroke();
      c.fillStyle = c.strokeStyle;
      c.fillRect(18, -49, 3, 5); c.fillRect(14, -47, 11, 2);
      c.restore();
    }
    if (awakened) {
      c.save();
      c.globalAlpha = .58 + Math.sin(now * 9) * .08;
      c.strokeStyle = '#b6f5ff';
      c.lineWidth = 2;
      c.beginPath(); c.arc(0, -22, 29 + Math.sin(now * 3) * 2, now * .7, now * .7 + 4.8); c.stroke();
      c.fillStyle = '#d8ffff';
      c.fillRect(-27, -35, 3, 3); c.fillRect(24, -13, 3, 2); c.fillRect(6, -53, 2, 3);
      c.restore();
    }
    if (h.shield > 0) {
      c.globalAlpha *= .5 + Math.sin(now * 3) * .12;
      c.strokeStyle = '#c1d5ff'; c.lineWidth = 1;
      c.beginPath(); c.arc(0, -21, 29, -.8, 2.8); c.stroke();
      c.fillStyle = '#e5e6ff'; c.fillRect(-22, -39, 3, 3); c.fillRect(23, -7, 2, 2);
    }
    c.restore();
  }

  private heldWeapon(weapon: Hero['weapon'], attacking: number, now: number, step = 1, awakened = false) {
    const c = this.ctx;
    if (weapon === 'blade') {
      const heavy = step === 3;
      const progress = 1 - clamp(attacking / (heavy ? .28 : .18), 0, 1);
      const reverse = step === 2;
      const swing = reverse ? 1.7 - progress * 3.2 : -1.8 + progress * 3.4;
      c.save(); c.translate(14, -15); c.rotate(attacking > 0 ? swing : -.64);
      c.fillStyle = '#1c4348'; c.fillRect(-2, -24, 5, 30);
      c.fillStyle = '#96ead3'; c.fillRect(-1, -25, 3, 23); c.fillRect(0, -28, 2, 4);
      c.fillStyle = '#e0ffe0'; c.fillRect(-1, -24, 1, 20);
      c.fillStyle = '#d7b47c'; c.fillRect(-5, -3, 11, 3);
      c.fillStyle = '#6f6551'; c.fillRect(-1, 0, 3, 6);
      c.restore();
      if (attacking > 0) {
        c.save();
        c.translate(8, -20);
        const radius = heavy ? (awakened ? 87 : 70) : (awakened ? 74 : 51);
        const end = reverse ? 1.25 - progress * 2.5 : -1.25 + progress * 2.5;
        const direction = reverse ? -1 : 1;
        c.globalAlpha = .24 + Math.sin(progress * Math.PI) * .6;
        c.strokeStyle = heavy ? '#ffd18c' : '#7ff3d4';
        c.lineWidth = heavy ? 13 : 8;
        c.beginPath(); c.arc(0, 0, radius, end - direction * 1.3, end, reverse); c.stroke();
        c.strokeStyle = heavy ? '#fff3c5' : '#e6fff0';
        c.lineWidth = heavy ? 4 : 2;
        c.beginPath(); c.arc(0, 0, radius + 3, end - direction * .85, end, reverse); c.stroke();
        c.globalAlpha *= .45;
        c.strokeStyle = heavy ? '#ffbd6d' : '#70d7ca'; c.lineWidth = 2;
        c.beginPath(); c.arc(0, 0, radius - 12, end - direction * 1.6, end - direction * .2, reverse); c.stroke();
        if (heavy) {
          c.fillStyle = '#ffeab4';
          for (let i = 0; i < 5; i++) {
            const angle = end - direction * (.2 + i * .24);
            c.fillRect(Math.round(Math.cos(angle) * (radius + 8)), Math.round(Math.sin(angle) * (radius + 8)), 3, 3);
          }
        }
        c.restore();
      }
    } else if (weapon === 'ember') {
      c.fillStyle = '#553c3b'; c.fillRect(16, -29, 4, 35);
      c.fillStyle = '#b99464'; c.fillRect(16, -27, 2, 31);
      c.fillStyle = '#ecbd7a'; c.fillRect(12, -28, 12, 3);
      this.glow(18, -34, attacking > 0 ? 29 : 18, '#ffad6d', attacking > 0 ? .38 : .24);
      c.fillStyle = '#fb9c68'; this.pixelDiamond(18, -34, 6, 13);
      c.fillStyle = '#ffe7ac'; c.fillRect(16, -39, 3, 6);
    } else {
      c.save(); c.translate(18, -14); c.rotate(Math.sin(now * 2) * .15);
      this.disc(0, 0, 11, now * .2); c.restore();
    }
  }

  private enemy(e: Enemy, now: number) {
    const c = this.ctx;
    const x = Math.round(e.x), y = Math.round(e.y);
    if (drawArtEnemy(c, e, now)) {
      if (e.hp < e.maxHp && e.hp > 0) {
        c.fillStyle = '#112b33'; c.fillRect(x + e.w / 2 - 15, y - 16, 30, 4);
        c.fillStyle = '#f3b184'; c.fillRect(x + e.w / 2 - 14, y - 15, 28 * (e.hp / e.maxHp), 2);
      }
      return;
    }
    this.shadow(x + e.w / 2, y + e.h + 1, e.w * .42, .2);
    c.save(); c.translate(x + e.w / 2, y + e.h); c.scale(e.facing || 1, 1);
    if (e.hurt > 0) {
      const impact = clamp(e.hurt / .18, 0, 1);
      c.scale(1 + impact * .19, 1 - impact * .16);
      if (e.hurt > .065) c.filter = 'brightness(2.8) saturate(.25)';
    }
    if (e.kind === 'slime') {
      c.scale(e.w / 32, e.h / 25);
      const squash = Math.sin(e.timer * 7 + e.id) * 1.5;
      c.translate(0, -Math.max(0, squash));
      c.fillStyle = '#2b3640'; c.fillRect(-14, -16, 28, 14); c.fillRect(-11, -22, 22, 6); c.fillRect(-6, -25, 12, 4);
      c.fillStyle = '#c27a80'; c.fillRect(-12, -16, 24, 12); c.fillRect(-9, -21, 18, 8); c.fillRect(-5, -23, 10, 5);
      c.fillStyle = '#df9c99'; c.fillRect(-8, -20, 15, 3); c.fillRect(-11, -15, 5, 4);
      c.fillStyle = '#965a70'; c.fillRect(-10, -7, 21, 4);
      c.fillStyle = '#f5d2b6'; c.fillRect(-9, -18, 4, 3); c.fillRect(-7, -21, 4, 2);
      c.fillStyle = '#2d3540'; c.fillRect(-1, -13, 3, 4); c.fillRect(7, -13, 3, 4);
      c.fillStyle = '#fce8c7'; c.fillRect(-1, -13, 1, 1); c.fillRect(7, -13, 1, 1);
      c.fillStyle = '#612f4c'; c.fillRect(2, -7, 4, 2);
      c.fillStyle = '#fff1c7'; c.fillRect(3, -7, 2, 2);
    } else if (e.kind === 'bat') {
      c.scale(e.w / 34, e.h / 24);
      const flap = Math.sin(now * 12 + e.id) * 10;
      c.fillStyle = '#24303f';
      c.beginPath(); c.moveTo(-6, -17); c.lineTo(-19, -23 - flap); c.lineTo(-26, -11 - flap); c.lineTo(-19, -7); c.lineTo(-15, -2); c.lineTo(-6, -8); c.closePath(); c.fill();
      c.beginPath(); c.moveTo(6, -17); c.lineTo(19, -23 - flap); c.lineTo(26, -11 - flap); c.lineTo(19, -7); c.lineTo(15, -2); c.lineTo(6, -8); c.closePath(); c.fill();
      c.fillStyle = '#8078a3';
      c.beginPath(); c.moveTo(-7, -15); c.lineTo(-19, -19 - flap); c.lineTo(-22, -12 - flap); c.lineTo(-16, -10); c.lineTo(-12, -5); c.closePath(); c.fill();
      c.beginPath(); c.moveTo(7, -15); c.lineTo(19, -19 - flap); c.lineTo(22, -12 - flap); c.lineTo(16, -10); c.lineTo(12, -5); c.closePath(); c.fill();
      c.fillStyle = '#3b3d59'; c.fillRect(-7, -23, 14, 21); c.fillRect(-8, -29, 4, 10); c.fillRect(4, -29, 4, 10);
      c.fillStyle = '#9d90b1'; c.fillRect(-5, -21, 10, 15);
      c.fillStyle = '#5f586e'; c.fillRect(-4, -9, 8, 6);
      c.fillStyle = '#ffd29a'; c.fillRect(-5, -18, 3, 3); c.fillRect(3, -18, 3, 3);
      c.fillStyle = '#2c3541'; c.fillRect(-3, -18, 1, 3); c.fillRect(5, -18, 1, 3);
      c.fillStyle = '#f4dbbc'; c.fillRect(-2, -11, 1, 3); c.fillRect(3, -11, 1, 3);
    } else {
      c.scale(e.w / 32, e.h / 40);
      c.fillStyle = '#172f36'; c.fillRect(-14, -35, 28, 31); c.fillRect(-11, -41, 22, 7); c.fillRect(-16, -6, 32, 6);
      c.fillStyle = '#5c7870'; c.fillRect(-12, -34, 24, 27); c.fillRect(-10, -39, 20, 7);
      c.fillStyle = '#87a185'; c.fillRect(-10, -39, 17, 3); c.fillRect(-12, -32, 3, 23);
      c.fillStyle = '#345450'; c.fillRect(8, -31, 4, 24); c.fillRect(-9, -16, 18, 2);
      c.fillStyle = '#162f37'; c.fillRect(-7, -29, 16, 8);
      this.glow(1, -25, 19, '#ffad70', .18);
      c.fillStyle = '#ffc884'; c.fillRect(-5, -27, 12, 4); c.fillStyle = '#fff0bb'; c.fillRect(1, -27, 4, 4);
      c.fillStyle = '#c8b08a'; this.pixelDiamond(1, -12, 4, 8);
      c.fillStyle = '#638c62'; c.fillRect(-15, -40, 12, 4); c.fillRect(-10, -43, 8, 3); c.fillRect(-15, -36, 4, 7);
    }
    c.restore();
    if (e.hp < e.maxHp && e.hp > 0) {
      c.fillStyle = '#112b33'; c.fillRect(x + e.w / 2 - 15, y - 9, 30, 4);
      c.fillStyle = '#f3b184'; c.fillRect(x + e.w / 2 - 14, y - 8, 28 * (e.hp / e.maxHp), 2);
    }
  }

  private boss(b: Boss, hero: Hero, now: number, roomWidth: number) {
    const c = this.ctx;
    const angry = b.phase >= 2;
    const furious = b.phase >= 3;
    const center = b.x + b.w / 2;
    const foot = b.y + b.h;
    if (b.mode === 'windup') {
      const direction = b.facing || Math.sign(hero.x - b.x) || 1;
      c.save();
      const warning = Math.min(1, .35 + Math.sin(now * 18) * .2);
      c.fillStyle = `rgba(255,145,96,${warning * .28})`;
      c.strokeStyle = '#ffc392'; c.lineWidth = 1;
      if (b.intent === 'leap') {
        const landing = clamp(b.targetX, 420, roomWidth - b.w - 90) + b.w / 2;
        c.fillRect(landing - b.w / 2 - 10, 442, b.w + 20, 6);
        c.strokeRect(Math.round(landing - b.w / 2 - 10), 435, b.w + 20, 12);
        c.fillStyle = '#ffd4a1';
        for (const side of [-1, 1]) {
          c.fillRect(Math.round(landing + side * (b.w / 2 + 10)), 424, 2, 11);
        }
        c.beginPath();
        c.moveTo(landing - 5, 420); c.lineTo(landing, 426); c.lineTo(landing + 5, 420); c.stroke();
        c.setLineDash([5, 8]);
        c.globalAlpha = .6;
        c.beginPath(); c.moveTo(center, b.y + 20); c.quadraticCurveTo((center + landing) / 2, b.y - 110, landing, 424); c.stroke();
        c.setLineDash([]);
      } else if (b.intent === 'barrage') {
        const originY = b.y + 30;
        const angle = Math.atan2(hero.y + hero.h / 2 - originY, hero.x + hero.w / 2 - center);
        const rays = furious ? 5 : 3;
        c.strokeStyle = '#ffb992'; c.lineWidth = 2;
        c.globalAlpha = .48 + Math.sin(now * 20) * .16;
        for (let i = 0; i < rays; i++) {
          const ray = angle + (i - (rays - 1) / 2) * .24;
          c.beginPath(); c.moveTo(center + Math.cos(ray) * 65, originY + Math.sin(ray) * 65);
          c.lineTo(center + Math.cos(ray) * 230, originY + Math.sin(ray) * 230); c.stroke();
        }
      } else {
        const directions = b.intent === 'slam' ? [-1, 1] : [direction];
        const distance = b.intent === 'slam' ? 460 : furious ? 550 : angry ? 430 : 330;
        for (const travelDirection of directions) {
          c.fillRect(travelDirection > 0 ? center : center - distance, foot - 5, distance, 5);
          for (let i = 0; i < Math.floor(distance / 48); i++) {
            const x = center + travelDirection * (45 + i * 48);
            c.beginPath(); c.moveTo(x - travelDirection * 5, foot - 13); c.lineTo(x, foot - 8); c.lineTo(x - travelDirection * 5, foot - 3); c.stroke();
          }
        }
      }
      c.restore();
      const label = { charge: b.chain > 0 ? '连环冲锋 · 再次闪避' : '冲锋 · 跳跃 / 闪避', leap: '追猎跃击 · 离开落点', slam: '震地 · 跳过地面波', barrage: '星火弹幕 · 移动穿隙' }[b.intent];
      this.bossCallout(label, center, Math.max(130, b.y - 65), '#ffcc91');
    }
    if (b.mode === 'transition') {
      c.save();
      c.strokeStyle = furious ? '#ff8aa0' : '#ffbd78'; c.lineWidth = 3;
      c.globalAlpha = .45;
      for (let ring = 0; ring < 3; ring++) {
        const radius = 45 + ((now * 105 + ring * 37) % 110);
        c.beginPath(); c.arc(center, b.y + b.h / 2, radius, 0, TAU); c.stroke();
      }
      c.restore();
    }
    if (b.mode === 'stagger' || b.exposed > 0) {
      c.save();
      c.strokeStyle = '#a0ffe0'; c.lineWidth = 2; c.globalAlpha = .55 + Math.sin(now * 14) * .18;
      c.beginPath(); c.ellipse(center, foot + 1, b.w * .75, 11, 0, 0, TAU); c.stroke();
      c.restore();
      this.bossCallout(b.mode === 'stagger' ? '破甲！全力输出' : '核心暴露 · 伤害提升', center, Math.max(130, b.y - 65), '#a2ffe0');
    }
    this.shadow(center, foot + 3, b.w * .62, .32);
    if (!drawArtBoss(c, b, now)) {
    c.save(); c.translate(Math.round(center), Math.round(foot)); c.scale((b.facing || -1) * b.w / 94, b.h / 112);
    const breathing = Math.sin(now * 2.3) * 1.5;
    const charging = b.mode === 'charge';
    c.translate(charging ? 4 : 0, b.mode === 'stagger' ? 7 + Math.sin(now * 22) * 1.5 : breathing);
    if (b.hurt > 0) { c.scale(1 + b.hurt * .25, 1 - b.hurt * .2); c.filter = 'brightness(1.75) saturate(.6)'; }
    const stone = furious ? '#71525c' : angry ? '#655956' : '#5b6c64';
    const lit = furious ? '#bd8a8b' : angry ? '#9f8571' : '#8c9d83';
    const shadow = furious ? '#453445' : angry ? '#403c43' : '#344c4a';
    const lava = furious ? '#ff7a89' : angry ? '#ff9261' : '#f3b879';
    this.glow(0, -58, 83, angry ? '#ff8e56' : '#ffcb87', b.mode === 'windup' ? .22 : .09);
    // Thick guardian feet and articulated legs.
    c.fillStyle = '#1f3038'; c.fillRect(-33, -31, 25, 29); c.fillRect(13, -31, 25, 29);
    c.fillStyle = stone; c.fillRect(-31, -28, 20, 23); c.fillRect(15, -28, 20, 23);
    c.fillStyle = lit; c.fillRect(-31, -27, 5, 16); c.fillRect(15, -27, 5, 16);
    c.fillStyle = '#263b3d'; c.fillRect(-39, -11, 32, 11); c.fillRect(11, -11, 32, 11);
    c.fillStyle = stone; c.fillRect(-37, -10, 28, 7); c.fillRect(13, -10, 28, 7);
    c.fillStyle = lit; c.fillRect(-36, -10, 26, 2); c.fillRect(14, -10, 26, 2);
    // Enormous angular torso, with a glowing exposed heart.
    c.fillStyle = '#1f3038'; c.fillRect(-33, -81, 68, 50); c.fillRect(-26, -89, 54, 13);
    c.fillStyle = stone; c.fillRect(-30, -79, 62, 45); c.fillRect(-23, -86, 48, 13);
    c.fillStyle = lit; c.fillRect(-29, -78, 8, 37); c.fillRect(-23, -85, 45, 4);
    c.fillStyle = shadow; c.fillRect(21, -76, 10, 42); c.fillRect(-17, -41, 39, 6);
    c.fillStyle = '#293e40'; c.fillRect(-15, -73, 34, 28); c.fillRect(-10, -78, 24, 38);
    c.fillStyle = lava; this.pixelDiamond(2, -59, 14, 27);
    c.fillStyle = '#ffe8b0'; this.pixelDiamond(1, -61, 6, 16);
    c.fillStyle = angry ? '#ffbb7f' : '#a2b18c';
    c.fillRect(-23, -69, 7, 3); c.fillRect(-20, -66, 3, 12); c.fillRect(18, -57, 9, 3); c.fillRect(25, -55, 3, 13);
    c.fillRect(-14, -37, 4, 5); c.fillRect(10, -37, 3, 6);
    // Head and crown: a recognisable ancient stag-like stone silhouette.
    c.fillStyle = '#203239'; c.fillRect(-24, -111, 52, 30); c.fillRect(-18, -118, 40, 11);
    c.fillStyle = stone; c.fillRect(-21, -109, 46, 25); c.fillRect(-16, -115, 36, 12);
    c.fillStyle = lit; c.fillRect(-18, -114, 35, 4); c.fillRect(-20, -106, 5, 18);
    c.fillStyle = '#26393d'; c.fillRect(-18, -102, 42, 12);
    c.fillStyle = lava; c.fillRect(-13, -99, 12, 5); c.fillRect(8, -99, 12, 5);
    c.fillStyle = '#fff0c2'; c.fillRect(-6, -99, 4, 4); c.fillRect(15, -99, 4, 4);
    c.fillStyle = shadow; c.fillRect(-1, -94, 8, 9); c.fillRect(-9, -87, 28, 3);
    c.fillStyle = '#2c4242'; c.fillRect(-29, -125, 9, 24); c.fillRect(27, -125, 9, 24);
    c.fillRect(-36, -131, 10, 10); c.fillRect(33, -135, 9, 14);
    c.fillStyle = lit; c.fillRect(-28, -125, 4, 20); c.fillRect(28, -125, 4, 20); c.fillRect(34, -134, 4, 11);
    // Bronze mask plates, tied sealing cords and etched circuits distinguish the ritual machine.
    c.fillStyle = furious ? '#d5a49a' : '#d3c09b';
    c.beginPath(); c.moveTo(-22, -111); c.lineTo(26, -111); c.lineTo(22, -105); c.lineTo(8, -104); c.lineTo(3, -94); c.lineTo(-2, -104); c.lineTo(-17, -104); c.closePath(); c.fill();
    c.strokeStyle = furious ? '#d88179' : '#ac674c'; c.lineWidth = 3;
    c.beginPath(); c.moveTo(-23, -111); c.quadraticCurveTo(-36, -120, -43, -117); c.moveTo(26, -111); c.quadraticCurveTo(40, -121, 46, -117); c.stroke();
    c.strokeStyle = '#a6533e'; c.lineWidth = 3; c.beginPath(); c.moveTo(-24, -82); c.lineTo(-36, -60); c.lineTo(-29, -46); c.moveTo(28, -83); c.lineTo(39, -59); c.lineTo(34, -41); c.stroke();
    this.rune(-21, -59, 10, '#d5bc8a', .72); this.rune(25, -60, 9, '#d5bc8a', .72);
    // Floating shoulder blocks and heavy fists.
    const arm = b.mode === 'windup' ? -12 : charging ? -5 : Math.sin(now * 2.3 + 1) * 3;
    c.fillStyle = '#1f3239'; c.fillRect(-49, -78 + arm, 23, 36); c.fillRect(30, -78 + arm, 23, 36);
    c.fillStyle = stone; c.fillRect(-46, -76 + arm, 19, 31); c.fillRect(32, -76 + arm, 18, 31);
    c.fillStyle = lit; c.fillRect(-46, -75 + arm, 5, 24); c.fillRect(32, -75 + arm, 5, 24);
    c.fillStyle = '#24383b'; c.fillRect(-53, -44 + arm, 30, 22); c.fillRect(30, -44 + arm, 30, 22);
    c.fillStyle = stone; c.fillRect(-50, -42 + arm, 25, 17); c.fillRect(32, -42 + arm, 25, 17);
    c.fillStyle = lava; c.fillRect(-47, -36 + arm, 3, 7); c.fillRect(45, -40 + arm, 3, 12);
    c.fillStyle = lit; c.fillRect(-49, -42 + arm, 22, 3); c.fillRect(33, -42 + arm, 22, 3);
    // A few moss tufts distinguish phase one from the stripped hot second phase.
    if (!angry) {
      c.fillStyle = '#6d956b'; c.fillRect(-43, -81 + arm, 13, 6); c.fillRect(32, -81 + arm, 16, 5);
      c.fillRect(-14, -119, 18, 5); c.fillRect(-9, -123, 9, 5);
      c.fillStyle = '#a3b884'; c.fillRect(-8, -123, 6, 2);
    } else {
      for (let i = 0; i < 8; i++) {
        const px = Math.sin(now * 2 + i * 2.3) * 40;
        const py = -((now * 22 + i * 17) % 150);
        c.globalAlpha *= .75;
        c.fillStyle = i % 2 ? '#ffbb75' : '#ee7a58'; c.fillRect(Math.round(px), Math.round(py), 2, 3);
        c.globalAlpha = 1;
      }
    }
    if (furious) {
      c.strokeStyle = '#ffb0ac'; c.lineWidth = 2;
      c.beginPath(); c.moveTo(-23, -79); c.lineTo(-14, -70); c.lineTo(-19, -58); c.lineTo(-12, -48); c.stroke();
      c.beginPath(); c.moveTo(19, -80); c.lineTo(12, -72); c.lineTo(22, -63); c.stroke();
    }
    c.restore();
    }
    if (b.active && b.maxGuard > 0) {
      const top = Math.max(150, b.y - 40);
      c.save();
      c.fillStyle = '#0b2029e0'; c.fillRect(center - 49, top, 98, 11);
      c.fillStyle = '#53666c'; c.fillRect(center - 46, top + 3, 92, 4);
      c.fillStyle = b.mode === 'stagger' ? '#a0ffe0' : furious ? '#db9ca1' : '#c1d5c2';
      c.fillRect(center - 46, top + 3, 92 * clamp(b.guard / b.maxGuard, 0, 1), 4);
      c.fillStyle = '#c6d9c4'; c.font = '9px "Microsoft YaHei",sans-serif'; c.textAlign = 'right';
      c.fillText(b.mode === 'stagger' ? '破甲' : '护甲', center - 54, top + 8);
      c.restore();
    }
  }

  private bossCallout(text: string, center: number, y: number, color: string) {
    const c = this.ctx;
    c.save();
    c.font = 'bold 12px "Microsoft YaHei",sans-serif'; c.textAlign = 'center';
    const width = c.measureText(text).width + 22;
    const x = clamp(center, this.viewportX + width / 2 + 16, this.viewportX + W - width / 2 - 16);
    c.fillStyle = '#0c2029eb'; c.fillRect(Math.round(x - width / 2), y - 16, width, 25);
    c.fillStyle = color; c.fillRect(Math.round(x - width / 2), y - 16, 3, 25);
    c.fillText(text, Math.round(x), y + 1);
    c.restore();
  }

  private impact(effect: Impact) {
    const c = this.ctx;
    if (drawArtImpact(c, effect)) {
      if (effect.kind !== 'hit') {
        const life = clamp(effect.life / effect.maxLife, 0, 1);
        c.save(); c.globalAlpha = life * .4; c.strokeStyle = effect.color; c.lineWidth = 1.5;
        c.beginPath(); c.ellipse(effect.x, effect.y, effect.size * (1.15 - life * .7), effect.size * (.8 - life * .45), effect.angle, 0, TAU); c.stroke(); c.restore();
      }
      return;
    }
    const life = clamp(effect.life / effect.maxLife, 0, 1);
    const progress = 1 - life;
    const strong = effect.kind !== 'hit';
    const breaking = effect.kind === 'break';
    const size = Math.max(9, effect.size);
    c.save();
    c.translate(Math.round(effect.x), Math.round(effect.y));
    c.rotate(effect.angle);
    c.globalAlpha = life;
    const radius = size * (.25 + progress * (strong ? .86 : .65));
    c.strokeStyle = effect.color;
    c.lineWidth = breaking ? 4 * life + 1 : strong ? 3 * life + 1 : 1.5;
    c.beginPath(); c.ellipse(0, 0, radius, radius * (breaking ? .8 : .65), 0, 0, TAU); c.stroke();
    if (strong) {
      c.globalAlpha = life * .4;
      c.lineWidth = 1;
      c.beginPath(); c.arc(0, 0, radius * 1.28, -.8, 2.8); c.stroke();
      c.globalAlpha = life;
    }
    // Directional slivers make the contact point distinct from the swing trail.
    const rays = strong ? 7 : 5;
    for (let i = 0; i < rays; i++) {
      const angle = i * TAU / rays + (i % 2) * .17;
      const inner = size * (.12 + progress * .65);
      const length = size * (.45 + (i % 3) * .16) * life;
      c.strokeStyle = i % 3 === 0 ? '#fff5d6' : effect.color;
      c.lineWidth = strong ? 3 : 2;
      c.beginPath(); c.moveTo(Math.cos(angle) * inner, Math.sin(angle) * inner);
      c.lineTo(Math.cos(angle) * (inner + length), Math.sin(angle) * (inner + length)); c.stroke();
    }
    if (life > .48) {
      c.globalAlpha = Math.min(1, life * 1.4);
      c.fillStyle = '#fff9df';
      const core = Math.max(2, Math.round(size * .22 * life));
      c.fillRect(-core, -2, core * 2, 4); c.fillRect(-2, -core, 4, core * 2);
      if (strong) { c.rotate(-.65); c.fillRect(-size * .7 * life, -2, size * 1.4 * life, 4); }
    }
    c.restore();
  }

  private pickup(p: Pickup, now: number) {
    const c = this.ctx;
    const x = Math.round(p.x + p.w / 2), y = Math.round(p.y + p.h / 2 + Math.sin(now * 3 + p.bob) * 3);
    c.save(); c.translate(x, y);
    if (p.kind === 'coin') {
      c.scale(.35 + Math.abs(Math.cos(now * 2 + p.bob)) * .65, 1);
      c.fillStyle = '#6e6840'; c.fillRect(-6, -6, 12, 12); c.fillRect(-4, -8, 8, 16);
      c.fillStyle = '#efbd65'; c.fillRect(-5, -5, 10, 10); c.fillRect(-3, -7, 6, 14);
      c.fillStyle = '#ffe5a3'; c.fillRect(-4, -4, 2, 7); c.fillRect(-2, -6, 4, 2);
      c.fillStyle = '#b88646'; c.fillRect(2, -3, 1, 7); c.fillRect(-1, 3, 4, 1);
    } else if (p.kind === 'xp') {
      this.glow(0, 0, 16, '#89f0c6', .12);
      c.fillStyle = '#327f79'; this.pixelDiamond(0, 0, 6, 12);
      c.fillStyle = '#92e7c2'; this.pixelDiamond(-1, -1, 4, 9);
      c.fillStyle = '#daffdd'; c.fillRect(-2, -3, 2, 3);
    } else {
      this.glow(0, 0, 20, '#f3a894', .12);
      this.heart(0, 0, 1);
    }
    c.restore();
  }

  private projectile(p: Projectile, now: number) {
    const c = this.ctx;
    const x = Math.round(p.x + p.w / 2), y = Math.round(p.y + p.h / 2);
    c.save(); c.translate(x, y);
    if (p.kind === 'ember') {
      c.rotate(Math.atan2(p.vy, p.vx));
      this.glow(0, 0, 25, '#ffb16c', .22);
      c.globalAlpha = .36;
      c.fillStyle = '#ffb56d'; c.fillRect(-34, -2, 21, 4); c.fillRect(-43, -1, 7, 2);
      c.globalAlpha = 1;
      c.fillStyle = '#e97d54'; c.fillRect(-15, -3, 16, 6); c.fillRect(-20, -1, 8, 3);
      c.fillStyle = '#ffc17b'; c.fillRect(-7, -6, 12, 12); c.fillRect(-10, -3, 16, 6);
      c.fillStyle = '#ffe9b6'; c.fillRect(-3, -3, 7, 6); c.fillRect(-1, -5, 3, 10);
    } else if (p.kind === 'disc') {
      const length = Math.hypot(p.vx, p.vy) || 1;
      const dx = p.vx / length, dy = p.vy / length;
      c.save(); c.globalAlpha = .2;
      c.strokeStyle = p.returning ? '#8de8e0' : '#b9aaff'; c.lineWidth = 3;
      c.beginPath(); c.moveTo(-dx * 10, -dy * 10); c.lineTo(-dx * 38, -dy * 38); c.stroke();
      c.restore();
      this.glow(0, 0, p.returning ? 27 : 20, p.returning ? '#9af2df' : '#c7baff', p.returning ? .18 : .1);
      this.disc(0, 0, 12, p.rotation || now * 13);
    } else if (p.kind === 'enemy') {
      this.glow(0, 0, 21, '#f7a38a', .16);
      c.fillStyle = '#6f4c6c'; this.pixelDiamond(0, 0, 9, 15);
      c.fillStyle = '#efa185'; this.pixelDiamond(0, 0, 6, 11);
      c.fillStyle = '#ffe0ab'; c.fillRect(-2, -3, 4, 6);
    } else {
      c.fillStyle = '#d77554'; c.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      c.fillStyle = '#ffb97d';
      c.fillRect(-p.w / 2, -p.h / 2, p.w, 3);
      for (let i = -p.w / 2; i < p.w / 2; i += 9) {
        const h = Math.round(4 + Math.sin(now * 18 + i) * 3);
        c.fillRect(i, -p.h / 2 - h, 5, h);
      }
      c.fillStyle = '#ffe4a3'; c.fillRect(-3, -p.h / 2 + 1, 6, p.h - 2);
    }
    c.restore();
  }

  private disc(x: number, y: number, radius: number, rotation: number) {
    const c = this.ctx;
    c.save(); c.translate(x, y); c.rotate(rotation);
    c.fillStyle = '#4f526e';
    c.fillRect(-radius + 2, -radius + 2, radius * 2 - 4, radius * 2 - 4);
    c.fillStyle = '#b6b1ea';
    c.fillRect(-radius, -5, radius * 2, 10); c.fillRect(-5, -radius, 10, radius * 2);
    c.fillStyle = '#eee1ff'; c.fillRect(-radius + 1, -5, 5, 2); c.fillRect(-5, -radius + 1, 2, 5);
    c.fillStyle = '#203b46'; c.fillRect(-4, -4, 8, 8);
    c.fillStyle = '#e9cba0'; c.fillRect(-2, -2, 4, 4);
    c.restore();
  }

  private heart(x: number, y: number, scale: number) {
    const c = this.ctx;
    c.save(); c.translate(x, y); c.scale(scale, scale);
    c.fillStyle = '#6c4149';
    c.fillRect(-7, -5, 6, 4); c.fillRect(1, -5, 6, 4); c.fillRect(-9, -2, 18, 6); c.fillRect(-6, 4, 12, 3); c.fillRect(-3, 7, 6, 3);
    c.fillStyle = '#ef9e87'; c.fillRect(-6, -3, 5, 3); c.fillRect(1, -3, 5, 3); c.fillRect(-7, 0, 14, 4); c.fillRect(-4, 4, 8, 3); c.fillRect(-1, 7, 2, 1);
    c.fillStyle = '#ffd0a8'; c.fillRect(-5, -2, 3, 2); c.fillRect(-6, 0, 2, 2);
    c.restore();
  }

  private pixelDiamond(x: number, y: number, half: number, height: number) {
    const c = this.ctx;
    const top = y - height / 2;
    for (let row = 0; row < height; row += 2) {
      const width = Math.max(2, Math.ceil((1 - Math.abs(row / height * 2 - 1)) * half / 2) * 2);
      c.fillRect(Math.round(x - width), Math.round(top + row), width * 2, 2);
    }
  }

  private shadow(x: number, y: number, half: number, alpha: number) {
    const c = this.ctx;
    c.save(); c.globalAlpha *= alpha; c.fillStyle = '#061b22';
    c.fillRect(Math.round(x - half), Math.round(y - 2), Math.round(half * 2), 4);
    c.fillRect(Math.round(x - half * .7), Math.round(y - 4), Math.round(half * 1.4), 8);
    c.restore();
  }

  private glow(x: number, y: number, radius: number, color: string, alpha: number) {
    const c = this.ctx;
    const g = c.createRadialGradient(x, y, 1, x, y, radius);
    g.addColorStop(0, color); g.addColorStop(1, `${color}00`);
    c.save(); c.globalAlpha *= alpha; c.fillStyle = g; c.fillRect(x - radius, y - radius, radius * 2, radius * 2); c.restore();
  }

  private ambient(camera: number, now: number, theme: number) {
    const c = this.ctx;
    for (let i = 0; i < 24; i++) {
      const x = ((hash(i, 92) * 1150 - camera * .65 + Math.sin(now * .4 + i) * 20) % 1150 + 1150) % 1150 - 90;
      const y = 130 + hash(i, 91) * 345 + Math.sin(now * .7 + i * 2) * 12;
      const alpha = .15 + Math.max(0, Math.sin(now * .9 + i)) * .55;
      c.globalAlpha = alpha;
      c.fillStyle = theme === 1 || theme === 5 || theme === 7 ? '#eab17a' : '#d8d6a0'; c.fillRect(Math.round(x), Math.round(y), 2, 2);
      if (i % 4 === 0) {
        c.globalAlpha = alpha * .1;
        c.fillRect(Math.round(x) - 3, Math.round(y) - 3, 8, 8);
      }
    }
    c.globalAlpha = 1;
  }

  private awakeningBackdrop(camera: number, now: number, strength: number) {
    const c = this.ctx;
    c.save();
    c.globalAlpha = strength;
    c.fillStyle = '#07172a70';
    c.fillRect(0, 0, W, H);
    const x = 660 - (camera * .03 % 100), y = 161;
    this.glow(x, y, 230, '#6bbee8', .18);
    c.save(); c.translate(x, y); c.rotate(now * .045);
    c.strokeStyle = '#a6d9eb'; c.lineWidth = 1;
    c.globalAlpha = strength * .21;
    c.beginPath(); c.arc(0, 0, 111, 0, TAU); c.stroke();
    c.beginPath(); c.arc(0, 0, 121, 0, TAU); c.stroke();
    c.beginPath(); c.arc(0, 0, 151, 0, TAU); c.stroke();
    for (let i = 0; i < 12; i++) {
      const angle = i / 12 * TAU;
      const px = Math.cos(angle) * 136, py = Math.sin(angle) * 136;
      c.save(); c.translate(px, py); c.rotate(angle);
      c.strokeRect(-4, -4, 8, 8);
      c.beginPath(); c.moveTo(12, 0); c.lineTo(23, 0); c.stroke(); c.restore();
    }
    c.globalAlpha = strength * .35;
    c.strokeStyle = '#c1e9de';
    c.beginPath();
    for (let i = 0; i < 6; i++) {
      const angle = i / 5 * TAU * 2 - Math.PI / 2;
      const px = Math.cos(angle) * 101, py = Math.sin(angle) * 101;
      if (i === 0) c.moveTo(px, py); else c.lineTo(px, py);
    }
    c.stroke(); c.restore();
    for (let i = 0; i < 18; i++) {
      const px = ((hash(i, 150) * 1250 - now * 24 - camera * .13) % 1250 + 1250) % 1250 - 90;
      const py = ((hash(i, 151) * 520 + now * 11) % 520);
      c.globalAlpha = strength * (.2 + Math.sin(now * 2 + i) * .15);
      c.fillStyle = i % 3 ? '#a0e4f3' : '#ffe1a5';
      c.fillRect(Math.round(px), Math.round(py), 3, 2);
      c.fillRect(Math.round(px) + 4, Math.round(py) - 2, 8, 1);
    }
    c.restore();
  }

  private menuScene(state: GameState, now: number) {
    const c = this.ctx;
    this.palette = PALETTES[0];
    this.background(0, 0, now);
    // The menu uses the same ritual machinery as the playable regions.
    c.save(); c.globalAlpha = .74;
    this.bamboo(943, 474, 1.4, '#254a42');
    this.pavilion(895, 458, .66, '#29423e', '#8e9a78', false);
    this.ruin(570, 460, .63); c.restore();
    this.glow(716, 298, 178, '#8ed5af', .10);
    this.celestial(716, 276, 97, now * .45, .21);
    this.gate(716, 417, 1.17, true);
    c.save();
    const beam = c.createLinearGradient(0, 210, 0, 417);
    beam.addColorStop(0, '#bce7c200'); beam.addColorStop(.6, '#8ac3ad0d'); beam.addColorStop(1, '#d4dfad22');
    c.fillStyle = beam; c.fillRect(653, 210, 125, 207); c.restore();
    this.platform({ x: 589, y: 416, w: 253, h: 32, kind: 'stone' }, 0);
    this.platform({ x: 526, y: 340 + Math.round(Math.sin(now) * 3), w: 66, h: 22, kind: 'stone' }, 0);
    this.platform({ x: 860, y: 337 + Math.round(Math.sin(now + 1.7) * 4), w: 61, h: 24, kind: 'stone' }, 0);
    this.platform({ x: 0, y: 482, w: W, h: 58, kind: 'ground' }, 0);
    this.platform({ x: 425, y: 461, w: 180, h: 79, kind: 'ground' }, 0);
    this.platform({ x: 841, y: 460, w: 119, h: 80, kind: 'ground' }, 0);
    this.lamp(879, 461, .95, now);
    this.decoration({ x: 611, y: 416, kind: 'crystal', scale: .8 });
    this.decoration({ x: 789, y: 416, kind: 'grass', scale: 1.3 });
    this.decoration({ x: 801, y: 416, kind: 'mushroom', scale: .8 });
    this.decoration({ x: 932, y: 460, kind: 'mushroom', scale: 1.5 });
    const menuHero = { ...state.hero, x: 678, y: 380, w: 28, h: 36, vx: 0, vy: 0, facing: 1, grounded: true, invincible: 0, dashTimer: 0, attackTimer: 0, shield: 0 };
    this.hero(menuHero, now, 1.62);
    // A little forest spirit watches from a lower ledge.
    const slime: Enemy = { id: 0, kind: 'slime', x: 477, y: 432, w: 33, h: 29, vx: 0, vy: 0, hp: 1, maxHp: 1, facing: 1, timer: now, hurt: 0, dead: false, originX: 477, originY: 432, attackCooldown: 0 };
    this.enemy(slime, now);
    for (let i = 0; i < 3; i++) {
      const x = 546 + i * 30;
      this.pickup({ id: i, x, y: 287 - Math.sin(i) * 20, w: 12, h: 14, kind: 'coin', value: 1, vy: 0, bob: i, collected: false }, now);
    }
    this.ambient(0, now, 0);
    // Ground foreground grasses and warm drifting lights finish the composition.
    for (let i = 0; i < 10; i++) this.decoration({ x: 416 + i * 59, y: 483, kind: 'grass', scale: .7 + hash(i, 90) * .8 });
    const shade = c.createLinearGradient(0, 0, 650, 0);
    shade.addColorStop(0, '#10232bec'); shade.addColorStop(.65, '#10232b9e'); shade.addColorStop(1, '#10232b00');
    c.fillStyle = shade; c.fillRect(0, 0, 650, H);
    const bottom = c.createLinearGradient(0, 440, 0, H);
    bottom.addColorStop(0, '#0a1b2300'); bottom.addColorStop(1, '#0a1b2388');
    c.fillStyle = bottom; c.fillRect(0, 440, W, 100);
  }
}
