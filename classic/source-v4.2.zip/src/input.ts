import { EMPTY_INPUT, type InputState } from './game/types';
import { CONTROL_ACTIONS, KEY_STORAGE, bindingConflict, bindableKey, defaultBindings, keyLabel, parseBindings, stickVector, type ControlAction, type KeyBindings } from './controls';

type Action = 'left' | 'right' | 'jump' | 'attack' | 'dash' | 'guard' | 'interact' | 'overdrive';
export class GameInput {
  private keys: KeyBindings = defaultBindings();
  private joystick: HTMLElement | null = null;
  private stickPointer: number | null = null;
  private held = new Map<string, Action>();
  private edges = new Set<Action>();
  private gamepadLast = [false, false, false, false, false, false];
  constructor(private active: () => boolean, private shortcut: (key: string) => void) {
    try { this.keys = parseBindings(JSON.parse(localStorage.getItem(KEY_STORAGE) || 'null')); } catch { /* Storage is optional. */ }
    window.addEventListener('keydown', e => {
      if(e.code==='Escape'){if(!e.repeat)this.shortcut(e.code);e.preventDefault();return;}
      if ((e.target as HTMLElement).closest('input,textarea,select,[contenteditable]')) return;
      const mapped = CONTROL_ACTIONS.find(action => this.keys[action].includes(e.code));
      if (mapped === 'pause' || mapped?.startsWith('weapon')) {
        if (!e.repeat) this.shortcut(mapped === 'pause' ? 'KeyP' : `Digit${mapped.slice(-1)}`);
        if (this.active()) e.preventDefault();
        return;
      }
      const action = mapped as Action | undefined;
      if (action && this.active()) {
        e.preventDefault();
        if (!this.held.has(e.code)) this.edges.add(action);
        this.held.set(e.code, action);
      }
    });
    window.addEventListener('keyup', e => this.held.delete(e.code));
    window.addEventListener('blur', () => this.clear());
    document.querySelectorAll<HTMLButtonElement>('[data-touch]').forEach(button => {
      if (button.dataset.touch === 'move') return;
      const action = button.dataset.touch as Action;
      button.addEventListener('pointerdown', e => {
        if (!this.active()) return;
        e.preventDefault();
        button.setPointerCapture(e.pointerId);
        const key = `pointer-${e.pointerId}`;
        this.held.set(key, action);
        this.edges.add(action);
        button.classList.add('pressed');
      });
      const release = (e: PointerEvent) => {
        this.held.delete(`pointer-${e.pointerId}`);
        button.classList.remove('pressed');
      };
      button.addEventListener('pointerup', release);
      button.addEventListener('pointercancel', release);
      button.addEventListener('lostpointercapture', release);
    });
    this.joystick = document.querySelector<HTMLElement>('[data-touch="move"]');
    if (this.joystick) {
      const stick = this.joystick;
      const move = (e: PointerEvent) => {
        if (this.stickPointer !== e.pointerId) return;
        if (!this.active()) { this.releaseStick(); return; }
        e.preventDefault();
        const rect = stick.getBoundingClientRect();
        const rotated = document.body.classList.contains('virtual-landscape');
        const radius = (rotated ? rect.height : rect.width) * .36;
        const vector = stickVector(e.clientX - rect.left - rect.width / 2, e.clientY - rect.top - rect.height / 2, radius, rotated);
        this.held.delete('stick-left'); this.held.delete('stick-right');
        if (vector.x < -.15) this.held.set('stick-left', 'left');
        if (vector.x > .15) this.held.set('stick-right', 'right');
        stick.style.setProperty('--stick-x', `${vector.x * radius}px`);
        stick.style.setProperty('--stick-y', `${vector.y * radius}px`);
      };
      stick.addEventListener('pointerdown', e => {
        if (!this.active() || this.stickPointer !== null) return;
        e.preventDefault(); this.stickPointer = e.pointerId;
        try { stick.setPointerCapture(e.pointerId); } catch { /* Window release remains available. */ }
        stick.classList.add('pressed'); move(e);
      });
      stick.addEventListener('pointermove', move);
      const release = (e: PointerEvent) => { if (this.stickPointer === e.pointerId) this.releaseStick(); };
      for (const event of ['pointerup', 'pointercancel', 'lostpointercapture'] as const) stick.addEventListener(event, release);
      window.addEventListener('pointerup', release); window.addEventListener('pointercancel', release);
      window.addEventListener('resize', () => this.releaseStick());
    }
  }
  get bindings(): KeyBindings { return Object.fromEntries(CONTROL_ACTIONS.map(action => [action, [...this.keys[action]]])) as KeyBindings; }
  keyLabel(action: ControlAction): string { return keyLabel(this.keys[action][0]); }
  rebind(action: ControlAction, code: string): { ok: boolean; conflict?: ControlAction } {
    if (!bindableKey(code)) return { ok: false };
    const conflict = bindingConflict(this.keys, action, code);
    if (conflict) return { ok: false, conflict };
    this.clear(); this.keys[action] = [code]; this.persistKeys(); return { ok: true };
  }
  resetBindings(): void { this.clear(); this.keys = defaultBindings(); this.persistKeys(); }
  private persistKeys(): void { try { localStorage.setItem(KEY_STORAGE, JSON.stringify({ v: 1, bindings: this.keys })); } catch { /* Session bindings still work. */ } }
  private releaseStick(): void {
    const pointer = this.stickPointer; this.stickPointer = null;
    this.held.delete('stick-left'); this.held.delete('stick-right');
    this.joystick?.classList.remove('pressed');
    this.joystick?.style.setProperty('--stick-x', '0px'); this.joystick?.style.setProperty('--stick-y', '0px');
    if (pointer !== null) { try { if (this.joystick?.hasPointerCapture(pointer)) this.joystick.releasePointerCapture(pointer); } catch { /* Capture may already be lost. */ } }
  }
  read(): InputState {
    const values = [...this.held.values()];
    const input: InputState = {
      left: values.includes('left'), right: values.includes('right'),
      jumpHeld: values.includes('jump'), attackHeld: values.includes('attack'),
      jumpPressed: this.edges.has('jump'), attackPressed: this.edges.has('attack'),
      dashPressed: this.edges.has('dash'), interactPressed: this.edges.has('interact'), overdrivePressed: this.edges.has('overdrive'),
      guardPressed: this.edges.has('guard'),
    };
    this.edges.clear();
    if (this.active()) {
      const pad = navigator.getGamepads?.()?.[0];
      if (pad) {
        input.left ||= pad.axes[0] < -.25 || pad.buttons[14]?.pressed;
        input.right ||= pad.axes[0] > .25 || pad.buttons[15]?.pressed;
        const buttons = [pad.buttons[0]?.pressed || false, pad.buttons[2]?.pressed || pad.buttons[7]?.pressed || false, pad.buttons[1]?.pressed || false, pad.buttons[3]?.pressed || false, pad.buttons[4]?.pressed || false, pad.buttons[5]?.pressed || false];
        input.jumpHeld ||= buttons[0]; input.attackHeld ||= buttons[1];
        input.jumpPressed ||= buttons[0] && !this.gamepadLast[0];
        input.attackPressed ||= buttons[1] && !this.gamepadLast[1];
        input.dashPressed ||= buttons[2] && !this.gamepadLast[2];
        input.interactPressed ||= buttons[3] && !this.gamepadLast[3];
        input.overdrivePressed ||= buttons[4] && !this.gamepadLast[4];
        input.guardPressed ||= buttons[5] && !this.gamepadLast[5];
        this.gamepadLast = buttons;
      }
    }
    return input;
  }
  clear(): void {
    this.releaseStick();
    this.held.clear(); this.edges.clear(); this.gamepadLast.fill(false);
    document.querySelectorAll('.pressed').forEach(el => el.classList.remove('pressed'));
  }
  trigger(action: Action): void { if (this.active()) this.edges.add(action); }
}
export function withoutEdges(input: InputState): InputState {
  return { ...input, jumpPressed: false, attackPressed: false, dashPressed: false, guardPressed: false, interactPressed: false, overdrivePressed: false };
}
export function mergeInput(a: InputState, b: InputState): InputState {
  return { ...b, jumpPressed: a.jumpPressed || b.jumpPressed, attackPressed: a.attackPressed || b.attackPressed, dashPressed: a.dashPressed || b.dashPressed, guardPressed: a.guardPressed || b.guardPressed, interactPressed: a.interactPressed || b.interactPressed, overdrivePressed: a.overdrivePressed || b.overdrivePressed };
}
export { EMPTY_INPUT };
