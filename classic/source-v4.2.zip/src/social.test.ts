import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { clearRecords, decodeChallenge, encodeChallenge, formatTime, getDailySeed, getPlayerName, getRecords, makeChallengeUrl, randomSeed, saveRecord, setPlayerName, type Challenge } from './social';
import { GameAudio } from './game/audio';
import type { GameResult } from './game/types';

const result = (overrides: Partial<GameResult> = {}): GameResult => ({
  seed: 123456, modifier: 'standard', weapon: 'blade', won: true, time: 183.426, score: 9400,
  coins: 36, kills: 18, level: 5, deaths: 1, roomsCleared: 4, maxCombo: 8,
  upgrades: ['quickstep', 'double-ember'], overdriveCount: 2, synergies: ['firestorm', 'echo-blade'], ...overrides,
});
const challenge = (): Challenge => ({ v: 1, seed: 123456, modifier: 'standard', weapon: 'blade', rival: { name: '小焰和朋友🌙', result: result() } });

function rawCode(payload: unknown): string {
  const bytes = new TextEncoder().encode(JSON.stringify(payload));
  const encoded = btoa(Array.from(bytes, (byte) => String.fromCharCode(byte)).join('')).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  let hash = 2166136261;
  for (let i = 0; i < encoded.length; i++) hash = Math.imul(hash ^ encoded.charCodeAt(i), 16777619);
  return `SH1.${encoded}.${(hash >>> 0).toString(16).padStart(8, '0')}`;
}

function memoryStorage(): Storage {
  const values = new Map<string, string>();
  return {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => { values.set(key, String(value)); },
    removeItem: (key) => { values.delete(key); },
    clear: () => values.clear(),
    key: (index) => [...values.keys()][index] ?? null,
    get length() { return values.size; },
  };
}

beforeEach(() => { vi.stubGlobal('localStorage', memoryStorage()); clearRecords(); setPlayerName('星际旅人'); });
afterEach(() => { vi.unstubAllGlobals(); vi.useRealTimers(); });

describe('challenge links', () => {
  it('round trips the actual winning result, initial weapon and a Unicode name', () => {
    const data = challenge();
    expect(decodeChallenge(encodeChallenge(data))).toEqual(data);
  });
  it('round trips awakening and synergy achievements without inventing missing legacy achievements', () => {
    const data = challenge();
    const decoded = decodeChallenge(encodeChallenge(data));
    expect(decoded.rival?.result.overdriveCount).toBe(2);
    expect(decoded.rival?.result.synergies).toEqual(['firestorm', 'echo-blade']);
    const legacy = structuredClone(data) as unknown as { rival: { result: Record<string, unknown> } };
    delete legacy.rival.result.overdriveCount;
    delete legacy.rival.result.synergies;
    const legacyDecoded = decodeChallenge(rawCode(legacy));
    expect(legacyDecoded.rival?.result.overdriveCount).toBe(0);
    expect(legacyDecoded.rival?.result.synergies).toEqual([]);
  });
  it('round trips a full URL without losing path or an existing query', () => {
    const link = makeChallengeUrl(challenge(), 'https://example.test/starhop/?lang=zh#old');
    expect(link).toContain('https://example.test/starhop/?lang=zh#c=SH1.');
    expect(decodeChallenge(link)).toEqual(challenge());
    expect(decodeChallenge(new URL(link).hash)).toEqual(challenge());
  });
  it('supports all modifiers, all weapons and unsigned 32-bit boundary seeds', () => {
    for (const modifier of ['standard', 'moon', 'haste', 'iron'] as const) {
      for (const weapon of ['blade', 'ember', 'disc'] as const) {
        for (const seed of [0, 0xffffffff]) {
          const data: Challenge = { v: 1, seed, modifier, weapon };
          expect(decodeChallenge(encodeChallenge(data))).toEqual(data);
        }
      }
    }
  });
  it('rejects corruption, truncation, empty and oversized pasted input', () => {
    const code = encodeChallenge(challenge());
    expect(() => decodeChallenge(code.slice(0, -1))).toThrow(/挑战/);
    expect(() => decodeChallenge(code.replace('SH1.', 'SH1.a'))).toThrow(/挑战/);
    expect(() => decodeChallenge('')).toThrow(/粘贴/);
    expect(() => decodeChallenge('x'.repeat(16001))).toThrow(/过长/);
    expect(() => decodeChallenge('https://example.test/#no-challenge')).toThrow(/挑战/);
  });
  it('validates config and all imported result numbers instead of accepting arbitrary JSON', () => {
    expect(() => encodeChallenge({ ...challenge(), seed: -1 })).toThrow();
    expect(() => encodeChallenge({ ...challenge(), seed: 1.2 })).toThrow();
    expect(() => encodeChallenge({ ...challenge(), seed: Infinity })).toThrow();
    expect(() => encodeChallenge({ ...challenge(), modifier: 'custom' as never })).toThrow(/规则/);
    expect(() => encodeChallenge({ ...challenge(), weapon: 'gun' as never })).toThrow(/武器/);
    for (const invalid of [{ time: -1 }, { time: NaN }, { score: 0.2 }, { kills: -1 }, { level: 0 }, { seed: 99 }, { modifier: 'moon' as const }, { upgrades: ['<script>'] }]) {
      expect(() => encodeChallenge({ ...challenge(), rival: { name: '好友', result: result(invalid) } })).toThrow();
    }
  });
  it('rejects unsupported versions and strips markup/control characters from names', () => {
    expect(() => encodeChallenge({ ...challenge(), v: 2 as never })).toThrow(/版本/);
    const data = { ...challenge(), rival: { name: '<好友>\u202e', result: result() } };
    expect(decodeChallenge(encodeChallenge(data)).rival?.name).toBe('好友');
  });
  it('rejects failed runs and different starting weapons as rival records, including legacy payloads', () => {
    for (const invalid of [{ won: false }, { weapon: 'ember' as const }, { weapon: 'disc' as const }]) {
      const data: Challenge = { ...challenge(), rival: { name: '好友', result: result(invalid) } };
      expect(() => encodeChallenge(data)).toThrow(/通关|条件/);
      expect(() => decodeChallenge(rawCode(data))).toThrow(/通关|条件/);
      const legacy = structuredClone(data) as unknown as { rival: { result: Record<string, unknown> } };
      delete legacy.rival.result.overdriveCount;
      delete legacy.rival.result.synergies;
      expect(() => decodeChallenge(rawCode(legacy))).toThrow(/通关|条件/);
    }
  });
  it('rejects malformed awakening/synergy fields, including valid-checksum malicious payloads', () => {
    for (const invalid of [
      { overdriveCount: -1 }, { overdriveCount: 1.5 }, { overdriveCount: '2' }, { overdriveCount: null },
      { overdriveCount: 100001 }, { synergies: null }, { synergies: 'firestorm' },
      { synergies: ['<img onerror=alert(1)>'] }, { synergies: [3] }, { synergies: ['x'.repeat(65)] },
      { synergies: Array.from({ length: 33 }, () => 'firestorm') },
    ]) {
      const data = { ...challenge(), rival: { name: '好友', result: { ...result(), ...invalid } } };
      expect(() => encodeChallenge(data as Challenge)).toThrow();
      expect(() => decodeChallenge(rawCode(data))).toThrow();
    }
  });
});

describe('dates and time', () => {
  it('changes daily seed at Hong Kong midnight, not UTC midnight', () => {
    const early = getDailySeed(new Date('2026-11-15T16:00:00.000Z'));
    expect(getDailySeed(new Date('2026-11-16T15:59:59.999Z'))).toBe(early);
    expect(getDailySeed(new Date('2026-11-16T16:00:00.000Z'))).not.toBe(early);
    expect(getDailySeed(new Date('2026-11-15T15:59:59.999Z'))).not.toBe(early);
  });
  it('formats stable centisecond results without rollover rounding', () => {
    expect(formatTime(0)).toBe('00:00.00');
    expect(formatTime(59.999)).toBe('00:59.99');
    expect(formatTime(60)).toBe('01:00.00');
    expect(formatTime(183.426)).toBe('03:03.42');
    expect(formatTime(NaN)).toBe('00:00.00');
    expect(formatTime(-1)).toBe('00:00.00');
  });
  it('makes seeds in the supported unsigned integer range', () => {
    for (let i = 0; i < 32; i++) { const seed = randomSeed(); expect(Number.isInteger(seed)).toBe(true); expect(seed).toBeGreaterThanOrEqual(0); expect(seed).toBeLessThanOrEqual(0xffffffff); }
  });
});

describe('local identity and real run history', () => {
  it('sanitizes the name and caps Unicode code points without splitting emoji', () => {
    expect(setPlayerName('  <小焰>\n  好友  ')).toBe('小焰 好友');
    expect(Array.from(setPlayerName('🌙'.repeat(20)))).toHaveLength(12);
    expect(setPlayerName(' ')).toBe('星际旅人');
    expect(getPlayerName()).toBe('星际旅人');
  });
  it('stores actual results, keeps recent history capped, and returns safe copies', () => {
    for (let i = 0; i < 55; i++) saveRecord(`玩家${i}`, result({ score: i }));
    const records = getRecords();
    expect(records).toHaveLength(50);
    expect(records[0].result.score).toBe(54);
    expect(records[49].result.score).toBe(5);
    expect(new Set(records.map((record) => record.id)).size).toBe(50);
    records[0].result.upgrades.push('modified');
    records[0].result.synergies.push('modified-synergy');
    expect(getRecords()[0].result.upgrades).not.toContain('modified');
    expect(getRecords()[0].result.synergies).not.toContain('modified-synergy');
    clearRecords();
    expect(getRecords()).toEqual([]);
  });
  it('recovers from corrupted or partially invalid saved data', () => {
    localStorage.setItem('starhop.runs.v1', '{broken');
    expect(getRecords()).toEqual([]);
    const good = saveRecord('好朋友', result());
    localStorage.setItem('starhop.runs.v1', JSON.stringify([{ id: 'broken' }, good]));
    expect(getRecords()).toEqual([good]);
    localStorage.setItem('starhop.runs.v1', JSON.stringify({ not: 'an array' }));
    expect(getRecords()).toEqual([]);
  });
  it('loads pre-awakening saved records with zero/empty defaults', () => {
    const good = saveRecord('早期旅人', result());
    const legacy = structuredClone(good) as unknown as { result: Record<string, unknown> };
    delete legacy.result.overdriveCount;
    delete legacy.result.synergies;
    localStorage.setItem('starhop.runs.v1', JSON.stringify([legacy]));
    expect(getRecords()[0].result.overdriveCount).toBe(0);
    expect(getRecords()[0].result.synergies).toEqual([]);
  });
  it('keeps working when the storage API throws', () => {
    vi.stubGlobal('localStorage', { getItem() { throw new Error('denied'); }, setItem() { throw new Error('denied'); } });
    expect(setPlayerName('离线旅人')).toBe('离线旅人');
    expect(getPlayerName()).toBe('离线旅人');
    saveRecord('离线旅人', result());
    expect(getRecords()).toHaveLength(1);
    clearRecords();
    expect(getRecords()).toEqual([]);
  });
  it('preserves newer names and records when reads work but writes exceed quota, then recovers', () => {
    const storage = memoryStorage();
    vi.stubGlobal('localStorage', storage);
    setPlayerName('旧昵称');
    saveRecord('旧昵称', result({ score: 100 }));
    let readOnly = true;
    vi.stubGlobal('localStorage', {
      getItem: storage.getItem,
      setItem(key: string, value: string) { if (readOnly) throw new Error('QuotaExceededError'); storage.setItem(key, value); },
    });
    setPlayerName('新昵称');
    expect(getPlayerName()).toBe('新昵称');
    expect(storage.getItem('starhop.player.v1')).toBe('旧昵称');
    saveRecord('新昵称', result({ score: 200 }));
    expect(getRecords().map((record) => record.result.score)).toEqual([200, 100]);
    saveRecord('新昵称', result({ score: 300 }));
    expect(getRecords().map((record) => record.result.score)).toEqual([300, 200, 100]);
    expect(JSON.parse(storage.getItem('starhop.runs.v1')!)).toHaveLength(1);
    // A successful write persists all newer memory and allows subsequent storage reads again.
    readOnly = false;
    setPlayerName('恢复昵称');
    saveRecord('恢复昵称', result({ score: 400 }));
    expect(getPlayerName()).toBe('恢复昵称');
    expect(getRecords().map((record) => record.result.score)).toEqual([400, 300, 200, 100]);
    expect(JSON.parse(storage.getItem('starhop.runs.v1')!)).toHaveLength(4);
    storage.setItem('starhop.player.v1', '其他标签页');
    storage.setItem('starhop.runs.v1', '[]');
    expect(getPlayerName()).toBe('其他标签页');
    expect(getRecords()).toEqual([]);
  });
  it('keeps quota-failed keys independent and preserves a clear while storage is read-only', () => {
    const storage = memoryStorage();
    vi.stubGlobal('localStorage', storage);
    setPlayerName('名字');
    saveRecord('名字', result());
    vi.stubGlobal('localStorage', {
      getItem: storage.getItem,
      setItem(key: string, value: string) { if (key === 'starhop.runs.v1') throw new Error('QuotaExceededError'); storage.setItem(key, value); },
    });
    clearRecords();
    expect(getRecords()).toEqual([]);
    expect(JSON.parse(storage.getItem('starhop.runs.v1')!)).toHaveLength(1);
    setPlayerName('成功写入');
    expect(getPlayerName()).toBe('成功写入');
    storage.setItem('starhop.player.v1', '外部修改');
    expect(getPlayerName()).toBe('外部修改');
    expect(getRecords()).toEqual([]);
  });
  it('rejects corrupt internal result data before it can enter saved history', () => {
    expect(() => saveRecord('好友', result({ score: Infinity }))).toThrow();
    expect(getRecords()).toEqual([]);
  });
});

describe('optional browser audio', () => {
  it('is safe without AudioContext, preserves mute, and disposes repeatedly', async () => {
    const audio = new GameAudio();
    await expect(audio.unlock()).resolves.toBeUndefined();
    audio.setMusic(true);
    audio.play('win');
    audio.setMuted(true);
    expect(audio.muted).toBe(true);
    audio.setMusic(false);
    audio.dispose();
    audio.dispose();
  });
  it('unlocks once, keeps one music scheduler, clears paused music, and respects mute', async () => {
    vi.useFakeTimers();
    const parameter = () => ({ value: 0, setValueAtTime: vi.fn(), exponentialRampToValueAtTime: vi.fn(), setTargetAtTime: vi.fn() });
    class FakeSource {
      type = '';
      frequency = parameter();
      buffer: unknown = null;
      onended: (() => void) | null = null;
      connect = vi.fn();
      disconnect = vi.fn();
      start = vi.fn();
      immediateStops = 0;
      stop = vi.fn((at?: number) => { if (at === undefined) { this.immediateStops++; this.onended?.(); } });
    }
    const contexts: FakeAudioContext[] = [];
    class FakeAudioContext {
      state = 'suspended';
      currentTime = 10;
      sampleRate = 8000;
      destination = {};
      sources: FakeSource[] = [];
      gains: ReturnType<FakeAudioContext['createGain']>[] = [];
      constructor() { contexts.push(this); }
      resume = vi.fn(async () => { this.state = 'running'; });
      close = vi.fn(async () => { this.state = 'closed'; });
      createGain(): { gain: ReturnType<typeof parameter>; connect: ReturnType<typeof vi.fn>; disconnect: ReturnType<typeof vi.fn> } {
        const gain = { gain: parameter(), connect: vi.fn(), disconnect: vi.fn() };
        this.gains.push(gain);
        return gain;
      }
      createDynamicsCompressor() { return { threshold: parameter(), knee: parameter(), ratio: parameter(), connect: vi.fn() }; }
      createBuffer(_channels: number, length: number) { return { getChannelData: () => new Float32Array(length) }; }
      createBiquadFilter() { return { type: '', frequency: parameter(), connect: vi.fn(), disconnect: vi.fn() }; }
      createOscillator() { const source = new FakeSource(); this.sources.push(source); return source; }
      createBufferSource() { const source = new FakeSource(); this.sources.push(source); return source; }
    }
    vi.stubGlobal('AudioContext', FakeAudioContext);
    const audio = new GameAudio();
    audio.setMusic(true);
    expect(vi.getTimerCount()).toBe(0);
    await Promise.all([audio.unlock(), audio.unlock()]);
    expect(contexts).toHaveLength(1);
    const ctx = contexts[0];
    expect(vi.getTimerCount()).toBe(1);
    const firstMusicSources = ctx.sources.length;
    expect(firstMusicSources).toBeGreaterThan(0);
    audio.setMusic(true);
    await audio.unlock();
    expect(vi.getTimerCount()).toBe(1);
    expect(ctx.sources).toHaveLength(firstMusicSources);
    audio.setMusic(false);
    expect(vi.getTimerCount()).toBe(0);
    expect(ctx.sources.every((source) => source.immediateStops === 1)).toBe(true);
    audio.setMusic(true);
    expect(vi.getTimerCount()).toBe(1);
    audio.setMuted(true);
    expect(ctx.gains[0].gain.setTargetAtTime).toHaveBeenLastCalledWith(0, 10, 0.015);
    const mutedSources = ctx.sources.length;
    audio.play('awaken');
    audio.play('synergy');
    expect(ctx.sources).toHaveLength(mutedSources);
    audio.setMuted(false);
    audio.play('awaken');
    const afterAwaken = ctx.sources.length;
    expect(afterAwaken).toBeGreaterThan(mutedSources);
    audio.play('synergy');
    expect(ctx.sources.length).toBeGreaterThan(afterAwaken);
    audio.dispose();
    expect(vi.getTimerCount()).toBe(0);
    expect(ctx.close).toHaveBeenCalledOnce();
    expect(ctx.sources.every((source) => source.immediateStops === 1)).toBe(true);
    audio.setMusic(true);
    await audio.unlock();
    expect(vi.getTimerCount()).toBe(0);
    expect(contexts).toHaveLength(1);
  });
});
