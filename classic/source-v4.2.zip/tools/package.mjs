import { readFile, writeFile, mkdir, readdir, copyFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let html = await readFile(path.join(root, 'dist/index.html'), 'utf8');
const script = html.match(/<script[^>]*src="([^"]+)"[^>]*><\/script>/);
const style = html.match(/<link[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/);
if (!script || !style) throw new Error('The Vite output must contain a script and stylesheet.');
let js = await readFile(path.join(root, 'dist', script[1]), 'utf8');
let css = await readFile(path.join(root, 'dist', style[1]), 'utf8');
// Keep the web build cacheable while making the delivered HTML truly portable.
for (const file of await readdir(path.join(root, 'dist/assets'))) {
  if (!file.endsWith('.png')) continue;
  const data = `data:image/png;base64,${(await readFile(path.join(root, 'dist/assets', file))).toString('base64')}`;
  for (const relative of [`./assets/${file}`, `assets/${file}`, `/assets/${file}`, file]) {
    js = js.replaceAll(JSON.stringify(relative), JSON.stringify(data));
    css = css.replaceAll(relative, data);
  }
}
const favicon = await readFile(path.join(root,'public/favicon.svg'),'utf8');
html = html.replace(script[0], () => `<script type="module">${js.replace(/<\/script/gi,'<\\/script')}</script>`)
  .replace(style[0], () => `<style>${css}</style>`)
  .replace(/href="\.\/favicon.svg"/, () => `href="data:image/svg+xml,${encodeURIComponent(favicon)}"`);
const delivery = path.join(root, 'delivery');
await mkdir(delivery, { recursive: true });
await copyFile(path.join(root, 'docs/素材来源与许可.md'), path.join(delivery, '素材来源与许可.md'));
await writeFile(path.join(delivery, '星跃远征.html'), html, 'utf8');
await writeFile(path.join(delivery, '开始游戏.cmd'), '@echo off\r\nchcp 65001 >nul\r\nstart "" "%~dp0星跃远征.html"\r\n', 'utf8');
const playGuide = `星跃远征 v4.2 / STARHOP

公共游玩链接：https://le3334515-tech.github.io/starhop-expedition/classic/
电脑和手机打开链接即可游玩，无需安装。分享此链接，朋友不需要连接同一 Wi-Fi。
离线游玩：直接双击“星跃远征.html”；游戏画面、角色和特效已内嵌，无需安装。

本版基于提供的 v4.1，沿用原像素武侠画风、人物素材与八幕主题。
增加章节剧情，丰富主路与高台支路，调整平台衔接、起跳与落地体验。
三种武器各有战斗反馈；闪避可伤敌，升级恢复生命，地图可拾取回血补给。
Boss 战支持格挡与精准格挡；留意攻击预警，抓住反击时机。

默认电脑操作
A/D 或方向键：移动
空格/K：跳跃、二段跳，长按跳得更高
J/X：攻击；按住短刃攻击可打出三连重斩
Shift/L：闪避
F：格挡；在攻击即将命中时起手可精准格挡
1/2/3：切换短刃、萤火法杖、回声飞轮
Q：星能蓄满后开启星陨觉醒
E：进入星门
ESC/P：暂停或继续
在按键设置中可以修改键盘绑定。

手机操作
左侧移动摇杆控制方向，右侧动作键支持多指同时操作。
确认开始后进入横屏游戏；可在按键布局中调整摇杆和动作键的位置、大小、透明度。
键位与触控布局保存在当前浏览器，下次打开会恢复。

八幕路线
雾竹山门 → 朱灯旧街 → 回风栈道 → 沉钟地宫 → 琉璃水庭 → 丹炉机坊 → 天仪中枢 → 余烬神殿。
清理主路敌人后进入星门；升级时选择一项强化，注意地图上的回血补给。

好友挑战
点击“发起挑战”分享同图挑战链接，或用挑战码让朋友接受相同条件的远征。
在线版本的链接可以直接分享；离线版本请把 HTML 文件和挑战码一起发给朋友。
本机远征记录保存在当前浏览器。共享成绩功能需要联网；离线成绩等待恢复联网后重试。

素材鸣谢
LuizMelo、Anokolisa、ansimuz、Szadi art.、Pimen。
出处和许可见随附《素材来源与许可.md》及大厅“素材鸣谢”。音乐音效由项目合成。
`;
await writeFile(path.join(delivery, '游玩说明.txt'), playGuide.replace(/\r?\n/g, '\r\n'), 'utf8');
console.log(`Portable game created: ${path.join(delivery, '星跃远征.html')}`);
