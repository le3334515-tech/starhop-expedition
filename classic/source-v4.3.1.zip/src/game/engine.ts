import {
  EMPTY_INPUT, EXPEDITION_ROOM_COUNT, type Boss, type EngineCallbacks, type Enemy, type GameConfig,
  type GameResult, type GameState, type Hero, type InputState, type Projectile,
  type Rect, type SoundName, type Synergy, type Upgrade, type WeaponId,
} from './types';
import { createRoom, seededRandom, isSafeFloorPoint } from './levels';

const GRAVITY = 1260;
// Hero reach is tuned to the authored 88–184px ledges. Keep enemy/Boss
// gravity separate so a higher jump does not slow combat telegraphs.
const HERO_RISE_GRAVITY = 2200;
const HERO_FALL_GRAVITY = 3000;
const HERO_JUMP_SPEED = 950;
const HERO_AIR_JUMP_SPEED = 580;
const HERO_TAP_SPEED = 800;
const HERO_AIR_TAP_SPEED = 440;
const VIEW_WIDTH = 960;
// Three distinct patterns, breakable guard and punish windows make survival and timing matter.
export const BOSS_MAX_HP = 600;
const UPGRADES: Upgrade[] = [
  { id: 'edge', name: '星刃淬火', description: '武器伤害 +65%基础值，刀光延伸，斩击附带朱金余焰。', icon: 'blade', rarity: 'common', color: '#e8b674' },
  { id: 'tempo', name: '疾风节拍', description: '攻击速度提高35%，连斩带出疾风残影。', icon: 'bolt', rarity: 'common', color: '#a8e3c4' },
  { id: 'vigor', name: '不灭星心', description: '生命上限 +2，立即回满生命，气血暖辉常驻。', icon: 'heart', rarity: 'rare', color: '#e59a83' },
  { id: 'stride', name: '追风旅靴', description: '移动速度 +18%，闪避冷却缩短，冲刺自带伤敌风刃。', icon: 'wind', rarity: 'common', color: '#c2cf95' },
  { id: 'multishot', name: '双星共鸣', description: '远程多一枚飞弹；近战附带星光弹。', icon: 'star', rarity: 'epic', color: '#ffcf83' },
  { id: 'shield', name: '月光守护', description: '获得3层月盾，每层挡一次伤害；进入新关补1层。', icon: 'shield', rarity: 'rare', color: '#c3d7bc' },
  { id: 'blood', name: '生命余烬', description: '击杀必定回复1颗心，红色星火沿符文回流。', icon: 'spark', rarity: 'rare', color: '#d88976' },
  { id: 'magnet', name: '星尘引力', description: '吸取范围 +220，远处经验与星币自动汇入引力阵。', icon: 'orbit', rarity: 'common', color: '#9fc9c2' },
  { id: 'fortune', name: '闪耀口袋', description: '每次拾取星币额外 +2金币，并获得3点觉醒星能。', icon: 'coin', rarity: 'common', color: '#e4c282' },
];

const SYNERGIES: Synergy[] = [
  { id: 'blazing', name: '烈星连斩', description: '淬火 × 节拍：伤害额外 +20%，攻击速度额外 +10%。', requires: ['edge', 'tempo'], color: '#ffad78' },
  { id: 'fireflies', name: '流萤星群', description: '共鸣 × 引力：所有武器多一枚星弹，拾取范围额外 +120。', requires: ['multishot', 'magnet'], color: '#a4e8cb' },
  { id: 'guardian', name: '不灭月华', description: '星心 × 余烬或守护：激活时及进入新房间，获得 1 层护盾。', requires: ['vigor', 'blood|shield'], color: '#c3b5ff' },
];

const overlap = (a: Rect, b: Rect) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
const clamp = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n));
const approach = (value: number, target: number, amount: number) => value < target ? Math.min(value + amount, target) : Math.max(value - amount, target);

function makeHero(config: GameConfig): Hero {
  const hp = config.modifier === 'iron' ? 1 : 5;
  return {
    x: 100, y: 410, w: 28, h: 36, vx: 0, vy: 0, facing: 1, hp, maxHp: hp,
    xp: 0, xpNeeded: 10, level: 1, grounded: false, jumps: 0, coyote: 0, jumpBuffer: 0,
    invincible: 0, attackTimer: 0, attackCooldown: 0, dashTimer: 0, dashCooldown: 0,
    weapon: config.weapon, damage: 1, speed: 260, attackSpeed: 1, critChance: .08,
    extraProjectiles: 0, lifesteal: 0, magnet: 80, shield: 0, upgrades: [], animation: 0,
    attackStep: 0, comboWindow: 0, swapBoost: 0, swapCooldown: 0, counterTimer: 0, perfectDodgeCooldown: 0,
    guardTimer: 0, guardCooldown: 0,
  };
}

function initialState(config: GameConfig): GameState {
  const content = createRoom(config.seed, 0);
  return {
    phase: 'menu', seed: config.seed >>> 0, modifier: config.modifier, roomIndex: 0, roomCount: EXPEDITION_ROOM_COUNT,
    ...content, hero: makeHero(config), boss: null, projectiles: [], particles: [], floatingTexts: [],
    cameraX: 0, time: 0, visualTime: 0, coins: 0, kills: 0, deaths: 0, combo: 0, maxCombo: 0,
    comboTimer: 0, roomCleared: false, roomsCleared: 0, upgradeChoices: [], shake: 0, flash: 0,
    transition: 0, announcement: '', announcementTimer: 0, result: null,
    resonance: 0, overdrive: 0, overdriveCount: 0, synergies: [], hitstop: 0, impacts: [],
  };
}

/** Pure simulation: no DOM, canvas, clocks, timers, or network dependencies. */
export class GameEngine {
  state: GameState;
  private callbacks: EngineCallbacks;
  private random = seededRandom(1);
  private visualRandom = seededRandom(17);
  private projectileId = 10000;
  private pickupId = 50000;
  private meleeHits = new Set<number>();
  private dashHits = new Set<number>();
  private awakenedDiscs = new Set<number>();
  private previousHeroBottom = 0;
  private weaponAtStart: WeaponId = 'blade';
  private variableJump = false;
  private jumpCutSpeed = HERO_TAP_SPEED;
  private attackPower = 1;
  private criticalHit = false;
  private bufferedEdges: Partial<InputState> = {};
  private attackBuffer = 0;
  private bossGuardRecovery = 0;

  constructor(callbacks: EngineCallbacks = {}) {
    this.callbacks = callbacks;
    this.state = initialState({ seed: 20261116, modifier: 'standard', weapon: 'blade' });
  }

  start(config: GameConfig): void {
    const safeConfig = { ...config, seed: config.seed >>> 0 };
    this.random = seededRandom(safeConfig.seed ^ 0xab10c377);
    this.visualRandom = seededRandom(safeConfig.seed ^ 0x781ab29);
    this.projectileId = 10000;
    this.pickupId = 50000;
    this.weaponAtStart = safeConfig.weapon;
    this.attackPower = 1; this.bufferedEdges = {}; this.attackBuffer = 0; this.bossGuardRecovery = 0;
    this.variableJump = false;
    this.jumpCutSpeed = HERO_TAP_SPEED;
    this.meleeHits.clear();
    this.dashHits.clear();
    this.awakenedDiscs.clear();
    this.state = initialState(safeConfig);
    this.state.phase = 'playing';
    this.state.announcement = this.state.room.name;
    this.state.announcementTimer = 2.5;
    this.state.transition = 1;
  }

  pause(): void { if (this.state.phase === 'playing') { this.state.phase = 'paused'; this.bufferedEdges = {}; } }
  resume(): void { if (this.state.phase === 'paused') this.state.phase = 'playing'; }

  equipWeapon(id: WeaponId): void {
    if (!['blade', 'ember', 'disc'].includes(id)) return;
    const h = this.state.hero;
    if (h.weapon !== id) {
      h.attackStep = 0; h.comboWindow = 0;
      if (this.state.phase === 'playing' && h.swapCooldown <= 0) {
        h.swapBoost = 1.2; h.swapCooldown = 2;
        this.gainResonance(6);
        this.label(h.x + 14, h.y - 25, '换武 · 下一击强化', '#a9dfff');
      }
    }
    h.weapon = id;
    if (this.state.phase === 'playing') this.sound('select');
  }

  chooseUpgrade(id: string): void {
    const state = this.state;
    if (state.phase !== 'upgrade' || !state.upgradeChoices.some(item => item.id === id)) return;
    const hero = state.hero;
    hero.upgrades.push(id);
    switch (id) {
      case 'edge': hero.damage += .65; break;
      case 'tempo': hero.attackSpeed = Math.min(2.8, hero.attackSpeed * 1.35); break;
      case 'vigor': hero.maxHp += 2; hero.hp = hero.maxHp; break;
      case 'stride': hero.speed = Math.min(460, hero.speed * 1.18); break;
      case 'multishot': hero.extraProjectiles = Math.min(3, hero.extraProjectiles + 1); break;
      case 'shield': hero.shield += 3; break;
      case 'blood': hero.lifesteal = 1; break;
      case 'magnet': hero.magnet += 220; break;
      case 'fortune': break;
    }
    this.refreshSynergies();
    // Every level is a small recovery opportunity, whichever upgrade is chosen.
    if (id !== 'vigor' && hero.hp < hero.maxHp) {
      hero.hp = Math.min(hero.maxHp, hero.hp + 1);
      this.label(hero.x + 14, hero.y - 36, '升阶回春 +1 ♥', '#ffa5ac');
    }
    state.upgradeChoices = [];
    state.phase = 'playing'; state.hitstop = 0; this.bufferedEdges = {};
    this.sound('upgrade');
    const acquired = UPGRADES.find(item => item.id === id)!;
    this.burst(hero.x + 14, hero.y + 15, acquired.color, 34, 210);
    this.impact(hero.x + 14, hero.y + 18, 'break', acquired.color);
    this.label(hero.x + 14, hero.y - 15, acquired.name, acquired.color);
    if (!(state.announcement.startsWith('羁绊觉醒') && state.announcementTimer > 0)) {
      state.announcement = `星纹入牒 · ${acquired.name}`;
      state.announcementTimer = 2.2;
    }
    if (hero.xp >= hero.xpNeeded) this.offerUpgrade();
  }

  update(dt: number, input: InputState = EMPTY_INPUT): void {
    if (!Number.isFinite(dt) || dt <= 0) return;
    dt = Math.min(dt, .05);
    const state = this.state;
    state.visualTime += dt;
    this.updateEffects(dt);
    if (state.phase !== 'playing') return;
    // The stopwatch counts the complete active run, including impact pauses.
    state.time += dt;
    const edgeKeys = ['jumpPressed','attackPressed','dashPressed','interactPressed','overdrivePressed','guardPressed'] as const;
    for (const key of edgeKeys) if (input[key]) this.bufferedEdges[key] = true;
    const frozen = Math.min(dt, state.hitstop);
    state.hitstop = Math.max(0, state.hitstop - dt);
    dt -= frozen;
    if (dt <= 0) return;
    input = { ...input };
    for (const key of edgeKeys) input[key] ||= !!this.bufferedEdges[key];
    this.bufferedEdges = {};
    // Small physics steps prevent a fast dash crossing an enemy or a narrow platform.
    const steps = Math.ceil(dt / (1 / 120));
    const step = dt / steps;
    for (let i = 0; i < steps && state.phase === 'playing'; i++) {
      const frameInput = i === 0 ? input : { ...input, jumpPressed: false, attackPressed: false, dashPressed: false, interactPressed: false, overdrivePressed: false, guardPressed: false };
      this.step(step, frameInput);
      if (state.hitstop > 0) break;
    }
  }

  private step(dt: number, input: InputState): void {
    const s = this.state;
    const h = s.hero;
    s.overdrive = Math.max(0, s.overdrive - dt);
    if (input.overdrivePressed && s.resonance >= 100 && s.overdrive <= 0) {
      s.resonance = 0;
      s.overdrive = 6;
      s.overdriveCount += 1;
      s.announcement = '星陨觉醒 · 全武器超载';
      s.announcementTimer = 2.2;
      s.shake = 8; s.flash = .35;
      h.invincible = Math.max(h.invincible, .8);
      h.dashCooldown = 0;
      this.burst(h.x + 14, h.y + 18, '#ffe4a2', 55, 260);
      this.sound('awaken');
    }
    s.comboTimer = Math.max(0, s.comboTimer - dt);
    if (s.comboTimer === 0) s.combo = 0;
    s.announcementTimer = Math.max(0, s.announcementTimer - dt);
    s.transition = Math.max(0, s.transition - dt * 1.8);
    this.updateHero(dt, input);
    if (s.phase !== 'playing') return;
    this.updateEnemies(dt);
    this.updateBoss(dt);
    this.updateAttacks(dt);
    if (s.phase !== 'playing') return;
    this.enemyContact();
    if (s.phase !== 'playing') return;
    this.updatePickups(dt);
    if (s.phase !== 'playing') return;

    if (!s.room.isBoss && !s.roomCleared && s.enemies.every(enemy => enemy.dead)) {
      s.roomCleared = true;
      s.roomsCleared = s.roomIndex + 1;
      s.announcement = '房间净化 · 星门已开启';
      s.announcementTimer = 2.8;
      h.hp = Math.min(h.maxHp, h.hp + 1);
      this.sound('portal');
      this.gainXp(5);
    }
    const exitArea = { ...s.room.exit, x: s.room.exit.x - 28, w: s.room.exit.w + 56 };
    if (s.phase === 'playing' && s.roomCleared && !s.room.isBoss && overlap(h, exitArea)) {
      // Walking through the open gate is enough on touch; E also works from its edge.
      if (input.interactPressed || h.x > s.room.exit.x - 12) this.nextRoom();
    }
    const cameraTarget = clamp(h.x - 340, 0, s.room.width - VIEW_WIDTH);
    s.cameraX = approach(s.cameraX, cameraTarget, Math.max(200, Math.abs(cameraTarget - s.cameraX) * 9) * dt);
  }

  private updateHero(dt: number, input: InputState): void {
    const s = this.state;
    const h = s.hero;
    const speedFactor = (s.modifier === 'haste' ? 1.16 : 1) * (s.overdrive > 0 ? 1.25 : 1);
    const moonGravity = s.modifier === 'moon' ? .62 : 1;
    const jumpScale = s.modifier === 'moon' ? .82 : 1;
    h.animation += dt;
    h.comboWindow = Math.max(0, h.comboWindow - dt);
    h.swapBoost = Math.max(0, h.swapBoost - dt);
    h.swapCooldown = Math.max(0, h.swapCooldown - dt);
    h.counterTimer = Math.max(0, h.counterTimer - dt);
    h.perfectDodgeCooldown = Math.max(0, h.perfectDodgeCooldown - dt);
    h.guardTimer = Math.max(0, h.guardTimer - dt);
    h.guardCooldown = Math.max(0, h.guardCooldown - dt);
    if (h.comboWindow === 0) h.attackStep = 0;
    h.invincible = Math.max(0, h.invincible - dt);
    h.attackTimer = Math.max(0, h.attackTimer - dt);
    h.attackCooldown = Math.max(0, h.attackCooldown - dt);
    this.attackBuffer = input.attackPressed ? .16 : Math.max(0, this.attackBuffer - dt);
    h.dashCooldown = Math.max(0, h.dashCooldown - dt);
    h.dashTimer = Math.max(0, h.dashTimer - dt);
    h.coyote = h.grounded ? .12 : Math.max(0, h.coyote - dt);
    h.jumpBuffer = input.jumpPressed ? .14 : Math.max(0, h.jumpBuffer - dt);

    const move = Number(input.right) - Number(input.left);
    if (move) h.facing = move;
    if (input.guardPressed && h.guardCooldown <= 0 && h.dashTimer <= 0) {
      h.guardTimer = .24;
      h.guardCooldown = .6;
      this.sound('select');
      this.burst(h.x + 14 + h.facing * 20, h.y + 16, '#c9eee1', 5, 55);
    }
    if (input.dashPressed && h.dashCooldown <= 0) {
      this.dashHits.clear();
      h.guardTimer = 0;
      h.dashTimer = .18;
      h.attackCooldown = Math.min(h.attackCooldown, .12);
      h.dashCooldown = s.overdrive > 0 ? .38 : Math.max(.7, 1.35 - h.upgrades.filter(item => item === 'stride').length * .15);
      h.invincible = Math.max(h.invincible, .24);
      this.variableJump = false;
      this.sound('dash');
      this.burst(h.x + 14, h.y + 20, '#8ee9de', 9, 110);
    }

    if (h.jumpBuffer > 0 && (h.grounded || h.coyote > 0 || h.jumps < 2)) {
      if (!h.grounded && h.coyote <= 0 && h.jumps === 0) h.jumps = 1;
      const isDouble = h.jumps >= 1 && !h.grounded && h.coyote <= 0;
      h.dashTimer = 0;
      const launchSpeed = (isDouble ? HERO_AIR_JUMP_SPEED : HERO_JUMP_SPEED) * jumpScale;
      // The air jump adds a small correction. Pressing it early must not
      // chop the stronger upward momentum of the first jump.
      const preserveAscent = isDouble && h.vy < -launchSpeed;
      if (!preserveAscent) h.vy = -launchSpeed;
      this.jumpCutSpeed = (isDouble && !preserveAscent ? HERO_AIR_TAP_SPEED : HERO_TAP_SPEED) * jumpScale;
      h.jumps = isDouble ? 2 : 1;
      h.grounded = false;
      h.coyote = 0;
      h.jumpBuffer = 0;
      this.variableJump = true;
      this.sound(isDouble ? 'doubleJump' : 'jump');
      this.burst(h.x + 14, h.y + h.h, isDouble ? '#a9dfff' : '#c9edda', isDouble ? 12 : 6, 75);
    }
    if (!input.jumpHeld && !input.jumpPressed && h.vy < -this.jumpCutSpeed && this.variableJump) {
      h.vy = -this.jumpCutSpeed;
      this.variableJump = false;
    }
    if ((this.attackBuffer > 0 || input.attackHeld) && h.attackCooldown <= 0) {
      this.attackBuffer = 0;
      this.attack();
    }

    this.previousHeroBottom = h.y + h.h;
    if (h.dashTimer > 0) {
      h.vx = h.facing * 520;
      h.vy = 0;
      if (Math.floor(s.visualTime * 70) % 2 === 0) this.burst(h.x + 14, h.y + 20, '#7cddcf', 1, 20);
    } else {
      h.vx = approach(h.vx, move * h.speed * speedFactor, (h.grounded ? 2400 : 1650) * dt);
      const jumpGravity = h.vy > 0 ? HERO_FALL_GRAVITY : HERO_RISE_GRAVITY * (input.jumpHeld && Math.abs(h.vy) < 90 ? .72 : 1);
      h.vy = Math.min(800, h.vy + jumpGravity * moonGravity * dt);
    }
    h.x += h.vx * dt;
    h.x = clamp(h.x, 0, s.room.width - h.w);
    for (const p of s.room.platforms) {
      if (p.oneWay || p.kind === 'spring' || !overlap(h, p)) continue;
      if (h.y + h.h > p.y + 5 && h.y < p.y + p.h - 3) {
        if (h.vx > 0) h.x = p.x - h.w;
        else if (h.vx < 0) h.x = p.x + p.w;
        h.vx = 0;
      }
    }
    const oldY = h.y;
    h.y += h.vy * dt;
    h.grounded = false;
    for (const p of s.room.platforms) {
      if (h.x + h.w <= p.x || h.x >= p.x + p.w) continue;
      if (h.vy >= 0 && oldY + h.h <= p.y + 4 && h.y + h.h >= p.y) {
        h.y = p.y - h.h;
        h.vy = 0;
        h.grounded = true;
        h.jumps = 0;
        this.variableJump = false;
        if (p.kind === 'spring') {
          h.vy = -960 * jumpScale;
          h.grounded = false;
          h.jumps = 1;
          this.sound('doubleJump');
          this.burst(h.x + 14, h.y + h.h, '#b9edb0', 14, 120);
        } else if (p.kind === 'ground' && h.x > s.room.checkpoint.x + 180 && h.x > p.x + 32 && h.x < p.x + p.w - 50) {
          if (isSafeFloorPoint(s.room, h.x, h.w)) s.room.checkpoint = { x: h.x, y: p.y - h.h };
        }
      } else if (!p.oneWay && h.vy < 0 && oldY >= p.y + p.h - 3 && h.y <= p.y + p.h) {
        h.y = p.y + p.h;
        h.vy = 0;
      }
    }
    for (const hazard of s.room.hazards) if (overlap(h, hazard)) {
      this.hurtHero(1, hazard.x + hazard.w / 2, false, false);
      if (s.phase !== 'playing') return;
      if (hazard.kind === 'lava') this.respawnFromFall();
    }
    if (h.y > 590) {
      this.hurtHero(1, h.x, true);
      if (s.phase === 'playing') this.respawnFromFall();
    }
  }

  private respawnFromFall(): void {
    const s = this.state;
    const h = s.hero;
    h.x = s.room.checkpoint.x;
    h.y = s.room.checkpoint.y - 4;
    h.vx = h.vy = 0;
    h.jumps = 0;
    h.dashTimer = 0;
    h.guardTimer = 0;
    h.invincible = 1.5;
    this.variableJump = false;
    s.deaths += 1;
    this.label(h.x, h.y - 10, '小心脚下！', '#ffb59c');
  }

  private attack(): void {
    const s = this.state;
    const h = s.hero;
    this.attackPower = (h.swapBoost > 0 ? 1.3 : 1) * (h.counterTimer > 0 ? 1.5 : 1);
    h.attackTimer = .2;
    this.meleeHits.clear();
    const attackSpeed = h.attackSpeed * (s.overdrive > 0 ? 1.65 : 1) * (s.synergies.includes('blazing') ? 1.1 : 1);
    const extraShots = h.extraProjectiles + Number(s.synergies.includes('fireflies')) + (s.overdrive > 0 ? 2 : 0);
    if (h.weapon === 'blade') {
      h.attackStep = h.comboWindow > 0 ? h.attackStep % 3 + 1 : 1;
      h.comboWindow = 1.05;
      h.attackTimer = h.attackStep === 3 ? .28 : .18;
      h.attackCooldown = (h.attackStep === 3 ? .43 : .28) / attackSpeed;
      this.sound('attack');
      for (let i = 0; i < extraShots; i++) this.heroProjectile('ember', (i - (extraShots - 1) / 2) * 70, .7);
    } else if (h.weapon === 'ember') {
      h.attackCooldown = .36 / attackSpeed;
      for (let i = 0; i <= extraShots; i++) this.heroProjectile('ember', (i - extraShots / 2) * 82);
      this.sound('fire');
    } else {
      h.attackCooldown = .55 / attackSpeed;
      for (let i = 0; i <= extraShots; i++) this.heroProjectile('disc', (i - extraShots / 2) * 65);
      this.sound('attack');
    }
    h.swapBoost = 0; h.counterTimer = 0;
  }

  private heroProjectile(kind: 'ember' | 'disc', verticalSpeed: number, multiplier = 1): void {
    const h = this.state.hero;
    const id = ++this.projectileId;
    if (kind === 'disc' && this.state.overdrive > 0) this.awakenedDiscs.add(id);
    this.state.projectiles.push({ id, kind, x: h.x + h.w / 2 + h.facing * 16 - 7,
      y: h.y + 12, w: kind === 'disc' ? 20 : 14, h: kind === 'disc' ? 20 : 12,
      vx: h.facing * (kind === 'disc' ? 420 : 520), vy: verticalSpeed,
      life: kind === 'disc' ? 1.7 : 1.4, damage: this.effectiveDamage() * multiplier,
      owner: 'hero', hitIds: [], returning: false, rotation: 0 });
  }

  private updateEnemies(dt: number): void {
    const s = this.state;
    const h = s.hero;
    const factor = s.modifier === 'haste' ? 1.28 : 1;
    for (const e of s.enemies) {
      if (e.dead) continue;
      e.timer += dt;
      e.hurt = Math.max(0, e.hurt - dt);
      e.attackCooldown = Math.max(0, e.attackCooldown - dt * factor);
      const distance = h.x - e.x;
      if (e.kind === 'bat') {
        const engaged = Math.abs(distance) < 440;
        const targetX = engaged ? h.x + (Math.sin(e.timer * 1.6) * 80) : e.originX + Math.sin(e.timer) * 65;
        const targetY = engaged ? h.y + 4 + Math.sin(e.timer * 2.4) * 56 : e.originY + Math.sin(e.timer * 2.5) * 24;
        e.vx = approach(e.vx, clamp((targetX - e.x) * 1.7, -135, 135) * factor, 420 * dt);
        e.vy = approach(e.vy, clamp((targetY - e.y) * 1.6, -100, 100) * factor, 280 * dt);
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        e.facing = e.vx >= 0 ? 1 : -1;
      } else {
        if (e.kind === 'slime') {
          if (Math.abs(distance) < 400) e.facing = distance >= 0 ? 1 : -1;
          else if (Math.abs(e.x - e.originX) > 92) e.facing = e.x > e.originX ? -1 : 1;
          const nextX = e.x + e.facing * 23 + e.w / 2;
          const hasGround = s.room.platforms.some(p => nextX >= p.x && nextX <= p.x + p.w && p.kind === 'ground');
          if (!hasGround) e.facing *= -1;
          if (e.hurt <= 0) e.vx = e.facing * 58 * factor;
          if (e.attackCooldown <= 0 && Math.abs(distance) < 350 && e.y + e.h >= 447) {
            e.vy = -205;
            e.attackCooldown = 1.7;
          }
        } else {
          e.vx = e.hurt > 0 ? e.vx : 0;
          e.facing = distance >= 0 ? 1 : -1;
          if (e.attackCooldown <= 0 && Math.abs(distance) < 720) {
            const dx = h.x + 14 - e.x - 16;
            const dy = h.y + 18 - e.y - 20;
            const len = Math.hypot(dx, dy) || 1;
            s.projectiles.push({ id: ++this.projectileId, kind: 'enemy', x: e.x + 10, y: e.y + 12,
              w: 12, h: 12, vx: dx / len * 190 * factor, vy: dy / len * 190 * factor,
              life: 4, damage: 1, owner: 'enemy', hitIds: [] });
            e.attackCooldown = 2.45;
            this.burst(e.x + 16, e.y + 16, '#ff9a86', 5, 50);
          }
        }
        e.x += e.vx * dt;
        const oldBottom = e.y + e.h;
        e.vy = Math.min(650, e.vy + GRAVITY * dt);
        e.y += e.vy * dt;
        for (const p of s.room.platforms) {
          if (e.x + e.w > p.x && e.x < p.x + p.w && e.vy >= 0 && oldBottom <= p.y + 4 && e.y + e.h >= p.y) {
            e.y = p.y - e.h;
            e.vy = 0;
          }
        }
        if (e.y > 600) this.hitEnemy(e, 100);
      }
    }
  }

  private updateBoss(dt: number): void {
    const s = this.state, b = s.boss, h = s.hero;
    if (!b || b.mode === 'dead') return;
    this.bossGuardRecovery = Math.max(0, this.bossGuardRecovery - dt);
    b.hurt = Math.max(0, b.hurt - dt);
    b.exposed = Math.max(0, b.exposed - dt);
    if (!b.active && h.x > 510) {
      b.active = true;
      s.announcement = '余烬守卫 · 观察预警，抓住破绽'; s.announcementTimer = 2.8;
      this.sound('boss'); s.shake = 5;
    }
    if (!b.active) return;
    const phase = b.hp <= b.maxHp / 3 ? 3 : b.hp <= b.maxHp * 2 / 3 ? 2 : 1;
    if (phase > b.phase) {
      b.phase = phase; b.mode = 'transition'; b.timer = 1.05;
      b.vx = b.vy = 0; b.y = 448 - b.h; b.exposed = 0;
      b.maxGuard = 24 + phase * 6; b.guard = b.maxGuard;
      s.projectiles = s.projectiles.filter(projectile => projectile.owner === 'hero');
      h.invincible = Math.max(h.invincible, .65);
      s.announcement = phase === 2 ? '第二阶段 · 连冲与烈焰弹幕' : '最终阶段 · 余烬暴君';
      s.announcementTimer = 2.6; s.shake = 9; s.flash = .3;
      this.impact(b.x + b.w / 2, b.y + b.h / 2, 'break', '#ff9b6d');
      this.burst(b.x + b.w / 2, b.y + b.h / 2, '#ff9466', 42, 230);
      this.sound('guardBreak');
    }
    b.timer -= dt;
    if (b.mode === 'transition') {
      if (b.timer <= 0) { b.mode = 'idle'; b.timer = .3; this.bossGuardRecovery = 1.4; }
      return;
    }
    if (b.mode === 'stagger') {
      b.vx = b.vy = 0;
      if (b.timer <= 0) { b.mode = 'idle'; b.timer = .3; b.guard = b.maxGuard; this.bossGuardRecovery = 1.4; }
      return;
    }
    if (b.mode === 'idle' || b.mode === 'recover') {
      b.vx = approach(b.vx, 0, 1000 * dt);
      if (b.timer <= 0) {
        const patterns: Boss['intent'][] = b.phase === 1 ? ['charge','leap','slam'] : b.phase === 2 ? ['charge','leap','barrage','slam'] : ['leap','charge','barrage','slam'];
        b.intent = patterns[b.attackCount % patterns.length];
        b.attackCount += 1;
        b.chain = b.intent === 'charge' ? b.phase - 1 : 0;
        this.bossWindup(b, .82 - (b.phase - 1) * .17);
      }
    } else if (b.mode === 'windup' && b.timer <= 0) {
      if (b.intent === 'charge') {
        b.mode = 'charge'; b.timer = .55;
        b.vx = b.facing * (420 + (b.phase - 1) * 60);
      } else if (b.intent === 'leap') {
        b.mode = 'jump'; b.vy = -540;
        b.vx = clamp((b.targetX - b.x) / (1080 / GRAVITY), -450, 450);
      } else if (b.intent === 'barrage') {
        b.mode = 'barrage'; b.timer = .08; b.chain = b.phase === 3 ? 3 : 2;
      } else { b.mode = 'slam'; b.timer = .12; }
    } else if (b.mode === 'charge') {
      this.burst(b.x + b.w / 2, 446, '#eb945e', 1, 40);
      const atWall = b.vx < 0 && b.x <= 420 || b.vx > 0 && b.x + b.w >= s.room.width - 90;
      if (b.timer <= 0 || atWall) {
        b.vx = 0;
        if (b.chain > 0) { b.chain -= 1; this.bossWindup(b, .44); }
        else { this.bossShockwaves(b); this.bossRecover(b, 1.05 - (b.phase - 1) * .12); }
      }
    } else if (b.mode === 'slam' && b.timer <= 0) {
      this.bossShockwaves(b); this.bossRecover(b, 1.15 - (b.phase - 1) * .12);
    } else if (b.mode === 'barrage' && b.timer <= 0) {
      this.bossVolley(b, b.phase === 3 ? 5 : 3);
      b.chain -= 1;
      if (b.chain > 0) b.timer = .38;
      else this.bossRecover(b, 1.1);
    }
    b.x = clamp(b.x + b.vx * dt, 410, s.room.width - b.w - 80);
    if (b.mode === 'jump') {
      b.vy += GRAVITY * dt; b.y += b.vy * dt;
      if (b.y + b.h >= 448 && b.vy > 0) {
        b.y = 448 - b.h; b.vy = b.vx = 0;
        this.bossShockwaves(b); this.bossRecover(b, 1.15 - (b.phase - 1) * .1);
      }
    }
  }

  private bossWindup(b: Boss, duration: number): void {
    b.mode = 'windup'; b.timer = duration; b.vx = 0;
    b.targetX = clamp(this.state.hero.x + 14 - b.w / 2, 420, this.state.room.width - b.w - 90);
    if (b.intent === 'leap') b.targetX = clamp(b.targetX, b.x - 380, b.x + 380);
    b.facing = this.state.hero.x + 14 < b.x + b.w / 2 ? -1 : 1;
  }

  private bossRecover(b: Boss, duration: number): void {
    b.mode = 'recover'; b.timer = duration; b.exposed = duration; b.vx = 0;
  }

  private bossVolley(b: Boss, count: number): void {
    const s = this.state, h = s.hero;
    const angle = Math.atan2(h.y + 18 - b.y - 30, h.x + 14 - b.x - b.w / 2);
    for (let i = 0; i < count; i++) {
      const offset = (i - (count - 1) / 2) * .24;
      s.projectiles.push({ id: ++this.projectileId, kind: 'enemy', x: b.x + b.w / 2, y: b.y + 30,
        w: 14, h: 14, vx: Math.cos(angle + offset) * (210 + b.phase * 12), vy: Math.sin(angle + offset) * (210 + b.phase * 12),
        life: 4, damage: 1, owner: 'enemy', hitIds: [] });
    }
    this.burst(b.x + b.w / 2, b.y + 30, '#ff956a', 10, 100);
    this.sound('fire');
  }

  private bossShockwaves(b: Boss): void {
    const s = this.state;
    s.shake = 7; this.sound('boss');
    this.impact(b.x + b.w / 2, 442, 'heavy', '#ffb474');
    this.burst(b.x + b.w / 2, 445, '#ffb474', 28, 210);
    for (const direction of [-1, 1]) {
      s.projectiles.push({ id: ++this.projectileId, kind: 'shockwave', x: b.x + b.w / 2, y: 424,
        w: 36, h: 24, vx: direction * (230 + (b.phase - 1) * 45), vy: 0, life: 4, damage: 1,
        owner: 'enemy', hitIds: [] });
    }
    if (b.phase === 3 && b.intent === 'slam') this.bossVolley(b, 3);
  }

  private updateAttacks(dt: number): void {
    const s = this.state;
    const h = s.hero;
    if (h.dashTimer > 0 && h.upgrades.includes('stride')) {
      const gust = { x: h.x - 12, y: h.y - 6, w: h.w + 24, h: h.h + 12 };
      for (const enemy of s.enemies) if (!enemy.dead && !this.dashHits.has(enemy.id) && overlap(gust, enemy)) {
        this.dashHits.add(enemy.id);
        this.hitEnemy(enemy, this.effectiveDamage() * .8);
        this.label(enemy.x + enemy.w / 2, enemy.y - 12, '追风刃', '#c2cf95');
      }
      if (s.boss?.active && !this.dashHits.has(-1) && overlap(gust, s.boss)) {
        this.dashHits.add(-1);
        this.hitBoss(this.effectiveDamage() * .8);
      }
    }
    if (h.attackTimer > 0 && h.weapon === 'blade') {
      const empowered = s.overdrive > 0;
      const finisher = h.attackStep === 3;
      const attackRect = empowered || finisher
        ? { x: h.facing === 1 ? h.x + 4 : h.x - 114, y: h.y - 28, w: 140, h: 96 }
        : { x: h.facing === 1 ? h.x + 12 : h.x - 70, y: h.y - 13, w: 88, h: 67 };
      const flameReach = Math.min(3, h.upgrades.filter(id => id === 'edge').length) * 12;
      attackRect.w += flameReach;
      if (h.facing < 0) attackRect.x -= flameReach;
      for (const e of s.enemies) if (!e.dead && !this.meleeHits.has(e.id) && overlap(attackRect, e)) {
        this.meleeHits.add(e.id);
        this.hitEnemy(e, this.effectiveDamage() * (h.attackStep === 3 ? 2.8 : h.attackStep === 2 ? 1.55 : 1.35), h.attackStep === 3);
      }
      if (s.boss && s.boss.active && !this.meleeHits.has(-1) && overlap(attackRect, s.boss)) {
        this.meleeHits.add(-1);
        this.hitBoss(this.effectiveDamage() * (h.attackStep === 3 ? 2.8 : h.attackStep === 2 ? 1.55 : 1.35), h.attackStep === 3);
      }
    }
    for (const p of s.projectiles) {
      if (p.life <= 0) continue;
      p.life -= dt;
      p.rotation = (p.rotation || 0) + dt * 16;
      if (p.kind === 'disc') {
        if (p.life < 1.1 && !p.returning) {
          p.returning = true; p.hitIds = [];
          if (this.awakenedDiscs.has(p.id)) {
            p.damage *= 1.6;
            p.w = p.h = 26;
            this.burst(p.x + 10, p.y + 10, '#c9baff', 6, 90);
          } else p.damage *= 1.45;
        }
        if (p.returning) {
          const dx = h.x + 14 - p.x;
          const dy = h.y + 18 - p.y;
          const len = Math.hypot(dx, dy) || 1;
          const returnSpeed = this.awakenedDiscs.has(p.id) ? 620 : 480;
          p.vx = dx / len * returnSpeed; p.vy = dy / len * returnSpeed;
          if (len < 22) {
            p.life = 0;
            if (p.hitIds.length) {
              this.gainResonance(5);
              this.burst(h.x + 14, h.y + 18, '#c9baff', 5, 70);
            }
          }
        }
      }
      if (p.kind === 'ember' && p.owner === 'hero') {
        // A shallow aim assist helps ranged attacks meet airborne enemies, while
        // retaining forward flight and the need to face the target.
        const targets: Rect[] = s.enemies.filter(e => !e.dead);
        if (s.boss?.active && s.boss.mode !== 'dead') targets.push(s.boss);
        const target = targets.filter(e => (e.x + e.w / 2 - p.x) * Math.sign(p.vx) > 0 && Math.abs(e.x - p.x) < 360 && Math.abs(e.y + e.h / 2 - p.y) < 130)
          .sort((a, b) => Math.hypot(a.x - p.x, a.y - p.y) - Math.hypot(b.x - p.x, b.y - p.y))[0];
        if (target) p.vy = approach(p.vy, clamp((target.y + target.h / 2 - p.y) * 4, -210, 210), 900 * dt);
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.x < -60 || p.x > s.room.width + 60 || p.y < -100 || p.y > 600) p.life = 0;
      if (p.life <= 0) continue;
      if (p.owner === 'hero') {
        for (const e of s.enemies) {
          if (!e.dead && !p.hitIds.includes(e.id) && overlap(p, e)) {
            p.hitIds.push(e.id);
            this.hitEnemy(e, p.damage * (p.kind === 'ember' ? 1.4 : 1));
            if (p.kind !== 'disc') { this.emberBurst(p); p.life = 0; break; }
          }
        }
        if (p.life > 0 && s.boss && s.boss.active && s.boss.mode !== 'dead' && !p.hitIds.includes(-1) && overlap(p, s.boss)) {
          p.hitIds.push(-1);
          // The guardian's plate absorbs the staff's direct explosion bonus;
          // crowd damage remains strong without erasing its attack phases.
          this.hitBoss(p.damage);
          if (p.kind !== 'disc') { this.emberBurst(p); p.life = 0; }
        }
      } else if (overlap(p, h)) {
        this.hurtHero(p.damage, p.x);
        if (p.kind !== 'shockwave') p.life = 0;
      }
      if (p.kind === 'ember') {
        for (const platform of s.room.platforms) if (!platform.oneWay && overlap(p, platform)) { p.life = 0; break; }
      }
    }
    s.projectiles = s.projectiles.filter(p => {
      if (p.life <= 0) this.awakenedDiscs.delete(p.id);
      return p.life > 0;
    });
  }

  private emberBurst(projectile: Projectile): void {
    if (projectile.kind !== 'ember') return;
    const s = this.state;
    const center = { x: projectile.x + 7, y: projectile.y + 6 };
    this.impact(center.x, center.y, 'heavy', '#ffd49a');
    this.burst(center.x, center.y, '#ffb474', 16, 160);
    for (const enemy of s.enemies) {
      if (enemy.dead || projectile.hitIds.includes(enemy.id)) continue;
      if (Math.hypot(enemy.x + enemy.w / 2 - center.x, enemy.y + enemy.h / 2 - center.y) < 76) {
        projectile.hitIds.push(enemy.id);
        this.hitEnemy(enemy, projectile.damage * .75);
      }
    }
    const boss = s.boss;
    if (boss?.active && !projectile.hitIds.includes(-1) && Math.hypot(boss.x + boss.w / 2 - center.x, boss.y + boss.h / 2 - center.y) < 100) {
      projectile.hitIds.push(-1);
      this.hitBoss(projectile.damage * .75);
    }
  }

  private enemyContact(): void {
    const s = this.state;
    const h = s.hero;
    for (const e of s.enemies) if (!e.dead && overlap(h, e)) {
      if (h.vy > 80 && this.previousHeroBottom <= e.y + 18) {
        this.hitEnemy(e, this.effectiveDamage() * 2);
        h.vy = -365;
        h.jumps = 1;
        this.variableJump = false;
        this.sound('jump');
        this.burst(e.x + e.w / 2, e.y, '#fff0b5', 12, 110);
      } else this.hurtHero(1, e.x + e.w / 2);
    }
    const b = s.boss;
    if (b && b.active && !['dead','transition','recover','stagger'].includes(b.mode) && overlap(h, b)) {
      if (h.vy > 80 && this.previousHeroBottom <= b.y + 18) {
        this.hitBoss(this.effectiveDamage() * 2);
        h.vy = -430; h.jumps = 1; h.invincible = Math.max(h.invincible, .25);
        this.variableJump = false;
        this.sound('jump');
      } else this.hurtHero(1, b.x + b.w / 2);
    }
  }

  private damageAmount(base: number): number {
    const critical = this.random() < this.state.hero.critChance;
    this.criticalHit = critical;
    return base * (critical ? 1.75 : 1);
  }

  private effectiveDamage(): number {
    const s = this.state;
    return s.hero.damage * (s.overdrive > 0 ? 1.55 : 1) * (s.synergies.includes('blazing') ? 1.2 : 1) * (s.hero.attackTimer > 0 ? this.attackPower : 1);
  }

  private gainResonance(amount: number): void {
    const s = this.state;
    if (s.overdrive > 0) return;
    const previous = s.resonance;
    s.resonance = Math.min(100, s.resonance + amount);
    if (previous < 100 && s.resonance >= 100) {
      s.announcement = '星能充盈 · 按 Q 觉醒';
      s.announcementTimer = 3;
      this.sound('upgrade');
      this.burst(s.hero.x + 14, s.hero.y + 18, '#ffe29b', 22, 150);
    }
  }

  private refreshSynergies(): void {
    const s = this.state;
    const active = SYNERGIES.filter(synergy => synergy.requires.every(requirement => requirement.split('|').some(id => s.hero.upgrades.includes(id)))).map(item => item.id);
    for (const id of active) if (!s.synergies.includes(id)) {
      const synergy = SYNERGIES.find(item => item.id === id)!;
      if (id === 'guardian') s.hero.shield += 1;
      this.label(s.hero.x + 14, s.hero.y - 36, `羁绊 · ${synergy.name}`, synergy.color);
      this.burst(s.hero.x + 14, s.hero.y + 18, synergy.color, 36, 220);
      this.sound('synergy');
      s.announcement = `羁绊觉醒 · ${synergy.name}`;
      s.announcementTimer = 3;
    }
    s.synergies = active;
  }

  private hitEnemy(e: Enemy, base: number, heavy = false): void {
    if (e.dead) return;
    const amount = this.damageAmount(base), critical = this.criticalHit;
    e.hp -= amount;
    this.gainResonance(8 + (heavy ? 5 : 0));
    e.hurt = heavy ? .25 : .17;
    e.vx = this.state.hero.facing * (heavy ? 310 : critical ? 220 : 155);
    if (heavy && e.kind !== 'bat') e.vy = -150;
    this.state.shake = Math.max(this.state.shake, heavy ? 5.5 : critical ? 4.2 : 2.8);
    this.state.hitstop = Math.max(this.state.hitstop, heavy ? .07 : critical ? .055 : .035);
    this.impact(e.x + e.w / 2, e.y + e.h / 2, heavy ? 'heavy' : critical ? 'critical' : 'hit', critical ? '#ffd779' : '#c8fff0');
    this.burst(e.x + e.w / 2, e.y + e.h / 2, critical ? '#ffd779' : '#dcfff1', heavy ? 17 : 10, heavy ? 210 : 140);
    this.label(e.x + e.w / 2, e.y - 2, `${critical ? '暴击 ' : heavy ? '终结 ' : ''}${Math.round(amount * 10) / 10}`, critical ? '#ffd779' : heavy ? '#aaffea' : '#fff0ce');
    this.sound(heavy ? 'heavy' : critical ? 'critical' : 'hit');
    if (e.hp > 0) return;
    const s = this.state;
    const h = s.hero;
    e.dead = true;
    this.gainResonance(18);
    s.kills += 1;
    s.combo += 1;
    s.maxCombo = Math.max(s.maxCombo, s.combo);
    s.comboTimer = 4;
    this.sound('kill');
    this.burst(e.x + e.w / 2, e.y + e.h / 2, e.kind === 'bat' ? '#b7afff' : '#8cdec0', 18, 150);
    const loot = seededRandom(s.seed ^ Math.imul(e.id + 1, 0x85ebca6b));
    this.drop('xp', e.x + 7, e.y, 5);
    for (let i = 0; i < 2 + Number(loot() > .5); i++) this.drop('coin', e.x - 4 + i * 13, e.y + 12, 1);
    const heartChance = h.hp <= Math.ceil(h.maxHp / 2) ? .4 : .25;
    if (loot() < heartChance && h.hp < h.maxHp) this.drop('heart', e.x + 13, e.y - 12, 1);
    if (h.hp < h.maxHp && h.lifesteal > 0 && loot() < h.lifesteal) {
      h.hp = Math.min(h.maxHp, h.hp + 1);
      this.label(h.x, h.y - 18, '汲取 +1 ♥', '#d88976');
      this.burst(h.x + 14, h.y + 18, '#d88976', 12, 95);
    }
  }

  private hitBoss(base: number, heavy = false): void {
    const s = this.state, b = s.boss;
    if (!b || b.mode === 'dead' || b.mode === 'transition' || !b.active) return;
    const weakness = b.mode === 'stagger' ? 1.6 : b.exposed > 0 ? 1.45 : 1;
    const amount = this.damageAmount(base) * weakness, critical = this.criticalHit;
    b.hp = Math.max(0, b.hp - amount);
    this.gainResonance(5 + (heavy ? 3 : 0));
    b.hurt = .15;
    s.shake = Math.max(s.shake, heavy ? 5 : critical ? 4 : 3);
    s.hitstop = Math.max(s.hitstop, heavy ? .065 : critical ? .045 : .025);
    this.impact(b.x + b.w / 2, b.y + b.h / 2, heavy ? 'heavy' : critical ? 'critical' : 'hit', weakness > 1 ? '#b6fff0' : '#ffbe7d');
    this.burst(b.x + b.w / 2, b.y + b.h / 2, weakness > 1 ? '#b6fff0' : '#ffbe7d', heavy ? 18 : 10, 170);
    this.label(b.x + b.w / 2, b.y, `${weakness > 1 ? '破绽 ' : critical ? '暴击 ' : ''}${Math.round(amount * 10) / 10}`, weakness > 1 ? '#b6fff0' : '#ffe1b0');
    this.sound(heavy ? 'heavy' : critical ? 'critical' : 'hit');
    // Recover armor long enough to release one warned move. Powerful builds
    // keep their full health damage, but cannot lock every attack in stagger.
    if (b.mode !== 'stagger' && this.bossGuardRecovery <= 0) {
      b.guard = Math.max(0, b.guard - amount * (heavy ? 1.8 : .8));
      if (b.guard <= 0 && b.hp > 0) {
        b.mode = 'stagger'; b.timer = 1.6; b.exposed = 1.6; b.vx = b.vy = 0; b.y = 448 - b.h;
        s.hitstop = .09; s.shake = 7;
        this.impact(b.x + b.w / 2, b.y + b.h / 2, 'break', '#adfff0');
        this.label(b.x + b.w / 2, b.y - 24, '护甲击破 · 全力输出！', '#adfff0');
        this.sound('guardBreak');
      }
    }
    if (b.hp <= 0) {
      b.mode = 'dead'; b.vx = b.vy = 0;
      s.kills += 1; s.roomCleared = true; s.roomsCleared = s.roomCount;
      this.burst(b.x + b.w / 2, b.y + b.h / 2, '#ffca78', 90, 300);
      s.shake = 12; s.flash = .8;
      this.finish(true);
    }
  }

  private hurtHero(amount: number, sourceX: number, force = false, parryable = true): void {
    const s = this.state;
    const h = s.hero;
    if (s.phase !== 'playing') return;
    if (!force && parryable && h.guardTimer > 0 && (sourceX - h.x - h.w / 2) * h.facing >= -4) {
      h.guardTimer = 0;
      h.invincible = Math.max(h.invincible, .2);
      h.counterTimer = 1.6;
      this.gainResonance(16);
      this.impact(h.x + 14 + h.facing * 22, h.y + 18, 'break', '#c1ffed');
      this.burst(h.x + 14, h.y + 18, '#c1ffed', 24, 200);
      this.label(h.x + 14, h.y - 28, '完美格挡 · 反击！', '#c1ffed');
      s.hitstop = Math.max(s.hitstop, .065);
      s.shake = 4;
      this.sound('guardBreak');
      const boss = s.boss;
      if (boss?.active && !['dead', 'transition', 'stagger'].includes(boss.mode)) {
        boss.guard = Math.max(0, boss.guard - 10);
        if (boss.guard === 0) {
          boss.mode = 'stagger'; boss.timer = 1.6; boss.exposed = 1.6;
          boss.vx = boss.vy = 0; boss.y = 448 - boss.h;
          this.label(boss.x + boss.w / 2, boss.y - 20, '弹反破甲', '#c1ffed');
        } else if (boss.mode === 'charge') this.bossRecover(boss, .7);
      }
      return;
    }
    if (!force && h.invincible > 0) {
      if (h.dashTimer > .1 && h.perfectDodgeCooldown <= 0) {
        h.perfectDodgeCooldown = 1; h.counterTimer = 1.4;
        this.gainResonance(20);
        this.impact(h.x + 14, h.y + 18, 'break', '#9cefff');
        this.label(h.x + 14, h.y - 30, '完美闪避 · 下一击反击', '#9cefff');
        this.sound('perfectDodge');
      }
      return;
    }
    if (h.shield > 0) {
      h.shield -= 1;
      h.invincible = 1;
      this.burst(h.x + 14, h.y + 18, '#b7afff', 18, 160);
      this.label(h.x, h.y - 12, '月光守护', '#c2bdff');
      this.sound('hurt');
      return;
    }
    h.hp = Math.max(0, h.hp - amount);
    h.invincible = 1.3;
    h.vx = (h.x + 14 >= sourceX ? 1 : -1) * 230;
    h.vy = -230;
    h.dashTimer = 0;
    h.guardTimer = 0;
    this.variableJump = false;
    s.combo = 0; s.comboTimer = 0;
    s.shake = 7; s.flash = .3; s.hitstop = Math.max(s.hitstop, .055);
    this.sound('hurt');
    this.burst(h.x + 14, h.y + 20, '#ff9a93', 18, 160);
    if (h.hp <= 0) this.finish(false);
  }

  private drop(kind: 'coin' | 'xp' | 'heart', x: number, y: number, value: number): void {
    this.state.pickups.push({ id: ++this.pickupId, kind, x, y, w: kind === 'xp' ? 11 : 14, h: kind === 'xp' ? 11 : 16,
      value, vy: -130, bob: this.visualRandom() * Math.PI * 2, collected: false });
  }

  private updatePickups(dt: number): void {
    const s = this.state;
    const h = s.hero;
    for (const p of s.pickups) {
      if (p.collected) continue;
      p.bob += dt * 2.5;
      if (p.vy !== 0) {
        p.vy += 430 * dt;
        p.y += p.vy * dt;
        for (const platform of s.room.platforms) if (p.x + p.w > platform.x && p.x < platform.x + platform.w && p.y + p.h >= platform.y && p.y < platform.y + 14 && p.vy > 0) {
          p.y = platform.y - p.h - 5; p.vy = 0;
        }
        if (p.y > 550) { p.collected = true; continue; }
      }
      const dx = h.x + h.w / 2 - p.x - p.w / 2;
      const dy = h.y + h.h / 2 - p.y - p.h / 2;
      const distance = Math.hypot(dx, dy);
      const magnetRange = h.magnet + (s.synergies.includes('fireflies') ? 120 : 0);
      const radius = p.kind === 'xp' ? Math.max(150, magnetRange) : magnetRange;
      if (distance < radius && (p.kind !== 'heart' || h.hp < h.maxHp)) {
        const speed = p.kind === 'xp' ? 400 : 320;
        p.x += dx / (distance || 1) * speed * dt;
        p.y += dy / (distance || 1) * speed * dt;
        p.vy = 0;
      }
      if (distance < 22 || overlap(p, h)) {
        if (p.kind === 'heart' && h.hp >= h.maxHp) continue;
        p.collected = true;
        if (p.kind === 'coin') {
          const fortune = h.upgrades.filter(item => item === 'fortune').length;
          s.coins += p.value + fortune * 2;
          if (fortune > 0) this.gainResonance(fortune * 3);
          this.sound('coin');
          this.burst(p.x + 6, p.y + 6, '#ffdb80', 4, 65);
        } else if (p.kind === 'xp') {
          this.gainResonance(4);
          this.gainXp(p.value);
          this.burst(p.x + 6, p.y + 6, '#80e5d1', 4, 65);
        } else {
          h.hp = Math.min(h.maxHp, h.hp + p.value);
          this.sound('coin');
          this.label(h.x, h.y - 15, '+1 ♥', '#ffb3bb');
        }
      }
    }
    s.pickups = s.pickups.filter(p => !p.collected);
  }

  private gainXp(amount: number): void {
    const h = this.state.hero;
    h.xp += amount;
    if (h.xp >= h.xpNeeded && this.state.phase === 'playing') this.offerUpgrade();
  }

  private offerUpgrade(): void {
    const s = this.state;
    const h = s.hero;
    h.xp -= h.xpNeeded;
    h.level += 1;
    h.xpNeeded += 5;
    const pool = UPGRADES.filter(item => !(s.modifier === 'iron' && item.id === 'vigor')
      && !(h.extraProjectiles >= 3 && item.id === 'multishot')
      && !(h.attackSpeed >= 2.8 && item.id === 'tempo')
      && !(h.speed >= 460 && item.id === 'stride')
      && !(h.lifesteal >= 1 && item.id === 'blood'));
    const random = seededRandom(s.seed ^ Math.imul(h.level, 0x45d9f3b));
    const choices: Upgrade[] = [];
    while (choices.length < 3 && pool.length) {
      const index = Math.floor(random() * pool.length);
      choices.push(pool.splice(index, 1)[0]);
    }
    // Once a player has a component, offer a matching component in later drafts.
    const complements: string[] = [];
    if (h.upgrades.includes('edge') && !h.upgrades.includes('tempo')) complements.push('tempo');
    if (h.upgrades.includes('tempo') && !h.upgrades.includes('edge')) complements.push('edge');
    if (h.upgrades.includes('multishot') && !h.upgrades.includes('magnet')) complements.push('magnet');
    if (h.upgrades.includes('magnet') && !h.upgrades.includes('multishot')) complements.push('multishot');
    if (h.upgrades.includes('vigor') && !h.upgrades.some(id => id === 'blood' || id === 'shield')) complements.push('shield');
    if (s.modifier !== 'iron' && h.upgrades.some(id => id === 'blood' || id === 'shield') && !h.upgrades.includes('vigor')) complements.push('vigor');
    if (complements.length && !choices.some(choice => complements.includes(choice.id))) {
      const matching = UPGRADES.find(item => item.id === complements[Math.floor(random() * complements.length)]);
      if (matching) choices[choices.length - 1] = matching;
    }
    s.upgradeChoices = choices;
    s.phase = 'upgrade';
    this.sound('upgrade');
  }

  private nextRoom(): void {
    const s = this.state;
    const nextIndex = s.roomIndex + 1;
    if (nextIndex >= s.roomCount) return;
    const content = createRoom(s.seed, nextIndex);
    s.roomIndex = nextIndex;
    s.room = content.room;
    s.enemies = content.enemies;
    s.pickups = content.pickups;
    s.projectiles = []; s.hitstop = 0; s.impacts = [];
    this.awakenedDiscs.clear();
    this.dashHits.clear();
    this.bossGuardRecovery = 0;
    s.particles = [];
    s.floatingTexts = [];
    s.hero.x = s.room.spawn.x; s.hero.y = s.room.spawn.y;
    s.hero.vx = 0; s.hero.vy = 0; s.hero.jumps = 0;
    s.hero.grounded = false; s.hero.dashTimer = 0; s.hero.invincible = 1.2;
    s.hero.guardTimer = s.hero.guardCooldown = 0;
    this.variableJump = false;
    if (s.synergies.includes('guardian')) s.hero.shield += 1;
    if (s.hero.upgrades.includes('shield')) s.hero.shield += 1;
    s.cameraX = 0; s.roomCleared = false;
    s.announcement = s.room.name; s.announcementTimer = 2.6; s.transition = 1;
    s.boss = s.room.isBoss ? { x: 1210, y: 330, w: 104, h: 118, hp: BOSS_MAX_HP, maxHp: BOSS_MAX_HP, phase: 1,
      mode: 'idle', timer: 1.1, vx: 0, vy: 0, facing: -1, hurt: 0, attackCount: 0, active: false,
      intent: 'charge', targetX: 700, chain: 0, guard: 30, maxGuard: 30, exposed: 0 } : null;
    this.sound('portal');
  }

  private finish(won: boolean): void {
    const s = this.state;
    if (s.result) return;
    s.phase = won ? 'victory' : 'gameover';
    const result: GameResult = {
      seed: s.seed, modifier: s.modifier, weapon: this.weaponAtStart, won,
      time: Math.round(s.time * 100) / 100,
      score: Math.max(0, Math.round(s.roomsCleared * 1200 + s.kills * 200 + s.coins * 25 + (won ? 5000 : 0) - s.time * 8 - s.deaths * 200)),
      coins: s.coins, kills: s.kills, level: s.hero.level, deaths: s.deaths,
      roomsCleared: s.roomsCleared, maxCombo: s.maxCombo, upgrades: [...s.hero.upgrades],
      overdriveCount: s.overdriveCount, synergies: [...s.synergies],
    };
    s.result = result;
    this.sound(won ? 'win' : 'lose');
  }

  private updateEffects(dt: number): void {
    const s = this.state;
    s.shake = Math.max(0, s.shake - dt * 20);
    s.flash = Math.max(0, s.flash - dt * 2.5);
    for (const impact of s.impacts) impact.life -= dt;
    s.impacts = s.impacts.filter(impact => impact.life > 0);
    for (const p of s.particles) {
      p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt;
      p.vy += (p.gravity ?? 220) * dt;
    }
    s.particles = s.particles.filter(p => p.life > 0);
    for (const text of s.floatingTexts) { text.life -= dt; text.y -= dt * 30; }
    s.floatingTexts = s.floatingTexts.filter(text => text.life > 0);
  }

  private impact(x: number, y: number, kind: 'hit' | 'critical' | 'heavy' | 'break', color: string): void {
    const life = kind === 'break' ? .42 : kind === 'heavy' ? .3 : .22;
    this.state.impacts.push({ x, y, kind, color, life, maxLife: life, size: kind === 'break' ? 84 : kind === 'heavy' ? 52 : kind === 'critical' ? 38 : 25, angle: this.state.hero.facing < 0 ? Math.PI : 0 });
    if (this.state.impacts.length > 28) this.state.impacts.shift();
  }

  private burst(x: number, y: number, color: string, count: number, speed: number): void {
    const particles = this.state.particles;
    for (let i = 0; i < count; i++) {
      const angle = this.visualRandom() * Math.PI * 2;
      const velocity = speed * (.25 + this.visualRandom() * .75);
      const life = .25 + this.visualRandom() * .45;
      particles.push({ x, y, vx: Math.cos(angle) * velocity, vy: Math.sin(angle) * velocity,
        life, maxLife: life, size: 2 + Math.floor(this.visualRandom() * 3), color, gravity: 170 });
    }
    if (particles.length > 350) particles.splice(0, particles.length - 350);
  }

  private label(x: number, y: number, text: string, color: string): void {
    this.state.floatingTexts.push({ x, y, text, color, life: .95, maxLife: .95 });
  }

  private sound(name: SoundName): void { this.callbacks.sound?.(name); }
}

export { UPGRADES, SYNERGIES };
