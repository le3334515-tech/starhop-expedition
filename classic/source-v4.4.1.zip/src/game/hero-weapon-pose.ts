import type { Hero } from './types';

type Point = { x: number; y: number };
export interface RangedWeaponPose {
  attacking: boolean; attackProgress: number; lean: number;
  hand: Point; offHand: Point; staffGrip: Point; staffAngle: number;
}
const cleanSheets = new WeakMap<HTMLImageElement, HTMLCanvasElement>();
// These four colors belong exclusively to this source character's sword and hilt.
// Keep the credited PNGs intact; only the cached ranged-body layer omits the sword.
const swordColors = new Set([0x5f4181, 0x442b61, 0x331685, 0x432792]);
export function weaponlessHeroSheet(image: HTMLImageElement): HTMLCanvasElement {
  const cached = cleanSheets.get(image); if (cached) return cached;
  const sheet = document.createElement('canvas');
  sheet.width = image.naturalWidth; sheet.height = image.naturalHeight;
  const c = sheet.getContext('2d')!;
  c.drawImage(image, 0, 0);
  const pixels = c.getImageData(0, 0, sheet.width, sheet.height), data = pixels.data;
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] && swordColors.has((data[i] << 16) | (data[i + 1] << 8) | data[i + 2])) data[i + 3] = 0;
  }
  c.putImageData(pixels, 0, 0); cleanSheets.set(image, sheet); return sheet;
}

const mix = (a: number, b: number, t: number) => a + (b - a) * t;
/** A quick release followed by recovery matches the existing immediate projectiles.
 * Both actions use the original locomotion body; neither borrows a sword frame. */
export function rangedWeaponPose(h: Hero, now: number): RangedWeaponPose {
  const attacking = h.attackTimer > 0 && h.hp > 0;
  const p = attacking ? Math.max(0, Math.min(1, 1 - h.attackTimer / .2)) : 1;
  const recover = Math.max(0, (p - .28) / .72), ease = recover * recover * (3 - 2 * recover);
  const motion = attacking ? 1 - ease : 0;
  const bob = h.grounded && Math.abs(h.vx) < 15 ? Math.sin(now * 2.8) * .6 : 0;
  if (h.weapon === 'ember') {
    const hand = { x: Math.round(mix(15, 21 + Math.sin(p * Math.PI) * 3, motion)), y: Math.round(mix(-20 + bob, -26, motion)) };
    const offHand = { x: Math.round(mix(0, 5, motion)), y: Math.round(mix(-20 + bob, -20, motion)) };
    return { attacking, attackProgress: p, lean: -.045 * motion, hand, offHand,
      staffGrip: attacking ? offHand : hand, staffAngle: mix(-.15, .92 + Math.sin(p * Math.PI) * .16, motion) };
  }
  return { attacking, attackProgress: p, lean: -.075 * motion,
    hand: { x: Math.round(mix(14, 23 + Math.sin(p * Math.PI) * 4, motion)), y: Math.round(mix(-21 + bob, -17 - Math.sin(p * Math.PI) * 5, motion)) },
    offHand: { x: Math.round(mix(-7, -11, motion)), y: Math.round(mix(-23 + bob, -19, motion)) },
    staffGrip: { x: 0, y: 0 }, staffAngle: 0 };
}

function arm(c: CanvasRenderingContext2D, shoulder: Point, elbow: Point, hand: Point, palm: boolean) {
  // Pixel steps use the source robe's plum shadows, ivory sleeve and pale glove.
  const segment = (a: Point, b: Point, color: string, size: number) => {
    c.fillStyle = color;
    const steps = Math.max(Math.abs(b.x - a.x), Math.abs(b.y - a.y), 1);
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      c.fillRect(Math.round(mix(a.x, b.x, t) - size / 2), Math.round(mix(a.y, b.y, t) - size / 2), size, size);
    }
  };
  segment(shoulder, elbow, '#3c2936', 7); segment(elbow, hand, '#3c2936', 6);
  segment(shoulder, elbow, '#b59fa8', 5); segment(elbow, hand, '#d1bfc1', 4);
  c.fillStyle = '#755568'; c.fillRect(hand.x - 4, hand.y - 2, 3, 5);
  c.fillStyle = '#ddcdcb'; c.fillRect(hand.x - 1, hand.y - 2, palm ? 5 : 4, palm ? 6 : 4);
  if (palm) { c.fillRect(hand.x + 2, hand.y - 5, 2, 4); c.fillRect(hand.x + 4, hand.y - 3, 2, 2); }
}

export function drawRangedArms(c: CanvasRenderingContext2D, h: Hero, pose: RangedWeaponPose): void {
  if (h.weapon === 'blade' || h.hp <= 0) return;
  arm(c, { x: -3, y: -25 }, { x: -7, y: -21 }, pose.offHand, false);
  const elbow = h.weapon === 'ember' ? { x: 9, y: pose.hand.y + 5 } : { x: 12, y: pose.hand.y - 2 };
  arm(c, { x: 4, y: -25 }, elbow, pose.hand, pose.attacking && h.weapon === 'ember');
}
