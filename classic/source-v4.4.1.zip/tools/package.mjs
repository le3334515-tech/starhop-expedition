import { readFile, writeFile, mkdir, readdir, copyFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let html = await readFile(path.join(root, 'dist/index.html'), 'utf8');
const script = html.match(/<script[^>]*src="([^"]+)"[^>]*><\/script>/);
const style = html.match(/<link[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/);
if (!script || !style) throw new Error('The Vite output must contain a script and stylesheet.');
let js = await readFile(path.join(root, 'dist', script[1]), 'utf8');
let css = await readFile(path.join(root, 'dist', style[1]), 'utf8');
// Keep the web build cacheable while making the delivered HTML truly portable.
for (const file of await readdir(path.join(root, 'dist/assets'))) {
  if (!file.endsWith('.png')) continue;
  const data = `data:image/png;base64,${(await readFile(path.join(root, 'dist/assets', file))).toString('base64')}`;
  for (const relative of [`./assets/${file}`, `assets/${file}`, `/assets/${file}`, file]) {
    js = js.replaceAll(JSON.stringify(relative), JSON.stringify(data));
    css = css.replaceAll(relative, data);
  }
}
const favicon = await readFile(path.join(root,'public/favicon.svg'),'utf8');
html = html.replace(script[0], () => `<script type="module">${js.replace(/<\/script/gi,'<\\/script')}</script>`)
  .replace(style[0], () => `<style>${css}</style>`)
  .replace(/href="\.\/favicon.svg"/, () => `href="data:image/svg+xml,${encodeURIComponent(favicon)}"`);
const delivery = path.join(root, 'delivery');
await mkdir(delivery, { recursive: true });
await copyFile(path.join(root, 'docs/素材来源与许可.md'), path.join(delivery, '素材来源与许可.md'));
await writeFile(path.join(delivery, '星跃远征.html'), html, 'utf8');
await writeFile(path.join(delivery, '开始游戏.cmd'), '@echo off\r\nchcp 65001 >nul\r\nstart "" "%~dp0星跃远征.html"\r\n', 'utf8');
const playGuide = `星跃远征 v4.4.1 / STARHOP

公共游玩链接：https://le3334515-tech.github.io/starhop-expedition/classic/?v=4.4.1
离线压缩包：https://le3334515-tech.github.io/starhop-expedition/classic/offline-v4.4.1.zip
源码压缩包：https://le3334515-tech.github.io/starhop-expedition/classic/source-v4.4.1.zip
电脑和手机打开链接即可游玩，无需安装。分享此链接，朋友不需要连接同一 Wi-Fi。
离线游玩：直接双击“星跃远征.html”；游戏画面、角色和特效已内嵌，无需安装。

本版基于提供的 v4.1，沿用原像素武侠画风、人物素材与八幕主题。
v4.4.1 修正武器动作：法杖抬杖出掌施法，飞轮独立甩投收手；远程角色清理残留剑影，不再拔刀。
短刃保留原三连斩；原角色、像素配色以及伤害、判定、出手时机保持。
增加章节剧情，丰富主路与高台支路，调整平台衔接、起跳与落地体验。
三种武器随修为在LV.4、LV.7同步进阶，武器栏显示当前阶数。
2号法杖强化追踪贯穿、焰爆与灼烧；3号飞轮强化双轮往返、回锋与破弹。
七个普通关采用不同的地区怪物组合、预警与招式，沿用统一像素画风。
闪避可伤敌，升级恢复生命，地图可拾取回血补给。
格挡按下即响应，可取消冲刺并穿过顿帧立即架势；精准窗口0.24秒，恢复0.36秒。
Boss第一形态余烬守卫，击败后玄烬魔君满血黑化觉醒；第二形态包括地裂墨柱、墨雨等新技能。
v4.4 保持一跳轻点约150、长按约202逻辑像素；二段跳满按额外补高约75，两跳合计约277。
空中轻点补高更小；过早二跳保留已有的更强上升速度，不能三段连跳。
修正天仪中枢远景的矩形硬边和海面色带，保留原像素武侠风格。
升级改为青玉行牒与三道符印，直接展示强化前后的数值；选中后获得本局常驻效果与对应特效。

九种强化
星刃淬火：每层伤害增加65%基础值，伴随朱金余焰。
疾风节拍：每层攻击速度乘1.35，最高2.8倍，伴随疾风残影。
不灭星心：每层生命上限+2，立即回满生命，伴随气血暖辉。
追风旅靴：每层移动速度乘1.18，最高460；缩短闪避冷却，闪避附带伤敌风刃。
双星共鸣：每层额外飞弹+1，最多额外3枚；近战同样能带出星光弹。
月光守护：立即获得3层护盾，每层抵挡一次伤害；进入新关补1层。
生命余烬：击杀必定回复1颗心，伴随红纹与回流星火。
星尘引力：每层吸取半径+220，伴随聚灵阵。
闪耀口袋：每层让拾取星币额外获得2金币和3点觉醒星能，伴随金色星屑。
除星心直接回满外，选择强化时通常恢复1颗心。效果持续到本局结束，重开远征重新成长。

默认电脑操作
A/D 或方向键：移动
空格/K：跳跃、二段跳；轻点也能跳上高台，长按跳得更高
J/X：攻击；按住短刃攻击可打出三连重斩
Shift/L：闪避
F：格挡；在攻击即将命中时起手可精准格挡
1/2/3：切换短刃、萤火法杖、回声飞轮
Q：星能蓄满后开启星陨觉醒
E：电脑可在星门边互动；清理主路后直接走入星门也能过关
ESC/P：暂停或继续
在按键设置中可以修改键盘绑定。

手机操作
左侧移动摇杆控制方向，右侧动作键支持多指同时操作。
手机已移除E互动按钮；清理主路敌人后直接走进星门，自动进入下一关。
格挡、攻击和武器HUD避免互相遮挡，放大按键及读取旧布局时也会检查碰撞。
确认开始后进入横屏游戏；可在按键布局中调整摇杆和动作键的位置、大小、透明度。
键位与触控布局保存在当前浏览器，下次打开会恢复。

八幕路线
雾竹山门 → 朱灯旧街 → 回风栈道 → 沉钟地宫 → 琉璃水庭 → 丹炉机坊 → 天仪中枢 → 余烬神殿。
清理主路敌人后进入星门；升级时选择一项强化，注意地图上的回血补给。

好友挑战
点击“发起挑战”分享同图挑战链接，或用挑战码让朋友接受相同条件的远征。
在线版本的链接可以直接分享；离线版本请把 HTML 文件和挑战码一起发给朋友。
本机远征记录保存在当前浏览器。共享成绩功能需要联网；离线成绩等待恢复联网后重试。
v4.4 沿用当前经典版榜单、玩家身份和历史纪录，不清空已有成绩。

素材鸣谢
LuizMelo、Anokolisa、ansimuz、Szadi art.、Pimen。
出处和许可见随附《素材来源与许可.md》及大厅“素材鸣谢”。音乐音效由项目合成。
`;
await writeFile(path.join(delivery, '游玩说明.txt'), playGuide.replace(/\r?\n/g, '\r\n'), 'utf8');
console.log(`Portable game created: ${path.join(delivery, '星跃远征.html')}`);
