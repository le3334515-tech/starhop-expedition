import type { Boss, Enemy, Projectile } from './types';

const TAU = Math.PI * 2;
const clamp = (n: number, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const pixel = (c: CanvasRenderingContext2D, x: number, y: number, w = 2, h = w) => c.fillRect(Math.round(x), Math.round(y), w, h);

function diamond(c: CanvasRenderingContext2D, x: number, y: number, radius: number, color: string) {
  c.fillStyle = color;
  for (let row = -radius; row <= radius; row += 2) {
    const width = Math.max(2, Math.round((radius - Math.abs(row)) / 2) * 2);
    pixel(c, x - width, y + row, width * 2, 2);
  }
}

function inkFlame(c: CanvasRenderingContext2D, x: number, foot: number, width: number, height: number, phase: number, alpha = 1) {
  c.save(); c.globalAlpha *= alpha;
  const sway = Math.round(Math.sin(phase) * width * .25);
  c.fillStyle = '#111821';
  for (let n = 0; n < 7; n++) {
    const t = n / 7, w = Math.max(2, Math.round(width * (1 - t) / 2) * 2);
    pixel(c, x - w / 2 + sway * t, foot - height * (t + 1 / 7), w, Math.ceil(height / 7) + 2);
  }
  c.fillStyle = '#5b3445'; pixel(c, x - width * .28, foot - height * .36, Math.max(2, width * .18), height * .4);
  c.fillStyle = '#bb5e60'; pixel(c, x + sway * .4, foot - height * .35, 2, height * .26);
  c.fillStyle = '#edac86'; pixel(c, x + sway * .4, foot - height * .2, 2, 4);
  c.restore();
}

/** Local ink, torn seals and a ground sigil leave the hero and HUD readable. */
export function drawDarkBossBack(c: CanvasRenderingContext2D, b: Boss, now: number): void {
  if (b.form !== 2 || b.mode === 'dead') return;
  const x = b.x + b.w / 2, foot = b.y + b.h;
  const transforming = b.mode === 'transition' && b.phase === 2;
  const progress = transforming ? clamp(1 - b.timer / 2.6) : 1;
  c.save(); c.globalAlpha *= transforming ? .85 : .56;
  c.fillStyle = '#151a2599';
  c.beginPath(); c.ellipse(x, foot + 2, transforming ? 83 : 67, 12, 0, 0, TAU); c.fill();
  c.strokeStyle = b.phase >= 3 ? '#d67c78' : '#ac6267'; c.lineWidth = 2;
  c.beginPath(); c.ellipse(x, foot + 1, 71 + Math.sin(now * 3) * 3, 11, 0, 0, TAU); c.stroke();
  for (let i = 0; i < 8; i++) {
    const a = i * TAU / 8 + now * .12;
    c.fillStyle = i % 2 ? '#dca078' : '#8c5260';
    pixel(c, x + Math.cos(a) * 73, foot + Math.sin(a) * 11 - 1, 3, 2);
  }
  for (let i = 0; i < (transforming ? 13 : b.phase >= 3 ? 8 : 6); i++) {
    const age = (now * (transforming ? .8 : .5) + i * .173) % 1;
    const side = i % 2 ? 1 : -1, spread = transforming ? (1 - progress) * 72 + 25 : 28;
    const fx = x + side * (18 + Math.sin(i * 2.3) * 13 + (1 - age) * spread), fy = foot - age * (transforming ? 175 : 105);
    inkFlame(c, fx, fy, transforming ? 15 : 9, (transforming ? 62 : 30) * (1 - age * .55), now * 4 + i, 1 - age * .7);
  }
  if (transforming) {
    const radius = progress < .65 ? 118 - progress * 85 : 66 + (progress - .65) * 165;
    c.strokeStyle = '#b76a6b'; c.lineWidth = 2;
    for (let part = 0; part < 6; part++) {
      const a = part * TAU / 6 + now * .45;
      c.beginPath(); c.arc(x, foot - 62, radius, a, a + .55); c.stroke();
    }
    c.strokeStyle = '#e2ae85'; c.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
      const angle = i * TAU / 5 - now * .24;
      c.beginPath(); c.moveTo(x + Math.cos(angle) * radius * .65, foot - 62 + Math.sin(angle) * radius * .65);
      c.lineTo(x + Math.cos(angle + .05) * (radius + 12), foot - 62 + Math.sin(angle + .05) * (radius + 12)); c.stroke();
    }
  }
  c.restore();
}

export function drawDarkBossFront(c: CanvasRenderingContext2D, b: Boss, now: number): void {
  if (b.form !== 2 || b.mode === 'dead') return;
  const x = b.x + b.w / 2, foot = b.y + b.h;
  c.save(); c.globalAlpha *= .65;
  const flicker = Math.floor(now * 9) % 3;
  for (const side of [-1, 1]) {
    c.strokeStyle = '#bd6e68'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(x + side * 25, foot - 99);
    c.lineTo(x + side * (34 + flicker), foot - 75); c.lineTo(x + side * 29, foot - 62); c.stroke();
  }
  if (b.guard > 0 && b.exposed <= 0) {
    c.strokeStyle = '#987984'; c.lineWidth = 1;
    const armor = [[-36, -89], [-45, -65], [-34, -35], [-17, -27], [21, -27], [40, -48], [43, -74], [31, -94]];
    c.beginPath();
    for (let i = 0; i < armor.length; i++) {
      const [px, py] = armor[i];
      if (i % 2 === 0) c.moveTo(x + px, foot + py); else c.lineTo(x + px, foot + py);
    }
    c.stroke();
    if (b.guard / b.maxGuard < .45) {
      c.strokeStyle = '#d49c83';
      c.beginPath(); c.moveTo(x + 29, foot - 86); c.lineTo(x + 23, foot - 70); c.lineTo(x + 33, foot - 56); c.stroke();
    }
  }
  c.restore();
}

export function drawBurningEnemy(c: CanvasRenderingContext2D, enemy: Enemy, now: number): void {
  if (!(enemy.burnTime && enemy.burnTime > 0) || enemy.dead) return;
  c.save();
  for (let i = 0; i < 4; i++) {
    const age = (now * 1.7 + i / 4) % 1;
    c.globalAlpha = .8; c.fillStyle = i % 2 ? '#f3be7c' : '#cf7650';
    pixel(c, enemy.x + enemy.w / 2 + Math.sin(i * 2.4) * enemy.w * .4, enemy.y + enemy.h - 3 - age * enemy.h * 1.1, 3, 5);
  }
  c.restore();
}

/** Only live, delayed simulation hazards get markers; the damaging column is
 * deliberately absent until its delay reaches zero. */
export function drawCombatProjectile(c: CanvasRenderingContext2D, p: Projectile, now: number): boolean {
  const x = p.x + p.w / 2, y = p.y + p.h / 2;
  if (p.kind === 'rift') {
    c.save();
    if ((p.delay ?? 0) > 0) {
      c.globalAlpha *= .58 + Math.sin(now * 18) * .16;
      c.fillStyle = '#ad59574d'; pixel(c, p.x - 6, p.y + p.h - 7, p.w + 12, 6);
      c.strokeStyle = '#e9a680'; c.lineWidth = 2;
      c.beginPath(); c.ellipse(x, p.y + p.h - 4, p.w * .68, 7, 0, 0, TAU); c.stroke();
      c.fillStyle = '#e8ba95'; pixel(c, x - 2, p.y + p.h - 22, 4, 10); pixel(c, x - 2, p.y + p.h - 8, 4, 3);
    } else {
      inkFlame(c, x, p.y + p.h, p.w + 6, p.h, now * 5);
      inkFlame(c, x - p.w * .3, p.y + p.h, p.w * .42, p.h * .72, now * 6 + 2, .8);
      c.fillStyle = '#e6b18a'; pixel(c, x - 2, p.y + p.h - 48, 4, 42);
      for (let i = 0; i < 5; i++) {
        const age = (now * 2 + i / 5) % 1;
        c.globalAlpha = (1 - age) * .8; c.fillStyle = '#b76766';
        pixel(c, x + Math.sin(i * 2) * p.w * .7, p.y + p.h - age * p.h, 3, 5);
      }
    }
    c.restore(); return true;
  }
  if (p.kind !== 'ember' && p.kind !== 'disc' && p.style !== 'ink' && p.style !== 'reflected') return false;
  c.save();
  if ((p.delay ?? 0) > 0) {
    c.globalAlpha *= .5 + Math.sin(now * 17) * .12;
    c.fillStyle = '#bc6e6c'; pixel(c, x - 9, 443, 18, 3);
    c.strokeStyle = '#e0aa83'; c.setLineDash([3, 7]);
    c.beginPath(); c.moveTo(x, Math.max(110, p.y)); c.lineTo(x, 434); c.stroke();
    c.restore(); return true;
  }
  c.translate(Math.round(x), Math.round(y));
  const angle = Math.atan2(p.vy, p.vx);
  if (p.kind === 'ember') {
    const heavy = p.style === 'charged', r = heavy ? 13 : 9;
    c.rotate(angle);
    for (let i = 5; i >= 1; i--) {
      c.globalAlpha = (1 - i / 7) * .6; c.fillStyle = i % 2 ? '#e19c58' : '#bf654c';
      pixel(c, -r - i * 8, Math.sin(now * 26 + i * 1.2) * 4 - 2, 11 - i, 4);
    }
    c.globalAlpha = 1;
    diamond(c, 0, 0, r + 3, '#b45d43'); diamond(c, 0, 0, r, '#f2b368');
    diamond(c, 1, 0, Math.max(4, r - 4), '#fff0b8');
    if (heavy) {
      c.strokeStyle = '#ffe1a1'; c.lineWidth = 2;
      c.beginPath(); c.arc(0, 0, r + 5, now * 9, now * 9 + 4.8); c.stroke();
      for (let i = 0; i < 4; i++) {
        const a = now * -5 + i * TAU / 4;
        c.fillStyle = '#eebd7a'; pixel(c, Math.cos(a) * (r + 7), Math.sin(a) * (r + 7), 3, 3);
      }
    }
  } else if (p.kind === 'disc') {
    const returning = !!p.returning, r = Math.max(12, p.w * .5);
    c.save(); c.rotate(angle); c.globalAlpha = .38;
    c.fillStyle = returning ? '#a6dac0' : '#b8c8e0';
    pixel(c, -r - 24, -2, 25, 4); pixel(c, -r - 39, -1, 9, 2); c.restore();
    c.rotate(p.rotation ?? now * 17);
    c.strokeStyle = '#21363e'; c.lineWidth = 5; c.beginPath(); c.arc(0, 0, r - 3, 0, TAU); c.stroke();
    c.strokeStyle = returning ? '#a5e9ce' : '#c3cce4'; c.lineWidth = 3;
    c.beginPath(); c.arc(0, 0, r - 2, 0, TAU); c.stroke();
    c.fillStyle = returning ? '#e1eed0' : '#ede0bd';
    for (let i = 0; i < 4; i++) {
      c.rotate(Math.PI / 2); c.beginPath(); c.moveTo(r - 5, -5); c.lineTo(r + 6, -1); c.lineTo(r - 3, 5); c.closePath(); c.fill();
    }
    c.fillStyle = '#cca36b'; pixel(c, -2, -2, 4, 4);
    if (returning) {
      c.strokeStyle = '#b9edcf'; c.globalAlpha = .45; c.lineWidth = 1;
      c.beginPath(); c.arc(0, 0, r + 8, 0, Math.PI * 1.5); c.stroke();
    }
  } else if (p.kind === 'shockwave') {
    c.fillStyle = '#1b202b'; pixel(c, -p.w / 2, -p.h / 2, p.w, p.h);
    c.fillStyle = '#9a5660'; pixel(c, -p.w / 2, -p.h / 2, p.w, 3);
    for (let i = -p.w / 2; i < p.w / 2; i += 8) {
      const height = 6 + Math.round(Math.sin(now * 17 + i) * 4);
      c.fillStyle = '#b96c69'; pixel(c, i, -p.h / 2 - height, 4, height);
    }
    c.fillStyle = '#e6b391'; pixel(c, -2, -p.h / 2 + 2, 4, 7);
  } else {
    c.rotate(angle); c.globalAlpha = .48; c.fillStyle = '#6b3e55';
    pixel(c, -31, -3, 23, 6); pixel(c, -43, -1, 8, 2); c.globalAlpha = 1;
    diamond(c, 0, 0, 10, '#1a1d29'); diamond(c, 0, 0, 6, p.style === 'reflected' ? '#a9d9bd' : '#bd676a');
    c.fillStyle = '#e6b391'; pixel(c, -1, -3, 3, 6);
  }
  c.restore(); return true;
}
