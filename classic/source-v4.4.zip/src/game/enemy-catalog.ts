import type { Enemy } from './types';

export type RegionalAbility = 'hop' | 'dive' | 'rush' | 'fan' | 'leap' | 'guard' | 'hex' | 'tide' | 'orbit' | 'bomb' | 'burst' | 'blink' | 'rift';
export interface RegionalEnemyProfile {
  id: string; name: string; skin: 'mushroom' | 'eye' | 'skeleton' | 'goblin' | 'wizard' | 'duelist';
  ability: RegionalAbility; color: string; hp: number; height: number; warning: number; interval: number; range: number;
}

export const REGIONAL_ENEMIES: Record<string, RegionalEnemyProfile> = Object.fromEntries(([
  ['bamboo-sprout', '雾竹孢妖', 'mushroom', 'hop', '#b8d399', 3, 30, .48, 2.1, 370],
  ['bamboo-moth', '巡竹飞瞳', 'eye', 'dive', '#a1cfb3', 3, 28, .6, 2.5, 420],
  ['lantern-raider', '朱灯掠客', 'goblin', 'rush', '#d99c68', 4, 38, .5, 2.2, 390],
  ['lantern-seer', '赤灯咒师', 'wizard', 'fan', '#d58c72', 3, 40, .62, 2.8, 530],
  ['gale-duelist', '回风刀客', 'duelist', 'leap', '#c4d4b8', 4, 42, .5, 2.4, 390],
  ['gale-wing', '裂风飞瞳', 'eye', 'dive', '#abc9cb', 3, 30, .5, 2.1, 460],
  ['crypt-bulwark', '沉钟盾骸', 'skeleton', 'guard', '#c8c19a', 6, 44, .65, 2.5, 330],
  ['crypt-wraith', '地宫引魂者', 'wizard', 'hex', '#adb4c5', 4, 43, .7, 3, 520],
  ['tide-mage', '琉璃水司', 'wizard', 'tide', '#9dd9c9', 5, 42, .6, 2.5, 550],
  ['tide-sprite', '回澜灵瞳', 'eye', 'orbit', '#a5ddcd', 4, 30, .55, 2.3, 440],
  ['forge-bomber', '丹炉投火妖', 'goblin', 'bomb', '#e3a56f', 5, 40, .65, 2.6, 540],
  ['forge-cinder', '熔火焚瞳', 'eye', 'burst', '#e7aa78', 4, 32, .65, 2.7, 430],
  ['astral-duelist', '天仪执刃使', 'duelist', 'blink', '#d4bd8f', 7, 44, .45, 2.4, 430],
  ['astral-seer', '逆星术士', 'wizard', 'rift', '#c0a7c8', 6, 44, .7, 3.2, 560],
] as const).map(([id, name, skin, ability, color, hp, height, warning, interval, range]) => [id, { id, name, skin, ability, color, hp, height, warning, interval, range }]));

/** Every non-Boss realm has its own two enemy identities and attack rules. */
export const REGIONAL_ROSTERS = [
  ['bamboo-sprout', 'bamboo-moth'], ['lantern-raider', 'lantern-seer'],
  ['gale-duelist', 'gale-wing'], ['crypt-bulwark', 'crypt-wraith'],
  ['tide-mage', 'tide-sprite'], ['forge-bomber', 'forge-cinder'],
  ['astral-duelist', 'astral-seer'],
] as const;

export function enemyProfile(enemy: Pick<Enemy, 'variant'>): RegionalEnemyProfile | undefined {
  return enemy.variant ? REGIONAL_ENEMIES[enemy.variant] : undefined;
}

export function regionalEnemyId(roomIndex: number, flying: boolean): string {
  return REGIONAL_ROSTERS[Math.max(0, Math.min(6, roomIndex))][flying ? 1 : 0];
}
