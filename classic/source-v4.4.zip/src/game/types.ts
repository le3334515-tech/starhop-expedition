export const EXPEDITION_ROOM_COUNT = 8;
export type WeaponId = 'blade' | 'ember' | 'disc';
export type ModifierId = 'standard' | 'moon' | 'haste' | 'iron';
export type Phase = 'menu' | 'playing' | 'paused' | 'upgrade' | 'victory' | 'gameover';
export type SoundName = 'jump' | 'doubleJump' | 'attack' | 'fire' | 'coin' | 'hurt' | 'kill' | 'upgrade' | 'portal' | 'boss' | 'win' | 'lose' | 'dash' | 'select' | 'awaken' | 'synergy' | 'hit' | 'critical' | 'heavy' | 'guardBreak' | 'perfectDodge';

export interface Rect { x: number; y: number; w: number; h: number }
export interface Vec { x: number; y: number }
export interface Platform extends Rect { kind: 'ground' | 'stone' | 'wood' | 'spring'; oneWay?: boolean }
export interface Hazard extends Rect { kind: 'spikes' | 'lava' }
export interface Decoration { x: number; y: number; kind: 'tree' | 'ruin' | 'lamp' | 'mushroom' | 'grass' | 'crystal'; scale?: number }
export interface Enemy extends Rect {
  id: number; kind: 'slime' | 'bat' | 'sentry'; vx: number; vy: number; hp: number; maxHp: number;
  facing: number; timer: number; hurt: number; dead: boolean; originX: number; originY: number; attackCooldown: number;
  variant?: string; skin?: string; aiMode?: 'patrol' | 'windup' | 'attack' | 'recover'; aiTimer?: number; aiCount?: number; targetX?: number;
  burnTime?: number; burnTick?: number; burnDamage?: number;
}
export interface Boss extends Rect {
  hp: number; maxHp: number; phase: number; mode: 'idle' | 'windup' | 'charge' | 'jump' | 'slam' | 'recover' | 'dead' | 'transition' | 'barrage' | 'stagger';
  timer: number; vx: number; vy: number; facing: number; hurt: number; attackCount: number; active: boolean;
  intent: 'charge' | 'leap' | 'slam' | 'barrage' | 'rift' | 'rain'; targetX: number; chain: number;
  guard: number; maxGuard: number; exposed: number;
  form?: 1 | 2; burnTime?: number; burnTick?: number; burnDamage?: number;
}
export interface Projectile extends Rect {
  id: number; kind: 'ember' | 'disc' | 'enemy' | 'shockwave' | 'rift'; vx: number; vy: number; life: number;
  damage: number; owner: 'hero' | 'enemy'; hitIds: number[]; returning?: boolean; rotation?: number;
  style?: 'charged' | 'ink' | 'reflected'; pierce?: number; burn?: number; delay?: number; gravity?: number; color?: string;
}
export interface Pickup extends Rect { id: number; kind: 'coin' | 'xp' | 'heart'; value: number; vy: number; bob: number; collected: boolean }
export interface Particle { x: number; y: number; vx: number; vy: number; life: number; maxLife: number; size: number; color: string; gravity?: number }
export interface FloatingText { x: number; y: number; text: string; color: string; life: number; maxLife: number }
export interface Impact { x: number; y: number; life: number; maxLife: number; size: number; angle: number; color: string; kind: 'hit' | 'critical' | 'heavy' | 'break' }
export interface Hero extends Rect {
  vx: number; vy: number; facing: number; hp: number; maxHp: number; xp: number; xpNeeded: number; level: number;
  grounded: boolean; jumps: number; coyote: number; jumpBuffer: number; invincible: number;
  attackTimer: number; attackCooldown: number; dashTimer: number; dashCooldown: number; weapon: WeaponId;
  damage: number; speed: number; attackSpeed: number; critChance: number; extraProjectiles: number;
  lifesteal: number; magnet: number; shield: number; upgrades: string[]; animation: number;
  attackStep: number; comboWindow: number; swapBoost: number; swapCooldown: number; counterTimer: number; perfectDodgeCooldown: number;
  guardTimer: number; guardCooldown: number;
}
export interface Room {
  index: number; name: string; subtitle: string; width: number; height: number; theme: number;
  platforms: Platform[]; hazards: Hazard[]; decorations: Decoration[];
  spawn: Vec; exit: Rect; checkpoint: Vec; isBoss: boolean;
}
export interface Upgrade { id: string; name: string; description: string; icon: string; rarity: 'common' | 'rare' | 'epic'; color: string }
export interface Synergy { id: string; name: string; description: string; requires: string[]; color: string }
export interface GameConfig { seed: number; modifier: ModifierId; weapon: WeaponId }
export interface GameResult extends GameConfig {
  won: boolean; time: number; score: number; coins: number; kills: number; level: number;
  deaths: number; roomsCleared: number; maxCombo: number; upgrades: string[]; overdriveCount: number; synergies: string[];
}
export interface InputState {
  left: boolean; right: boolean; jumpPressed: boolean; jumpHeld: boolean;
  attackPressed: boolean; attackHeld: boolean; dashPressed: boolean; interactPressed: boolean; overdrivePressed: boolean;
  guardPressed?: boolean;
}
export interface GameState {
  phase: Phase; seed: number; modifier: ModifierId; roomIndex: number; roomCount: number; room: Room;
  hero: Hero; enemies: Enemy[]; boss: Boss | null; projectiles: Projectile[]; pickups: Pickup[];
  particles: Particle[]; floatingTexts: FloatingText[]; cameraX: number; time: number; visualTime: number;
  coins: number; kills: number; deaths: number; combo: number; maxCombo: number; comboTimer: number;
  roomCleared: boolean; roomsCleared: number; upgradeChoices: Upgrade[];
  shake: number; flash: number; transition: number; announcement: string; announcementTimer: number;
  result: GameResult | null;
  resonance: number; overdrive: number; overdriveCount: number; synergies: string[];
  hitstop: number; impacts: Impact[];
}
export interface EngineCallbacks { sound?: (name: SoundName) => void }
export const EMPTY_INPUT: InputState = { left: false, right: false, jumpPressed: false, jumpHeld: false, attackPressed: false, attackHeld: false, dashPressed: false, interactPressed: false, overdrivePressed: false, guardPressed: false };

/** All three weapons awaken new moves as the current run grows. */
export function weaponTier(hero: Pick<Hero, 'level'>): number { return hero.level >= 7 ? 3 : hero.level >= 4 ? 2 : 1; }

export const WEAPONS: Record<WeaponId, { name: string; subtitle: string; description: string; color: string; icon: string }> = {
  blade: { name: '星陨短刃', subtitle: '近战 · 迅捷连斩', description: '挥出弧形剑气，近身攻击更强。', color: '#7de7cf', icon: 'blade' },
  ember: { name: '萤火法杖', subtitle: '远程 · 贯穿焰爆', description: '追踪贯穿并引爆灼烧，每第三次施放为蓄能重弹；二阶增加一道星焰，三阶贯穿更多敌人。', color: '#ffb474', icon: 'ember' },
  disc: { name: '回声飞轮', subtitle: '投掷 · 双轮回锋', description: '双轮往返穿透，回程伤害提升45%；二阶三轮齐出，三阶可击碎敌方飞弹。命中回收积攒星能。', color: '#b7afff', icon: 'disc' },
};
export const MODIFIERS: Record<ModifierId, { name: string; tag: string; description: string; icon: string }> = {
  standard: { name: '经典远征', tag: 'STANDARD', description: '标准规则，踏上你的第一场远征。', icon: 'star' },
  moon: { name: '月球漫步', tag: 'LOW GRAVITY', description: '重力降低，跳得更高，滞空更久。', icon: 'moon' },
  haste: { name: '极速派对', tag: 'HYPER SPEED', description: '你和敌人一起加速，反应决定胜负。', icon: 'bolt' },
  iron: { name: '一命之约', tag: 'ONE HEART', description: '仅有一颗心，护盾与闪避更珍贵。', icon: 'heart' },
};
