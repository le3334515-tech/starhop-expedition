import type { GameConfig } from './game/types';
import { parseRaceResponse, sanitizeRaceFrame, type RaceFrame, type RaceGhost, type RaceResponse, type RaceRoom, type RaceSeat, type RaceView } from './race-types';
export type { RaceFrame, RaceGhost, RacePlayer, RaceRoom, RaceView } from './race-types';

export const RACE_ENDPOINT = 'https://starhop-race-relay-20261118.fruitfulmaple8.chatgpt.site/api/race';
interface Options { onChange?: (view: RaceView) => void; onStart?: (config: GameConfig, startAt: number) => void; onError?: (message: string) => void }
interface Credentials { roomId: string; token: string; clientId: string; selfId: RaceSeat }
interface GhostSample { frame: RaceFrame; at: number; receivedAt: number; name: string }
class RaceApiError extends Error { constructor(message: string, public status: number) { super(message); } }
const storageKey = (room: string) => `starhop.race.room.v1.${room}`;
const uid = () => globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}_${Math.random().toString(36).slice(2)}`;
const friendlyError = (error: unknown) => error instanceof Error ? error.message : '暂时未能连接竞速房间。';

/** Independent race transport. Frames are visual ghosts, never simulation inputs. */
export class RaceSession {
  private room: RaceRoom | null = null;
  private credentials: Credentials | null = null;
  private connection: RaceView['connection'] = 'idle';
  private error: string | null = null;
  private offset = 0;
  private bestRtt = Infinity;
  private latestFrame: RaceFrame | null = null;
  private samples: GhostSample[] = [];
  private timer: ReturnType<typeof setTimeout> | undefined;
  private startTimer: ReturnType<typeof setTimeout> | undefined;
  private request: AbortController | null = null;
  private generation = 0;
  private busy = false;
  private startedKey = '';
  private finishFrame: RaceFrame | null = null;
  private lastOpponentSeq = -1;
  private latestSnapshotAt = 0;
  private pollPeriod = 0;

  constructor(readonly endpoint = RACE_ENDPOINT, private options: Options = {}) {}

  get view(): RaceView {
    const selfId = this.credentials?.selfId ?? null;
    const self = this.room && selfId ? this.room[selfId] : null;
    const opponent = this.room && selfId ? this.room[selfId === 'host' ? 'guest' : 'host'] : null;
    const startAt = this.room?.startAt ?? null;
    return { connection: this.connection, room: this.room, selfId, self, opponent,
      started: startAt !== null && this.estimatedServerNow() >= startAt,
      countdown: startAt !== null && this.estimatedServerNow() < startAt ? Math.max(1, Math.ceil((startAt - this.estimatedServerNow()) / 1000)) : null,
      elapsed: this.elapsed(), error: this.error, opponentAgeMs: this.samples.length ? Math.max(0, Date.now() - this.samples.at(-1)!.receivedAt) : 0 };
  }
  estimatedServerNow(): number { return Date.now() + this.offset; }
  elapsed(): number {
    const at = this.room?.startAt;
    if (at == null) return 0;
    const self = this.credentials ? this.room?.[this.credentials.selfId] : null;
    const end = self?.finishedAt ?? (this.finishFrame ? at + this.finishFrame.elapsed * 1000 : this.estimatedServerNow());
    return Math.max(0, (end - at) / 1000);
  }
  tick(): void { this.maybeStart(); }

  async create(config: GameConfig, name: string): Promise<void> {
    this.disconnect(); const generation = this.generation;
    this.connection = 'connecting'; this.error = null; this.publish();
    const clientId = uid();
    try {
      const response = await this.post({ action: 'create', config, name, clientId });
      if (generation !== this.generation) return;
      if (!response.token) throw new Error('房间凭证未能生成，请重新发起。');
      this.credentials = { roomId: response.room.id, token: response.token, selfId: response.selfId, clientId };
      this.saveCredentials(); this.accept(response); this.startPolling();
    } catch (error) { if (generation !== this.generation) return; this.fail(error); throw error; }
  }
  async join(roomId: string, name: string): Promise<void> {
    if (!/^[a-zA-Z0-9_-]{12,128}$/.test(roomId)) throw new Error('这份在线挑战链接不完整。');
    this.disconnect(); const generation = this.generation;
    this.connection = 'connecting'; this.error = null; this.publish();
    let saved: Credentials | null = null;
    try { const value = JSON.parse(sessionStorage.getItem(storageKey(roomId)) || 'null'); if (value?.roomId === roomId && typeof value.token === 'string' && typeof value.clientId === 'string' && ['host', 'guest'].includes(value.selfId)) saved = value; } catch { /* Optional refresh recovery. */ }
    const clientId = saved?.clientId ?? uid();
    try {
      let response: RaceResponse;
      if (saved) {
        this.credentials = saved;
        try { response = await this.post({ action: 'state', roomId, token: saved.token, clientId }); }
        catch (error) {
          if (!(error instanceof RaceApiError) || error.status !== 401) throw error;
          this.credentials = null; response = await this.post({ action: 'join', roomId, name, clientId });
        }
      } else response = await this.post({ action: 'join', roomId, name, clientId });
      if (generation !== this.generation) return;
      const token = response.token ?? saved?.token;
      if (!token) throw new Error('未能取得同行凭证，请重新打开邀请。');
      this.credentials = { roomId, token, selfId: response.selfId, clientId };
      this.saveCredentials(); this.accept(response); this.startPolling();
    } catch (error) { if (generation !== this.generation) return; this.fail(error); throw error; }
  }
  async ready(ready = true): Promise<void> { await this.command('ready', { ready }); }
  async reset(): Promise<void> {
    await this.command('reset'); this.startedKey = ''; this.finishFrame = null; this.latestFrame = null; this.samples = []; this.lastOpponentSeq = -1;
    this.startPolling(); this.publish();
  }
  updateFrame(frame: RaceFrame): void {
    if (!this.credentials || this.finishFrame) return;
    this.latestFrame = sanitizeRaceFrame({ ...frame, elapsed: this.elapsed() });
  }
  async finish(won: boolean): Promise<void> {
    if (!this.credentials || this.finishFrame) return;
    this.finishFrame = sanitizeRaceFrame({ ...this.latestFrame, elapsed: this.elapsed(), finished: true, won, phase: won ? 'victory' : 'gameover', seq: (this.latestFrame?.seq ?? 0) + 1 });
    this.latestFrame = this.finishFrame;
    await this.command('state', { frame: this.finishFrame });
    this.startPolling(1000);
  }
  async leave(): Promise<void> {
    const credentials = this.credentials;
    this.disconnect(); this.connection = 'closed'; this.publish();
    if (!credentials) return;
    try { sessionStorage.removeItem(storageKey(credentials.roomId)); } catch { /* Optional storage. */ }
    const abort = new AbortController(), timeout = setTimeout(() => abort.abort(), 3000);
    try { await fetch(this.endpoint, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: 'leave', ...credentials }), signal: abort.signal, keepalive: true }); }
    catch { /* Local departure does not depend on a reply. */ }
    finally { clearTimeout(timeout); }
  }
  opponentFrame(): RaceGhost | null {
    if (this.view.opponent?.leftAt != null) return null;
    const latest = this.samples.at(-1); if (!latest) return null;
    const now = Date.now(), target = now - 180;
    const previous = this.samples.length > 1 ? this.samples[this.samples.length - 2] : latest;
    let frame = { ...latest.frame };
    if (previous.frame.roomIndex === latest.frame.roomIndex && previous.receivedAt < latest.receivedAt && target < latest.receivedAt) {
      const t = Math.max(0, Math.min(1, (target - previous.receivedAt) / (latest.receivedAt - previous.receivedAt)));
      frame.x = previous.frame.x + (latest.frame.x - previous.frame.x) * t;
      frame.y = previous.frame.y + (latest.frame.y - previous.frame.y) * t;
      frame.animation = previous.frame.animation + (latest.frame.animation - previous.frame.animation) * t;
    }
    const ageMs = Math.max(0, Date.now() - latest.receivedAt);
    if (ageMs < 600 && latest.frame.phase === 'playing' && !latest.frame.finished && target > latest.receivedAt) {
      const dt = Math.min(.12, (target - latest.receivedAt) / 1000);
      frame.x += latest.frame.vx * dt; frame.y += latest.frame.vy * dt;
    }
    return { ...frame, name: latest.name, ageMs, stale: ageMs > 2000 };
  }

  private saveCredentials() { try { if (this.credentials) sessionStorage.setItem(storageKey(this.credentials.roomId), JSON.stringify(this.credentials)); } catch { /* In-memory networking remains available. */ } }
  private publish() { this.options.onChange?.(this.view); }
  private fail(error: unknown) { this.connection = 'error'; this.error = friendlyError(error); this.publish(); this.options.onError?.(this.error); }
  private disconnect() {
    this.generation++; clearTimeout(this.timer); clearTimeout(this.startTimer); this.timer = undefined; this.startTimer = undefined; this.pollPeriod = 0;
    this.request?.abort(); this.request = null; this.busy = false;
    this.room = null; this.credentials = null; this.latestFrame = null; this.finishFrame = null; this.samples = []; this.lastOpponentSeq = -1; this.latestSnapshotAt = 0; this.startedKey = ''; this.bestRtt = Infinity; this.offset = 0;
  }
  private startPolling(period = 200) {
    if (this.pollPeriod === period && (this.timer || this.busy)) return;
    clearTimeout(this.timer); this.timer = undefined; this.pollPeriod = period;
    if (!this.busy) this.scheduleExchange(period);
  }
  private scheduleExchange(delay: number) { this.timer = setTimeout(() => { this.timer = undefined; void this.exchange(); }, delay); }
  private async exchange() {
    if (this.busy || !this.credentials) return;
    this.busy = true; const generation = this.generation, sent = Date.now();
    try {
      const response = await this.post({ action: 'state', ...this.credentials, frame: this.finishFrame ?? this.latestFrame ?? undefined });
      if (generation === this.generation) this.accept(response);
    } catch (error) {
      if (generation !== this.generation) return;
      if (error instanceof RaceApiError && [401, 404, 410].includes(error.status)) { clearTimeout(this.timer); clearTimeout(this.startTimer); this.fail(error); }
      else { this.connection = 'reconnecting'; this.error = '连接暂时中断，正在重连…'; this.publish(); }
    } finally {
      if (generation === this.generation) {
        this.busy = false;
        if (this.credentials && this.connection !== 'error') this.scheduleExchange(Math.max(30, this.pollPeriod - (Date.now() - sent)));
      }
    }
  }
  private async command(action: string, data: Record<string, unknown> = {}) {
    if (!this.credentials) throw new Error('请先进入在线竞速房间。');
    const generation = this.generation;
    try { const response = await this.post({ action, ...this.credentials, ...data }); if (generation === this.generation) this.accept(response); }
    catch (error) { this.error = friendlyError(error); this.publish(); throw error; }
  }
  private async post(body: Record<string, unknown>): Promise<RaceResponse> {
    const sent = Date.now(), abort = new AbortController();
    // Capture the round when sending. Old completion frames must not enter a rematch.
    const payload = body.action === 'state' ? { ...body, epoch: this.room?.epoch ?? 0 } : body;
    // A command can run alongside a state exchange; its own timeout always releases.
    const timeout = setTimeout(() => abort.abort(), 6500);
    this.request = abort;
    try {
      const response = await fetch(this.endpoint, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload), cache: 'no-store', signal: abort.signal });
      const raw = await response.json();
      if (!response.ok || raw?.ok !== true) throw new RaceApiError(typeof raw?.message === 'string' ? raw.message : '未能进入这个竞速房间。', response.status);
      const result = parseRaceResponse(raw), received = Date.now(), rtt = received - sent;
      if (rtt <= this.bestRtt + 25) {
        const estimate = result.serverNow - (sent + received) / 2;
        this.offset = this.bestRtt === Infinity ? estimate : this.offset * .35 + estimate * .65;
        this.bestRtt = Math.min(this.bestRtt, rtt);
      }
      return result;
    } finally { clearTimeout(timeout); if (this.request === abort) this.request = null; }
  }
  private accept(response: RaceResponse) {
    if (response.serverNow < this.latestSnapshotAt) return;
    if (this.room && (response.room.epoch ?? 0) < (this.room.epoch ?? 0)) return;
    this.latestSnapshotAt = response.serverNow;
    if (this.room && (response.room.epoch !== this.room.epoch || this.room.startAt !== null && response.room.startAt === null && !this.startedKey)) {
      this.finishFrame = null; this.latestFrame = null; this.samples = []; this.lastOpponentSeq = -1; this.startedKey = '';
      this.startPolling();
    }
    this.room = response.room; this.connection = 'online'; this.error = null;
    if (this.credentials) this.credentials.selfId = response.selfId;
    const opponent = response.selfId === 'host' ? response.room.guest : response.room.host;
    if (opponent?.frame && opponent.frame.seq > this.lastOpponentSeq) {
      this.lastOpponentSeq = opponent.frame.seq;
      this.samples.push({ frame: opponent.frame, at: opponent.lastSeen, receivedAt: Date.now(), name: opponent.name });
      if (this.samples.length > 3) this.samples.shift();
    }
    this.maybeStart();
    if (response.room.status === 'finished' || this.credentials && response.room[this.credentials.selfId]?.finishedAt != null) this.startPolling(1000);
    this.publish();
  }
  private maybeStart() {
    const room = this.room, credentials = this.credentials, at = room?.startAt;
    if (at == null || !room || !credentials || this.connection === 'error') return;
    const key = `${room.id}:${at}`;
    if (this.startedKey === key || room[credentials.selfId]?.finishedAt != null) return;
    clearTimeout(this.startTimer);
    const remaining = at - this.estimatedServerNow();
    if (remaining > 0) { this.startTimer = setTimeout(() => this.maybeStart(), remaining + 1); return; }
    this.startedKey = key; this.options.onStart?.({ ...room.config }, at);
  }
}

export function raceInviteUrl(roomId: string, pageUrl = location.href): string {
  const url = new URL(pageUrl); url.hash = `race=${encodeURIComponent(roomId)}`; return url.href;
}
export function raceRoomFromUrl(url: string): string | null {
  try { const id = new URL(url).hash.match(/^#race=([a-zA-Z0-9_-]{12,128})$/)?.[1]; return id ?? null; } catch { return null; }
}
