import './story.css';
import type { GameEngine } from './game/engine';
import { escapeHtml as esc } from './icons';
import { expeditionOrder, EXPEDITION_TITLES } from './game/levels';

export interface StoryEntry {
  title: string;
  speaker: string;
  text: string[];
  objective: string;
  realm?: number;
}

export const PROLOGUE: StoryEntry = {
  title: '序 · 最后一盏星灯', speaker: '阿萤的留音',
  text: ['今夜，八境的星灯同时熄灭。姐姐阿萤只留下一枚仍有余温的行牒，和一段被风切碎的声音。', '「天仪没有坏，它在等人替它作一个选择。沿着我留下的灯走……别让守卫独自等到天亮。」'],
  objective: '循着阿萤的灯火，找回八境熄灭的原因。',
};

export const STORY_CHAPTERS: StoryEntry[] = [
  {
    title: '一 · 雾竹山门', speaker: '行牒上的字',
    text: ['山门的铜锁早已锈断，竹间却仍响着阿萤常吹的曲子。守门人只剩一具被星火驱动的空壳。', '行牒浮出熟悉的字迹：「我们借星火照亮八境，却从未问过，谁在替星火守夜。」'],
    objective: '净化山门守卫，穿过星门；上层晶台藏着补给。',
  },
  {
    title: '二 · 朱灯旧街', speaker: '灯铺老人的纸笺',
    text: ['街上的灯都亮着，屋里却没有人。灯铺的纸笺压在柜台下：居民已被阿萤送往山外，她独自去了地宫。', '每盏朱灯里都有一小点黑色余烬。它们不是失去光，而是把光送向了同一个地方。'],
    objective: '净化旧街，带走朱灯中指向星火汇流处的线索。',
  },
  {
    title: '三 · 回风栈道', speaker: '断桥旁的留音',
    text: ['断桥旁系着熟悉的红绳。留音终于清楚起来：「守卫正在抽走八境的星火，封住天上的裂隙。继续供火，八境会枯竭；拔掉天仪，裂隙就会重开。」', '桥下的风带来远处钟声。阿萤说，地宫里还藏着第三条路。'],
    objective: '越过断桥与弹簧台，取回留音中的线索。',
  },
  {
    title: '四 · 沉钟地宫', speaker: '旧天仪碑文',
    text: ['沉钟背面的碑文记着被抹去的旧法：八境并非八份燃料，而是八个可以彼此分担的星环。', '只要重连水庭、机坊与中枢，就能让星火循环。守卫不是敌人——它只是执行着最后一道无人撤销的命令。'],
    objective: '净化地宫，取回重连八境星环的碑文。',
  },
  {
    title: '五 · 琉璃水庭', speaker: '水面里的回声',
    text: ['星火沉在水底，像一条倒悬的银河。阿萤留下的引流槽尚未合拢，最后一处机关被魔物占据。', '你将行牒浸入水中，细小的星光沿着回流槽奔向山门。远处，一盏熄灭的灯重新亮了。'],
    objective: '净化水庭，让第一股星火重新回流。',
  },
  {
    title: '六 · 丹炉机坊', speaker: '阿萤的最后一封信',
    text: ['机坊深处，旧齿轮终于再次咬合。炉边的信写着：「我去神殿拖住守卫。若你读到这里，说明那条路真的存在。」', '信末有她画歪的小星星，和一句熟悉的话：「这次，换你来接我回家。」'],
    objective: '重启机坊，取回炉中断开的回流星火。',
  },
  {
    title: '七 · 天仪中枢', speaker: '重启的天仪',
    text: ['八道环轨在头顶缓缓显露。天仪发出残缺的指令：重连八境，解除守卫的封锁，将囤积的星火归还故土。', '神殿方向传来阿萤微弱的回应。她还在等你，但守卫已分不清援手与入侵者。'],
    objective: '取回中枢的星环刻印，继续净化余下诸境。',
  },
  {
    title: '八 · 余烬神殿', speaker: '余烬守卫',
    text: ['「封锁未解除。任何来者，不得靠近裂隙。」守卫的声音在空殿回响，它的胸前却系着阿萤的红绳。', '你举起八境行牒。不是为了夺走最后的星火，而是让这位守夜人终于能够放下武器。'],
    objective: '观察冲锋、跃击和弹幕预警，格挡或闪避后反击。',
  },
];

export const EPILOGUE: StoryEntry = {
  title: '终 · 群星归途', speaker: '天亮之前',
  text: ['守卫的护甲碎开，星火沿八道环轨奔向山门。裂隙在晨光中合拢，八境的灯逐一亮起。', '阿萤从神殿后走来，把那根红绳重新系回你的行牒。「走吧，」她说，「这回不用谁独自守夜了。」', '你们经过旧街时，第一家灯铺已经开门。'],
  objective: '八境远征完成。你的通关成绩仍保留在结算页。',
};

const CHAPTER_NUMERALS = ['一', '二', '三', '四', '五', '六', '七', '八'];
export function chapterForRoom(theme: number, stage: number): StoryEntry {
  const chapter = STORY_CHAPTERS[theme];
  if (!chapter || !CHAPTER_NUMERALS[stage]) throw new RangeError('Unknown story realm or stage');
  return { ...chapter, realm: theme, title: `${CHAPTER_NUMERALS[stage]} · ${EXPEDITION_TITLES[theme][0]}`,
    objective: stage === 6 ? `${chapter.objective} 净化此境后，八道星纹将齐，前往余烬神殿。` : chapter.objective };
}

interface StoryOptions { clearInput: () => void; onResume?: () => void; route?: () => number[]; skipScenes?: () => boolean }

/** Called once per frame before simulation; narrative pauses never count as run time. */
export function installStory(engine: GameEngine, options: StoryOptions) {
  const dialog = document.createElement('dialog');
  dialog.id = 'story-dialog';
  dialog.className = 'story-dialog';
  dialog.setAttribute('aria-labelledby', 'story-title');
  (document.getElementById('game-shell') ?? document.body).append(dialog);
  const journalButton = document.createElement('button');
  journalButton.id = 'story-journal-button';
  journalButton.className = 'text-button story-journal-button';
  journalButton.textContent = '✦ 剧情手札';
  journalButton.setAttribute('aria-label', '阅读八境剧情手札');
  document.querySelector('.eyebrow-line')?.append(journalButton);

  let state = engine.state;
  let seen = new Set<number>();
  let endingSeen = false;
  let pausedByStory = false;
  let queue: StoryEntry[] = [];
  let journal = false;
  let skipChapterScenes = false;
  const unlockedRealms = new Set<number>();
  try {
    const saved = localStorage.getItem('starhop.story.realms.v1');
    if (saved) {
      const realms: unknown = JSON.parse(saved);
      if (Array.isArray(realms)) for (const realm of realms) if (Number.isInteger(realm) && realm >= 0 && realm <= 7) unlockedRealms.add(realm);
    } else {
      const legacy = localStorage.getItem('starhop.story.progress');
      if (legacy !== null) for (let theme = 0; theme <= Math.min(7, Number(legacy) || 0); theme++) unlockedRealms.add(theme);
    }
  } catch { /* Session progress still works. */ }
  const route = () => options.route?.() ?? expeditionOrder(engine.state.seed);

  function close(resume = true) {
    queue = [];
    if (dialog.open) dialog.close();
    options.clearInput();
    if (resume && pausedByStory && engine.state.phase === 'paused') engine.resume();
    pausedByStory = false;
    options.onResume?.();
    document.getElementById('game-shell')?.focus({ preventScroll: true });
  }

  function draw(entry: StoryEntry) {
    const chapter = entry.realm ?? STORY_CHAPTERS.indexOf(entry);
    const tabs = journal ? `<nav class="story-chapters" aria-label="已解锁章节"><button type="button" data-story-entry="-1" aria-pressed="${entry === PROLOGUE}">序</button>${route().map((theme, stage) => `<button type="button" data-story-entry="${theme}" aria-label="第${stage + 1}境 ${esc(EXPEDITION_TITLES[theme][0])}" aria-pressed="${chapter === theme}" ${!unlockedRealms.has(theme) ? 'disabled title="到达此境后解锁"' : ''}>${stage + 1}</button>`).join('')}${endingSeen ? `<button type="button" data-story-entry="8" aria-pressed="${entry === EPILOGUE}">终</button>` : ''}</nav>` : '';
    dialog.innerHTML = `<div class="story-sheet"><div class="story-topline"><span>八境行牒 / THE EMBER CHRONICLE</span><button type="button" class="story-close" data-story-close aria-label="关闭剧情手札">×</button></div>${tabs}<div class="story-heading"><span class="story-seal" aria-hidden="true">牒</span><div><span class="story-speaker">${esc(entry.speaker)}</span><h2 id="story-title">${esc(entry.title)}</h2></div></div><div class="story-copy">${entry.text.map(paragraph => `<p>${esc(paragraph)}</p>`).join('')}</div><p class="story-objective"><span>此行所向</span>${esc(entry.objective)}</p><div class="story-bottom"><span>${journal ? '已到达的章节可以随时重读' : '剧情阅读期间暂停计时 · ESC 跳过此页'}</span><button type="button" class="primary-button" data-story-next autofocus>${journal ? '合上手札' : queue.length > 1 ? '继续阅读' : entry === EPILOGUE ? '查看通关结算' : '踏入此境'} <span aria-hidden="true">↗</span></button></div>${!journal && entry !== EPILOGUE ? '<label class="story-skip"><input type="checkbox" id="story-skip-chapters">本局后续剧情收进手札，不再自动弹出</label>' : ''}</div>`;
    if (!dialog.open) dialog.showModal();
    dialog.querySelector<HTMLButtonElement>('[data-story-next]')?.focus({ preventScroll: true });
  }

  function open(entries: StoryEntry[], asJournal = false) {
    if (dialog.open || document.querySelector('#dialog[open]')) return;
    options.clearInput();
    pausedByStory = engine.state.phase === 'playing';
    if (pausedByStory) engine.pause();
    journal = asJournal;
    queue = entries;
    draw(queue[0]);
  }

  function next() {
    if (dialog.querySelector<HTMLInputElement>('#story-skip-chapters')?.checked) skipChapterScenes = true;
    if (!journal && queue.length > 1 && !skipChapterScenes) { queue.shift(); draw(queue[0]); }
    else close();
  }

  journalButton.addEventListener('click', () => open([PROLOGUE], true));
  dialog.addEventListener('click', event => {
    const button = (event.target as HTMLElement).closest<HTMLButtonElement>('button');
    if (!button) return;
    if (button.hasAttribute('data-story-close')) close();
    else if (button.hasAttribute('data-story-next')) next();
    else if (button.dataset.storyEntry !== undefined) {
      const index = Number(button.dataset.storyEntry);
      if (index < 0) draw(PROLOGUE);
      else if (index === 8) draw(EPILOGUE);
      else if (unlockedRealms.has(index)) draw(chapterForRoom(index, route().indexOf(index)));
    }
  });
  dialog.addEventListener('cancel', event => { event.preventDefault(); next(); });
  window.addEventListener('keydown', event => {
    if (!dialog.open) return;
    event.stopImmediatePropagation();
    if (event.code === 'Escape' || event.code === 'Enter' && !(event.target as HTMLElement).closest('button,input')) {
      event.preventDefault();
      if (!event.repeat) next();
    }
  }, true);

  return {
    get open() { return dialog.open; },
    update() {
      if (engine.state !== state) {
        close(false);
        state = engine.state;
        seen = new Set(); endingSeen = false; skipChapterScenes = options.skipScenes?.() ?? false;
      }
      if (engine.state.phase === 'menu') { if (dialog.open && !journal) close(false); return; }
      if (dialog.open) return;
      if (engine.state.phase === 'playing' && !seen.has(engine.state.roomIndex)) {
        const index = engine.state.roomIndex;
        seen.add(index);
        const theme = engine.state.room.theme;
        unlockedRealms.add(theme);
        try { localStorage.setItem('starhop.story.realms.v1', JSON.stringify([...unlockedRealms])); } catch { /* Optional persistence. */ }
        const chapter = chapterForRoom(theme, index);
        if (!skipChapterScenes) open(index === 0 ? [PROLOGUE, chapter] : [chapter]);
      } else if (engine.state.phase === 'victory' && !endingSeen) {
        endingSeen = true;
        if (!options.skipScenes?.()) open([EPILOGUE]);
      }
    },
    close,
  };
}
