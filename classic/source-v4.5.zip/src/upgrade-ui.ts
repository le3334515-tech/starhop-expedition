import type { Hero, Upgrade } from './game/types';
import { icon, escapeHtml as esc } from './icons';

const SEALS: Record<string, { glyph: string; path: string; effect: string }> = {
  edge: { glyph: '刃', path: '淬刃之道', effect: '朱金刀焰 · 刃光外延' },
  tempo: { glyph: '风', path: '驭风之道', effect: '连斩风纹 · 出手更快' },
  vigor: { glyph: '心', path: '养元之道', effect: '气血回满 · 暖辉护体' },
  stride: { glyph: '行', path: '逐影之道', effect: '冲刺风刃 · 掠身伤敌' },
  multishot: { glyph: '星', path: '引星之道', effect: '星火随行 · 每击附弹' },
  shield: { glyph: '月', path: '守月之道', effect: '月环护盾 · 新境补一层' },
  blood: { glyph: '生', path: '回春之道', effect: '红纹回流 · 击杀必回春' },
  magnet: { glyph: '引', path: '聚灵之道', effect: '聚灵磁场 · 远处收补给' },
  fortune: { glyph: '财', path: '藏金之道', effect: '金色星屑 · 拾币蓄星能' },
};
const fixed = (number: number) => number.toFixed(2).replace(/\.00$/, '');
const count = (hero: Hero, id: string) => hero.upgrades.filter(item => item === id).length;

export function upgradePreview(upgrade: Upgrade, hero: Hero): { label: string; before: string; after: string; effect: string } {
  const metadata = SEALS[upgrade.id];
  const effect = metadata?.effect ?? upgrade.description;
  switch (upgrade.id) {
    case 'edge': return { label: '武器伤害', before: `×${fixed(hero.damage)}`, after: `×${fixed(hero.damage + .65)}`, effect };
    case 'tempo': return { label: '攻击速度', before: `${Math.round(hero.attackSpeed * 100)}%`, after: `${Math.round(Math.min(2.8, hero.attackSpeed * 1.35) * 100)}%`, effect };
    case 'vigor': return { label: '生命上限', before: `${hero.maxHp} 心`, after: `${hero.maxHp + 2} 心`, effect };
    case 'stride': return { label: '移动速度', before: `${Math.round(hero.speed / 260 * 100)}%`, after: `${Math.round(Math.min(460, hero.speed * 1.18) / 260 * 100)}%`, effect };
    case 'multishot': return { label: '附加飞弹', before: `${hero.extraProjectiles} 枚`, after: `${Math.min(3, hero.extraProjectiles + 1)} 枚`, effect };
    case 'shield': return { label: '护盾层数', before: `${hero.shield} 层`, after: `${hero.shield + 3} 层`, effect };
    case 'blood': return { label: '击杀回血', before: `${Math.round(hero.lifesteal * 100)}%`, after: '100%', effect };
    case 'magnet': return { label: '聚灵半径', before: `${hero.magnet}`, after: `${hero.magnet + 220}`, effect };
    case 'fortune': return { label: '单枚星币收益', before: `${1 + count(hero, 'fortune') * 2}`, after: `${3 + count(hero, 'fortune') * 2}`, effect: '每枚额外 +3 星能 · 金色星屑' };
    default: return { label: '修行层数', before: `${count(hero, upgrade.id)}`, after: `${count(hero, upgrade.id) + 1}`, effect };
  }
}

export function renderUpgradeScreen(choices: Upgrade[], hero: Hero): string {
  return `<section class="jade-upgrade" aria-labelledby="jade-upgrade-title"><header class="jade-upgrade-heading"><span class="jade-upgrade-mark" aria-hidden="true">牒</span><div><span class="jade-upgrade-kicker">八境行牒 · 修为进阶</span><h2 id="jade-upgrade-title">星纹入牒，择一道修行。</h2></div><span class="jade-upgrade-level">第 ${hero.level} 阶</span></header><p class="jade-upgrade-intro">三道星纹，取其一。化作随身之力，伴你踏破余下诸境。</p><div class="jade-talisman-choices">${choices.map((upgrade, index) => {
    const metadata = SEALS[upgrade.id] ?? { glyph: '星', path: '修行之道' };
    const preview = upgradePreview(upgrade, hero);
    const stacks = count(hero, upgrade.id);
    return `<button type="button" class="jade-talisman talisman-${upgrade.id}" data-upgrade="${esc(upgrade.id)}" style="--talisman-color:${upgrade.color};--talisman-order:${index}" tabindex="-1" disabled aria-label="选择${esc(upgrade.name)}，${preview.label}从${preview.before}到${preview.after}"><span class="talisman-top"><span>${metadata.path}</span><span class="talisman-stack">${stacks ? `已有 ${stacks} 重` : '初习此印'}</span></span><span class="talisman-portrait" aria-hidden="true"><i class="talisman-orbit"></i><i class="talisman-ray"></i><span class="talisman-glyph">${metadata.glyph}</span><span class="talisman-symbol">${icon(upgrade.icon)}</span><i class="talisman-spark spark-a"></i><i class="talisman-spark spark-b"></i><i class="talisman-spark spark-c"></i></span><h3>${esc(upgrade.name)}</h3><span class="talisman-effect">${esc(preview.effect)}</span><span class="talisman-stat"><span>${preview.label}</span><span class="talisman-stat-values"><s>${esc(preview.before)}</s><span aria-hidden="true">→</span><strong>${esc(preview.after)}</strong></span></span><span class="talisman-description">${esc(upgrade.description)}</span><span class="talisman-choose"><span class="talisman-touch-mark" aria-hidden="true">${icon('spark')}</span><span>点按收入行牒</span>${icon('arrow')}</span></button>`;
  }).join('')}</div><footer class="jade-upgrade-footer"><span>${icon('heart')} 选印后恢复生命 · 本局持续生效</span><span class="upgrade-selection-hint" role="status"><span class="upgrade-opening-hint">行牒展开中…</span><span class="upgrade-ready-hint">仅点击或点按选择</span></span></footer></section>`;
}

export function renderBuffSeals(upgrades: Upgrade[], hero: Hero): string {
  return `<span class="buff-seal-label">修行</span>${upgrades.filter(upgrade => hero.upgrades.includes(upgrade.id)).map(upgrade => {
    const stacks = count(hero, upgrade.id);
    const metadata = SEALS[upgrade.id];
    const status = upgrade.id === 'shield' ? `现有 ${hero.shield} 层护盾` : `${stacks} 重修行`;
    return `<span role="listitem" class="buff-seal buff-seal-${upgrade.id}${upgrade.id === 'shield' && hero.shield === 0 ? ' dormant' : ''}" style="--seal-color:${upgrade.color}" title="${esc(upgrade.name)} · ${status}" aria-label="${esc(upgrade.name)}，${status}">${metadata?.glyph ?? '星'}${stacks > 1 ? `<b>${stacks}</b>` : ''}</span>`;
  }).join('')}`;
}
