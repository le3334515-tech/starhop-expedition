import { sampleTrap, TRAP_DESIGNS } from './realm-traps';
import type { RealmTrap } from './types';

export function drawRealmTrap(c: CanvasRenderingContext2D, trap: RealmTrap, time: number) {
  const design = TRAP_DESIGNS[trap.theme], { hit, warning, progress } = sampleTrap(trap, time);
  const { x, w } = trap, floor = trap.y + trap.h;
  const ink = '#283d38', bronze = '#817757', light = '#f1dfad', color = design.color;
  const rect = (x: number, y: number, w: number, h: number, fill: string) => {
    c.fillStyle = fill; c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
  };
  const line = (x: number, y: number, ex: number, ey: number, color: string, width = 2) => {
    c.strokeStyle = color; c.lineWidth = width; c.beginPath(); c.moveTo(Math.round(x), Math.round(y)); c.lineTo(Math.round(ex), Math.round(ey)); c.stroke();
  };
  const spark = (sx: number, sy: number) => { rect(sx - 3, sy, 7, 1, light); rect(sx, sy - 3, 1, 7, light); };
  c.save();
  rect(x, floor - 3, w, 4, ink);
  rect(x + 2, floor - 4, w - 4, 2, bronze);
  if (warning) {
    // The full sweep is marked before its first damaging frame.
    const lane = design.kind === 'star' ? trap.y + 9 : floor - 6;
    for (let dx = 2; dx < w - 2; dx += 9) rect(x + dx, lane, 5, 2, color);
    for (const edge of [x + 2, x + w - 3]) {
      rect(edge, lane - 8, 2, 9, light); rect(edge - 2, lane - 11, 6, 2, color);
    }
  }
  switch (design.kind) {
    case 'bamboo':
      for (let i = 0; i < 4; i++) {
        const sx = x + 6 + i * 14, h = hit ? Math.max(4, hit.h - i % 2 * 6) : warning ? 5 + 4 * progress : 3;
        rect(sx, floor - h + 3, 5, h - 3, '#587350'); rect(sx + 2, floor - h, 2, h, color);
        if (h > 13) { rect(sx - 1, floor - h + 10, 6, 2, light); line(sx + 3, floor - 10, sx + 9, floor - 16, '#73945e'); }
      } break;
    case 'lantern': {
      const hook = x + w / 2, top = trap.y;
      const cx = hit ? hit.x + hit.w / 2 : x + 8, cy = hit ? hit.y + 9 : floor - 37;
      rect(hook - 8, top - 2, 16, 5, bronze); line(hook, top + 3, cx, cy - 9, bronze);
      rect(cx - 6, cy - 11, 12, 3, ink); rect(cx - 8, cy - 8, 16, 14, hit ? '#cd7145' : '#915144');
      rect(cx - 3, cy - 7, 6, 12, warning || hit ? light : color); rect(cx - 6, cy + 6, 12, 3, bronze);
      rect(cx, cy + 9, 2, 5, color); if (hit) spark(cx - 10, cy + 3); break;
    }
    case 'gust':
      rect(x + w - 4, floor - 28, 3, 26, bronze);
      line(x + w - 3, floor - 27, x + w - (hit ? 23 : 10), floor - (hit ? 27 : 16), color, 3);
      if (hit) for (let i = 0; i < 6; i++) {
        const dx = (time * 95 + i * 15) % (w - 15), sy = floor - 9 - i * Math.min(9, hit.h / 7);
        line(x + w - dx, sy - 2, x + w - dx - 14, sy, color);
      } break;
    case 'bell': {
      rect(x - 1, floor - 29, 3, 28, ink); rect(x - 3, floor - 31, 20, 3, bronze);
      rect(x + 7, floor - 27, 6, 4, bronze); rect(x + 4, floor - 23, 12, 10, color); rect(x + 2, floor - 14, 16, 3, bronze);
      if (hit) { const cx = hit.x + 9; for (let n = 0; n < 3; n++) {
        line(cx - n * 5, floor - 2, cx + 8 - n * 5, floor - 11, n ? bronze : light);
        line(cx + 8 - n * 5, floor - 11, cx + 2 - n * 5, floor - 23, color);
      } } break;
    }
    case 'tide':
    case 'kiln': {
      const water = design.kind === 'tide';
      rect(x + 1, floor - 5, w - 2, 5, water ? '#497777' : '#594236');
      for (let dx = 5; dx < w - 3; dx += 8) {
        rect(x + dx, floor - 6, 3, 3, warning || hit ? light : bronze);
      }
      if (hit && water) {
        // The central stream breaks into two lips and detached drops.
        const cx = x + w / 2;
        for (let i = 0; i < hit.h; i += 4) {
          const t = i / hit.h, bend = Math.sin(time * 9 + t * 6) * t * 3;
          const radius = 10 - 5 * Math.sin(t * Math.PI) + 8 * t ** 5;
          rect(cx + bend - radius, floor - i - 4, radius * 2, 4, '#4e9394');
          rect(cx + bend - radius + 2, floor - i - 4, 3, 4, color);
          if ((i + Math.floor(time * 18)) % 13 < 6) rect(cx + bend + 3, floor - i - 3, 3, 3, '#cee3ce');
        }
        for (const sign of [-1, 1]) for (let n = 0; n < 4; n++) {
          const t = (time * 1.4 + n / 4) % 1;
          rect(cx + sign * (12 + t * 14), hit.y + t * t * 30 - 4, 3, 4, color);
        }
        rect(x + 4, floor - 4, w - 8, 3, '#b9daca');
      } else if (hit) {
        for (let n = 0; n < 3; n++) {
          const peak = hit.h * (n === 1 ? 1 : .62 + .16 * Math.sin(time * 12 + n));
          const root = x + w * (.23 + .27 * n);
          for (let i = 0; i < peak; i += 4) {
            const t = i / peak, radius = Math.max(1, (1 - t) * 9);
            const bend = Math.sin(time * 11 + t * 7 + n) * (1 + t * 4);
            rect(root + bend - radius, floor - i - 4, 2 * radius, 4, '#bb6343');
            if (t < .83) rect(root + bend - radius * .5, floor - i - 4, radius, 4, t < .35 ? '#ebc18b' : color);
          }
          const ember = (time * .95 + n / 3) % 1;
          rect(root + Math.sin(time * 6 + n) * 5, hit.y - ember * 9, 2, 3, color);
        }
      }
      break;
    }
    case 'star': {
      const sy = trap.y + 10;
      for (const ox of [x + 3, x + w - 4]) {
        rect(ox - 1, sy + 7, 3, floor - sy - 8, bronze); rect(ox - 4, sy - 4, 9, 9, ink);
        rect(ox - 2, sy - 5, 5, 10, color); rect(ox, sy - 2, 2, 4, light);
      }
      if (hit) { rect(hit.x, hit.y, hit.w, hit.h, '#7d758c'); rect(hit.x, hit.y + 2, hit.w, 3, color); rect(hit.x, hit.y + 3, hit.w, 1, light); }
      break;
    }
  }
  c.restore();
}
