import { defineConfig } from 'vite';
export default defineConfig({ base: './', build: { target: ['chrome80', 'safari13.1', 'firefox80'] } });
