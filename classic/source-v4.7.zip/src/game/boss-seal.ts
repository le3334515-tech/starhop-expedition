import type { Boss } from './types';

export const BOSS_TRANSFORM_TIME = 3.2;
export const sealProgress = (b: Boss) => Math.min(1, Math.max(0, 1 - b.timer / BOSS_TRANSFORM_TIME));
export const openingSeal = (b: Boss) => b.form===2 && b.phase===2 && b.mode==='transition';
export const ease = (a:number,b:number,t:number) => { const x=Math.min(1,Math.max(0,(t-a)/(b-a))); return x*x*(3-2*x); };
