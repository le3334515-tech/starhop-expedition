import type { GameState } from './types';
// Separate musical movements load on demand. Embedding the encoded recording in
// its own module also supports offline HTML and webviews that discard media fetches.
const tracks = {
  mist: () => import('../assets/music/mist-pass.mp3?inline'),
  guardian: () => import('../assets/music/ember-vigil.mp3?inline'),
  seal: () => import('../assets/music/seal-break.mp3?inline'),
  dark: () => import('../assets/music/broken-seal.mp3?inline'),
};
export type ScoreCue = keyof typeof tracks;
export function scoreCue(s: GameState): ScoreCue | null {
  if (s.phase !== 'playing') return null;
  const b = s.boss;
  if (!b?.active) return 'mist';
  if (b.mode === 'dead') return null;
  if (b.form !== 2) return 'guardian';
  return b.phase === 2 && b.mode === 'transition' ? 'seal' : 'dark';
}

interface Voice { source: AudioBufferSourceNode; gain: GainNode; }
export class ExpeditionScore {
  private buffers = new Map<ScoreCue, Promise<AudioBuffer>>();
  private voice: Voice | null = null;
  private cue: ScoreCue | null = null;
  private startedAt = 0;
  private saved: {cue:ScoreCue; position:number} | null = null;
  private generation = 0;
  private retry?: ReturnType<typeof setTimeout>;

  constructor(private ctx: AudioContext, private bus: GainNode) {}

  private load(cue: ScoreCue) {
    let promise = this.buffers.get(cue);
    if (!promise) {
      promise = tracks[cue]().then(({default: data}) => {
        const binary = atob(data.slice(data.indexOf(',')+1));
        const bytes = new Uint8Array(binary.length);
        for (let i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i);
        return this.ctx.decodeAudioData(bytes.buffer);
      }).catch(error => { this.buffers.delete(cue); throw error; });
      this.buffers.set(cue, promise);
    }
    return promise;
  }
  private warmed = new Set<ScoreCue>();
  warm(cue: ScoreCue) {
    if (this.warmed.has(cue)) return;
    this.warmed.add(cue); void this.load(cue).catch(() => {});
  }

  select(cue: ScoreCue | null, offset?: number) {
    if (this.cue === cue) return;
    clearTimeout(this.retry);
    const serial = ++this.generation, now = this.ctx.currentTime;
    if (!cue && this.cue) this.saved = {cue:this.cue,position:Math.max(0,now-this.startedAt)};
    if (this.voice) {
      const {source,gain} = this.voice, fade = cue === 'seal' ? .10 : cue ? .32 : .055;
      gain.gain.cancelScheduledValues(now);
      gain.gain.setTargetAtTime(0,now,fade/4);
      source.stop(now + fade); this.voice = null;
    }
    this.cue = cue;
    if (!cue) return;
    this.startedAt = now - (offset ?? (this.saved?.cue === cue ? this.saved.position : 0));
    this.saved = null;
    if (cue === 'guardian') { this.warm('seal'); this.warm('dark'); }
    const play = async (attempt: number) => {
      try {
        const buffer = await this.load(cue);
        if (serial !== this.generation || this.ctx.state === 'closed') return;
        const time = this.ctx.currentTime, elapsed = Math.max(0,time-this.startedAt);
        if (cue === 'seal' && elapsed >= buffer.duration) return;
        const source=this.ctx.createBufferSource(), gain=this.ctx.createGain();
        source.buffer=buffer; source.loop=cue !== 'seal';
        gain.gain.setValueAtTime(.001,time);
        gain.gain.linearRampToValueAtTime(1,time + (cue==='mist'?.32:.045));
        source.connect(gain); gain.connect(this.bus);
        source.onended=()=>{ source.disconnect(); gain.disconnect(); if (this.voice?.source===source) this.voice=null; };
        this.voice={source,gain};
        source.start(time,source.loop ? elapsed % buffer.duration : elapsed);
      } catch {
        if (serial===this.generation && attempt<2) this.retry=setTimeout(()=>void play(attempt+1),900*(attempt+1));
      }
    };
    void play(0);
  }
  reset() { this.select(null); this.saved=null; }
  dispose() { this.reset(); clearTimeout(this.retry); this.generation++; this.buffers.clear(); }
}

// Some embedded browsers can decode MP3 in a media element but do not expose
// Web Audio. Reuse a single gesture-unlocked element across scene changes.
export class ElementScore {
  private player = new Audio();
  private cue: ScoreCue | null = null;
  private bookmark: {cue: ScoreCue; position: number} | null = null;
  private serial = 0;
  private primed = false;
  private warmed = new Set<ScoreCue>();
  constructor(muted: boolean) {
    this.player.preload='auto'; this.player.volume=.56; this.player.muted=muted;
  }
  setMuted(value:boolean) { this.player.muted=value; }
  unlock() {
    if (!this.primed) {
      this.primed=true;
      this.player.src='data:audio/wav;base64,UklGRiYAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQIAAACAgA==';
      void this.player.play().catch(()=>{});
    } else if(this.cue && this.player.paused && this.player.readyState>=2) {
      void this.player.play().catch(()=>{});
    }
  }
  warm(cue:ScoreCue) {
    if(this.warmed.has(cue))return;
    this.warmed.add(cue);void tracks[cue]().catch(()=>{});
  }
  select(cue:ScoreCue|null,offset?:number) {
    if(cue===this.cue)return;
    const serial=++this.serial, player=this.player;
    if(!cue && this.cue)this.bookmark={cue:this.cue,position:player.currentTime || 0};
    player.onloadedmetadata=null;player.pause();this.cue=cue;
    if(!cue)return;
    const resume=offset ?? (this.bookmark?.cue===cue?this.bookmark.position:0);
    this.bookmark=null;
    if(cue==='guardian'){this.warm('seal');this.warm('dark');}
    const requested=performance.now();
    void tracks[cue]().then(({default:uri})=>{
      if(serial!==this.serial)return;
      player.loop=cue!=='seal';
      player.onloadedmetadata=()=>{
        if(serial!==this.serial)return;
        const elapsed=resume+(performance.now()-requested)/1000;
        if(cue==='seal'&&elapsed>=player.duration)return;
        if(Number.isFinite(player.duration)&&player.duration>0)player.currentTime=elapsed%player.duration;
      };
      player.src=uri;
      // A mobile media element may defer even metadata until it receives play().
      void player.play().catch(()=>{});
    }).catch(()=>{});
  }
  reset(){this.select(null);this.bookmark=null;}
  dispose(){this.reset();this.serial++;this.player.removeAttribute('src');this.player.load();}
}

