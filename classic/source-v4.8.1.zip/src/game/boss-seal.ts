import type { Boss } from './types';

export const BOSS_TRANSFORM_TIME = 3.2;
export const BOSS_ASCENSION_TIME = 2.8;
export const BOSS_ASCENSION_IMPACT = 1.82;
export const ECLIPSE_WINDUP = .8;
export const ECLIPSE_WIDTH = 52;
export const sealProgress = (b: Boss) => Math.min(1, Math.max(0, 1 - b.timer / BOSS_TRANSFORM_TIME));
export const openingSeal = (b: Boss) => b.form===2 && b.phase===2 && b.mode==='transition';
export const openingAscension = (b: Boss) => b.form === 2 && b.phase === 3 && b.mode === 'transition';
export const ascensionProgress = (b: Boss) => Math.min(1, Math.max(0, 1 - b.timer / BOSS_ASCENSION_TIME));
export const ease = (a:number,b:number,t:number) => { const x=Math.min(1,Math.max(0,(t-a)/(b-a))); return x*x*(3-2*x); };

/** Shift the entire pattern at arena edges, keeping safe gaps between every hitbox. */
export function eclipseLanes(b: Boss, roomWidth: number): number[] {
  const spacing = 100;
  const center = Math.min(roomWidth - 80 - spacing * 2, Math.max(420 + spacing * 2, b.targetX + b.w / 2));
  return [-2, -1, 0, 1, 2].map(offset => center + offset * spacing);
}
