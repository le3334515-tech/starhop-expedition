import { ascensionProgress, BOSS_ASCENSION_IMPACT, BOSS_ASCENSION_TIME, ease, eclipseLanes, ECLIPSE_WIDTH, openingAscension, openingSeal, sealProgress } from './boss-seal';
import type { Boss, Enemy, Projectile } from './types';

const TAU = Math.PI * 2;
const clamp = (n: number, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const pixel = (c: CanvasRenderingContext2D, x: number, y: number, w = 2, h = w) => c.fillRect(Math.round(x), Math.round(y), w, h);

function diamond(c: CanvasRenderingContext2D, x: number, y: number, radius: number, color: string) {
  c.fillStyle = color;
  for (let row = -radius; row <= radius; row += 2) {
    const width = Math.max(2, Math.round((radius - Math.abs(row)) / 2) * 2);
    pixel(c, x - width, y + row, width * 2, 2);
  }
}

function inkFlame(c: CanvasRenderingContext2D, x: number, foot: number, width: number, height: number, phase: number, alpha = 1) {
  c.save(); c.globalAlpha *= alpha;
  const sway = Math.round(Math.sin(phase) * width * .25);
  c.fillStyle = '#111821';
  for (let n = 0; n < 7; n++) {
    const t = n / 7, w = Math.max(2, Math.round(width * (1 - t) / 2) * 2);
    pixel(c, x - w / 2 + sway * t, foot - height * (t + 1 / 7), w, Math.ceil(height / 7) + 2);
  }
  c.fillStyle = '#5b3445'; pixel(c, x - width * .28, foot - height * .36, Math.max(2, width * .18), height * .4);
  c.fillStyle = '#bb5e60'; pixel(c, x + sway * .4, foot - height * .35, 2, height * .26);
  c.fillStyle = '#edac86'; pixel(c, x + sway * .4, foot - height * .2, 2, 4);
  c.restore();
}

const ASCENSION_RELEASE = BOSS_ASCENSION_IMPACT / BOSS_ASCENSION_TIME;

export function drawAscensionBack(c: CanvasRenderingContext2D, b: Boss, now: number): void {
  if (b.form !== 2 || b.phase !== 3 || b.mode === 'dead') return;
  const ascending = openingAscension(b);
  const progress = ascending ? ascensionProgress(b) : 1;
  const pull = ascending ? ease(.06, .55, progress) * (1 - ease(.59, .82, progress)) : 0;
  const crown = ease(.54, .88, progress);
  const x = b.x + b.w / 2, foot = b.y + b.h;
  const centerY = foot - 179 + pull * 83;
  const radius = 113 - pull * 81 + crown * 23;
  c.save();
  c.globalAlpha *= b.mode === 'stagger' ? .25 : ascending ? .82 : .45;
  c.fillStyle = '#18101c';
  c.beginPath(); c.arc(x, centerY, radius, 0, TAU); c.fill();
  c.strokeStyle = '#985042'; c.lineWidth = 2;
  c.beginPath(); c.arc(x, centerY, radius, 0, TAU); c.stroke();
  for (let i = 0; i < 12; i++) {
    const angle = i * TAU / 12 + (ascending ? progress * 1.2 : .03 * Math.sin(now * .8));
    const cx = x + Math.cos(angle) * radius, cy = centerY + Math.sin(angle) * radius;
    c.save(); c.translate(cx, cy); c.rotate(angle);
    c.fillStyle = '#8f4138'; pixel(c, -15, -1, 30, 2);
    c.fillStyle = i % 3 === 0 ? '#ffd790' : '#b67054';
    pixel(c, -5, -2, 10, 4);
    if (i % 2 === 0) {
      c.beginPath(); c.moveTo(-5,-4); c.lineTo(8,-4); c.lineTo(16,0); c.lineTo(8,4); c.lineTo(-5,4); c.closePath(); c.fill();
      c.fillStyle='#532932'; pixel(c,-3,-1,10,2);
    }
    c.restore();
  }
  if (ascending && progress >= ASCENSION_RELEASE) {
    const expansion = ease(ASCENSION_RELEASE, .93, progress);
    c.globalAlpha *= 1 - expansion;
    c.strokeStyle = '#f5c57e'; c.lineWidth = 3;
    c.beginPath(); c.ellipse(x, foot - 4, 27 + expansion * 270, 5 + expansion * 23, 0, 0, TAU); c.stroke();
    for (let i = 0; i < 14; i++) {
      const angle = i * TAU / 14;
      const distance = 38 + expansion * 175;
      diamond(c, x + Math.cos(angle) * distance, centerY + Math.sin(angle) * distance * .65, 4, '#ffd2a0');
    }
  }
  c.restore();
}

export function drawEclipseWarning(c: CanvasRenderingContext2D, b: Boss, roomWidth: number, now: number): void {
  c.save();
  const pulse = .68 + Math.sin(now * 15) * .18;
  eclipseLanes(b, roomWidth).forEach((x, i) => {
    c.globalAlpha = pulse * (i % 2 === 0 ? .95 : .58);
    const side = ECLIPSE_WIDTH / 2;
    c.fillStyle = '#55262f'; pixel(c,x-side,438,ECLIPSE_WIDTH,10);
    c.fillStyle = '#f1b678'; pixel(c,x-side,440,ECLIPSE_WIDTH,3);
    pixel(c,x-side,430,3,11); pixel(c,x+side-3,430,3,11);
    diamond(c, x, 432, 6, '#ffd69d');
    c.fillStyle = '#dc9573';
    for (let y = 180; y <= 404; y += 28) pixel(c, x - 1, y, 2, 5);
  });
  c.restore();
}

/** Local ink, torn seals and a ground sigil leave the hero and HUD readable. */
export function drawDarkBossBack(c: CanvasRenderingContext2D, b: Boss, now: number): void {
  if (b.form !== 2 || b.mode === 'dead') return;
  const x = b.x + b.w / 2, foot = b.y + b.h;
  const transforming = openingSeal(b);
  const progress = transforming ? sealProgress(b) : 1;
  c.save(); c.globalAlpha *= transforming ? .85 : .56;
  c.fillStyle = '#151a2599';
  c.beginPath(); c.ellipse(x, foot + 2, transforming ? 83 : 67, 12, 0, 0, TAU); c.fill();
  c.strokeStyle = b.phase >= 3 ? '#d67c78' : '#ac6267'; c.lineWidth = 2;
  c.beginPath(); c.ellipse(x, foot + 1, 71 + Math.sin(now * 3) * 3, 11, 0, 0, TAU); c.stroke();
  for (let i = 0; i < 8; i++) {
    const a = i * TAU / 8 + now * .12;
    c.fillStyle = i % 2 ? '#dca078' : '#8c5260';
    pixel(c, x + Math.cos(a) * 73, foot + Math.sin(a) * 11 - 1, 3, 2);
  }
  for (let i = 0; i < (transforming ? 13 : b.phase >= 3 ? 8 : 6); i++) {
    const age = (now * (transforming ? .8 : .5) + i * .173) % 1;
    const side = i % 2 ? 1 : -1, spread = transforming ? (1 - progress) * 72 + 25 : 28;
    const fx = x + side * (18 + Math.sin(i * 2.3) * 13 + (1 - age) * spread), fy = foot - age * (transforming ? 175 : 105);
    inkFlame(c, fx, fy, transforming ? 15 : 9, (transforming ? 62 : 30) * (1 - age * .55), now * 4 + i, 1 - age * .7);
  }
  if (transforming) {
    const p=progress, eye=foot-93, tension=ease(.04,.55,p);
    // Seal slips pull taut around the staff before the central strike cuts their gold cords.
    if(p < .66) {
      c.lineWidth=1.5;
      for(let i=0;i<6;i++){
        const angle=i*TAU/6 + p*1.24, radius=116-tension*70;
        const px=x+Math.cos(angle)*radius, py=eye+Math.sin(angle)*radius*.61;
        c.strokeStyle='#c99e71';c.beginPath();c.moveTo(x,eye);c.lineTo(px,py);c.stroke();
        c.save();c.translate(px,py);c.rotate(angle+.5);
        c.fillStyle='#251b25';c.fillRect(-5,-11,10,23);c.fillStyle='#ce9b63';c.fillRect(-4,-10,8,20);
        c.fillStyle='#813f36';c.fillRect(-1,-7,2,12);c.fillRect(-3,-3,6,2);c.restore();
      }
    }
    if(p>=.62){
      const release=ease(.62,.98,p);
      c.globalAlpha*=1-release;
      c.strokeStyle='#ecc085';c.lineWidth=3;
      c.beginPath();c.ellipse(x,foot,20+release*200,3+release*19,0,0,TAU);c.stroke();
      for(let i=0;i<12;i++){
        const a=i*TAU/12-.4;
        const r=26+release*(i%2?126:104);
        const px=x+Math.cos(a)*r,py=eye+Math.sin(a)*r*.73+release*release*21;
        c.save();c.translate(px,py);c.rotate(a+release*3);c.fillStyle=i%2?'#d9a365':'#9d5950';c.fillRect(-2,-5,4,11);c.restore();
      }
    }
  }
  c.restore();
}

export function drawDarkBossFront(c: CanvasRenderingContext2D, b: Boss, now: number): void {
  if (b.form !== 2 || b.mode === 'dead') return;
  if (openingAscension(b)) {
    const progress = ascensionProgress(b);
    const flare = ease(ASCENSION_RELEASE - .06, ASCENSION_RELEASE, progress) * (1 - ease(ASCENSION_RELEASE, .76, progress));
    if (flare <= .01) return;
    const x = b.x + b.w / 2, foot = b.y + b.h;
    c.save(); c.globalAlpha *= flare * .84;
    c.fillStyle = '#a94a48'; pixel(c, x - 14, 64, 28, foot - 64);
    c.fillStyle = '#e7a771'; pixel(c, x - 6, 84, 12, foot - 85);
    c.fillStyle = '#ffe2aa'; pixel(c, x - 2, 100, 4, foot - 104);
    c.restore();
    return;
  }
  if (!openingSeal(b)) return;
  const p=sealProgress(b);
  if(p<.59 || p>.78) return;
  const cut=ease(.59,.642,p), fade=1-ease(.65,.78,p);
  const x=b.x+b.w/2, y=b.y+b.h-92;
  c.save(); c.globalAlpha*=fade*.9;
  c.translate(x,y);c.rotate(-.48*(b.facing || -1));c.scale(cut,1);
  c.fillStyle='#e5ac72'; c.beginPath();c.moveTo(-135,2);c.lineTo(-9,-3);c.lineTo(122,-2);c.lineTo(7,3);c.fill();
  c.fillStyle='#ffdfab';pixel(c,-42,-1,110,2);c.restore();
}

export function drawBurningEnemy(c: CanvasRenderingContext2D, enemy: Enemy, now: number): void {
  if (!(enemy.burnTime && enemy.burnTime > 0) || enemy.dead) return;
  c.save();
  for (let i = 0; i < 4; i++) {
    const age = (now * 1.7 + i / 4) % 1;
    c.globalAlpha = .8; c.fillStyle = i % 2 ? '#f3be7c' : '#cf7650';
    pixel(c, enemy.x + enemy.w / 2 + Math.sin(i * 2.4) * enemy.w * .4, enemy.y + enemy.h - 3 - age * enemy.h * 1.1, 3, 5);
  }
  c.restore();
}

/** Only live, delayed simulation hazards get markers; the damaging column is
 * deliberately absent until its delay reaches zero. */
export function drawCombatProjectile(c: CanvasRenderingContext2D, p: Projectile, now: number): boolean {
  const x = p.x + p.w / 2, y = p.y + p.h / 2;
  if (p.kind === 'rift') {
    c.save();
    if (p.style === 'eclipse') {
      const foot = p.y + p.h;
      if ((p.delay ?? 0) > 0) {
        c.globalAlpha *= .7 + Math.sin(now * 24) * .19;
        c.fillStyle = '#ad5553'; pixel(c, p.x, foot-5, p.w, 5);
        c.fillStyle = '#ffcf90'; pixel(c, p.x, foot-15, 3, 12); pixel(c, p.x+p.w-3, foot-15, 3, 12);
        for (let yMark = p.y + 12; yMark < foot - 16; yMark += 24) pixel(c, x - 1, yMark, 2, 7);
      } else {
        c.globalAlpha *= Math.min(1, p.life * 7);
        c.fillStyle = '#59232c'; pixel(c, p.x, p.y, p.w, p.h);
        c.fillStyle = '#d57757'; pixel(c, x-12, p.y, 24, p.h);
        c.fillStyle = '#ffcc88'; pixel(c, x-3, p.y, 6, p.h);
        for (let i = 0; i < 9; i++) {
          const step = (i / 9 + now * 1.8) % 1;
          const sideways = Math.sin(i * 4.4) * p.w * .4;
          diamond(c,x+sideways,foot-step*p.h,3,'#ffd49a');
        }
      }
      c.restore(); return true;
    }
    if ((p.delay ?? 0) > 0) {
      c.globalAlpha *= .58 + Math.sin(now * 18) * .16;
      c.fillStyle = '#ad59574d'; pixel(c, p.x - 6, p.y + p.h - 7, p.w + 12, 6);
      c.strokeStyle = '#e9a680'; c.lineWidth = 2;
      c.beginPath(); c.ellipse(x, p.y + p.h - 4, p.w * .68, 7, 0, 0, TAU); c.stroke();
      c.fillStyle = '#e8ba95'; pixel(c, x - 2, p.y + p.h - 22, 4, 10); pixel(c, x - 2, p.y + p.h - 8, 4, 3);
    } else {
      inkFlame(c, x, p.y + p.h, p.w + 6, p.h, now * 5);
      inkFlame(c, x - p.w * .3, p.y + p.h, p.w * .42, p.h * .72, now * 6 + 2, .8);
      c.fillStyle = '#e6b18a'; pixel(c, x - 2, p.y + p.h - 48, 4, 42);
      for (let i = 0; i < 5; i++) {
        const age = (now * 2 + i / 5) % 1;
        c.globalAlpha = (1 - age) * .8; c.fillStyle = '#b76766';
        pixel(c, x + Math.sin(i * 2) * p.w * .7, p.y + p.h - age * p.h, 3, 5);
      }
    }
    c.restore(); return true;
  }
  if (p.kind !== 'ember' && p.kind !== 'disc' && p.style !== 'ink' && p.style !== 'reflected') return false;
  c.save();
  if ((p.delay ?? 0) > 0) {
    c.globalAlpha *= .5 + Math.sin(now * 17) * .12;
    c.fillStyle = '#bc6e6c'; pixel(c, x - 9, 443, 18, 3);
    c.strokeStyle = '#e0aa83'; c.setLineDash([3, 7]);
    c.beginPath(); c.moveTo(x, Math.max(110, p.y)); c.lineTo(x, 434); c.stroke();
    c.restore(); return true;
  }
  c.translate(Math.round(x), Math.round(y));
  const angle = Math.atan2(p.vy, p.vx);
  if (p.kind === 'ember') {
    const heavy = p.style === 'charged', r = heavy ? 13 : 9;
    c.rotate(angle);
    for (let i = 5; i >= 1; i--) {
      c.globalAlpha = (1 - i / 7) * .6; c.fillStyle = i % 2 ? '#e19c58' : '#bf654c';
      pixel(c, -r - i * 8, Math.sin(now * 26 + i * 1.2) * 4 - 2, 11 - i, 4);
    }
    c.globalAlpha = 1;
    diamond(c, 0, 0, r + 3, '#b45d43'); diamond(c, 0, 0, r, '#f2b368');
    diamond(c, 1, 0, Math.max(4, r - 4), '#fff0b8');
    if (heavy) {
      c.strokeStyle = '#ffe1a1'; c.lineWidth = 2;
      c.beginPath(); c.arc(0, 0, r + 5, now * 9, now * 9 + 4.8); c.stroke();
      for (let i = 0; i < 4; i++) {
        const a = now * -5 + i * TAU / 4;
        c.fillStyle = '#eebd7a'; pixel(c, Math.cos(a) * (r + 7), Math.sin(a) * (r + 7), 3, 3);
      }
    }
  } else if (p.kind === 'disc') {
    const returning = !!p.returning, r = Math.max(12, p.w * .5);
    c.save(); c.rotate(angle); c.globalAlpha = .38;
    c.fillStyle = returning ? '#a6dac0' : '#b8c8e0';
    pixel(c, -r - 24, -2, 25, 4); pixel(c, -r - 39, -1, 9, 2); c.restore();
    c.rotate(p.rotation ?? now * 17);
    c.strokeStyle = '#21363e'; c.lineWidth = 5; c.beginPath(); c.arc(0, 0, r - 3, 0, TAU); c.stroke();
    c.strokeStyle = returning ? '#a5e9ce' : '#c3cce4'; c.lineWidth = 3;
    c.beginPath(); c.arc(0, 0, r - 2, 0, TAU); c.stroke();
    c.fillStyle = returning ? '#e1eed0' : '#ede0bd';
    for (let i = 0; i < 4; i++) {
      c.rotate(Math.PI / 2); c.beginPath(); c.moveTo(r - 5, -5); c.lineTo(r + 6, -1); c.lineTo(r - 3, 5); c.closePath(); c.fill();
    }
    c.fillStyle = '#cca36b'; pixel(c, -2, -2, 4, 4);
    if (returning) {
      c.strokeStyle = '#b9edcf'; c.globalAlpha = .45; c.lineWidth = 1;
      c.beginPath(); c.arc(0, 0, r + 8, 0, Math.PI * 1.5); c.stroke();
    }
  } else if (p.kind === 'shockwave') {
    c.fillStyle = '#1b202b'; pixel(c, -p.w / 2, -p.h / 2, p.w, p.h);
    c.fillStyle = '#9a5660'; pixel(c, -p.w / 2, -p.h / 2, p.w, 3);
    for (let i = -p.w / 2; i < p.w / 2; i += 8) {
      const height = 6 + Math.round(Math.sin(now * 17 + i) * 4);
      c.fillStyle = '#b96c69'; pixel(c, i, -p.h / 2 - height, 4, height);
    }
    c.fillStyle = '#e6b391'; pixel(c, -2, -p.h / 2 + 2, 4, 7);
  } else {
    c.rotate(angle); c.globalAlpha = .48; c.fillStyle = '#6b3e55';
    pixel(c, -31, -3, 23, 6); pixel(c, -43, -1, 8, 2); c.globalAlpha = 1;
    diamond(c, 0, 0, 10, '#1a1d29'); diamond(c, 0, 0, 6, p.style === 'reflected' ? '#a9d9bd' : '#bd676a');
    c.fillStyle = '#e6b391'; pixel(c, -1, -3, 3, 6);
  }
  c.restore(); return true;
}
