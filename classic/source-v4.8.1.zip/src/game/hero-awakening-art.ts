import { ease } from './boss-seal';
import type { Hero } from './types';

const TAU = Math.PI * 2;
const JADE = '#8ce3ce';
const GOLD = '#e6b572';
const IVORY = '#fff0bc';
export interface AwakeningOrigin { x: number; foot: number }

function pixel(c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  c.fillRect(Math.round(x), Math.round(y), w, h);
}

function star(c: CanvasRenderingContext2D, x: number, y: number, radius: number, color: string) {
  c.fillStyle = color;
  pixel(c, x - radius, y, radius * 2 + 2, 2);
  pixel(c, x, y - radius, 2, radius * 2 + 2);
  pixel(c, x - 1, y - 1, 4, 4);
}

function seal(c: CanvasRenderingContext2D, x: number, y: number, i: number) {
  c.save();
  c.translate(Math.round(x), Math.round(y));
  c.fillStyle = '#27464a';
  c.fillRect(-6, -10, 12, 20);
  c.strokeStyle = i % 2 ? GOLD : JADE;
  c.lineWidth = 1;
  c.strokeRect(-5.5, -9.5, 11, 19);
  c.fillStyle = IVORY;
  c.fillRect(-2, -4, 5, 1);
  c.fillRect(0, -6, 1, 10);
  c.fillRect(-2, 1, 5, 1);
  c.fillRect(-1, 5, 3, 1);
  c.restore();
}

export function drawAwakeningGround(c: CanvasRenderingContext2D, hero: Hero, origin: AwakeningOrigin,
  age: number, strength: number, reducedMotion: boolean) {
  const center = hero.x + hero.w / 2;
  const foot = hero.y + hero.h;
  c.save();
  c.globalAlpha *= strength * .52;
  c.fillStyle = '#15353a';
  c.beginPath();
  c.ellipse(center, foot + 1, 25, 4, 0, 0, TAU);
  c.fill();
  c.strokeStyle = JADE;
  c.lineWidth = 1.5;
  c.beginPath();
  c.ellipse(center, foot + 1, 28, 6, 0, 0, TAU);
  c.stroke();
  if (age < .82) {
    const unfold = ease(0, .74, age);
    const radius = 17 + unfold * (reducedMotion ? 42 : 126);
    c.globalAlpha = strength * .85 * (1 - ease(.34, .82, age));
    c.strokeStyle = GOLD;
    c.lineWidth = 2;
    c.beginPath();
    c.ellipse(origin.x, origin.foot - 1, radius, 5 + unfold * 21, 0, 0, TAU);
    c.stroke();
    for (let point = 0; point < 8; point++) {
      const angle = point * TAU / 8;
      star(c, origin.x + Math.cos(angle) * radius, origin.foot - 1 + Math.sin(angle) * (5 + unfold * 21),
        point % 2 ? 2 : 4, point % 2 ? JADE : IVORY);
    }
  }
  c.restore();
}

export function drawAwakeningSeals(c: CanvasRenderingContext2D, hero: Hero, origin: AwakeningOrigin,
  age: number, strength: number, reducedMotion: boolean) {
  const center = hero.x + hero.w / 2;
  const focusY = hero.y + 15;
  const moving = Math.abs(hero.vx) > 85 || hero.dashTimer > 0;
  const turn = reducedMotion ? 0 : age * 4.5;
  c.save();

  // The world-space seal blossoms where the player activated the ability.
  if (age < .92) {
    const unfold = ease(.02, .47, age);
    const radius = 14 + (reducedMotion ? 30 : 52) * unfold;
    const opacity = strength * ease(0, .09, age) * (1 - ease(.49, .92, age));
    const height = origin.foot - 32 - unfold * 27;
    c.globalAlpha = opacity * .55;
    c.lineWidth = 1.5;
    c.strokeStyle = JADE;
    for (let part = 0; part < 4; part++) {
      const angle = part * TAU / 4 - age;
      c.beginPath();
      c.arc(origin.x, height, radius + 8, angle, angle + 1.07);
      c.stroke();
    }
    c.globalAlpha = opacity;
    const count = reducedMotion ? 4 : 7;
    for (let index = 0; index < count; index++) {
      const angle = index * TAU / count - 1.6 + (reducedMotion ? 0 : age * 1.8);
      seal(c, origin.x + Math.cos(angle) * radius, height + Math.sin(angle) * radius * .73, index);
    }
    for (let ray = 0; ray < (reducedMotion ? 6 : 18); ray++) {
      const offset = (ray * 37 % 143) - 71;
      const life = (ray * 29 % 17) / 16;
      const x = origin.x + offset * (.5 + unfold);
      const y = origin.foot - 13 - unfold * (22 + life * 108);
      c.fillStyle = ray % 3 ? JADE : IVORY;
      pixel(c, x, y, 2, 8 + life * 24);
      pixel(c, x + 1, y - 4, 1, 2);
    }
  }

  // Persistent accents use the hero's existing attacks and motion for timing.
  const charge = ease(.25, .8, age);
  c.globalAlpha = strength * charge * .76;
  for (let light = 0; light < 3; light++) {
    const angle = turn + light * TAU / 3;
    const x = center + Math.cos(angle) * 27;
    const y = focusY - 5 + Math.sin(angle) * 18;
    star(c, x, y, light === 1 ? 3 : 2, light === 1 ? GOLD : JADE);
  }
  if (moving && !reducedMotion) {
    const direction = Math.sign(hero.vx) || hero.facing;
    for (let trail = 0; trail < 6; trail++) {
      const phase = (turn / 3 + trail / 6) % 1;
      const distance = 14 + phase * (hero.dashTimer > 0 ? 76 : 42);
      const y = focusY - 12 + trail * 4 + phase * 7;
      c.globalAlpha = strength * (1 - phase) * .5;
      c.fillStyle = trail % 2 ? GOLD : JADE;
      pixel(c, center - direction * distance, y, 3 + phase * 14, trail % 2 ? 2 : 1);
    }
  }
  c.restore();
}
