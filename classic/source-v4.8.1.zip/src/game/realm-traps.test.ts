import { describe, expect, it } from 'vitest';
import { createThemedRoom, isSafeFloorPoint } from './levels';
import { sampleTrap, TRAP_DESIGNS } from './realm-traps';
import { GameEngine } from './engine';
import { EMPTY_INPUT } from './types';

describe('realm mechanisms', () => {
  it.each(TRAP_DESIGNS.map((d,theme) => [theme,d.name] as const))('places readable timed hazards in realm %i (%s)', theme => {
    for (let seed = 0; seed < 18; seed++) {
      const {room} = createThemedRoom(seed,0,theme);
      const traps = room.hazards.filter(t => t.kind === 'mechanism');
      expect(traps).toHaveLength(2);
      for (const trap of traps) {
        if (trap.kind !== 'mechanism') throw Error('unexpected trap');
        expect(isSafeFloorPoint(room,trap.x)).toBe(false);
        expect(isSafeFloorPoint(room,room.spawn.x)).toBe(true);
        const d=TRAP_DESIGNS[theme], end=d.period-trap.offset;
        const pre=sampleTrap(trap,end-d.active-.45);
        expect(pre.warning).toBe(true);expect(pre.hit).toBeNull();
        const mid=sampleTrap(trap,end-d.active*.5);
        expect(mid.active).toBe(true);expect(mid.hit?.w).toBeGreaterThan(0);
      }
    }
  });
  it.each([0,1,2,3,4,5,6])('applies the visible active shape for realm %i',theme=>{
    const game = new GameEngine(); game.start({seed:42, modifier:'standard', weapon:'blade'});
    const s=game.state; s.room = createThemedRoom(42,0,theme).room;
    const trap=s.room.hazards.find(t=>t.kind==='mechanism')!;
    if(trap.kind!=='mechanism') throw Error('missing mechanism');
    const d=TRAP_DESIGNS[theme];
    s.room.platforms=s.room.platforms.filter(p=>p.kind==='ground');
    s.room.hazards=[trap]; s.pickups=[]; s.enemies=[]; s.roomCleared=true;
    s.time=d.period-trap.offset-d.active*.5;
    const hit=sampleTrap(trap,s.time).hit!;
    const h=s.hero;
    Object.assign(h,{x:hit.x+hit.w/2-h.w/2,y:theme===6?hit.y:448-h.h,grounded:theme!==6,invincible:0});
    const oldX=h.x,oldHp=h.hp;
    game.update(1/120,EMPTY_INPUT);
    if(theme===4){expect(h.vy).toBeLessThan(-600);expect(h.hp).toBe(oldHp);}
    else if(theme===2){expect(h.x).toBeLessThan(oldX);expect(h.hp).toBe(oldHp);}
    else expect(h.hp).toBe(oldHp-1);
  });
  it('keeps the final arena clear of ordinary mechanisms',()=>{
    expect(createThemedRoom(42,7,7).room.hazards).toHaveLength(0);
  });
});
