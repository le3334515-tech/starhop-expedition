import { describe, expect, it } from 'vitest';
import { createRoom, createThemedRoom, expeditionOrder, EXPEDITION_TITLES } from './levels';
import { REGIONAL_ROSTERS } from './enemy-catalog';

describe('the lobby seed changes the actual order of ordinary realms', () => {
  it('visits each ordinary realm once, with the Boss always in the eighth slot', () => {
    for (let seed = 0; seed < 400; seed++) {
      const order = expeditionOrder(seed);
      expect(order.slice(0, 7).sort()).toEqual([0, 1, 2, 3, 4, 5, 6]);
      expect(order).toHaveLength(8); expect(order[7]).toBe(7);
      expect(order).toEqual(expeditionOrder(seed));
    }
    expect(expeditionOrder(-1)).toEqual(expeditionOrder(0xffffffff));
  });

  it('moves worlds among all ordinary positions rather than only changing decoration', () => {
    const routes = new Set<string>();
    const positions = Array.from({ length: 7 }, () => new Set<number>());
    for (let seed = 1; seed <= 96; seed++) {
      const order = expeditionOrder(seed); routes.add(order.join(','));
      order.slice(0, 7).forEach((theme, index) => positions[index].add(theme));
    }
    expect(routes.size).toBeGreaterThan(80);
    expect(positions.every(themes => themes.size === 7)).toBe(true);
  });

  it('loads the advertised theme, complete layout and regional roster at every actual stage', () => {
    for (const seed of [1, 7, 42, 20261116, 987654321]) {
      const order = expeditionOrder(seed);
      order.forEach((theme, stage) => {
        const content = createRoom(seed, stage);
        expect(content).toEqual(createThemedRoom(seed, stage, theme));
        expect(content.room.index).toBe(stage); expect(content.room.theme).toBe(theme);
        expect(content.room.name).toBe(EXPEDITION_TITLES[theme][0]);
        expect(content.room.isBoss).toBe(stage === 7);
        if (stage < 7) {
          const roster = [...REGIONAL_ROSTERS[theme], ...(theme === 5 ? ['forge-bulwark'] : [])];
          expect(new Set(content.enemies.map(enemy => enemy.variant))).toEqual(new Set(roster));
        }
      });
    }
  });

  it('keeps geometry and rosters intact while applying stage-local IDs and enemy endurance', () => {
    const seed = 42, order = expeditionOrder(seed);
    const enemyIds: number[] = [], pickupIds: number[] = [];
    order.slice(0, 7).forEach((theme, stage) => {
      const actual = createRoom(seed, stage), canonical = createThemedRoom(seed, 0, theme);
      expect(actual.room).toEqual({ ...canonical.room, index: stage });
      expect(actual.enemies).toEqual(canonical.enemies.map(enemy => {
        const hp = Math.min(7, enemy.hp * (1 + .04 * Math.max(0, stage - 3)));
        return { ...enemy, id: enemy.id + stage * 100, hp, maxHp: hp };
      }));
      expect(actual.pickups.map(pickup => ({ ...pickup, id: pickup.id % 1000 })))
        .toEqual(canonical.pickups.map(pickup => ({ ...pickup, id: pickup.id % 1000 })));
      enemyIds.push(...actual.enemies.map(enemy => enemy.id));
      pickupIds.push(...actual.pickups.map(pickup => pickup.id));
    });
    expect(new Set(enemyIds).size).toBe(enemyIds.length);
    expect(new Set(pickupIds).size).toBe(pickupIds.length);
  });

  it('keeps the complete final Boss arena outside the shuffle', () => {
    for (let seed = 1; seed <= 30; seed++) {
      const actual = createRoom(seed, 7);
      expect(actual).toEqual(createThemedRoom(seed, 7, 7));
      expect(actual.room.width).toBe(1660); expect(actual.room.isBoss).toBe(true);
      expect(actual.enemies).toHaveLength(0);
    }
  });

  it('rejects invalid stages and cannot place a Boss theme in an ordinary slot', () => {
    for (const index of [-1, .5, 8]) expect(() => createRoom(42, index)).toThrow(RangeError);
    expect(() => createThemedRoom(42, 0, 7)).toThrow(RangeError);
    expect(() => createThemedRoom(42, 7, 0)).toThrow(RangeError);
  });
});
