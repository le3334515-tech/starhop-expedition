import { expeditionOrder, EXPEDITION_TITLES } from './game/levels';
import { escapeHtml as esc, icon } from './icons';

let previousSeed: number | undefined;
/** The pass, atlas and actual rooms all use the same seed-derived itinerary. */
export function refreshRoutePreview(seed: number): void {
  if (previousSeed === seed) return;
  previousSeed = seed;
  const order = expeditionOrder(seed);
  const pass = document.querySelector<HTMLElement>('.expedition-pass')!;
  pass.dataset.routeOrder = order.join(',');
  pass.dataset.routeSeed = String(seed);
  const first = EXPEDITION_TITLES[order[0]];
  pass.querySelector('.pass-mobile-world')!.textContent = first[0];
  pass.querySelector('.pass-world')!.innerHTML = `${esc(first[0])}<span>此行起点 · ${esc(first[1])}</span>`;
  const route = pass.querySelector<HTMLElement>('.pass-route')!;
  route.classList.add('route-real-order'); route.setAttribute('role', 'list');
  route.setAttribute('aria-label', '本次实际关卡顺序，余烬神殿固定最后');
  route.innerHTML = order.map((theme, stage) => `<span role="listitem" class="route-stage${theme === 7 ? ' route-stage-boss' : ''}" data-route-theme="${theme}" data-route-stage="${stage}"><b>${stage + 1}</b><span>${esc(EXPEDITION_TITLES[theme][0])}</span>${theme === 7 ? icon('flag') : ''}</span>`).join('');
  const atlas = document.querySelector('.world-atlas>ol')!;
  for (const [stage, theme] of order.entries()) {
    const card = atlas.querySelector<HTMLElement>(`[data-realm="${theme}"]`)!;
    card.querySelector('.atlas-number')!.textContent = String(stage + 1).padStart(2, '0');
    card.setAttribute('aria-label', `第${stage + 1}关 ${EXPEDITION_TITLES[theme][0]}${theme === 7 ? '，最终Boss' : ''}`);
    atlas.append(card);
  }
  const caption = document.querySelector('.atlas-heading>span');
  if (caption) caption.textContent = '七境换序，终抵神殿';
}
