import type { CoopCharacterId } from './coop-transport';
import type { WeaponId } from './game/types';

interface Character {
  name: string;
  title: string;
  gender: string;
  trait: string;
  color: string;
  weapon: WeaponId;
  icon: string;
  portrait: string;
  crop: [number, number, number];
}

export const COOP_CHARACTERS: Record<CoopCharacterId, Character> = {
  blade: { name: '沈霄', title: '雾门剑客', gender: '男', trait: '近身快斩，第三刀重击', color: '#e98b79', weapon: 'blade', icon: 'blade', portrait: 'actors/coop-warrior-idle.png', crop: [61,52,39] },
  staff: { name: '陆照野', title: '观焰术士', gender: '男', trait: '法杖引焰，贯穿敌阵', color: '#eac582', weapon: 'ember', icon: 'ember', portrait: 'actors/coop-staff-idle.png', crop: [54,41,38] },
  wheel: { name: '青翎', title: '飞轮猎手', gender: '女', trait: '投出双轮，回程再斩', color: '#91d7ba', weapon: 'disc', icon: 'disc', portrait: 'actors/coop-wheel-idle.png', crop: [73,68,51] },
  spear: { name: '闻朔', title: '玄铁枪卫', gender: '女', trait: '长枪突刺，重击破甲', color: '#a8bdef', weapon: 'spear', icon: 'spear', portrait: 'actors/coop-huntress-portrait.png', crop: [0,0,112] },
};

export const COOP_CHARACTER_IDS = Object.keys(COOP_CHARACTERS) as CoopCharacterId[];
