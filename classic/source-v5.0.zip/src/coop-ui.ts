import { icon, escapeHtml as esc } from './icons';
import { COOP_CHARACTER_IDS, COOP_CHARACTERS } from './coop-characters';
import { artImage } from './game/art-assets';
import { formatTime } from './social';
import type { CoopCharacterId, CoopView } from './coop-transport';
import type { PartyTraveller } from './coop-play';
import type { GameResult } from './game/types';

const portraits = new Map<CoopCharacterId, string>();
export function getCoopPortrait(id: CoopCharacterId): string {
  const stored = portraits.get(id);
  if (stored) return stored;
  const role = COOP_CHARACTERS[id];
  const image = artImage(role.portrait);
  if (!image) return '';
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 72;
  const context = canvas.getContext('2d')!;
  context.imageSmoothingEnabled = false;
  const [x,y,size] = role.crop;
  context.drawImage(image,x,y,size,size,0,0,72,72);
  const url = canvas.toDataURL();
  portraits.set(id,url);
  return url;
}

export function coopLobby(view: CoopView, invite: string, host: boolean) {
  const { room, error, seat } = view;
  if (!room) return `<p class="dialog-description">${esc(error ?? '正在接通星门…')}</p>${error ? '<button class="small-button" data-action="coop-retry">重新连接</button>' : ''}`;
  const own = room.players.find(player => player.seat === seat);
  const allReady = room.players.every(player => player.connected && player.role && player.ready);
  const locked = room.status === 'running';
  return `<p class="dialog-description">1–4 人 · 十一境 · 两场三阶段首领战。队友倒地后，靠近即可援救。</p>
    <ol class="coop-seats">${Array.from({length:4}, (_,i) => {
      const player = room.players.find(entry => entry.seat === i);
      const character = player?.role ? COOP_CHARACTERS[player.role] : null;
      return `<li style="--role-tint:${character?.color ?? '#899b93'}"><strong>${player ? esc(player.name) : '空席'}</strong><small>${player ? `${character?.name ?? '选角中'} · ${player.connected ? (player.ready ? '已准备' : '未准备') : '重连中'}` : '等待队友'}${i === seat ? ' · 你' : ''}</small></li>`;
    }).join('')}</ol>
    <div class="coop-picks" role="group" aria-label="选择角色">${COOP_CHARACTER_IDS.map(id => {
      const character = COOP_CHARACTERS[id];
      const occupied = room.players.find(player => player.role === id && player.seat !== seat);
      const selected = own?.role === id;
      const image = getCoopPortrait(id);
      return `<button type="button" class="coop-role" style="--role-tint:${character.color}" data-coop-role="${id}" aria-pressed="${selected}" ${occupied || locked ? 'disabled' : ''}>
        <span class="coop-portrait" ${image ? `style="--portrait:url('${image}')"` : ''}></span>
        <strong>${character.name} <small>${character.gender}</small></strong><span>${icon(character.icon)} ${character.title}</span>
        <small>${occupied ? `已被 ${esc(occupied.name)} 选用` : character.trait}</small></button>`;
    }).join('')}</div>
    <label class="coop-invite" for="coop-invite">邀请链接<div><input id="coop-invite" readonly value="${esc(invite)}"><button class="small-button" data-action="coop-copy">复制邀请</button></div></label>
    <p class="coop-room-status" role="status">${esc(error ?? (locked ? '星门即将开启…' : !own?.role ? '选定你的角色后，点击准备。' : own.ready ? '已准备，等待队伍出发。' : '角色已选定。'))}</p>
    <div class="coop-room-actions"><button class="secondary-button" data-action="coop-leave">离开房间</button><button class="${host ? 'secondary-button' : 'primary-button'}" data-action="coop-ready" ${own?.role && !locked ? '' : 'disabled'}>${own?.ready ? '取消准备' : '准备'}</button>
    ${host ? `<button class="primary-button" data-action="coop-start" ${allReady && !locked ? '' : 'disabled'}>${room.players.length === 1 ? '独自出发' : '全队出发'} ${icon('arrow')}</button>` : ''}</div>`;
}

export function coopHud(party: readonly PartyTraveller[]) {
  return party.map(player => {
    const character = player.role ? COOP_CHARACTERS[player.role] : null;
    const hp = Math.max(0, Math.ceil(player.hero.hp));
    return `<div style="--role-tint:${character?.color ?? player.color}"><b>${character?.name ?? esc(player.name)}</b><span>${!player.connected ? '离线' : !hp ? '倒地' : `${hp}/${player.hero.maxHp}`}</span></div>`;
  }).join('');
}

export function coopResult(result: GameResult, party: readonly PartyTraveller[]) {
  return `<div class="result-panel ${result.won?'victory':'defeat'}"><div class="result-emblem">${icon(result.won?'trophy':'flag')}</div><h2>${result.won?'玄阙已破，星路归明。':'星火未尽。'}</h2>
    <p>${party.map(player => esc(player.name)).join(' · ')}　${result.roomsCleared} / 11 境　${formatTime(result.time)}</p><button class="primary-button" data-action="home">返回远征大厅 ${icon('arrowLeft')}</button></div>`;
}
