import { COOP_CHARACTERS } from '../coop-characters';
import type { CoopCharacterId, CoopSeat } from '../coop-transport';
import type { PartyTraveller } from '../coop-play';
import { drawArtHero } from './actor-art';
import { artImage } from './art-assets';
import type { Hero, Projectile } from './types';

export interface CoopFrame {
  people: readonly PartyTraveller[];
  seat: CoopSeat | null;
  shots: readonly Projectile[];
}
const kit = {
  blade: { file: 'coop-warrior', anchorX:81, anchorY:101, scale:1.20, attack:[7,7,8] },
  staff: { file: 'coop-staff', anchorX:69, anchorY:97, scale:1.04, attack:[7,7,13] },
  spear: { file: 'coop-huntress', anchorX:75, anchorY:97, scale:1.13, attack:[5,5,7] },
} as const;
const TAU = Math.PI * 2;

export function drawCoopHero(ctx: CanvasRenderingContext2D, role: CoopCharacterId, hero: Hero, now: number, awakened: boolean) {
  if (role === 'wheel') {
    return drawArtHero(ctx, hero, now, 1, awakened, 'jade');
  }
  const style = kit[role], timer = hero.attackTimer, step = Math.max(1, hero.attackStep);
  const attackDuration = step === 3 ? .32 : .22;
  const progress = Math.max(0, Math.min(.99, 1 - timer / attackDuration));
  const attacking = timer > 0;
  let pose = 'idle', phase = hero.animation * 8;
  if (hero.hp <= 0) { pose = 'death'; phase = 8; }
  else if (hero.invincible > 1.07 && hero.invincible <= 1.31 && Math.abs(hero.vx) > 160) { pose = 'hurt'; phase = (1.31-hero.invincible)*10; }
  else if (attacking) { pose = `attack${role === 'staff' ? (step === 3 ? 2 : 1) : step}`; phase = style.attack[step-1] * progress; }
  else if (!hero.grounded && hero.dashTimer <= 0) { pose = hero.vy < 0 ? 'jump' : 'fall'; phase = Math.abs(hero.vy) > 100 ? 0 : 1; }
  else if (Math.abs(hero.vx) > 14 || hero.dashTimer > 0) { pose = 'run'; phase = hero.animation * 13; }
  const image = artImage(`actors/${style.file}-${pose}.png`);
  if (!image) return false;
  const tile = image.naturalHeight, count = Math.floor(image.naturalWidth / tile);
  const frame = pose === 'death' ? count - 1 : Math.floor(Math.max(0, phase)) % count;
  const tint = COOP_CHARACTERS[role].color;
  ctx.save();
  ctx.translate(Math.round(hero.x+hero.w/2), Math.round(hero.y+hero.h));
  ctx.fillStyle = '#08171890';
  ctx.beginPath(); ctx.ellipse(0, 2, 15, 3, 0, 0, TAU); ctx.fill();
  if (awakened || hero.guardTimer > 0) {
    ctx.strokeStyle = tint; ctx.lineWidth = 1.5; ctx.globalAlpha *= .72;
    ctx.beginPath(); ctx.arc(0,-26,30, now*.85, now*.85+5.25); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  ctx.scale(hero.facing, 1);
  if (hero.invincible > 0 && Math.floor(now * 13) % 2 === 0) ctx.globalAlpha = .66;
  if (hero.hp <= 0) ctx.globalAlpha = .67;
  ctx.imageSmoothingEnabled = false;
  const drawScale = style.scale;
  ctx.drawImage(image, frame * tile,0,tile,tile,-style.anchorX*drawScale,-style.anchorY*drawScale,tile*drawScale,tile*drawScale);
  ctx.filter = 'none';
  if (attacking && role === 'spear') {
    const length = step === 3 ? 88 : 67;
    ctx.globalAlpha *= Math.sin(Math.PI * progress) * .87;
    ctx.strokeStyle = tint; ctx.lineWidth = step === 3 ? 4 : 2;
    ctx.beginPath(); ctx.moveTo(14, -23); ctx.lineTo(length, -24); ctx.stroke();
    ctx.strokeStyle = '#e0e8df'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(26, -21); ctx.lineTo(length+8,-24); ctx.stroke();
  }
  ctx.restore(); return true;
}

export function drawTravellerBadge(ctx: CanvasRenderingContext2D, p: PartyTraveller, hero: Hero, local: boolean) {
  if (!p.role) return;
  const character = COOP_CHARACTERS[p.role], y = Math.round(hero.y) - (p.role === 'staff' ? 20 : 14);
  const x = Math.round(hero.x+hero.w/2);
  ctx.save(); ctx.font = '10px sans-serif'; ctx.textAlign = 'center';
  const label = hero.hp > 0 ? (local ? `${character.name} · 你` : character.name) : p.aid > 0 ? '救援中' : '倒地';
  const size = Math.ceil(ctx.measureText(label).width) + 12;
  ctx.fillStyle = '#0c2526e8'; ctx.fillRect(x-size/2,y-12,size,15);
  ctx.fillStyle = character.color; ctx.fillRect(x-size/2,y+2,size,1);
  ctx.fillText(label,x,y-1);
  if (p.aid > 0) { ctx.fillStyle = '#f6d38d'; ctx.fillRect(x-size/2,y+3,size*Math.min(1,p.aid/1.15),2); }
  ctx.restore();
}
