import type { GameState, Hero } from './types';

const TAU = Math.PI * 2;
const count = (hero: Hero, id: string) => hero.upgrades.filter(upgrade => upgrade === id).length;
const pixel = (context: CanvasRenderingContext2D, x: number, y: number, w = 2, h = w) => context.fillRect(Math.round(x), Math.round(y), w, h);

function star(context: CanvasRenderingContext2D, x: number, y: number, color: string, size = 2) {
  context.fillStyle = color;
  pixel(context, x - size, y, size * 3, size);
  pixel(context, x, y - size, size, size * 3);
  context.fillStyle = '#fff3ce'; pixel(context, x, y, size);
}

function line(context: CanvasRenderingContext2D, points: Array<[number, number]>, color: string, width = 1) {
  context.strokeStyle = color; context.lineWidth = width;
  context.beginPath();
  points.forEach(([x, y], index) => index ? context.lineTo(Math.round(x), Math.round(y)) : context.moveTo(Math.round(x), Math.round(y)));
  context.stroke();
}

/** One quiet ground layer, a real shield layer and small orbital embers at most.
 * All marks read current simulation state; none modify damage or spawn entities. */
export function drawBuffBack(context: CanvasRenderingContext2D, state: GameState, now: number): void {
  const hero = state.hero;
  if (hero.hp <= 0 || hero.upgrades.length === 0 && hero.shield <= 0) return;
  const x = hero.x + hero.w / 2, foot = hero.y + hero.h, facing = hero.facing || 1;
  const vigor = count(hero, 'vigor'), magnet = count(hero, 'magnet'), stride = count(hero, 'stride');
  context.save();

  if (vigor > 0) {
    context.globalAlpha = .16 + Math.sin(now * 2.5) * .035;
    context.fillStyle = '#dfa66e';
    context.beginPath(); context.ellipse(x, foot - 2, 23, 6, 0, 0, TAU); context.fill();
    context.globalAlpha = .42;
    for (let i = 0; i < 3; i++) {
      const age = (now * .48 + i / 3) % 1;
      context.fillStyle = i === 1 ? '#df9c77' : '#e3c391';
      pixel(context, x - 17 + i * 16, foot - 5 - age * 35, 2, 3);
    }
    line(context, [[x - 12, foot - 17], [x - 15, foot - 25], [x - 12, foot - 32]], '#dcb38477');
    line(context, [[x + 13, foot - 14], [x + 16, foot - 21]], '#dcb38477');
  }

  if (magnet > 0 && hero.grounded) {
    context.globalAlpha = .48;
    for (let i = 0; i < 24; i++) {
      if (i % 6 === 0) continue;
      const angle = i / 24 * TAU + now * .16;
      context.fillStyle = '#8db7ae';
      pixel(context, x + Math.cos(angle) * 35, foot + Math.sin(angle) * 8, i % 3 === 0 ? 3 : 2, 1);
    }
    for (const direction of [-1, 1]) {
      const shift = (now * 18) % 12;
      line(context, [[x + direction * (31 - shift), foot - 3], [x + direction * (27 - shift), foot], [x + direction * (31 - shift), foot + 3]], '#b6d5bd', 1);
    }
  }

  if (stride > 0 && Math.abs(hero.vx) > 60) {
    const movement = Math.sign(hero.vx);
    for (let i = 0; i < 5; i++) {
      const age = (now * 2 + i / 5) % 1;
      context.globalAlpha = (1 - age) * .7;
      context.fillStyle = age < .35 ? '#c5d9b5' : '#7fa994';
      pixel(context, x - movement * (14 + age * (hero.dashTimer > 0 ? 90 : 44)), foot - 2 - Math.sin(age * Math.PI) * 9, 6 - Math.floor(age * 4), 2);
    }
    context.globalAlpha = .64;
    line(context, [[x - movement * 31, foot - 5], [x - movement * 17, foot - 7], [x - movement * 3, foot - 4]], '#c2d5ad', 1);
  }

  if (hero.shield > 0) {
    const visibleLayers = Math.min(3, hero.shield);
    for (let i = 0; i < visibleLayers; i++) {
      const angle = -2.1 + i * TAU / 3 + Math.sin(now * .7) * .08;
      const radius = 34;
      context.globalAlpha = .62;
      const points: Array<[number, number]> = [];
      for (let step = 0; step <= 5; step++) {
        const at = angle + step * .16;
        points.push([x + Math.cos(at) * radius, foot - 24 + Math.sin(at) * radius]);
      }
      line(context, points, '#c4ceb4', 2);
      context.globalAlpha = .84;
      star(context, x + Math.cos(angle + .4) * radius, foot - 24 + Math.sin(angle + .4) * radius, '#d6dfbb', 1);
    }
    // More than three charges stay explicit as tiny reserve marks, not extra rings.
    context.fillStyle = '#d7dfbc'; context.globalAlpha = .8;
    for (let i = 3; i < Math.min(hero.shield, 7); i++) pixel(context, x - 5 + (i - 3) * 4, foot - 64, 2, 2);
  }

  if (count(hero, 'multishot') > 0 && hero.extraProjectiles > 0) {
    const amount = Math.min(3, hero.extraProjectiles);
    for (let i = 0; i < amount; i++) {
      const angle = now * 1.6 + i * TAU / amount;
      const emberX = x + Math.cos(angle) * 36, emberY = foot - 27 + Math.sin(angle) * 12;
      context.globalAlpha = .8;
      star(context, emberX, emberY, '#dfbd7a', 2);
      context.globalAlpha = .3; context.fillStyle = '#d98f5e';
      pixel(context, emberX - Math.sin(angle) * 6, emberY + Math.cos(angle) * 2, 3, 2);
    }
  }

  if (count(hero, 'blood') > 0 && hero.lifesteal > 0) {
    context.globalAlpha = .65;
    const runeX = x - facing * 22, runeY = foot - 24 + Math.round(Math.sin(now * 2));
    line(context, [[runeX - 3, runeY - 9], [runeX + 3, runeY - 9], [runeX + 3, runeY - 3], [runeX - 3, runeY - 3], [runeX - 3, runeY + 3], [runeX + 3, runeY + 3]], '#c47f72');
    context.fillStyle = '#dcaf8b'; pixel(context, runeX, runeY - 7, 1, 9);
  }

  if (count(hero, 'fortune') > 0) {
    for (let i = 0; i < 2; i++) {
      const age = (now * .6 + i * .5) % 1;
      context.globalAlpha = (1 - age) * .65;
      star(context, x + facing * (15 + i * 8), foot - 10 - age * 27, '#d6b86f', 1);
    }
    context.globalAlpha = .55;
    line(context, [[x - 8, foot - 12], [x - 5, foot - 15], [x - 2, foot - 12], [x - 5, foot - 9], [x - 8, foot - 12]], '#d8b978');
  }
  context.restore();
}

/** Weapon marks live around the blade, never as a full-screen color wash. */
export function drawBuffFront(context: CanvasRenderingContext2D, state: GameState, now: number): void {
  const hero = state.hero;
  if (hero.hp <= 0 || hero.upgrades.length === 0) return;
  const x = hero.x + hero.w / 2, foot = hero.y + hero.h, facing = hero.facing || 1;
  const edge = count(hero, 'edge'), tempo = count(hero, 'tempo'), stride = count(hero, 'stride');
  context.save();

  if (edge > 0) {
    if (hero.attackTimer > 0 && hero.weapon === 'blade') {
      const duration = hero.attackStep === 3 ? .28 : .18;
      const progress = Math.max(0, Math.min(1, 1 - hero.attackTimer / duration));
      const reverse = hero.attackStep === 2;
      const end = reverse ? 1.4 - progress * 3 : -1.4 + progress * 3;
      const radius = (hero.attackStep === 3 ? 76 : 58) + Math.min(3, edge) * 12;
      context.save(); context.translate(x + facing * 7, foot - 25); context.scale(facing, 1);
      context.globalAlpha = .32 + Math.sin(progress * Math.PI) * .55;
      const points: Array<[number, number]> = [], inner: Array<[number, number]> = [];
      for (let i = 0; i <= 10; i++) {
        const angle = end + (reverse ? 1 : -1) * (1 - i / 10);
        points.push([Math.cos(angle) * radius, Math.sin(angle) * radius]);
        inner.push([Math.cos(angle) * (radius - 5), Math.sin(angle) * (radius - 5)]);
      }
      line(context, points, '#f3d6a0', hero.attackStep === 3 ? 3 : 2);
      line(context, inner, '#b96443', hero.attackStep === 3 ? 5 : 3);
      for (let i = 0; i < 4; i++) {
        const angle = end + (reverse ? 1 : -1) * (.13 + i * .22);
        context.fillStyle = i % 2 ? '#d78954' : '#f1cf83';
        pixel(context, Math.cos(angle) * (radius + 4 + i), Math.sin(angle) * (radius + 4 + i), i % 2 ? 2 : 3, 2);
      }
      context.restore();
    } else {
      const handX = x + facing * 18;
      context.globalAlpha = .8;
      line(context, [[handX - facing * 3, foot - 23], [handX + facing * 2, foot - 29], [handX + facing * 6, foot - 38]], '#d08b5e', 2);
      context.fillStyle = '#f0d29b'; pixel(context, handX + facing * 5, foot - 38 - Math.round(Math.sin(now * 7) * 2), 2, 4);
      context.globalAlpha = .44; context.fillStyle = '#ba6447';
      pixel(context, handX + facing * 10, foot - 32 - (now * 12 % 10), 2, 3);
    }
  }

  if (tempo > 0 && hero.attackTimer > 0) {
    context.save(); context.translate(x, foot - 24); context.scale(facing, 1);
    context.globalAlpha = .6;
    const shift = Math.floor(now * 34) % 7;
    line(context, [[-30 - shift, -16], [-12 - shift, -20], [2 - shift, -17]], '#bbd6bf', 1);
    line(context, [[-37 + shift, -5], [-20 + shift, -8], [-5 + shift, -5]], '#83b4a7', 2);
    line(context, [[-24 - shift, 8], [-10 - shift, 7]], '#c4d9bf', 1);
    context.restore();
  }

  if (stride > 0 && hero.dashTimer > 0) {
    context.save(); context.translate(x, foot - 20); context.scale(facing, 1);
    context.globalAlpha = .8;
    line(context, [[24, -24], [37, -14], [43, 0], [37, 14], [24, 24]], '#c9d9b0', 2);
    line(context, [[31, -17], [40, -8], [44, 0]], '#7fbba7', 3);
    context.restore();
  }

  if (count(hero, 'blood') > 0 && hero.lifesteal > 0) {
    const healing = state.floatingTexts.find(text => /汲取|吸血/.test(text.text) && text.life > 0);
    if (healing) {
      const progress = 1 - healing.life / healing.maxLife;
      context.globalAlpha = Math.sin(Math.min(1, progress * 2) * Math.PI) * .8;
      for (let i = 0; i < 5; i++) {
        const phase = (progress * 1.5 + i / 5) % 1;
        const offset = (1 - phase) * 33;
        context.fillStyle = i % 2 ? '#c67366' : '#e6b18f';
        pixel(context, x - facing * offset, foot - 20 - Math.sin(phase * Math.PI) * 15, 2, 3);
      }
    }
  }
  context.restore();
}
