import type { RaceGhost } from '../race-types';
import type { GameState, Hero } from './types';
import { drawArtHero } from './actor-art';

/** Opponents are a render layer only. Never add them to collision or combat lists. */
export function drawRaceGhost(c: CanvasRenderingContext2D, state: GameState, remote: RaceGhost, now: number): void {
  if (remote.roomIndex !== state.roomIndex || remote.ageMs > 8000 || !['playing', 'paused', 'upgrade'].includes(remote.phase)) return;
  if (remote.x < state.cameraX - 100 || remote.x > state.cameraX + 1060) return;
  const hero: Hero = { ...state.hero, x: remote.x, y: remote.y, vx: remote.vx, vy: remote.vy,
    facing: remote.facing, grounded: remote.grounded, weapon: remote.weapon, level: remote.level,
    attackTimer: remote.attackTimer, attackStep: remote.attackStep, animation: remote.animation,
    hp: Math.max(1, remote.hp), maxHp: remote.maxHp, shield: 0, upgrades: [], invincible: 0,
    dashTimer: 0, swapBoost: 0, counterTimer: 0, guardTimer: 0 };
  c.save();
  const freshness = remote.ageMs <= 2000 ? 1 : Math.max(0, 1 - (remote.ageMs - 2000) / 6000);
  c.globalAlpha *= .38 * freshness;
  c.filter = 'saturate(.45) sepia(.2) hue-rotate(110deg)';
  c.shadowColor = '#9bdfdd'; c.shadowBlur = 3;
  drawArtHero(c, hero, now);
  c.restore();
  c.save(); c.globalAlpha *= .8 * freshness; c.font = '10px "Microsoft YaHei", sans-serif';
  c.textAlign = 'center'; c.lineWidth = 3; c.strokeStyle = '#102a2e'; c.fillStyle = '#b7e2dc';
  const label = `${remote.name || '对手'} · 影`;
  c.strokeText(label, remote.x + hero.w / 2, remote.y - 23);
  c.fillText(label, remote.x + hero.w / 2, remote.y - 23);
  c.restore();
}
