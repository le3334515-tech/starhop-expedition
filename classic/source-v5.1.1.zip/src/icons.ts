const paths: Record<string, string> = {
  star: '<path d="m12 2 2.6 6.4L21 11l-6.4 2.6L12 20l-2.6-6.4L3 11l6.4-2.6L12 2Z"/><path d="m20 16 .8 2.2L23 19l-2.2.8L20 22l-.8-2.2L17 19l2.2-.8Z"/>',
  play: '<path d="m9 5 11 7-11 7V5Z"/>',
  arrow: '<path d="M4 12h15m-6-6 6 6-6 6"/>',
  arrowLeft: '<path d="M20 12H5m6-6-6 6 6 6"/>',
  chevron: '<path d="m9 5 7 7-7 7"/>',
  blade: '<path d="m15 3 6 0 0 6-11 11-6-6L15 3Z"/><path d="m3 12 9 9M6 18l-3 3m7-10 3 3"/>',
  spear: '<path d="m4 20 10-10m-2-1 8-5-4 9-4-4ZM7 17l-3-3m5 1 2 2"/>',
  fan: '<path d="M3 9a13 13 0 0 1 18 0l-9 11L3 9Zm5-3 4 14 4-14M6 11l6 9 6-9"/><circle cx="12" cy="20" r="1"/>',
  fist: '<path d="M6 13V8a2 2 0 0 1 4 0V6a2 2 0 0 1 4 0v1a2 2 0 0 1 4 0v2a2 2 0 0 1 3 2v4l-4 6H9l-5-6a2 2 0 0 1 2-3l3 2"/><path d="M10 8v4m4-5v5m4-3v4"/>',
  ember: '<path d="M13 2c2 5-1 6 2 9 1-1 2-2 2-4 5 5 5 9 1 13-4 3-11 1-12-4-1-4 3-7 3-10 2 1 2 3 2 4 2-2 3-4 2-8Z"/><path d="M12 13c-3 3-3 6 0 7 4-1 3-4 0-7Z"/>',
  disc: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/><path d="m5 6 5 3m5-5-1 5m6 7-5-2M8 20l2-5"/>',
  moon: '<path d="M20 14A9 9 0 0 1 10 3a9 9 0 1 0 10 11Z"/><path d="M18 2v5m-2.5-2.5h5"/>',
  bolt: '<path d="m14 2-9 12h7l-2 8 10-13h-8l2-7Z"/>',
  heart: '<path d="M20 5c-3-3-7-1-8 2-1-3-5-5-8-2-4 4 1 10 8 15 7-5 12-11 8-15Z"/>',
  sound: '<path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="M17 8c3 2 3 6 0 8m3-11c5 4 5 10 0 14"/>',
  muted: '<path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="m17 9 5 6m0-6-5 6"/>',
  fullscreen: '<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  flag: '<path d="M5 22V3c5-4 9 4 15 0v11c-6 4-10-4-15 0"/>',
  trophy: '<path d="M7 3h10v6c0 7-10 7-10 0V3Zm0 2H3v3c0 3 3 4 5 4m9-7h4v3c0 3-3 4-5 4m-4 3v5m-5 1h10"/>',
  copy: '<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M15 5V3H3v13h2"/>',
  link: '<path d="m9 15 6-6m-8 8-1 1c-5 5-10-2-6-6l4-4c2-2 4-2 6 0m3-1 1-1c5-5 10 2 6 6l-4 4c-2 2-4 2-6 0" transform="translate(2 0)"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 1 1 5 2c-2 1-2 2-2 3m0 3h.01"/>',
  refresh: '<path d="M20 10a8 8 0 1 0-2 8m3-15v7h-7"/>',
  users: '<circle cx="9" cy="7" r="3"/><path d="M3 21v-3c0-6 12-6 12 0v3m1-17c5 0 5 7 0 7m2 3c3 0 4 2 4 5v2"/>',
  coin: '<circle cx="12" cy="12" r="9"/><path d="M10 7h4m-2 0v10m-2 0h4"/>',
  shield: '<path d="m12 2 8 4v7c0 4-5 7-8 9-3-2-8-5-8-9V6l8-4Z"/><path d="m8 12 3 3 5-6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
  check: '<path d="m5 12 5 5L20 6"/>',
  jump: '<path d="M12 21V4m-6 6 6-6 6 6M4 21h16"/>',
  keyboard: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M6 9h1m4 0h1m4 0h1M6 13h1m4 0h1m4 0h1m-9 3h8"/>',
  wind: '<path d="M3 7h12a3 3 0 1 0-3-3M2 12h17a3 3 0 1 1-3 3M5 17h5a2 2 0 1 1-2 2"/>',
  spark: '<path d="m12 2 2.5 6 6 2.5-6 2.5-2.5 7-2.5-7-6-2.5 6-2.5L12 2Zm7 15 1 2 2 1-2 1-1 2-1-2-2-1 2-1 1-2Z"/>',
  orbit: '<circle cx="12" cy="12" r="3"/><ellipse cx="12" cy="12" rx="11" ry="5" transform="rotate(-35 12 12)"/><path d="M6 3c5-1 13 12 12 17M4 4h.01M20 20h.01"/>',
  rotate: '<rect x="7" y="5" width="10" height="14" rx="2" transform="rotate(-25 12 12)"/><path d="M2 10a10 10 0 0 1 16-7m0-3v4h-4M22 14a10 10 0 0 1-16 7m0 3v-4h4M12 16h.01"/>',
};
export function icon(name: string, className = ''): string {
  return `<svg class="icon ${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.star}</svg>`;
}
export function escapeHtml(value: unknown): string {
  return String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
}
