import { describe, expect, it } from 'vitest';
import { LEADERBOARD_VERSION, makeSnapshot, mergeRecords, parseFeed, parseSnapshot, sanitizeName, validateRecord, validateProfile, validateLegacyRecord, mergeProfiles, applyProfiles, parseFeedState, type LeaderboardRecord } from './leaderboard-core';
import type { GameResult, ModifierId } from './game/types';

const result = (overrides: Partial<GameResult> = {}): GameResult => ({
  seed: 42, modifier: 'standard', weapon: 'ember', won: true, time: 123.45, score: 12000, coins: 30,
  kills: 24, level: 5, deaths: 0, roomsCleared: 8, maxCombo: 6, upgrades: ['edge'], overdriveCount: 1, synergies: [], ...overrides,
});
function record(player = 1, time = 100, rule: ModifierId = 'standard'): LeaderboardRecord {
  return { version: LEADERBOARD_VERSION, runId: `run_test_${player}_${time}`, playerId: `player_test_${player}`, name: `玩家${player}`,
    createdAt: '2026-11-16T12:00:00.000Z', result: result({ time, modifier: rule }) };
}
const event = (r: unknown) => JSON.stringify({ id: 'actual-server-event', event: 'message', message: JSON.stringify(r) });

describe('shared leaderboard validation', () => {
  it('accepts full current victories and removes markup from the player name', () => {
    const input = { ...record(), name: '<小星>\u202e &旅人' };
    expect(validateRecord(input)?.name).toBe('小星 旅人');
    expect(sanitizeName('   ')).toBe('星际旅人');
    expect(Array.from(sanitizeName('🌟'.repeat(30)))).toHaveLength(12);
    expect(validateRecord(input)?.result).not.toBe(input.result);
  });
  it.each([
    { won: false }, { roomsCleared: 3 }, { roomsCleared: 5 }, { time: 0 }, { time: -2 }, { time: Infinity }, { time: NaN },
    { kills: 0 }, { kills: 1.4 }, { modifier: 'custom' }, { weapon: 'gun' }, { seed: -1 }, { score: 1.2 }, { upgrades: ['<script>'] },
    { synergies: ['bad id'] }, { overdriveCount: -1 }, { level: 0 },
  ])('rejects incomplete or invalid run %j', invalid => {
    expect(validateRecord({ ...record(), result: { ...result(), ...invalid } })).toBeNull();
  });
  it('rejects unknown versions, missing data, malformed IDs and timestamps', () => {
    for (const invalid of [null, [], {}, { ...record(), version: 'starhop-v1' }, { ...record(), runId: '<script>' },
      { ...record(), playerId: '' }, { ...record(), createdAt: 'not a date' }, { ...record(), name: 'x'.repeat(101) }]) expect(validateRecord(invalid)).toBeNull();
  });
  it('never invents a record for an empty snapshot', () => {
    const snapshot = makeSnapshot([], '2026-11-16T12:00:00Z');
    expect(parseSnapshot(snapshot)?.records).toEqual([]);
    expect(parseSnapshot({ ...snapshot, version: 'old' })).toBeNull();
  });
  it('merges concurrent scores, keeps each player fastest per rule and sorts top ten', () => {
    const first = Array.from({ length: 15 }, (_, i) => record(i + 1, 90 + i));
    const faster = { ...record(1, 80), runId: 'run_faster_result' };
    const moon = record(1, 72, 'moon');
    const merged = mergeRecords(first, [faster, record(1, 130), moon], [record(20, 79)]);
    const standard = merged.filter(r => r.result.modifier === 'standard');
    expect(standard).toHaveLength(10);
    expect(standard.map(r => r.result.time)).toEqual([79, 80, 91, 92, 93, 94, 95, 96, 97, 98]);
    expect(merged.find(r => r.result.modifier === 'moon')?.playerId).toBe(faster.playerId);
    expect(mergeRecords(merged, first, [faster, moon])).toEqual(merged);
  });
  it('breaks equal times by earliest completion then run ID independent of receive order', () => {
    const a = { ...record(1), createdAt: '2026-11-16T12:00:02Z' };
    const b = { ...record(2), createdAt: '2026-11-16T12:00:01Z' };
    expect(mergeRecords([a, b])).toEqual(mergeRecords([b, a]));
    expect(mergeRecords([a, b])[0].playerId).toBe(b.playerId);
  });
  it('parses independent server events while ignoring keepalive, malformed messages and losses', () => {
    const parsed = parseFeed([JSON.stringify({ event: 'open' }), '{oops', event(record()), event({ ...record(2), result: result({ won: false }) }), event(record(3, 90))].join('\n'));
    expect(parsed.map(r => r.result.time)).toEqual([90, 100]);
    expect(parseFeed('')).toEqual([]);
  });
});


describe('separate immutable scores and editable shared names',()=>{
  it('keeps legacy four-room results out of the eight-room ranking',()=>{
    const legacy={...record(),version:'starhop-v2',result:result({roomsCleared:4})};
    expect(validateRecord(legacy)).toBeNull();
    expect(validateLegacyRecord(legacy)?.result.time).toBe(123.45);
    const migrated=parseSnapshot({version:'starhop-v2',updatedAt:'2026-11-16T12:00:00Z',records:[legacy]});
    expect(migrated?.records).toEqual([]);expect(migrated?.legacyRecords).toHaveLength(1);
  });
  it('uses the latest profile independent of receive order without changing time or rank',()=>{
    const old=validateProfile({version:LEADERBOARD_VERSION,type:'profile',playerId:record().playerId,name:'旧昵称',updatedAt:'2026-11-16T12:00:01Z'})!;
    const next={...old,name:'新昵称',updatedAt:'2026-11-16T12:00:02.000Z'};
    expect(mergeProfiles([next],[old])).toEqual([next]);
    const records=mergeRecords([record(2,90),record(1,100)]);
    const named=applyProfiles(records,[next]);
    expect(named.map(r=>r.result.time)).toEqual([90,100]);
    expect(named[1].name).toBe('新昵称');expect(named[1].runId).toBe(records[1].runId);
    expect(records[1].name).toBe('玩家1');
  });
  it('applies one profile to both boards and survives permanent snapshot replay',()=>{
    const profile=validateProfile({version:LEADERBOARD_VERSION,type:'profile',playerId:record().playerId,name:'云间客',updatedAt:'2026-11-16T12:00:02Z'})!;
    const legacy=validateLegacyRecord({...record(),version:'starhop-v2',result:result({roomsCleared:4})})!;
    const snapshot=makeSnapshot([record()],'2026-11-16T12:00:03Z',[profile],[legacy]);
    const reloaded=parseSnapshot(JSON.parse(JSON.stringify(snapshot)))!;
    expect(reloaded.records[0].name).toBe('云间客');expect(reloaded.legacyRecords[0].name).toBe('云间客');
    expect(reloaded.legacyRecords[0].result.roomsCleared).toBe(4);expect(reloaded.records[0].result.roomsCleared).toBe(8);
    expect(parseFeedState(event(profile)).profiles).toEqual([profile]);
    expect(parseFeed(event(profile))).toEqual([]);
  });
});
