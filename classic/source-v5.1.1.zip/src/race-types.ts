import type { GameConfig, Phase, WeaponId } from './game/types';

export type RaceSeat = 'host' | 'guest';
export interface RaceFrame {
  seq: number; roomIndex: number; x: number; y: number; vx: number; vy: number; facing: number;
  grounded: boolean; weapon: WeaponId; attackTimer: number; attackStep: number; hp: number; maxHp: number;
  level: number; animation: number; phase: Phase; progress: number; elapsed: number; finished?: boolean; won?: boolean;
}
export interface RacePlayer {
  id: RaceSeat; name: string; readyAt: number | null; lastSeen: number; frame: RaceFrame | null; finishedAt: number | null; leftAt?: number | null;
}
export interface RaceRoom {
  id: string; config: GameConfig; createdAt: number; startAt: number | null; epoch?: number;
  status: 'waiting' | 'countdown' | 'racing' | 'finished'; host: RacePlayer; guest: RacePlayer | null;
}
export interface RaceResponse { ok: true; serverNow: number; selfId: RaceSeat; token?: string; room: RaceRoom }
export interface RaceGhost extends RaceFrame { name: string; ageMs: number; stale: boolean }
export interface RaceView {
  connection: 'idle' | 'connecting' | 'online' | 'reconnecting' | 'error' | 'closed';
  room: RaceRoom | null; selfId: RaceSeat | null; self: RacePlayer | null; opponent: RacePlayer | null;
  started: boolean; countdown: number | null; elapsed: number; error: string | null; opponentAgeMs?: number;
}

const finite = (value: unknown, fallback: number) => typeof value === 'number' && Number.isFinite(value) ? value : fallback;
const clamp = (value: unknown, min: number, max: number, fallback = min) => Math.max(min, Math.min(max, finite(value, fallback)));
const weapons: WeaponId[] = ['blade', 'ember', 'disc'];
const phases: Phase[] = ['menu', 'playing', 'paused', 'upgrade', 'victory', 'gameover'];
export function sanitizeRaceFrame(value: unknown): RaceFrame {
  const v = value && typeof value === 'object' ? value as Record<string, unknown> : {};
  return {
    seq: Math.floor(clamp(v.seq, 0, 2_147_483_647)), roomIndex: Math.floor(clamp(v.roomIndex, 0, 7)),
    x: clamp(v.x, -100, 5000), y: clamp(v.y, -500, 1200), vx: clamp(v.vx, -2500, 2500, 0), vy: clamp(v.vy, -3000, 3000, 0),
    facing: finite(v.facing, 1) < 0 ? -1 : 1, grounded: v.grounded === true,
    weapon: weapons.includes(v.weapon as WeaponId) ? v.weapon as WeaponId : 'blade',
    attackTimer: clamp(v.attackTimer, 0, .5), attackStep: Math.floor(clamp(v.attackStep, 0, 3)),
    hp: clamp(v.hp, 0, 999, 1), maxHp: clamp(v.maxHp, 1, 999, 5), level: Math.floor(clamp(v.level, 1, 1000, 1)),
    animation: clamp(v.animation, 0, 1_000_000), phase: phases.includes(v.phase as Phase) ? v.phase as Phase : 'playing',
    progress: clamp(v.progress, 0, 1), elapsed: clamp(v.elapsed, 0, 86_400), finished: v.finished === true, won: v.won === true,
  };
}
function object(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object') throw new Error('竞速房间返回的数据不完整。');
  return value as Record<string, unknown>;
}
function timestamp(value: unknown, nullable = false): number | null {
  if (nullable && value == null) return null;
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) throw new Error('竞速房间时间无效。');
  return value;
}
function player(value: unknown, seat: RaceSeat): RacePlayer {
  const v = object(value);
  return { id: seat, name: typeof v.name === 'string' ? Array.from(v.name.replace(/[<>\x00-\x1f]/g, '')).slice(0, 24).join('') || '同行旅人' : '同行旅人',
    readyAt: timestamp(v.readyAt, true), lastSeen: timestamp(v.lastSeen)!, frame: v.frame ? sanitizeRaceFrame(v.frame) : null,
    finishedAt: timestamp(v.finishedAt, true), leftAt: timestamp(v.leftAt, true) };
}
export function parseRaceResponse(value: unknown): RaceResponse {
  const v = object(value), r = object(v.room), c = object(r.config);
  if (v.ok !== true || !['host', 'guest'].includes(v.selfId as string)) throw new Error('竞速房间身份无效。');
  if (typeof r.id !== 'string' || !/^[a-zA-Z0-9_-]{12,128}$/.test(r.id)) throw new Error('竞速房间编号无效。');
  if (!Number.isInteger(c.seed) || (c.seed as number) < 0 || (c.seed as number) > 0xffffffff
    || !['standard', 'moon', 'haste', 'iron'].includes(c.modifier as string) || !weapons.includes(c.weapon as WeaponId)) throw new Error('竞速路线无效。');
  if (!['waiting', 'countdown', 'racing', 'finished'].includes(r.status as string)) throw new Error('竞速房间状态无效。');
  return { ok: true, serverNow: timestamp(v.serverNow)!, selfId: v.selfId as RaceSeat,
    token: typeof v.token === 'string' && /^[a-zA-Z0-9_-]{16,256}$/.test(v.token) ? v.token : undefined,
    room: { id: r.id, config: { seed: c.seed as number, modifier: c.modifier as GameConfig['modifier'], weapon: c.weapon as WeaponId },
      createdAt: timestamp(r.createdAt)!, startAt: timestamp(r.startAt, true), epoch: Math.floor(clamp(r.epoch, 0, 1_000_000)), status: r.status as RaceRoom['status'],
      host: player(r.host, 'host'), guest: r.guest ? player(r.guest, 'guest') : null } };
}

export function raceSeconds(player: RacePlayer | null, startAt: number | null, now: number): number | null {
  if (!player || startAt === null) return null;
  return Math.max(0, ((player.finishedAt ?? now) - startAt) / 1000);
}
