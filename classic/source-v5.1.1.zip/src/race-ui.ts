import { directRoom } from './race-host';
import { escapeHtml as esc, icon } from './icons';
import { MODIFIERS, WEAPONS } from './game/types';
import { raceSeconds, type RacePlayer, type RaceView } from './race-types';

export function raceTime(seconds: number | null): string {
  if (seconds == null) return '—';
  const centiseconds = Math.max(0, Math.floor(seconds * 100));
  return `${String(Math.floor(centiseconds / 6000)).padStart(2, '0')}:${String(Math.floor(centiseconds / 100) % 60).padStart(2, '0')}.${String(centiseconds % 100).padStart(2, '0')}`;
}
function readyLabel(player: RacePlayer | null, started: boolean) {
  if (!player) return '等待好友加入';
  if (player.leftAt != null) return '已离开';
  if (player.finishedAt != null) return player.frame?.won ? '已通关' : '本次止步';
  return started ? `第 ${(player.frame?.roomIndex ?? 0) + 1} 境` : player.readyAt ? '已准备' : '尚未准备';
}
export function renderRaceRoom(view: RaceView, inviteUrl: string): string {
  if (!view.room) return `<section class="race-room"><div class="race-room-mark">${icon('users')}</div><h3>${view.connection === 'connecting' ? '正在展开二人行牒…' : '同道竞速'}</h3><p>${esc(view.error ?? '邀一位朋友，同刻出发，竞逐归星。')}</p>${view.connection === 'error' ? '<button class="small-button" data-race-action="retry">重新连接</button> <button class="text-button" data-race-action="new-direct">新建好友直连房</button>' : ''}</section>`;
  const { room, self, opponent } = view;
  const waiting = room.startAt == null;
  const players = [self, opponent];
  return `<section class="race-room" data-race-room="${esc(room.id)}"><div class="race-room-title"><span class="race-room-mark">${icon('users')}</span><div><span>${directRoom(room.id) ? '好友房 · 房主请留在此页' : '服务器联机'} </span><h3>同刻启程，逐星而归。</h3></div></div><p class="race-room-rules">相同路线 · ${esc(MODIFIERS[room.config.modifier].name)} · ${esc(WEAPONS[room.config.weapon].name)}</p><div class="race-seats">${players.map((player, index) => `<div class="race-seat${index === 0 ? ' race-self' : ' race-opponent'}"><span>${index === 0 ? '你' : '同行幽影'}</span><strong>${esc(player?.name ?? '等待好友')}</strong><small>${readyLabel(player, view.started)}</small></div>`).join('')}</div>${waiting ? `<label class="field-label" for="race-invite">发送此链接，好友直接进入同一房间</label><div class="copy-field"><input id="race-invite" readonly value="${esc(inviteUrl)}" aria-label="在线竞速邀请链接"><button class="small-button" data-race-action="copy">${icon('copy')} 复制</button></div><details class="share-code"><summary>使用房间码加入</summary><div class="copy-field"><input id="race-code" readonly value="R-${esc(room.id)}" aria-label="房间码"><button class="small-button" data-race-action="copy-code">复制房间码</button></div><p>好友可在大厅点「接受战书」粘贴房间码。</p></details>${directRoom(room.id) && view.selfId === 'host' && !opponent ? '<button class="text-button" data-race-action="switch-server">好友连不上？改用服务器建房</button>' : ''}` : ''}<div class="race-room-live" aria-live="polite"><strong data-race-countdown>${view.countdown ? `${view.countdown}` : view.started ? '竞速进行中' : opponent ? '两人准备后同步倒数' : '等候一位同道'}</strong><span data-race-connection>${esc(view.connection === 'reconnecting' ? '连接暂时中断，正在重连…' : view.error ?? (view.countdown ? '请留在此页，即将同时出发' : '画卷载入后再准备 · 选强化和暂停也计入竞速用时'))}</span></div><div class="race-room-actions">${waiting ? `<button class="primary-button" data-race-action="ready" ${view.connection !== 'online' ? 'disabled' : ''}>${self?.readyAt ? '取消准备' : '我已准备'} ${icon('check')}</button>` : ''}${room.status === 'finished' && view.selfId === 'host' ? `<button class="primary-button" data-race-action="reset">再赛一场 ${icon('refresh')}</button>` : ''}<button class="text-button" data-race-action="leave">离开竞速房间</button></div>${renderRaceSummary(view)}</section>`;
}
export function renderRaceHud(view: RaceView): string {
  if (!view.room || !view.started) return '';
  const opponent = view.opponent;
  const stale = !opponent || (view.opponentAgeMs ?? 0) > 3500;
  const status = view.connection === 'reconnecting' ? '正在重连' : !opponent || opponent.leftAt != null ? '好友已离开' : opponent.finishedAt ? opponent.frame?.won ? '对手已通关' : '对手已止步' : stale ? '等待对方信号' : `第 ${(opponent.frame?.roomIndex ?? 0) + 1} / 8 境`;
  return `<span class="race-hud-emblem">${icon('users')}</span><span class="race-hud-copy"><strong>${esc(opponent?.name ?? '同行旅人')} <em>幽影</em></strong><small>${esc(status)}</small></span><time>${raceTime(view.elapsed)}</time>`;
}
export function renderRaceSummary(view: RaceView): string {
  const room = view.room;
  if (!room?.startAt || (!view.self?.finishedAt && !view.opponent?.finishedAt)) return '';
  const finishers = [room.host, room.guest].filter((p): p is RacePlayer => p !== null);
  finishers.sort((a, b) => Number(!a.frame?.won) - Number(!b.frame?.won) || (a.finishedAt ?? Infinity) - (b.finishedAt ?? Infinity));
  return `<section class="race-summary"><h4>双人竞速</h4>${finishers.map((player, index) => `<div class="race-summary-row"><span>${player.finishedAt && player.frame?.won ? index + 1 : '·'}</span><strong>${esc(player.name)}${player.id === view.selfId ? '（你）' : ''}</strong><time>${player.finishedAt ? raceTime(raceSeconds(player, room.startAt, player.finishedAt)) : '仍在远征'}</time><small>${player.finishedAt ? player.frame?.won ? '通关' : '止步' : `第 ${(player.frame?.roomIndex ?? 0) + 1} 境`}</small></div>`).join('')}</section>`;
}
