import type { CoopCharacterId } from './coop-transport';
export { COOP_CHARACTER_IDS } from './coop-transport';
import type { WeaponId } from './game/types';

interface Character {
  name: string;
  title: string;
  gender: string;
  trait: string;
  color: string;
  weapon: WeaponId;
  icon: string;
  portrait: string;
  crop: [number, number, number];
}

export const COOP_CHARACTERS: Record<CoopCharacterId, Character> = {
  blade: { name: '沈霄', title: '雾门剑客', gender: '男', trait: '近身快斩，第三刀重击', color: '#e98b79', weapon: 'blade', icon: 'blade', portrait: 'actors/coop-warrior-idle.png', crop: [61,52,39] },
  staff: { name: '陆照月', title: '观焰术士', gender: '女', trait: '法杖引焰，贯穿敌阵', color: '#eac582', weapon: 'ember', icon: 'ember', portrait: 'actors/coop-staff-idle.png', crop: [54,41,38] },
  wheel: { name: '青翎', title: '青羽扇客', gender: '女', trait: '扇风直射，第三式贯穿', color: '#91d7ba', weapon: 'fan', icon: 'fan', portrait: 'actors/coop-wheel-idle.png', crop: [73,68,51] },
  spear: { name: '闻朔', title: '玄铁枪卫', gender: '女', trait: '长枪突刺，重击破甲', color: '#a8bdef', weapon: 'spear', icon: 'spear', portrait: 'actors/coop-huntress-portrait.png', crop: [0,0,112] },
  traveller: { name: '红笠旅人', title: '游侠长刀', gender: '男', trait: '长刀横扫，第三式斩势更广', color: '#e7a6cc', weapon: 'sabre', icon: 'blade', portrait: 'actors/hero-idle.png', crop: [73,69,51] },
  monk: { name: '铜衣武僧', title: '镇岳拳', gender: '男', trait: '贴身快拳，第三拳蓄劲', color: '#e6aa76', weapon: 'fist', icon: 'fist', portrait: 'actors/coop-monk-idle.png', crop: [14,47,39] },
};
