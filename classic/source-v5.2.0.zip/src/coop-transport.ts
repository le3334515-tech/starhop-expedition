import Peer, { util, type DataConnection } from 'peerjs';
import { isCharacterId, type CharacterId, type GameConfig } from './game/types';
import { raceKey } from './race-host';
import { CoopPipe } from './coop-pipe';

export const COOP_COLORS = ['#89dbc0', '#ffb476', '#93c6ff', '#eca4d6'] as const;
export type CoopSeat = 0 | 1 | 2 | 3;
export { CHARACTER_IDS as COOP_CHARACTER_IDS } from './game/types';
export type CoopCharacterId = CharacterId;
export interface CoopPlayer {
  seat: CoopSeat; name: string; color: string; ready: boolean; connected: boolean; role: CoopCharacterId | null;
}
export interface CoopRoom {
  id: string; config: GameConfig; players: CoopPlayer[]; status: 'lobby' | 'running'; startAt: number | null;
}
export interface CoopView {
  connection: 'idle' | 'connecting' | 'online' | 'reconnecting' | 'error';
  room: CoopRoom | null; seat: CoopSeat | null; isHost: boolean; error: string | null;
}

interface Options {
  onChange?: (view: CoopView) => void;
  onStart?: (room: CoopRoom) => void;
  onGuestMessage?: (seat: CoopSeat, data: unknown) => void;
  onHostMessage?: (data: unknown) => void;
}

type GameMessage = { id: number; json: string };
type Request =
  | { action: 'join'; client: string; name: string }
  | { action: 'poll' | 'leave'; seat: CoopSeat; token: string; ready?: boolean; role?: CoopCharacterId; messages?: GameMessage[] };
type Reply = {
  ok: true; room: CoopRoom; hostTime: number; ack: number;
  seat?: CoopSeat; token?: string; snapshot?: GameMessage; actionError?: string;
};
type Fault = { ok: false; error: string; closed?: boolean };
type ServerPacket =
  | { kind: 'reply'; call: number; reply: Reply | Fault }
  | { kind: 'room'; reply: Reply }
  | { kind: 'world'; message: GameMessage }
  | { kind: 'ended' };
type ClientPacket = { kind: 'call'; call: number; request: Request };
interface Member {
  player: CoopPlayer; client: string; token: string; peer: DataConnection | null; lastSeen: number; ack: number;
}
interface Pending {
  resolve: (reply: Reply) => void; reject: (error: Error) => void;
}

const ROOM_ID = /^c4_[0-9a-f]{32}$/;
const SESSION_KEY = /^[0-9a-f]{32}$/;
const SEATS = [0, 1, 2, 3] as const;
const PEER_PREFIX = 'starhop-party-';
const PEER_LABEL = 'starhop-party-v1';
const GAME_LIMIT = 60_000;
const INPUT_LIMIT = 1_000;
const START_DELAY = 1900;
const MEMBER_GRACE = 14_000;
const pause = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
const clean = (name: unknown) => typeof name === 'string' ? Array.from(name.trim().replace(/[<>\u0000-\u001f]/g, '')).slice(0, 18).join('') || '旅人' : '旅人';
const object = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null && !Array.isArray(value);
const isSeat = (seat: unknown): seat is CoopSeat => SEATS.includes(seat as CoopSeat);
const isRole = isCharacterId;

class CoopFault extends Error {
  constructor(message: string, readonly closed = false) { super(message); }
}

function cloneRoom(room: CoopRoom): CoopRoom {
  return { ...room, config: { ...room.config }, players: room.players.map(player => ({ ...player })) };
}

function isRoom(value: unknown, id: string): value is CoopRoom {
  if (!object(value) || value.id !== id || !object(value.config) || !Array.isArray(value.players)
    || (value.status !== 'lobby' && value.status !== 'running')) return false;
  const cfg = value.config;
  if (!Number.isSafeInteger(cfg.seed) || Number(cfg.seed) < 0 || Number(cfg.seed) > 0xffffffff
    || !['standard', 'moon', 'haste', 'iron'].includes(String(cfg.modifier))
    || !['blade', 'ember', 'disc'].includes(String(cfg.weapon))) return false;
  if (value.status === 'running' ? !Number.isFinite(value.startAt) : value.startAt !== null) return false;
  const roles = value.players.flatMap(player => player && isRole(player.role) ? [player.role] : []);
  return value.players.length >= 1 && value.players.length <= 4 && value.players[0]?.seat === 0
    && value.players.every((player: unknown) => object(player) && isSeat(player.seat)
      && typeof player.name === 'string' && player.name.length <= 36
      && player.color === COOP_COLORS[player.seat] && typeof player.ready === 'boolean' && typeof player.connected === 'boolean'
      && (isRole(player.role) || player.role === null && !player.ready))
    && new Set(value.players.map(player => player.seat)).size === value.players.length
    && new Set(roles).size === roles.length;
}

function readReply(value: unknown, id: string): Reply {
  if (!object(value)) throw new Error('联机线路送回了不完整的数据。');
  if (value.ok === false) throw new CoopFault(typeof value.error === 'string' ? value.error : '房间暂不可用。', value.closed === true);
  if (value.ok !== true || !isRoom(value.room, id) || !Number.isFinite(value.hostTime) || !Number.isSafeInteger(value.ack)) {
    throw new Error('暂未收到有效的房间数据。');
  }
  return value as unknown as Reply;
}

function player(seat: CoopSeat, name: unknown): CoopPlayer {
  return { seat, name: clean(name), color: COOP_COLORS[seat], ready: false, connected: true, role: null };
}

function whenOpen(start: (finish: (error?: Error) => void) => void | (() => void), ms: number, error: string) {
  return new Promise<void>((resolve, reject) => {
    let cleanup: void | (() => void);
    const finish = (reason?: Error) => {
      clearTimeout(timer);
      cleanup?.();
      if (reason) reject(reason); else resolve();
    };
    const timer = setTimeout(() => finish(new Error(error)), ms);
    cleanup = start(finish);
  });
}

export function coopRoomFromUrl(value: string): string | null {
  const exact = value.trim();
  if (ROOM_ID.test(exact)) return exact;
  try {
    const room = new URL(exact, globalThis.location?.href ?? 'https://starhop.invalid/').searchParams.get('coop');
    return room && ROOM_ID.test(room) ? room : null;
  } catch {
    return null;
  }
}

export function coopInviteUrl(room: string, href: string): string {
  const url = new URL(href);
  url.searchParams.delete('race');
  url.searchParams.set('coop', room);
  url.hash = '';
  return url.href;
}

/** Browser-hosted four-seat room. Only the host accepts gameplay input and emits world snapshots. */
export class CoopSession {
  private model: CoopView = { connection: 'idle', room: null, seat: null, isHost: false, error: null };
  private members = new Map<CoopSeat, Member>();
  private peer: Peer | null = null;
  private uplink: DataConnection | null = null;
  private pipe: CoopPipe | null = null;
  private generation = 0;
  private roomId = '';
  private client = '';
  private name = '';
  private token = '';
  private requestedReady: { ready: boolean } | undefined;
  private requestedRole: { id: CoopCharacterId } | undefined;
  private call = 0;
  private inputId = 0;
  private worldId = 0;
  private input: GameMessage[] = [];
  private world: GameMessage | undefined;
  private pending = new Map<number, Pending>();
  private startTimer?: ReturnType<typeof setTimeout>;
  private pollTimer?: ReturnType<typeof setTimeout>;
  private memberTimer?: ReturnType<typeof setInterval>;
  private signalTimer?: ReturnType<typeof setTimeout>;
  private started = false;
  private pipeOnly = false;
  private failures = 0;

  constructor(private options: Options = {}) {}
  get view(): CoopView { return this.model; }

  private display(update: Partial<CoopView>) {
    const old = this.model;
    const next = { ...old, ...update };
    if (next.connection === old.connection && next.seat === old.seat && next.isHost === old.isHost
      && next.error === old.error && JSON.stringify(next.room) === JSON.stringify(old.room)) return;
    this.model = next;
    this.options.onChange?.(next);
  }

  private async preparePipe(generation: number) {
    if (!globalThis.crypto?.subtle) return null;
    const pipe = await CoopPipe.open(this.roomId);
    if (generation !== this.generation) { pipe.close(); return null; }
    this.pipe = pipe;
    return pipe;
  }

  private async register(id: string, generation: number) {
    if (!globalThis.RTCPeerConnection || !globalThis.WebSocket) throw new Error('当前浏览器未开放直连。');
    const peer = new Peer(id, {
      secure: true, debug: 0,
      config: { ...util.defaultConfig, iceServers: [...util.defaultConfig.iceServers, { urls: 'stun:stun.cloudflare.com:3478' }] },
    });
    this.peer = peer;
    peer.on('connection', channel => {
      if (generation === this.generation && this.model.isHost) this.acceptPeer(channel); else channel.close();
    });
    peer.on('disconnected', () => {
      clearTimeout(this.signalTimer);
      this.signalTimer = setTimeout(() => {
        if (generation === this.generation && this.peer === peer && !peer.destroyed && peer.disconnected) peer.reconnect();
      }, 1400);
    });
    await whenOpen(finish => {
      const open = () => finish(), error = () => finish(new Error('直连信令暂不可用。'));
      peer.on('open', open); peer.on('error', error); peer.on('close', error);
      return () => { peer.off('open', open); peer.off('error', error); peer.off('close', error); };
    }, 4200, '直连信令回应超时。');
    if (generation !== this.generation) throw new Error('房间已关闭。');
    return peer;
  }

  private listenPipe(pipe: CoopPipe) {
    const generation = this.generation;
    const receive = (lane: CoopSeat | null, request: unknown) => generation === this.generation
      ? this.respond(request, null, lane)
      : { ok: false, error: '房主已结束组队远征。', closed: true };
    void pipe.listen('lobby', request => receive(null, request));
    for (const seat of [1, 2, 3] as const) void pipe.listen('s' + seat, request => receive(seat, request));
  }

  async create(config: GameConfig, name: string): Promise<void> {
    this.leave();
    const generation = this.generation;
    this.roomId = 'c4_' + raceKey();
    this.name = clean(name);
    this.display({ connection: 'connecting', isHost: true, seat: 0 });
    const room: CoopRoom = { id: this.roomId, config: { ...config }, players: [player(0, this.name)], status: 'lobby', startAt: null };
    this.display({ room });
    try {
      const pipe = await this.preparePipe(generation).catch(() => null);
      if (generation !== this.generation) return;
      if (pipe) this.listenPipe(pipe);
      try { await this.register(PEER_PREFIX + this.roomId, generation); }
      catch {
        if (generation !== this.generation) return;
        this.peer?.destroy(); this.peer = null;
        if (!pipe || !await pipe.available()) throw new Error('暂时无法创建组队房，请检查网络后重试。');
      }
      if (generation !== this.generation) return;
      this.display({ connection: 'online' });
      this.memberTimer = setInterval(() => this.expireMembers(), 2400);
    } catch (error) {
      if (generation !== this.generation) return;
      this.fail(error);
      throw error;
    }
  }

  async join(id: string, name: string): Promise<void> {
    const room = coopRoomFromUrl(id);
    if (!room) throw new Error('这个组队邀请链接无效。');
    this.leave();
    const generation = this.generation;
    this.roomId = room;
    this.client = raceKey();
    this.name = clean(name);
    this.display({ connection: 'connecting' });
    try {
      await this.preparePipe(generation).catch(() => null);
      if (generation !== this.generation) return;
      await this.admit(generation);
      if (generation === this.generation) this.schedulePoll(90);
    } catch (error) {
      if (generation !== this.generation) return;
      this.fail(error);
      throw error;
    }
  }

  private async admit(generation: number) {
    const join: Request = { action: 'join', client: this.client, name: this.name };
    let reply: Reply;
    if (!this.pipeOnly) {
      try {
        const peer = this.peer?.open ? this.peer : await this.register(PEER_PREFIX + 'guest-' + raceKey(), generation);
        await this.openUplink(peer);
        reply = await this.callPeer(join);
        if (generation === this.generation) this.acceptAdmission(reply);
        return;
      } catch (error) {
        if (generation !== this.generation || error instanceof CoopFault) throw error;
        this.uplink?.close(); this.uplink = null;
        this.peer?.destroy(); this.peer = null;
        this.pipeOnly = true;
      }
    }
    if (!this.pipe) throw new Error('直连失败。请确认房主仍在游戏页面。');
    // Simultaneous invite opens may collide on discovery. Admission is
    // idempotent for the same client; later traffic uses its own seat lane.
    for (let attempt = 0; attempt < 4; attempt++) {
      try {
        reply = readReply(await this.pipe.request('lobby', join), this.roomId);
        if (generation === this.generation) this.acceptAdmission(reply);
        return;
      } catch (error) {
        if (generation !== this.generation || error instanceof CoopFault || attempt === 3) throw error;
        await pause(210 * (attempt + 1) + parseInt(this.client.slice(0, 2), 16));
      }
    }
  }

  private acceptAdmission(reply: Reply) {
    const { seat, token } = reply;
    if (!isSeat(seat) || seat === 0 || !token || !SESSION_KEY.test(token)) throw new Error('没有收到有效的队伍席位。');
    this.token = token;
    this.display({ seat });
    this.receive(reply);
  }

  private async openUplink(peer: Peer) {
    const channel = peer.connect(PEER_PREFIX + this.roomId, { label: PEER_LABEL, reliable: true, serialization: 'binary' });
    this.uplink = channel;
    channel.on('data', packet => this.receivePeer(channel, packet));
    channel.on('close', () => this.lostUplink(channel));
    channel.on('error', () => channel.close());
    await whenOpen(finish => {
      const open = () => finish();
      const lost = () => finish(new Error('未能连接到房主。'));
      const peerError = (error: Error & { type?: string }) => { if (error.type === 'peer-unavailable') lost(); };
      channel.on('open', open); channel.on('close', lost); peer.on('error', peerError);
      return () => { channel.off('open', open); channel.off('close', lost); peer.off('error', peerError); };
    }, 5200, '直连房主超时。');
  }

  private lostUplink(channel: DataConnection) {
    if (this.uplink !== channel) return;
    this.uplink = null;
    for (const waiter of this.pending.values()) waiter.reject(new Error('联机已中断。'));
    this.pending.clear();
    if (this.model.seat !== null) this.display({ connection: 'reconnecting' });
  }

  private acceptPeer(channel: DataConnection) {
    if (channel.label !== PEER_LABEL) { channel.close(); return; }
    const generation = this.generation;
    // An unauthenticated channel cannot reserve a seat.
    const timeout = setTimeout(() => {
      if (![...this.members.values()].some(member => member.peer === channel)) channel.close();
    }, 7000);
    channel.on('data', (packet: unknown) => {
      if (generation !== this.generation || !object(packet) || packet.kind !== 'call'
        || !Number.isSafeInteger(packet.call)) return;
      this.sendPeer(channel, { kind: 'reply', call: Number(packet.call), reply: this.respond(packet.request, channel, null) });
    });
    channel.on('error', () => channel.close());
    channel.on('close', () => {
      clearTimeout(timeout);
      const member = [...this.members.values()].find(entry => entry.peer === channel);
      if (!member) return;
      member.peer = null;
      member.player.connected = false;
      this.updateMembers();
    });
  }

  private sendPeer(channel: DataConnection, packet: ClientPacket | ServerPacket) {
    if (!channel.open) return;
    try { channel.send(packet); } catch { channel.close(); }
  }

  private async callPeer(request: Request): Promise<Reply> {
    const channel = this.uplink;
    if (!channel?.open) throw new Error('直连暂不可用。');
    const call = ++this.call;
    return new Promise<Reply>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(call);
        reject(new Error('房主暂时未响应。'));
      }, 4200);
      this.pending.set(call, {
        resolve: reply => { clearTimeout(timer); resolve(reply); },
        reject: error => { clearTimeout(timer); reject(error); },
      });
      this.sendPeer(channel, { kind: 'call', call, request });
    });
  }

  private receivePeer(channel: DataConnection, packet: unknown) {
    if (this.uplink !== channel || !object(packet)) return;
    if (packet.kind === 'ended') { this.fail(new CoopFault('房主已结束组队远征。', true)); return; }
    if (packet.kind === 'world' && this.model.seat !== null) { this.deliverWorld(packet.message); return; }
    if (packet.kind === 'room' && this.model.seat !== null) {
      try { this.receive(readReply(packet.reply, this.roomId)); } catch { /* A poll will refresh the room. */ }
      return;
    }
    if (packet.kind !== 'reply' || !Number.isSafeInteger(packet.call)) return;
    const pending = this.pending.get(Number(packet.call));
    if (!pending) return;
    this.pending.delete(Number(packet.call));
    try { pending.resolve(readReply(packet.reply, this.roomId)); }
    catch (error) { pending.reject(error instanceof Error ? error : new Error('联机回应无效。')); }
  }

  private respond(value: unknown, channel: DataConnection | null, lane: CoopSeat | null): Reply | Fault {
    try {
      const room = this.model.room;
      if (!room || !this.model.isHost) throw new CoopFault('房主已离开。', true);
      if (!object(value)) throw new CoopFault('房间请求无效。');
      if (value.action === 'join') {
        if (lane !== null || typeof value.client !== 'string' || !SESSION_KEY.test(value.client)) throw new CoopFault('邀请无效。');
        let member = [...this.members.values()].find(entry => entry.client === value.client);
        if (!member) {
          if (room.status !== 'lobby') throw new CoopFault('本次远征已经出发。', true);
          const seat = SEATS.find(id => id > 0 && !this.members.has(id));
          if (seat === undefined) throw new CoopFault('队伍已满，最多四名旅人。', true);
          member = { player: player(seat, value.name), client: value.client, token: raceKey(), peer: null, lastSeen: Date.now(), ack: 0 };
          this.members.set(seat, member);
        }
        const previous = member.peer;
        member.peer = channel;
        if (previous && previous !== channel) previous.close();
        member.player.connected = true;
        member.lastSeen = Date.now();
        this.updateMembers();
        return { ...this.reply(member), seat: member.player.seat, token: member.token };
      }
      if ((value.action !== 'poll' && value.action !== 'leave') || !isSeat(value.seat)) throw new CoopFault('房间请求无效。');
      const member = this.members.get(value.seat);
      if (!member || member.token !== value.token || member.peer !== channel || (channel === null && lane !== value.seat)) {
        throw new CoopFault('席位已失效，请重新进入房间。');
      }
      if (value.action === 'leave') {
        member.player.connected = false;
        member.peer = null;
        if (room.status === 'lobby') this.members.delete(member.player.seat);
        this.updateMembers();
        return this.reply(member);
      }
      member.lastSeen = Date.now();
      const statusChanged = !member.player.connected;
      member.player.connected = true;
      let selectionChanged = false, readyChanged = false, actionError: string | undefined;
      if (room.status === 'lobby') {
        if (value.role !== undefined) {
          if (!isRole(value.role)) actionError = '职业选择无效。';
          else actionError = this.roleError(member.player.seat, value.role);
          if (!actionError && value.role !== member.player.role && isRole(value.role)) {
            member.player.role = value.role;
            member.player.ready = false;
            selectionChanged = true;
          }
        }
        if (!actionError && typeof value.ready === 'boolean' && member.player.ready !== value.ready) {
          if (value.ready && (!member.player.role || selectionChanged)) actionError = '请先确认职业，再准备。';
          else { member.player.ready = value.ready; readyChanged = true; }
        }
      }
      if (selectionChanged || readyChanged || statusChanged) this.updateMembers();
      if (room.status === 'running' && this.started && Array.isArray(value.messages)) {
        for (const message of value.messages.slice(0, 32)) {
          if (!object(message) || !Number.isSafeInteger(message.id) || Number(message.id) <= member.ack
            || typeof message.json !== 'string' || message.json.length > INPUT_LIMIT) continue;
          member.ack = Number(message.id);
          try { this.options.onGuestMessage?.(member.player.seat, JSON.parse(message.json)); }
          catch { /* Malformed game messages never end a room. */ }
        }
      }
      return { ...this.reply(member, channel === null), ...(actionError ? { actionError } : {}) };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : '房间请求无效。', closed: error instanceof CoopFault && error.closed };
    }
  }

  private reply(member: Member, snapshot = false): Reply {
    return { ok: true, room: cloneRoom(this.model.room!), hostTime: Date.now(), ack: member.ack,
      ...(snapshot && this.world ? { snapshot: this.world } : {}) };
  }

  private updateMembers() {
    const room = this.model.room;
    if (!room) return;
    const oldHost = room.players.find(player => player.seat === 0)!;
    const players = [oldHost, ...[...this.members.values()].map(member => member.player)].sort((a, b) => a.seat - b.seat);
    this.display({ room: cloneRoom({ ...room, players }) });
    for (const member of this.members.values()) if (member.peer?.open) this.sendPeer(member.peer, { kind: 'room', reply: this.reply(member) });
  }

  private expireMembers() {
    const room = this.model.room;
    if (!room) return;
    let changed = false;
    const now = Date.now();
    for (const [seat, member] of this.members) {
      if (now - member.lastSeen <= MEMBER_GRACE) continue;
      if (member.player.connected) { member.player.connected = false; changed = true; }
      if (room.status === 'lobby') { this.members.delete(seat); changed = true; }
      const stalePeer = member.peer;
      member.peer = null;
      stalePeer?.close();
    }
    if (changed) this.updateMembers();
  }

  private receive(reply: Reply) {
    if (reply.ack > 0) this.input = this.input.filter(message => message.id > reply.ack);
    const error = typeof reply.actionError === 'string' ? reply.actionError : this.model.connection === 'online' ? this.model.error : null;
    this.display({ room: cloneRoom(reply.room), connection: 'online', error });
    this.tryStart(reply.hostTime);
    if (reply.snapshot) this.deliverWorld(reply.snapshot);
  }

  private deliverWorld(value: unknown) {
    if (!object(value) || !Number.isSafeInteger(value.id) || Number(value.id) <= this.worldId
      || typeof value.json !== 'string' || value.json.length > GAME_LIMIT) return;
    this.worldId = Number(value.id);
    try { this.options.onHostMessage?.(JSON.parse(value.json)); } catch { /* Ignore malformed snapshots. */ }
  }

  private schedulePoll(ms: number) {
    clearTimeout(this.pollTimer);
    this.pollTimer = setTimeout(() => void this.poll(), ms);
  }

  private async poll() {
    const generation = this.generation;
    if (this.model.isHost || this.model.seat === null) return;
    try {
      if (!this.pipeOnly && !this.uplink?.open) await this.admit(generation);
      if (generation !== this.generation) return;
      const seat = this.model.seat!;
      const role = this.requestedRole;
      const ready = this.requestedReady;
      const request: Request = {
        action: 'poll', seat, token: this.token,
        ...(role ? { role: role.id } : {}),
        ...(ready ? { ready: ready.ready } : {}),
        messages: this.input.slice(0, 32),
      };
      const reply = this.pipeOnly
        ? readReply(await this.pipe!.request('s' + seat, request), this.roomId)
        : await this.callPeer(request);
      if (generation !== this.generation) return;
      this.failures = 0;
      if (this.requestedRole === role) this.requestedRole = undefined;
      if (this.requestedReady === ready) this.requestedReady = undefined;
      this.receive(reply);
      this.schedulePoll(this.model.room?.status === 'running' ? (this.pipeOnly ? 190 : 36) : 450);
    } catch (error) {
      if (generation !== this.generation) return;
      this.failures++;
      if (error instanceof CoopFault && error.closed || this.failures >= 5) { this.fail(error); return; }
      this.display({ connection: 'reconnecting' });
      if (!this.pipeOnly) this.uplink?.close();
      if (error instanceof CoopFault && this.pipeOnly) {
        try { await this.admit(generation); } catch { /* Retry on the next poll. */ }
      }
      if (generation === this.generation) this.schedulePoll(this.pipeOnly ? 550 : 270);
    }
  }

  private roleError(seat: CoopSeat, id: CoopCharacterId): string | undefined {
    const players = this.model.room?.players;
    const other = players?.find(player => player.seat !== seat && player.role === id);
    return other ? '该职业已被 ' + other.name + ' 选择，请换一个。' : undefined;
  }

  selectRole(id: CoopCharacterId) {
    if (!isRole(id)) throw new Error('职业选择无效。');
    const { room, seat, isHost, connection } = this.model;
    if (!room || room.status !== 'lobby' || seat === null || connection !== 'online') return;
    const error = this.roleError(seat, id);
    if (error) throw new Error(error);
    const self = room.players.find(player => player.seat === seat);
    if (!self || self.role === id && !this.requestedRole) return;
    if (isHost) {
      const players = [{ ...self, role: id, ready: false }, ...room.players.slice(1)];
      this.display({ room: { ...room, players }, error: null });
      this.updateMembers();
    } else {
      this.requestedRole = { id };
      this.requestedReady = undefined;
      this.display({ error: null });
    }
  }

  setReady(ready: boolean) {
    const { room, seat, isHost, connection } = this.model;
    if (!room || room.status !== 'lobby' || seat === null || connection !== 'online') return;
    const self = room.players.find(player => player.seat === seat);
    if (ready && (!self?.role || this.requestedRole)) throw new Error('请先确认职业，再准备。');
    if (isHost) {
      if (!self || self.ready === ready) return;
      const players = [{ ...self, ready }, ...room.players.slice(1)];
      this.display({ room: { ...room, players }, error: null });
      this.updateMembers();
    } else {
      this.requestedReady = { ready };
      this.display({ error: null });
    }
  }

  start() {
    const room = this.model.room;
    if (!this.model.isHost || this.model.connection !== 'online' || !room || room.status !== 'lobby') throw new Error('只有房主可以开始远征。');
    if (room.players.some(player => !player.connected || !player.ready || !player.role)) throw new Error('请选择职业并等待全队准备。');
    const now = Date.now();
    this.display({ room: { ...room, status: 'running', startAt: now + START_DELAY } });
    this.updateMembers();
    this.tryStart(now);
  }

  private tryStart(hostTime: number) {
    const room = this.model.room;
    if (this.started || this.startTimer !== undefined || !room || room.status !== 'running' || room.startAt === null) return;
    const delay = Math.max(0, Math.min(START_DELAY, room.startAt - hostTime));
    this.startTimer = setTimeout(() => {
      this.startTimer = undefined;
      if (this.started || this.model.room?.status !== 'running') return;
      this.started = true;
      this.options.onStart?.(cloneRoom(this.model.room));
    }, delay);
  }

  send(data: unknown) {
    if (this.model.isHost || this.model.seat === null || !this.started) return;
    const json = JSON.stringify(data);
    if (typeof json !== 'string' || json.length > INPUT_LIMIT) return;
    this.input.push({ id: ++this.inputId, json });
    if (this.input.length > 128) this.input.shift();
  }

  broadcast(data: unknown) {
    if (!this.model.isHost || !this.started) return;
    const json = JSON.stringify(data);
    if (typeof json !== 'string' || json.length > GAME_LIMIT) return;
    const message = { id: ++this.worldId, json };
    this.world = message;
    for (const member of this.members.values()) if (member.peer?.open) this.sendPeer(member.peer, { kind: 'world', message });
  }

  private fail(error: unknown) {
    const text = error instanceof Error ? error.message : '组队线路暂不可用。';
    this.leave();
    this.display({ connection: 'error', error: text });
  }

  leave() {
    const hosting = this.model.isHost && this.model.connection === 'online';
    const directGuest = !this.model.isHost && this.model.seat !== null && this.uplink?.open;
    if (this.model.isHost) {
      for (const member of this.members.values()) if (member.peer?.open) this.sendPeer(member.peer, { kind: 'ended' });
    } else if (this.model.seat !== null && this.token) {
      const request: Request = { action: 'leave', seat: this.model.seat, token: this.token };
      if (this.uplink?.open) this.sendPeer(this.uplink, { kind: 'call', call: ++this.call, request });
      else if (this.pipeOnly && this.pipe) {
        // The departure is explicit if the relay is reachable. The host's
        // inactivity deadline removes the seat if the browser closes sooner.
        const pipe = this.pipe;
        this.pipe = null;
        void pipe.request('s' + this.model.seat, request).catch(() => {}).finally(() => pipe.close());
      }
    }
    this.generation++;
    clearTimeout(this.startTimer); this.startTimer = undefined;
    clearTimeout(this.pollTimer); this.pollTimer = undefined;
    clearTimeout(this.signalTimer); this.signalTimer = undefined;
    clearInterval(this.memberTimer); this.memberTimer = undefined;
    for (const pending of this.pending.values()) pending.reject(new Error('已离开组队。'));
    this.pending.clear();
    const peer = this.peer;
    this.peer = null;
    this.uplink = null;
    this.members.clear();
    const pipe = this.pipe;
    this.pipe = null;
    // Let explicit departures reach the remaining seats before closing the connection.
    if (hosting || directGuest) setTimeout(() => peer?.destroy(), 80);
    else peer?.destroy();
    if (hosting) setTimeout(() => pipe?.close(), 700);
    else pipe?.close();
    this.client = this.token = this.roomId = '';
    this.requestedReady = undefined;
    this.requestedRole = undefined;
    this.input = []; this.world = undefined; this.inputId = this.worldId = 0;
    this.started = this.pipeOnly = false; this.failures = 0;
    this.display({ connection: 'idle', room: null, seat: null, isHost: false, error: null });
  }
}
