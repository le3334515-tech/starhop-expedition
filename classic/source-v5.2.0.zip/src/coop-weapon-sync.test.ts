import { describe, expect, it } from 'vitest';
import { CoopPlay } from './coop-play';
import type { CoopRoom, CoopSeat, CoopSession, CoopView } from './coop-transport';
import { GameEngine } from './game/engine';
import { EMPTY_INPUT } from './game/types';

function party() {
  const room: CoopRoom = {
    id: 'weapon-room',
    config: { seed:42,modifier:'standard',weapon:'blade' },
    status: 'running',
    startAt: 0,
    players: [
      { seat:0,name:'房主',color:'#fff',ready:true,connected:true,role:'blade' },
      { seat:1,name:'客人',color:'#ffe',ready:true,connected:true,role:'staff' },
    ],
  };
  const session = (seat: CoopSeat, send: (data:unknown)=>void, broadcast: (data:unknown)=>void) => {
    const view: CoopView = { connection:'online',room,seat,isHost:seat===0,error:null };
    return { view,send,broadcast } as CoopSession;
  };
  const hostEngine = new GameEngine(), guestEngine = new GameEngine();
  let world: unknown;
  let input: unknown;
  const ignore = () => {};
  const host = new CoopPlay(session(0,ignore,data => { world = data; }),hostEngine,room);
  const guest = new CoopPlay(session(1,data => { input = data; },ignore),guestEngine,room);
  host.tick(.2,EMPTY_INPUT);
  host.tick(.09,EMPTY_INPUT);
  return {
    host,guest,hostEngine,guestEngine,get world() { return world; },
    nextInput() { guest.tick(.05,EMPTY_INPUT); return input as { kind:'input'; seq:number; bits:number; room:number; weapon?:string }; },
    nextWorld() { host.tick(.09,EMPTY_INPUT); return world; },
  };
}

describe('co-op weapon authority', () => {
  it('updates only the requesting seat and rejects a different character’s weapons', () => {
    const p = party();
    expect(p.guestEngine.state.hero.weapon).toBe('ember');
    p.guest.equipWeapon('halberd');
    expect(p.nextInput().weapon).toBeUndefined();

    p.guest.equipWeapon('moonMirror');
    const first = p.nextInput();
    p.host.acceptInput(1,{ ...first,weapon:'halberd' });
    p.guest.acceptWorld(p.nextWorld());
    expect(p.guestEngine.state.hero.weapon).toBe('ember');

    p.host.acceptInput(1,p.nextInput());
    p.host.equipWeapon('willowSword');
    p.guest.acceptWorld(p.nextWorld());
    expect(p.guestEngine.state.hero.weapon).toBe('moonMirror');
    expect(p.hostEngine.state.hero.weapon).toBe('willowSword');
    expect(p.nextInput().weapon).toBeUndefined();
  });

  it('keeps the latest requested weapon until the host acknowledges that request', () => {
    const p = party();
    const originalWorld = p.world;
    p.guest.equipWeapon('frostStaff');
    p.host.acceptInput(1,p.nextInput());
    const swappedWorld = p.nextWorld();

    p.guest.equipWeapon('ember');
    p.guest.acceptWorld(originalWorld);
    const latest = p.nextInput();
    expect(latest.weapon).toBe('ember');
    p.guest.acceptWorld(swappedWorld);
    expect(p.nextInput().weapon).toBe('ember');
    p.host.acceptInput(1,latest);
    p.guest.acceptWorld(p.nextWorld());
    expect(p.guestEngine.state.hero.weapon).toBe('ember');
    expect(p.nextInput().weapon).toBeUndefined();
  });

  it('replicates separate upgrade selections for each traveller', () => {
    const p = party();
    p.hostEngine.state.enemies.forEach(enemy => { enemy.dead = true; });
    p.guest.acceptWorld(p.nextWorld());
    const roomHost = p.hostEngine.state, roomGuest = p.guestEngine.state;
    const first = roomHost.upgradeChoices[0]?.id;
    const second = roomGuest.upgradeChoices.find(upgrade => upgrade.id !== first)?.id;
    expect(first && second).toBeTruthy();

    p.host.chooseUpgrade(first!);
    p.guest.acceptWorld(p.nextWorld());
    expect(roomGuest.phase).toBe('upgrade');
    expect(roomGuest.hero.upgrades).toEqual([]);
    p.guest.chooseUpgrade(second!);
    p.host.acceptInput(1,p.nextInput());
    p.guest.acceptWorld(p.nextWorld());
    expect(roomHost.hero.upgrades).toEqual([first]);
    expect(roomGuest.hero.upgrades).toEqual([second]);
    expect(p.guest.party().map(player => player.hero.upgrades)).toEqual([[first],[second]]);
  });
});
