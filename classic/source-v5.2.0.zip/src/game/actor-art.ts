import { artImage } from './art-assets';
import { WEAPONS, weaponTier, type Boss, type Enemy, type Hero } from './types';
import { drawBurningEnemy } from './combat-vfx';
import { guardianMantle } from './guardian-regalia';
import { ascensionProgress, BOSS_ASCENSION_IMPACT, BOSS_ASCENSION_TIME, ease, ECLIPSE_WINDUP, openingAscension, openingSeal, sealProgress } from './boss-seal';
import { drawRegionalEnemy } from './enemy-art';
import { drawRangedArms, rangedWeaponPose, weaponlessHeroSheet } from './hero-weapon-pose';
import { drawWardenArt } from './warden-art';
import { drawHeldVariant, isVariantWeapon } from './weapon-visuals';

/** Animated CC0 pixel art by LuizMelo. Source and licenses live in docs. */
type Sheet = { file: string; frames: number; size: number; anchorX: number; anchorY: number };
const sheet = (file: string, frames: number, size = 200, anchorX = 100, anchorY = 122): Sheet =>
  ({ file: `actors/${file}.png`, frames, size, anchorX, anchorY });
const HERO = {
  idle: sheet('hero-idle', 8), run: sheet('hero-run', 8),
  jump: sheet('hero-jump', 2), fall: sheet('hero-fall', 2),
  attack1: sheet('hero-attack1', 6), attack2: sheet('hero-attack2', 6),
  hurt: sheet('hero-hurt', 4), death: sheet('hero-death', 6),
};
const monster = (name: string, action: string, frames: number) => sheet(`${name}-${action}`, frames, 150, 75, 101);
const ENEMY = {
  slime: { idle: monster('mushroom', 'idle', 4), move: monster('mushroom', 'run', 8), attack: monster('mushroom', 'attack', 8), hurt: monster('mushroom', 'hurt', 4) },
  bat: { idle: monster('eye', 'flight', 8), move: monster('eye', 'flight', 8), attack: monster('eye', 'attack', 8), hurt: monster('eye', 'hurt', 4) },
  sentry: { idle: monster('skeleton', 'idle', 4), move: monster('skeleton', 'walk', 4), attack: monster('skeleton', 'attack', 8), hurt: monster('skeleton', 'hurt', 4) },
};
const wizard = (action: string, frames: number) => sheet(`boss-${action}`, frames, 250, 130, 167);
const BOSS = {
  idle: wizard('idle', 8), run: wizard('run', 8), attack1: wizard('attack1', 8),
  attack2: wizard('attack2', 8), jump: wizard('jump', 2), fall: wizard('fall', 2),
  hurt: wizard('hurt', 3), death: wizard('death', 7),
};
const TAU = Math.PI * 2;
const heroDeaths = new WeakMap<Hero, number>();
const bossDeaths = new WeakMap<Boss, number>();
const clamp = (value: number, min = 0, max = 1) => Math.max(min, Math.min(max, value));
const frameAt = (s: Sheet, progress: number) => Math.min(s.frames - 1, Math.floor(clamp(progress) * s.frames));

function sprite(c: CanvasRenderingContext2D, s: Sheet, frame: number, scale: number, rangedBody = false): boolean {
  const original = artImage(s.file);
  if (!original) return false;
  const image = rangedBody ? weaponlessHeroSheet(original) : original;
  c.imageSmoothingEnabled = false;
  c.drawImage(image, Math.floor(frame) % s.frames * s.size, 0, s.size, s.size,
    -s.anchorX * scale, -s.anchorY * scale, s.size * scale, s.size * scale);
  return true;
}

function shadow(c: CanvasRenderingContext2D, x: number, y: number, radius: number, opacity: number) {
  c.save(); c.globalAlpha *= opacity; c.fillStyle = '#07171e';
  c.beginPath(); c.ellipse(x, y + 2, radius, 3.2, 0, 0, TAU); c.fill(); c.restore();
}

function ring(c: CanvasRenderingContext2D, radius: number, color: string, now: number, alpha: number) {
  c.save(); c.strokeStyle = color; c.lineWidth = 1.5; c.globalAlpha *= alpha;
  c.beginPath(); c.arc(0, -25, radius, now * .6, now * .6 + 4.8); c.stroke();
  for (let i = 0; i < 3; i++) {
    const angle = now * -.8 + i * TAU / 3;
    c.fillStyle = color; c.fillRect(Math.cos(angle) * radius - 1, -25 + Math.sin(angle) * radius - 1, 3, 3);
  }
  c.restore();
}

function bladeMotionTime(h: Hero): number {
  if (WEAPONS[h.weapon].archetype === 'sabre') return h.attackStep === 3 ? .34 : .24;
  return h.attackStep === 3 ? .28 : .18;
}

function drawFoldingFan(c: CanvasRenderingContext2D, h: Hero, hand: {x:number;y:number}, tier: number) {
  const active = h.attackTimer > 0;
  const heavy = h.attackStep === 3;
  const progress = active ? clamp(1-h.attackTimer/(heavy ? .28 : .20)) : 0;
  const flare = active ? Math.sin(Math.PI*(.17+.73*progress)) : 0;
  const spread = .65 + flare*.72;
  const reach = 17 + tier*2 + (heavy && active ? 3 : 0);
  const ribs = 8;
  c.save();
  c.translate(Math.round(hand.x), Math.round(hand.y));
  c.rotate(active ? -.98 + progress*1.25 : -.64);
  for (let n=0;n<ribs;n++) {
    const from = -spread+2*spread*n/ribs, to = -spread+2*spread*(n+1)/ribs;
    c.fillStyle = n%2===0 ? '#8ab8a1' : '#547f76';
    c.beginPath(); c.moveTo(0,0);
    c.lineTo(reach*Math.cos(from),reach*Math.sin(from));
    c.lineTo(reach*Math.cos(to),reach*Math.sin(to)); c.closePath(); c.fill();
    c.strokeStyle = n===0 || n===ribs-1 ? '#e6c58c' : '#3f645d';
    c.lineWidth = 1; c.stroke();
  }
  c.strokeStyle = '#d7e6c9'; c.lineWidth = 1.4;
  c.beginPath(); c.arc(0,0,reach,-spread,spread); c.stroke();
  c.fillStyle = '#e4ba75'; c.fillRect(-2,-1,4,3);
  c.restore();
}

function heroWeapon(c: CanvasRenderingContext2D, h: Hero, now: number, awakened: boolean) {
  if (h.hp <= 0) return;
  const attacking = h.attackTimer > 0;
  const tier = weaponTier(h);
  const pose = rangedWeaponPose(h, now);
  const {archetype, color, tuning} = WEAPONS[h.weapon];
  const variant = isVariantWeapon(h.weapon);
  if (variant) {
    drawHeldVariant(c,h,pose.hand,pose.attackProgress);
    if (archetype !== 'blade' && archetype !== 'sabre') return;
  }
  if (archetype === 'fan') { drawFoldingFan(c,h,pose.hand,tier); return; }
  if (archetype === 'blade' || archetype === 'sabre') {
    if (tier >= 2) {
      c.fillStyle = '#ddbb7d'; c.fillRect(8, -29, 5, 2);
      if (tier >= 3) { c.fillRect(10, -34, 3, 2); c.fillRect(12, -23, 4, 2); }
    }
    if (!attacking) return;
    const heavy = h.attackStep === 3;
    const sabre = archetype === 'sabre';
    const progress = clamp(1 - h.attackTimer / bladeMotionTime(h));
    const reverse = h.attackStep === 2;
    const end = reverse ? 1.55 - progress * 3.2 : -1.55 + progress * 3.2;
    const radius = ((heavy ? 67 : 48) + (tier - 1) * 7 + (sabre ? 17 : 0)) * (tuning?.reach ?? 1);
    c.save(); c.translate(8, -25); c.globalAlpha *= Math.sin(progress * Math.PI) * .75;
    c.strokeStyle = variant ? color : heavy ? '#ffcf91' : sabre ? '#d1b9d4' : awakened ? '#8cffff' : tier >= 3 ? '#e9d8a3' : '#b5f0db';
    c.lineWidth = heavy ? 10 : 6;
    c.beginPath(); c.arc(0, 0, radius, end + (reverse ? 1.1 : -1.1), end, reverse); c.stroke();
    c.strokeStyle = '#fff2d5'; c.lineWidth = 1.5;
    c.beginPath(); c.arc(0, 0, radius + 3, end + (reverse ? .7 : -.7), end, reverse); c.stroke();
    c.restore();
  } else if (archetype === 'ember') {
    const charged = attacking && h.attackStep === 3;
    const flash = attacking ? Math.max(0, 1 - pose.attackProgress / .28) : 0;
    c.save(); c.translate(Math.round(pose.staffGrip.x), Math.round(pose.staffGrip.y)); c.rotate(pose.staffAngle);
    // A slender staff stays clear of the face, with a small bronze crescent.
    c.fillStyle = '#382d35'; c.fillRect(-2, -22, 4, 32);
    c.fillStyle = '#a98559'; c.fillRect(-1, -21, 2, 30);
    c.fillStyle = '#e2c58b'; c.fillRect(0, -20, 1, 27);
    c.fillStyle = '#73533c'; c.fillRect(-2, -7, 4, 3); c.fillRect(-2, 4, 4, 2);
    c.strokeStyle = tier >= 2 ? '#e0bd7a' : '#b7d0b7'; c.lineWidth = 1.5;
    c.beginPath(); c.arc(0, -23, tier >= 2 ? 6 : 5, .25, 5.3); c.stroke();
    if (tier >= 2) { c.fillStyle = '#b86b4a'; c.fillRect(-6, -27, 2, 7); c.fillRect(5, -27, 2, 7); }
    c.fillStyle = charged ? '#fff0bd' : '#ebbd75';
    c.beginPath(); c.moveTo(0, -29); c.lineTo(3, -23); c.lineTo(0, -18); c.lineTo(-3, -23); c.closePath(); c.fill();
    c.fillStyle = '#fff0bd'; c.fillRect(0, -25, 1, 4);
    if (tier >= 3) { c.fillStyle = '#e6bb7e'; c.fillRect(-3,-13,6,1); c.fillRect(-2,-11,4,1); }
    if (flash > 0) {
      c.globalAlpha *= flash;
      c.strokeStyle = charged ? '#fff0b6' : '#e5bd80'; c.lineWidth = charged ? 2 : 1;
      c.beginPath(); c.moveTo(-5,-24); c.lineTo(5,-24); c.moveTo(0,-29); c.lineTo(0,-18); c.stroke();
    }
    c.restore();
    if (flash > 0) {
      const tipX=pose.staffGrip.x + Math.sin(pose.staffAngle)*23;
      const tipY=pose.staffGrip.y - Math.cos(pose.staffAngle)*23;
      c.save(); c.globalAlpha *= flash; c.strokeStyle = charged ? '#fff0b6' : '#edd0a0'; c.lineWidth = charged ? 2 : 1;
      c.beginPath(); c.moveTo(tipX+3,tipY); c.lineTo(tipX+15,tipY); c.moveTo(tipX+6,tipY-3); c.lineTo(tipX+11,tipY-3); c.stroke();
      c.fillStyle='#ffe3a6'; c.fillRect(Math.round(tipX+17),Math.round(tipY)-1,2,2); c.restore();
    }
  } else {
    const reappear=attacking ? Math.max(0,Math.min(1,(pose.attackProgress-.64)/.24)) : 1;
    for (let wheel = (tier >= 2 ? 2 : 1); wheel >= 0; wheel--) {
      if (reappear <= 0) continue;
      // The spare wheels sit by the belt, never over the face or hat.
      const x=wheel===0?pose.hand.x+3:wheel===1?-11:-15;
      const y=wheel===0?pose.hand.y:wheel===1?-14:-9;
      c.save(); c.translate(Math.round(x),Math.round(y));
      c.globalAlpha *= reappear*(wheel===0?1:wheel===1?.7:.45);
      c.rotate(now*1.6*(wheel%2?-1:1));
      c.strokeStyle=tier>=3?'#a6d2bd':'#bcb8cd'; c.lineWidth=2;
      c.beginPath(); c.arc(0,0,5.5,0,TAU); c.stroke();
      c.strokeStyle='#e8dcc1'; c.lineWidth=1; c.beginPath(); c.arc(0,0,7,0,TAU); c.stroke();
      c.fillStyle='#bea16f';
      for (let i=0;i<3;i++) {c.rotate(TAU/3);c.beginPath();c.moveTo(5,-2);c.lineTo(9,0);c.lineTo(5,2);c.closePath();c.fill();}
      c.restore();
    }
    if (attacking && pose.attackProgress < .3) {
      c.save(); c.globalAlpha *= (1-pose.attackProgress/.3)*.68;
      c.strokeStyle=tier>=3?'#b4d9c7':'#d0c4da';c.lineWidth=1;
      c.beginPath();c.moveTo(pose.hand.x-4,pose.hand.y+2);c.lineTo(pose.hand.x+10,pose.hand.y-2);c.stroke();
      c.fillStyle='#ebe0c9';c.fillRect(Math.round(pose.hand.x+12),Math.round(pose.hand.y-2),2,1);c.restore();
    }
  }
}

export function drawArtHero(c: CanvasRenderingContext2D, h: Hero, now: number, menuScale = 1, awakened = false, costume: 'classic' | 'jade' = 'classic'): boolean {
  if (h.hp > 0) heroDeaths.delete(h);
  const running = Math.abs(h.vx) > 15 && h.grounded;
  const attacking = h.attackTimer > 0;
  const { archetype } = WEAPONS[h.weapon];
  const ranged = archetype === 'ember' || archetype === 'disc' || archetype === 'fan';
  const weaponless = ranged || isVariantWeapon(h.weapon);
  let s: Sheet = HERO.idle;
  let frame = Math.floor((h.animation || now) * 8) % 8;
  if (h.hp <= 0) {
    if (!heroDeaths.has(h)) heroDeaths.set(h, now);
    s = HERO.death; frame = Math.min(s.frames - 1, Math.floor((now - heroDeaths.get(h)!) * 11));
  } else if (h.invincible > 1.07 && h.invincible <= 1.31 && Math.abs(h.vx) > 160 && h.dashTimer <= 0) {
    s = HERO.hurt; frame = frameAt(s, (1.3 - h.invincible) / .23);
  }
  else if (attacking && !weaponless) {
    s = h.attackStep === 2 ? HERO.attack2 : HERO.attack1;
    const duration = bladeMotionTime(h);
    const progress = clamp(1 - h.attackTimer / duration);
    frame = frameAt(s, progress);
  } else if (h.dashTimer > 0) { s = HERO.run; frame = Math.floor((.18 - h.dashTimer) * 40) % 8; }
  else if (!h.grounded) { s = h.vy < 0 ? HERO.jump : HERO.fall; frame = Math.abs(h.vy) > 180 ? 0 : 1; }
  else if (running) { s = HERO.run; frame = Math.floor(h.animation * 13) % 8; }
  const jadeCostume = costume === 'jade';
  if (jadeCostume) {
    const replacement = s.file.replace('actors/hero-', 'actors/coop-wheel-');
    if (artImage(replacement)) s = { ...s, file:replacement };
    // Hold the kneeling pose with her face visible while she can be revived.
    if (h.hp <= 0) frame = 3;
  }
  if (!artImage(s.file)) return false;
  const center = Math.round(h.x + h.w / 2), foot = Math.round(h.y + h.h);
  const bodyScale = menuScale * (jadeCostume ? 1.135 : 1);
  shadow(c, center, foot, (h.grounded ? 17 : 12) * bodyScale, .26);
  c.save(); c.translate(center, foot); c.scale((h.facing || 1) * bodyScale, bodyScale);
  const pose = rangedWeaponPose(h, now);
  if (weaponless && attacking && s !== HERO.hurt && h.hp > 0) c.transform(1, 0, pose.lean, 1, 0, 0);
  const scale = .98;
  if (h.dashTimer > 0) {
    for (let i = 3; i > 0; i--) {
      c.save(); c.translate(-i * 12, 0); c.globalAlpha *= (4 - i) * .07;
      c.filter = 'brightness(1.7) sepia(.7) hue-rotate(100deg)'; sprite(c, s, frame, scale, weaponless); c.restore();
    }
  }
  if (awakened) {
    c.save(); c.globalAlpha *= .36; c.filter = 'brightness(1.6) drop-shadow(0 0 6px #84f5e7)';
    sprite(c, s, frame, scale * 1.035, weaponless); c.restore(); ring(c, 32, '#baffea', now, .6);
  }
  if (h.invincible > 0) {
    if (h.invincible > .95) c.filter = 'brightness(2.2) saturate(.3)';
    else c.globalAlpha *= Math.sin(now * 42) > .2 ? .56 : 1;
  }
  sprite(c, s, frame, scale, weaponless);
  c.filter = 'none';
  if (weaponless) drawRangedArms(c, h, pose);
  heroWeapon(c, h, now, awakened);
  if (h.shield > 0) ring(c, 29, '#d3daff', now, .52 + Math.sin(now * 3) * .1);
  if (h.swapBoost > 0 || h.counterTimer > 0) ring(c, 25, h.counterTimer > 0 ? '#ffda91' : '#cbbcff', now * 2, .7);
  c.restore(); return true;
}

export function drawArtEnemy(c: CanvasRenderingContext2D, e: Enemy, now: number): boolean {
  if (drawRegionalEnemy(c, e, now)) { drawBurningEnemy(c, e, now); return true; }
  const art = ENEMY[e.kind];
  const moving = Math.abs(e.vx) > 10;
  let s = moving ? art.move : art.idle;
  let frame = Math.floor(e.timer * (moving ? 10 : 7) + e.id) % s.frames;
  if (e.hurt > 0) { s = art.hurt; frame = frameAt(s, 1 - e.hurt / .18); }
  else if (e.kind === 'sentry' && e.attackCooldown > 2.05) {
    s = art.attack; frame = frameAt(s, (2.45 - e.attackCooldown) / .4);
  } else if (e.kind === 'slime' && e.attackCooldown > 1.35) {
    s = art.attack; frame = frameAt(s, (1.7 - e.attackCooldown) / .35);
  }
  if (!artImage(s.file)) return false;
  const x = Math.round(e.x + e.w / 2), foot = Math.round(e.y + e.h);
  if (e.kind !== 'bat') shadow(c, x, foot, e.w * .46, .23);
  c.save(); c.translate(x, foot); c.scale(e.facing || 1, 1);
  const scale = e.kind === 'slime' ? e.h / 34 : e.kind === 'sentry' ? e.h / 47 : e.h / 29;
  if (e.kind === 'bat') c.translate(0, 8 * scale);
  if (e.hurt > .065) c.filter = 'brightness(3.5) saturate(.2)';
  sprite(c, s, frame, scale);
  c.restore();
  drawBurningEnemy(c, e, now);
  return true;
}

export function drawArtBoss(c: CanvasRenderingContext2D, b: Boss, now: number): boolean {
  if (b.kind === 'warden') return drawWardenArt(c, b, now);
  if (b.mode !== 'dead') bossDeaths.delete(b);
  let s = BOSS.idle;
  let frame = Math.floor(now * 7) % 8;
  if (b.mode === 'charge') { s = BOSS.run; frame = Math.floor((.55 - b.timer) * 19) % 8; }
  else if (b.mode === 'windup') {
    s = ['barrage', 'rift', 'rain', 'eclipse'].includes(b.intent) ? BOSS.attack2 : BOSS.attack1;
    const duration = b.intent === 'eclipse' ? ECLIPSE_WINDUP : .82 - (b.phase - 1) * .17;
    frame = Math.min(3, frameAt(s, (1 - b.timer / duration) * .52));
  } else if (b.mode === 'barrage') { s = BOSS.attack2; frame = 4 + Math.floor((.38 - Math.max(0, b.timer)) * 10) % 4; }
  else if (b.mode === 'slam') { s = BOSS.attack1; frame = 4 + frameAt({ ...s, frames: 4 }, 1 - b.timer / .12); }
  else if (b.mode === 'jump') { s = b.vy < 0 ? BOSS.jump : BOSS.fall; frame = Math.abs(b.vy) > 200 ? 0 : 1; }
  else if (b.mode === 'recover') {
    s = b.intent === 'barrage' ? BOSS.attack2 : BOSS.attack1;
    const duration = b.intent === 'barrage' ? 1.1 : b.intent === 'charge' ? 1.05 - (b.phase - 1) * .12 : 1.15 - (b.phase - 1) * .12;
    const elapsed = Math.max(0, duration - b.timer);
    if (elapsed < .3) frame = 5 + Math.min(2, Math.floor(elapsed * 10));
    else { s = BOSS.idle; frame = Math.floor(now * 6) % 8; }
  } else if (b.mode === 'stagger' || b.hurt > .07) { s = BOSS.hurt; frame = b.mode === 'stagger' ? 1 : frameAt(s, 1 - b.hurt / .18); }
  else if (b.mode === 'dead') {
    if (!bossDeaths.has(b)) bossDeaths.set(b, now);
    s = BOSS.death; frame = Math.min(s.frames - 1, Math.floor((now - bossDeaths.get(b)!) * 10));
  }
  const dark = b.form === 2, transforming = openingSeal(b);
  const ascended = dark && b.phase === 3, ascending = openingAscension(b);
  const ascent = ascending ? ascensionProgress(b) : Number(ascended);
  const ascensionImpact = BOSS_ASCENSION_IMPACT / BOSS_ASCENSION_TIME;
  const transformation = transforming ? sealProgress(b) : 1;
  if (transforming) {
    const p = transformation;
    if (p < .30) { s=BOSS.attack1; frame=Math.min(2,Math.floor(p*10)); }
    else if (p < .64) { s=BOSS.attack2; frame=Math.min(3,Math.floor((p-.30)*12)); }
    else if (p < .81) { s=BOSS.attack2; frame=Math.min(7,4+Math.floor((p-.64)*24)); }
    else { s=BOSS.idle; frame=Math.floor((p-.81)*24)%8; }
  }
  if (ascending) {
    if (ascent < .25) { s = BOSS.hurt; frame = Math.min(2, Math.floor(ascent * 12)); }
    else if (ascent < ascensionImpact) { s = BOSS.attack2; frame = Math.min(3, Math.floor((ascent - .25) * 10)); }
    else if (ascent < .82) { s = BOSS.attack2; frame = Math.min(7, 4 + Math.floor((ascent - ascensionImpact) * 20)); }
    else { s = BOSS.idle; frame = Math.floor((ascent - .82) * 26) % 8; }
  }
  if (!artImage(s.file)) return false;
  const color = dark ? '#d6958a' : '#dcb087';
  c.save(); c.translate(Math.round(b.x + b.w / 2), Math.round(b.y + b.h)); c.scale(b.facing || -1, 1);
  const scale = b.h / 91 * (dark ? 1 + ease(.35,.77,transformation)*.24 + .08 * ease(.48,.76,ascent) : 1);
  if (transforming) {
    const lift=ease(.22,.54,transformation)*(1-ease(.62,.70,transformation));
    const landing=ease(.62,.70,transformation)*(1-ease(.70,.85,transformation));
    c.translate(0,Math.round(-26*lift)); c.scale(1+.06*landing,1-.10*landing);
  }
  if (ascending) {
    const lift = ease(.15,.54,ascent) * (1 - ease(.60,.72,ascent));
    const crouch = ease(0,.13,ascent) * (1 - ease(.18,.28,ascent));
    const landing = ease(.63,.71,ascent) * (1 - ease(.73,.86,ascent));
    c.translate(0, Math.round(9 * crouch - 44 * lift));
    c.scale(1 + .08 * landing, 1 - .12 * landing);
  }
  if (dark) guardianMantle(c,b,s.file,frame,now,scale,false);
  if (!dark && (b.mode === 'windup' || b.mode === 'transition')) {
    c.save(); c.strokeStyle = color; c.lineWidth = 1; c.globalAlpha *= b.mode === 'windup' ? .6 : .3;
    const radius = b.w * .59;
    c.beginPath(); c.arc(2, -b.h * .52, radius, now * .25, now * .25 + 5.2); c.stroke();
    for (let i = 0; i < 5; i++) { const a = now * .25 + i * TAU / 5; c.fillStyle = color; c.fillRect(Math.cos(a) * radius, -b.h * .52 + Math.sin(a) * radius, 2, 4); }
    c.restore();
  }
  if (dark && b.mode === 'charge') {
    for (let echo = 3; echo > 0; echo--) {
      c.save(); c.translate(-echo * 15, 0); c.globalAlpha *= (4 - echo) * .075;
      c.filter = 'brightness(.15) saturate(.1)'; c.scale(1.28, 1); sprite(c, s, frame, scale); c.restore();
    }
  }
  if (b.hurt > .065) c.filter = dark ? 'brightness(1.5) sepia(.6) saturate(.7)' : 'brightness(3) saturate(.2)';
  else if (dark) {
    c.filter = `brightness(${1 - transformation * .12}) saturate(${1 - transformation * .10})`;
  }
  c.save(); c.scale(1.28, 1); sprite(c, s, frame, scale); c.restore();
  c.filter='none'; c.shadowBlur=0;
  if (dark) guardianMantle(c,b,s.file,frame,now,scale,true);
  c.restore(); return true;
}
