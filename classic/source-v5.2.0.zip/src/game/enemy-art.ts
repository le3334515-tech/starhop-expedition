import { artImage } from './art-assets';
import type { Enemy } from './types';
import { enemyProfile } from './enemy-catalog';

const TAU = Math.PI * 2;
const pixel = (c: CanvasRenderingContext2D, x: number, y: number, w = 2, h = w) => c.fillRect(Math.round(x), Math.round(y), w, h);
const BODY = {
  mushroom: { size: 150, anchorX: 75, anchorY: 101, bodyHeight: 37 },
  eye: { size: 150, anchorX: 75, anchorY: 101, bodyHeight: 29 },
  skeleton: { size: 150, anchorX: 75, anchorY: 101, bodyHeight: 51 },
  goblin: { size: 150, anchorX: 75, anchorY: 101, bodyHeight: 36 },
  wizard: { size: 150, anchorX: 75, anchorY: 100, bodyHeight: 55 },
  duelist: { size: 200, anchorX: 100, anchorY: 128, bodyHeight: 56 },
} as const;

/** Intent warnings are world-space and readable without relying on hue alone. */
export function drawEnemyTelegraph(c: CanvasRenderingContext2D, e: Enemy, now: number): void {
  const profile = enemyProfile(e); if (!profile || e.dead || e.aiMode !== 'windup') return;
  const x = e.x + e.w / 2, foot = e.y + e.h, direction = e.facing || 1;
  const progress = 1 - Math.min(1, (e.aiTimer ?? 0) / profile.warning);
  c.save(); c.globalAlpha *= .65 + progress * .3;
  c.strokeStyle = profile.color; c.fillStyle = profile.color; c.lineWidth = 1.5;
  const ring = e.kind === 'bat' ? 21 : 16;
  c.beginPath(); c.arc(x, e.y - 8, 7, -Math.PI / 2, -Math.PI / 2 + TAU * progress); c.stroke();
  // Melee and dive tell the attack direction; ranged enemies show a cast seal.
  if (['rush', 'blink', 'leap', 'guard', 'dive'].includes(profile.ability)) {
    const y = e.kind === 'bat' ? foot - 12 : foot - 3;
    c.beginPath(); c.moveTo(x + direction * 24, y); c.lineTo(x + direction * (46 + progress * 26), y);
    c.lineTo(x + direction * (37 + progress * 26), y - 6); c.moveTo(x + direction * (46 + progress * 26), y); c.lineTo(x + direction * (37 + progress * 26), y + 6); c.stroke();
    c.fillStyle = '#f3dfba'; pixel(c, x + direction * 19, y - 1, 3, 3);
  } else {
    c.save(); c.translate(x, foot - e.h * .45); c.rotate(now * .65);
    c.strokeRect(-ring, -ring, ring * 2, ring * 2); c.rotate(Math.PI / 4); c.strokeRect(-ring * .7, -ring * .7, ring * 1.4, ring * 1.4); c.restore();
    if ((profile.ability === 'rift' || profile.ability === 'starfall') && e.targetX !== undefined) {
      c.globalAlpha *= .7; c.strokeStyle = profile.color;
      if (profile.ability === 'starfall') { for (let n = 0; n < 4; n++) pixel(c, e.targetX - 1, 340 + n * 21, 2, 6); }
      c.beginPath(); c.ellipse(e.targetX, 444, 24 + progress * 6, 6, 0, 0, TAU); c.stroke();
      for (const side of [-1, 1]) pixel(c, e.targetX + side * 27, 435 - progress * 14, 2, 6);
    }
  }
  c.restore();
}

/** Newly sourced CC0 sheets share the original LuizMelo pixel-art family. */
export function drawRegionalEnemy(c: CanvasRenderingContext2D, e: Enemy, now: number): boolean {
  const profile = enemyProfile(e); if (!profile) return false;
  const skin = profile.skin, body = BODY[skin];
  let action = skin === 'eye' ? 'flight' : Math.abs(e.vx) > 8 ? (skin === 'skeleton' ? 'walk' : 'run') : 'idle';
  if (e.aiMode === 'windup' || e.aiMode === 'attack') action = 'attack';
  if (profile.ability === 'guard' && e.aiMode === 'patrol') action = 'shield';
  if (e.hurt > .06) action = 'hurt';
  const image = artImage(`actors/${skin}-${action}.png`); if (!image) return false;
  const frames = Math.max(1, Math.floor(image.width / body.size));
  let frame = Math.floor(e.timer * (action === 'idle' ? 7 : 10) + e.id) % frames;
  if (e.aiMode === 'windup' && action === 'attack') frame = Math.min(2, frames - 1);
  if (e.aiMode === 'attack' && action === 'attack') frame = Math.min(frames - 1, Math.max(2, Math.floor(e.timer * 15) % frames));
  const x = Math.round(e.x + e.w / 2), foot = Math.round(e.y + e.h);
  drawEnemyTelegraph(c, e, now);
  c.save();
  if (e.kind !== 'bat') {
    c.globalAlpha = .2; c.fillStyle = '#102622'; c.beginPath(); c.ellipse(x, foot, 16, 3, 0, 0, TAU); c.fill(); c.globalAlpha = 1;
  }
  if (e.kind === 'bat' && skin === 'wizard') {
    c.strokeStyle = `${profile.color}88`; c.lineWidth = 1;
    c.beginPath(); c.ellipse(x, foot + 3, 17, 4, 0, 0, TAU); c.stroke();
    c.fillStyle = profile.color;
    for (let i = 0; i < 3; i++) { const t = (now * .6 + i / 3) % 1; c.globalAlpha = (1 - t) * .6; pixel(c, x - 11 + i * 10, foot + t * 17, 2, 3); }
    c.globalAlpha = 1;
  }
  c.translate(x, foot); c.scale(e.facing || 1, 1);
  const scale = e.h / body.bodyHeight;
  if (skin === 'eye') c.translate(0, 8 * scale);
  if (e.hurt > .06) c.filter = 'brightness(2.7) saturate(.4)';
  else if (e.variant?.startsWith('tide-')) c.filter = 'hue-rotate(90deg) saturate(.65)';
  else if (e.variant?.startsWith('crypt-')) c.filter = 'saturate(.55) brightness(.85)';
  else if (e.variant === 'forge-cinder' || e.variant === 'forge-bulwark') c.filter = 'sepia(.7) saturate(1.6)';
  c.imageSmoothingEnabled = false;
  c.drawImage(image, frame * body.size, 0, body.size, body.size, -body.anchorX * scale, -body.anchorY * scale, body.size * scale, body.size * scale);
  c.filter = 'none';
  // A small regional sign supplements a genuinely different sprite/pose, not a recolor substitute.
  c.fillStyle = profile.color; c.globalAlpha = .72;
  if (profile.ability === 'needle') {
    c.strokeStyle = profile.color; c.lineWidth = 2;
    c.beginPath(); c.moveTo(12, -31); c.lineTo(21, -23); c.lineTo(14, -14); c.stroke();
    pixel(c, 10, -24, 16, 2);
  }
  if (profile.ability === 'groundwave') {
    pixel(c, 15, -25, 3, 15); pixel(c, 12, -27, 10, 5); pixel(c, 11, -13, 10, 4);
  }
  if (profile.ability === 'starfall') {
    pixel(c, 15, -38, 2, 26); pixel(c, 12, -40, 8, 7); c.fillStyle = '#f1d4a0'; pixel(c, 15, -39, 2, 4);
  }
  if (profile.ability === 'bomb') { pixel(c, 17, -16, 5, 5); pixel(c, 19, -20, 2, 3); }
  if (profile.ability === 'guard' && e.aiMode !== 'attack' && e.aiMode !== 'recover') {
    c.strokeStyle = '#dfd7b3'; c.lineWidth = 2; c.beginPath(); c.moveTo(19, -37); c.lineTo(26, -31); c.lineTo(25, -15); c.lineTo(19, -9); c.lineTo(13, -15); c.lineTo(12, -31); c.closePath(); c.stroke();
  }
  if (profile.ability === 'rift' || profile.ability === 'hex') {
    c.strokeStyle = profile.color; c.lineWidth = 1;
    c.beginPath(); c.arc(0, -e.h * .52, 23, now * .6, now * .6 + 4.8); c.stroke();
  }
  if (profile.ability === 'tide' || profile.ability === 'orbit') {
    c.strokeStyle = '#b0decb'; c.lineWidth = 1;
    c.beginPath(); c.ellipse(0, 2, 20, 4, 0, 0, TAU); c.stroke();
  }
  if (profile.ability === 'blink') {
    for (let i = 0; i < 3; i++) { c.fillStyle = profile.color; pixel(c, -18 - i * 4, -e.h + 8 + i * 7, 3, 1); }
  }
  c.restore();
  if ((e.emberMark ?? 0) > 0) {
    const y = e.y - 19 + Math.sin(now * 6) * 2;
    c.save();
    c.fillStyle = '#552b30'; pixel(c, x - 5, y - 3, 10, 8);
    c.fillStyle = '#eda275'; pixel(c, x - 1, y - 5, 2, 12); pixel(c, x - 4, y - 1, 8, 5);
    c.fillStyle = '#ffe7a8'; pixel(c, x - 1, y, 2, 3);
    c.restore();
  }
  return true;
}
