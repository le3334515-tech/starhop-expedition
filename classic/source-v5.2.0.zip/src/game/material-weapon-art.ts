import { artImage } from './art-assets';
import type { WeaponId } from './types';

// Source tips point up-left. The grip is defined on the native 16px tile.
const grips: Partial<Record<WeaponId, [tile: number, grip: number, scale: number]>> = {
  willowSword: [0, 12.5, 2.06],
  frostStaff: [1, 8, 2.65],
  jadeNeedle: [2, 13, 1.38],
};

const polearms = {
  reedJavelin: { tile: 3, size: 10, pivotX: 6.7, pivotY: 5.7, scale: 1.22, butt: -21, neck: 25, wrap: '#9ba58d' },
  halberd: { tile: 4, size: 9, pivotX: 7.7, pivotY: 7.4, scale: 1.55, butt: -19, neck: 28, wrap: '#c4a479' },
};

export function drawMaterialWeapon(ctx: CanvasRenderingContext2D, weapon: WeaponId): boolean {
  const sheet = artImage('equipment/steel-arms.png');
  if (!sheet) return false;
  if (weapon === 'halberd' || weapon === 'reedJavelin') {
    const { tile, size, pivotX, pivotY, scale, butt, neck, wrap } = polearms[weapon];
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    // Keep the author's blade and continue the socket through the character's hand.
    ctx.fillStyle = '#332e2a'; ctx.fillRect(butt, -1.75, neck - butt + 3, 3.5);
    ctx.fillStyle = '#846c55'; ctx.fillRect(butt + 1, -1, neck - butt + 1, 1.7);
    ctx.fillStyle = wrap; ctx.fillRect(neck - 6, -2, 6, 3);
    ctx.fillStyle = '#c9a680'; ctx.fillRect(-5, -1.15, 9, 2);
    ctx.translate(neck, 0);
    ctx.rotate(Math.PI * .75);
    ctx.scale(scale, scale);
    ctx.drawImage(sheet, tile * 16, 0, size, size, -pivotX, -pivotY, size, size);
    ctx.restore();
    return true;
  }
  const grip = grips[weapon];
  if (!grip) return false;
  const [tile, pivot, scale] = grip;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.rotate(Math.PI * .75);
  ctx.scale(scale, scale);
  ctx.drawImage(sheet, tile*16, 0, 16, 16, -pivot, -pivot, 16, 16);
  ctx.restore();
  return true;
}
