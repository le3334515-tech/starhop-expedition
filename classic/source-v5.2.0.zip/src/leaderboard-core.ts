import { EXPEDITION_ROOM_COUNT, type GameResult, type ModifierId } from './game/types';
import { readRunLoadout } from './run-loadout';

export const LEADERBOARD_VERSION = 'starhop-v3' as const;
export const LEGACY_VERSION = 'starhop-v2' as const;
export const REQUIRED_ROOMS = EXPEDITION_ROOM_COUNT;
export const MODIFIER_IDS: ModifierId[] = ['standard', 'moon', 'haste', 'iron'];

export interface LeaderboardRecord {
  version: typeof LEADERBOARD_VERSION | typeof LEGACY_VERSION;
  runId: string;
  playerId: string;
  name: string;
  createdAt: string;
  result: GameResult;
}
export interface LeaderboardSnapshot {
  version: typeof LEADERBOARD_VERSION;
  updatedAt: string;
  records: LeaderboardRecord[];
  legacyRecords: LeaderboardRecord[];
  profiles: LeaderboardProfile[];
}
export interface LeaderboardProfile {
  version: typeof LEADERBOARD_VERSION;
  type: 'profile';
  playerId: string;
  name: string;
  updatedAt: string;
}
export interface LeaderboardFeed { records: LeaderboardRecord[]; legacyRecords: LeaderboardRecord[]; profiles: LeaderboardProfile[] }

export function sanitizeName(name: string): string {
  return Array.from(name.normalize('NFC').replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069<>&"'`]/g, '').replace(/\s+/g, ' ').trim()).slice(0, 12).join('') || '星际旅人';
}
function object(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;
}
function number(value: unknown, min: number, max: number, integer = true): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max && (!integer || Number.isInteger(value));
}
function ids(value: unknown, max: number): value is string[] {
  return Array.isArray(value) && value.length <= max && value.every(v => typeof v === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(v));
}
function date(value: unknown): value is string {
  return typeof value === 'string' && value.length <= 40 && Number.isFinite(Date.parse(value));
}

/** Accept only current-version, complete victories; discard all unrecognised fields. */
function validateScore(value: unknown, version: typeof LEADERBOARD_VERSION | typeof LEGACY_VERSION): LeaderboardRecord | null {
  const v = object(value);
  if (!v || v.version !== version || typeof v.runId !== 'string' || !/^[a-zA-Z0-9_-]{8,100}$/.test(v.runId) ||
      typeof v.playerId !== 'string' || !/^[a-zA-Z0-9_-]{8,100}$/.test(v.playerId) || typeof v.name !== 'string' || v.name.length > 100 || !date(v.createdAt)) return null;
  const r = object(v.result);
  const loadout = r && readRunLoadout(r.weapon, r.character);
  if (!r || !loadout || (version === LEGACY_VERSION && loadout.character) || r.won !== true || r.roomsCleared !== (version === LEADERBOARD_VERSION ? REQUIRED_ROOMS : 4) || !MODIFIER_IDS.includes(r.modifier as ModifierId) ||
      !number(r.seed, 0, 0xffffffff) || !number(r.time, .01, 86400, false) || !number(r.score, 0, 100000000) || !number(r.coins, 0, 1000000) ||
      !number(r.kills, 1, 100000) || !number(r.level, 1, 10000) || !number(r.deaths, 0, 100000) || !number(r.maxCombo, 0, 100000) ||
      !number(r.overdriveCount, 0, 100000) || !ids(r.upgrades, 100) || !ids(r.synergies, 32)) return null;
  return {
    version, runId: v.runId, playerId: v.playerId, name: sanitizeName(v.name), createdAt: new Date(v.createdAt).toISOString(),
    result: { seed: r.seed, modifier: r.modifier as ModifierId, ...loadout, won: true, time: r.time, score: r.score,
      coins: r.coins, kills: r.kills, level: r.level, deaths: r.deaths, roomsCleared: r.roomsCleared as number, maxCombo: r.maxCombo,
      overdriveCount: r.overdriveCount, upgrades: [...r.upgrades], synergies: [...r.synergies] },
  };
}

export function validateRecord(value: unknown): LeaderboardRecord | null { return validateScore(value, LEADERBOARD_VERSION); }
export function validateLegacyRecord(value: unknown): LeaderboardRecord | null { return validateScore(value, LEGACY_VERSION); }
export function validateProfile(value: unknown): LeaderboardProfile | null {
  const v = object(value);
  if (!v || v.version !== LEADERBOARD_VERSION || v.type !== 'profile' || typeof v.playerId !== 'string' ||
      !/^[a-zA-Z0-9_-]{8,100}$/.test(v.playerId) || typeof v.name !== 'string' || v.name.length > 100 || !date(v.updatedAt)) return null;
  return { version: LEADERBOARD_VERSION, type: 'profile', playerId: v.playerId, name: sanitizeName(v.name), updatedAt: new Date(v.updatedAt).toISOString() };
}
export function mergeProfiles(...groups: ReadonlyArray<ReadonlyArray<LeaderboardProfile>>): LeaderboardProfile[] {
  const latest = new Map<string, LeaderboardProfile>();
  for (const group of groups) for (const raw of group) {
    const profile = validateProfile(raw); if (!profile) continue;
    const previous = latest.get(profile.playerId);
    if (!previous || profile.updatedAt > previous.updatedAt || (profile.updatedAt === previous.updatedAt && profile.name > previous.name)) latest.set(profile.playerId, profile);
  }
  return [...latest.values()].sort((a,b)=>a.playerId.localeCompare(b.playerId));
}
export function applyProfiles(records: LeaderboardRecord[], profiles: LeaderboardProfile[]): LeaderboardRecord[] {
  const names = new Map(mergeProfiles(profiles).map(p=>[p.playerId,p.name]));
  return records.map(record=>({...record, name: names.get(record.playerId) ?? record.name, result: {...record.result,upgrades:[...record.result.upgrades],synergies:[...record.result.synergies]}}));
}
export function compareRecords(a: LeaderboardRecord, b: LeaderboardRecord): number {
  return a.result.time - b.result.time || a.createdAt.localeCompare(b.createdAt) || a.runId.localeCompare(b.runId);
}
function ranked(groups: ReadonlyArray<ReadonlyArray<LeaderboardRecord>>, version: typeof LEADERBOARD_VERSION | typeof LEGACY_VERSION): LeaderboardRecord[] {
  const best = new Map<string, LeaderboardRecord>();
  for (const group of groups) for (const raw of group) {
    const record = validateScore(raw,version); if (!record) continue;
    const key = `${record.result.modifier}:${record.playerId}`;
    const previous = best.get(key);
    if (!previous || compareRecords(record, previous) < 0) best.set(key, record);
  }
  return MODIFIER_IDS.flatMap(rule => [...best.values()].filter(r => r.result.modifier === rule).sort(compareRecords).slice(0, 10));
}
export function mergeRecords(...groups: ReadonlyArray<ReadonlyArray<LeaderboardRecord>>): LeaderboardRecord[] { return ranked(groups,LEADERBOARD_VERSION); }
export function mergeLegacyRecords(...groups: ReadonlyArray<ReadonlyArray<LeaderboardRecord>>): LeaderboardRecord[] { return ranked(groups,LEGACY_VERSION); }
export function makeSnapshot(records: LeaderboardRecord[], updatedAt = new Date().toISOString(), profiles: LeaderboardProfile[] = [], legacyRecords: LeaderboardRecord[] = []): LeaderboardSnapshot {
  const names = mergeProfiles(profiles);
  return { version: LEADERBOARD_VERSION, updatedAt: new Date(updatedAt).toISOString(), records: applyProfiles(mergeRecords(records),names),
    legacyRecords: applyProfiles(mergeLegacyRecords(legacyRecords),names), profiles: names };
}
export function parseSnapshot(value: unknown): LeaderboardSnapshot | null {
  const v = object(value);
  if (!v || ![LEADERBOARD_VERSION,LEGACY_VERSION].includes(v.version as typeof LEADERBOARD_VERSION) || !date(v.updatedAt) || !Array.isArray(v.records) || v.records.length > 10000) return null;
  if(v.version===LEGACY_VERSION) return makeSnapshot([],v.updatedAt,[],v.records.map(validateLegacyRecord).filter((r):r is LeaderboardRecord=>!!r));
  if(v.profiles!==undefined && (!Array.isArray(v.profiles)||v.profiles.length>100000)) return null;
  if(v.legacyRecords!==undefined && (!Array.isArray(v.legacyRecords)||v.legacyRecords.length>10000)) return null;
  return makeSnapshot(v.records.map(validateRecord).filter((r): r is LeaderboardRecord => !!r), v.updatedAt,
    (v.profiles??[] as unknown[]) as LeaderboardProfile[], (v.legacyRecords??[] as unknown[]) as LeaderboardRecord[]);
}
export function parseFeedState(ndjson: string): LeaderboardFeed {
  const records: LeaderboardRecord[] = [], legacyRecords: LeaderboardRecord[] = [], profiles: LeaderboardProfile[] = [];
  for (const line of ndjson.split('\n')) {
    if (!line.trim() || line.length > 16384) continue;
    try {
      const event = object(JSON.parse(line));
      if (event?.event !== 'message' || typeof event.message !== 'string' || event.message.length > 8192) continue;
      const payload = JSON.parse(event.message);
      const record = validateRecord(payload), legacy = validateLegacyRecord(payload), profile = validateProfile(payload);
      if (record) records.push(record); if(legacy) legacyRecords.push(legacy); if(profile) profiles.push(profile);
    } catch { /* Ignore malformed messages without losing valid results or profile updates. */ }
  }
  return {records:mergeRecords(records),legacyRecords:mergeLegacyRecords(legacyRecords),profiles:mergeProfiles(profiles)};
}
export function parseFeed(ndjson: string): LeaderboardRecord[] { return parseFeedState(ndjson).records; }
