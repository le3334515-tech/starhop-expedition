import { afterEach, describe, expect, it, vi } from 'vitest';
import { LiveLeaderboard } from './leaderboard';
import { LEADERBOARD_VERSION, makeSnapshot, type LeaderboardRecord } from './leaderboard-core';
import type { GameResult } from './game/types';

function memoryStorage(): Storage {
  const values = new Map<string, string>();
  return { getItem: k => values.get(k) ?? null, setItem: (k, v) => { values.set(k, String(v)); }, removeItem: k => { values.delete(k); },
    clear: () => values.clear(), key: i => [...values.keys()][i] ?? null, get length() { return values.size; } };
}
const result = (overrides: Partial<GameResult> = {}): GameResult => ({
  seed: 42, modifier: 'standard', weapon: 'ember', won: true, time: 123.45, score: 12000, coins: 30,
  kills: 24, level: 5, deaths: 0, roomsCleared: 8, maxCombo: 6, upgrades: ['edge'], overdriveCount: 1, synergies: [], ...overrides,
});
function event(record: LeaderboardRecord): string { return JSON.stringify({ id: 'serverMsg1', event: 'message', message: JSON.stringify(record) }); }
function fetcher(handler: (url: string, init: RequestInit) => string | Promise<string>): typeof fetch {
  return vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}) => new Response(await handler(String(input), init))) as typeof fetch;
}
function remoteRecord(): LeaderboardRecord {
  return { version: LEADERBOARD_VERSION, runId: 'remote_run_123', playerId: 'remote_player_123', name: '远方玩家', createdAt: '2026-11-16T12:00:00Z', result: result({ time: 98.76 }) };
}
afterEach(() => { vi.useRealTimers(); });

describe('real shared score client', () => {
  it('shows an empty shared board, not demonstration scores', async () => {
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, fetch: fetcher(url => url.includes('/json?') ? '' : JSON.stringify(makeSnapshot([]))) });
    await board.refresh();
    expect(board.getState().records).toEqual([]);
    expect(board.getState().error).toBeNull();
  });
  it('rejects losses without a POST and accepts only server acknowledged victories', async () => {
    const request = fetcher((_, init) => event(JSON.parse(String(init.body))));
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, fetch: request });
    expect((await board.submit('测试者', result({ won: false }))).status).toBe('rejected');
    expect(request).not.toHaveBeenCalled();
    const outcome = await board.submit('测试者', result());
    expect(outcome.status).toBe('submitted');
    expect(board.getState().records[0].result.time).toBe(123.45);
    expect(board.getState().pending).toBe(0);
    expect((request as ReturnType<typeof vi.fn>).mock.calls[0][1]).toMatchObject({ method: 'POST', headers: { 'Content-Type': 'text/plain' } });
  });
  it('does not show queued offline scores and retries the same run ID after refresh', async () => {
    vi.useFakeTimers();
    const storage = memoryStorage();
    let online = false;
    const posted: string[] = [];
    const request = fetcher((url, init) => {
      if (init.method === 'POST') { const record = JSON.parse(String(init.body)); posted.push(record.runId); if (!online) throw new Error('offline'); return event(record); }
      return url.includes('/json?') ? '' : JSON.stringify(makeSnapshot([]));
    });
    const board = new LiveLeaderboard({ storage, autoRetry: false, fetch: request });
    expect((await board.submit('真实通关者', result())).status).toBe('pending');
    expect(board.getState().records).toEqual([]);
    expect(board.getState().pending).toBe(1);
    const reloaded = new LiveLeaderboard({ storage, autoRetry: false, fetch: request });
    expect(reloaded.getPlayerId()).toBe(board.getPlayerId());
    expect(reloaded.getState().pending).toBe(1);
    online = true;
    await reloaded.refresh();
    expect(reloaded.getState().pending).toBe(0);
    expect(reloaded.getState().records).toHaveLength(1);
    expect(posted[0]).toBe(posted[1]);
    expect(reloaded.getState().lastSubmission?.status).toBe('submitted');
  });
  it('deduplicates repeated submission and changed object key order across reload', async () => {
    const storage = memoryStorage();
    const request = fetcher((_, init) => event(JSON.parse(String(init.body))));
    const board = new LiveLeaderboard({ storage, autoRetry: false, fetch: request });
    await board.submit('旅人', result());
    expect((await board.submit('新名字', result())).status).toBe('duplicate');
    const reversed = Object.fromEntries(Object.entries(result()).reverse()) as unknown as GameResult;
    const reloaded = new LiveLeaderboard({ storage, autoRetry: false, fetch: request });
    expect((await reloaded.submit('旅人', reversed)).status).toBe('duplicate');
    expect(request).toHaveBeenCalledTimes(1);
  });
  it('requires matching server acknowledgement and preserves local queue after a malformed ACK', async () => {
    vi.useFakeTimers();
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, fetch: fetcher(() => '{"ok":true}') });
    expect((await board.submit('旅人', result())).status).toBe('pending');
    expect(board.getState().pending).toBe(1);
    expect(board.getState().records).toEqual([]);
  });
  it('states that queued scores survive only on this page when local storage is unavailable', async () => {
    vi.useFakeTimers();
    const storage = memoryStorage();
    storage.setItem = () => { throw new Error('Quota exceeded'); };
    const board = new LiveLeaderboard({ storage, autoRetry: false, fetch: fetcher(() => { throw new Error('offline'); }) });
    const pending = await board.submit('旅人', result());
    expect(pending.status).toBe('pending');
    expect(pending.error).toMatch(/本页面/);
    expect(board.getState().error).toMatch(/本页面/);
    expect(board.getState().pending).toBe(1);
  });
  it('handles HTTP failures as pending rather than claiming an upload succeeded', async () => {
    vi.useFakeTimers();
    const request = vi.fn(async () => new Response('rate limited', { status: 429 })) as typeof fetch;
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, fetch: request });
    expect((await board.submit('旅人', result())).status).toBe('pending');
    expect(board.getState().records).toEqual([]);
    expect(board.getState().pending).toBe(1);
  });
  it('aborts a stalled score request and keeps the result queued', async () => {
    vi.useFakeTimers();
    const request = vi.fn((_: RequestInfo | URL, init: RequestInit) => new Promise<Response>((_, reject) => {
      init.signal?.addEventListener('abort', () => reject(new Error('Timed out')));
    })) as typeof fetch;
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, timeoutMs: 100, fetch: request });
    const uploading = board.submit('旅人', result());
    await vi.advanceTimersByTimeAsync(101);
    expect((await uploading).status).toBe('pending');
    expect(board.getState().records).toEqual([]);
  });
  it('merges a permanent snapshot and independent recent messages without overwriting', async () => {
    const one = remoteRecord();
    const two = { ...remoteRecord(), playerId: 'another_player', runId: 'another_run', result: result({ time: 88 }) };
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, fetch: fetcher(url => url.includes('/json?') ? event(two) : JSON.stringify(makeSnapshot([one]))) });
    await board.refresh();
    expect(board.getState().records.map(r => r.result.time)).toEqual([88, 98.76]);
  });
  it('preserves cached scores while reporting total network failure', async () => {
    const storage = memoryStorage();
    const board = new LiveLeaderboard({ storage, autoRetry: false, fetch: fetcher(url => url.includes('/json?') ? event(remoteRecord()) : JSON.stringify(makeSnapshot([]))) });
    await board.refresh();
    const offline = new LiveLeaderboard({ storage, autoRetry: false, fetch: fetcher(() => { throw new Error('offline'); }), EventSource: null });
    offline.open();
    await offline.refresh();
    expect(offline.getState().records).toHaveLength(1);
    expect(offline.getState().error).toMatch(/无法连接/);
    expect(offline.getState().connection).toBe('offline');
    offline.close();
  });
  it('reports missing historical data even if the recent feed is empty and readable', async () => {
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, fetch: fetcher(url => {
      if (!url.includes('/json?')) throw new Error('Snapshot unavailable');
      return '';
    }) });
    await board.refresh();
    expect(board.getState().error).toMatch(/历史榜/);
    expect(board.getState().records).toEqual([]);
  });
  it('reports interrupted recent updates even if the permanent snapshot succeeds', async () => {
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, EventSource: null, fetch: fetcher(url => {
      if (url.includes('/json?')) throw new Error('Feed unavailable');
      return JSON.stringify(makeSnapshot([remoteRecord()]));
    }) });
    board.open(); await board.refresh();
    expect(board.getState().error).toMatch(/即时成绩同步暂时中断/);
    expect(board.getState().records).toHaveLength(1);
    expect(board.getState().connection).toBe('polling');
    board.close();
  });
  it('keeps readable events but marks a truncated replay as incomplete', async () => {
    const request = vi.fn(async (input: RequestInfo | URL) => String(input).includes('/json?') ?
      new Response(event(remoteRecord()), { headers: { 'X-Messages-Truncated': '1' } }) : new Response(JSON.stringify(makeSnapshot([])))) as typeof fetch;
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, fetch: request });
    await board.refresh();
    expect(board.getState().records).toHaveLength(1);
    expect(board.getState().error).toMatch(/同步不完整/);
  });
  it('drains scores queued during an existing upload without losing either result', async () => {
    let release: ((value: string) => void) | undefined;
    let first: LeaderboardRecord | undefined;
    let count = 0;
    const request = fetcher(async (_, init) => {
      const record = JSON.parse(String(init.body));
      if (++count === 1) { first = record; return new Promise<string>(resolve => { release = resolve; }); }
      return event(record);
    });
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, fetch: request });
    const one = board.submit('旅人', result());
    const two = board.submit('旅人', result({ modifier: 'moon' }));
    release!(event(first!));
    expect((await one).status).toBe('submitted');
    expect((await two).status).toBe('submitted');
    expect(board.getState().pending).toBe(0);
    expect(board.getState().records).toHaveLength(2);
    expect(count).toBe(2);
  });
  it('receives live events, ignores unrelated events, falls back to polling and stops on close', async () => {
    vi.useFakeTimers();
    class Source {
      static instances: Source[] = [];
      onopen: (() => void) | null = null;
      onmessage: ((event: { data: string }) => void) | null = null;
      onerror: (() => void) | null = null;
      close = vi.fn();
      constructor(public url: string) { Source.instances.push(this); }
    }
    const board = new LiveLeaderboard({ storage: memoryStorage(), autoRetry: false, fetch: fetcher(url => url.includes('/json?') ? '' : JSON.stringify(makeSnapshot([]))), EventSource: Source as unknown as typeof EventSource });
    const listener = vi.fn();
    const unsubscribe = board.subscribe(listener);
    board.open(); await board.refresh();
    const source = Source.instances[0];
    expect(source.url).toContain('/sse?since=all');
    source.onopen?.();
    expect(board.getState().connection).toBe('live');
    source.onmessage?.({ data: event(remoteRecord()) });
    source.onmessage?.({ data: '{"event":"keepalive"}' });
    expect(board.getState().records).toHaveLength(1);
    source.onerror?.();
    expect(board.getState().connection).toBe('polling');
    unsubscribe();
    board.close();
    await vi.advanceTimersByTimeAsync(35000);
    expect(Source.instances).toHaveLength(1);
    expect(board.getState().connection).toBe('idle');
  });
});


describe('live shared nickname edits',()=>{
  it('renames existing current and legacy entries using a profile event without resubmitting scores',async()=>{
    const storage=memoryStorage();storage.setItem('starhop.leaderboard.v2.player',JSON.stringify('player_existing'));
    const own={...remoteRecord(),playerId:'player_existing',name:'旧名'};
    const legacy={...own,version:'starhop-v2' as const,result:result({roomsCleared:4,time:54.87})};
    const posts:Record<string,unknown>[]=[];
    const request=fetcher((url,init)=>{
      if(init.method==='POST'){const profile=JSON.parse(String(init.body));posts.push(profile);return JSON.stringify({event:'message',message:JSON.stringify(profile)});}
      return url.includes('/json?')?'':JSON.stringify(makeSnapshot([own],undefined,[],[legacy]));
    });
    const board=new LiveLeaderboard({storage,autoRetry:false,fetch:request});await board.refresh();
    expect(board.getPlayerId()).toBe('player_existing');
    const before=JSON.stringify(board.getState().records[0].result);
    expect((await board.rename('云间客')).status).toBe('submitted');
    expect(posts).toHaveLength(1);expect(posts[0].type).toBe('profile');expect(posts[0].result).toBeUndefined();
    expect(board.getState().records[0].name).toBe('云间客');expect(board.getState().legacyRecords[0].name).toBe('云间客');
    expect(JSON.stringify(board.getState().records[0].result)).toBe(before);expect(board.getState().legacyRecords[0].result.time).toBe(54.87);
    const reloaded=new LiveLeaderboard({storage,autoRetry:false,fetch:request});
    expect(reloaded.getState().records[0].name).toBe('云间客');
    expect((await reloaded.rename('云间客')).status).toBe('duplicate');expect(posts).toHaveLength(1);
  });
  it('persists an offline rename, marks it pending, and later shares the same profile without a fake score',async()=>{
    vi.useFakeTimers();const storage=memoryStorage();let online=false;const posts:unknown[]=[];
    const request=fetcher((url,init)=>{
      if(init.method==='POST'){const payload=JSON.parse(String(init.body));posts.push(payload);if(!online)throw new Error('Offline');return JSON.stringify({event:'message',message:JSON.stringify(payload)});}
      return url.includes('/json?')?'':JSON.stringify(makeSnapshot([]));
    });
    const board=new LiveLeaderboard({storage,autoRetry:false,fetch:request});
    expect((await board.rename('等待联网')).status).toBe('pending');expect(board.getState().pendingRenames).toBe(1);
    const reloaded=new LiveLeaderboard({storage,autoRetry:false,fetch:request});expect(reloaded.getState().lastRename).toEqual({name:'等待联网',status:'pending'});
    online=true;await reloaded.refresh();expect(reloaded.getState().pendingRenames).toBe(0);expect(reloaded.getState().lastRename?.status).toBe('submitted');
    expect(reloaded.getState().records).toEqual([]);expect(posts[0]).toEqual(posts[1]);
  });
  it('receives another browser nickname edit through SSE and keeps all score fields unchanged',async()=>{
    class Source { static source:Source;onopen:(()=>void)|null=null;onmessage:((e:{data:string})=>void)|null=null;onerror:(()=>void)|null=null;close(){} constructor(_url:string){Source.source=this;} }
    const original=remoteRecord();const board=new LiveLeaderboard({storage:memoryStorage(),autoRetry:false,fetch:fetcher(url=>url.includes('/json?')?'':JSON.stringify(makeSnapshot([original]))),EventSource:Source as unknown as typeof EventSource});
    board.open();await board.refresh();
    Source.source.onmessage?.({data:JSON.stringify({event:'message',message:JSON.stringify({version:LEADERBOARD_VERSION,type:'profile',playerId:original.playerId,name:'别人改的新名字',updatedAt:'2026-11-16T13:00:00Z'})})});
    expect(board.getState().records[0].name).toBe('别人改的新名字');expect(board.getState().records[0].result).toEqual(original.result);board.close();
  });
});
