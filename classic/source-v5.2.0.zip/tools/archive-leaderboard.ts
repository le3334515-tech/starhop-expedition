import { readFile, mkdir, writeFile, rename } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { LEADERBOARD_CONFIG } from '../src/leaderboard';
import { LEADERBOARD_VERSION, makeSnapshot, mergeRecords, parseSnapshot, validateRecord, validateLegacyRecord, validateProfile, mergeLegacyRecords, mergeProfiles, type LeaderboardRecord, type LeaderboardProfile } from '../src/leaderboard-core';

export interface ArchiveCursor {
  version: string;
  lastEventId: string;
  lastEventTime: number;
}

interface FeedEvent { id: string; time: number; record: LeaderboardRecord | null; legacyRecord: LeaderboardRecord | null; profile: LeaderboardProfile | null }

/** A damaged response must never advance the archive cursor. Invalid score payloads are simply skipped. */
export function collectMessages(text: string): FeedEvent[] {
  const events: FeedEvent[] = [];
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let event: Record<string, unknown>;
    try { event = JSON.parse(line); } catch { throw new Error('Malformed leaderboard event response'); }
    if (!event || typeof event !== 'object' || Array.isArray(event)) throw new Error('Invalid leaderboard event');
    if (event.event === 'open' || event.event === 'keepalive') continue;
    if (event.event !== 'message') throw new Error('Unexpected leaderboard event response');
    if (typeof event.id !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(event.id) ||
        typeof event.time !== 'number' || !Number.isSafeInteger(event.time) || event.time < 0) {
      throw new Error('Invalid leaderboard event cursor');
    }
    let record: LeaderboardRecord | null = null;
    let legacyRecord: LeaderboardRecord | null = null;
    let profile: LeaderboardProfile | null = null;
    if (typeof event.message === 'string' && event.message.length <= 4096) {
      try { const payload=JSON.parse(event.message);record = validateRecord(payload);legacyRecord=validateLegacyRecord(payload);profile=validateProfile(payload); } catch { /* Unrelated messages cannot enter the board. */ }
    }
    events.push({ id: event.id, time: event.time, record, legacyRecord, profile });
  }
  return events;
}

export function parseCursor(value: unknown): ArchiveCursor | null {
  if (!value || typeof value !== 'object') return null;
  const cursor = value as Partial<ArchiveCursor>;
  return cursor.version === LEADERBOARD_VERSION && typeof cursor.lastEventId === 'string' &&
    /^[A-Za-z0-9_-]{1,100}$/.test(cursor.lastEventId) && typeof cursor.lastEventTime === 'number' &&
    Number.isSafeInteger(cursor.lastEventTime) && cursor.lastEventTime >= 0 ? cursor as ArchiveCursor : null;
}

async function optionalJson(file: string): Promise<unknown | undefined> {
  try { return JSON.parse(await readFile(file, 'utf8')); }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return undefined;
    throw new Error(`Cannot read ${path.basename(file)}: ${(error as Error).message}`);
  }
}

async function writeJson(file: string, value: unknown): Promise<void> {
  await mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.tmp`;
  await writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
  await rename(temporary, file);
}

export interface ArchiveOptions {
  root?: string;
  topic?: string;
  baseUrl?: string;
  legacyTopic?: string;
  fetch?: typeof fetch;
  now?: () => Date;
}

export async function archiveLeaderboard(options: ArchiveOptions = {}) {
  const root = path.resolve(options.root ?? process.cwd());
  const topic = options.topic ?? LEADERBOARD_CONFIG.topic;
  if (!/^[A-Za-z0-9_-]+$/.test(topic)) throw new Error('Invalid leaderboard topic');
  const baseUrl = (options.baseUrl ?? LEADERBOARD_CONFIG.baseUrl).replace(/\/$/, '');
  const fetcher = options.fetch ?? fetch;
  const snapshotFile = path.join(root, 'leaderboard', 'v3.json');
  const cursorFile = path.join(root, 'leaderboard', 'cursor-v3.json');
  const rawSnapshot = await optionalJson(snapshotFile);
  const previous = rawSnapshot === undefined ? null : parseSnapshot(rawSnapshot);
  if (rawSnapshot !== undefined && !previous) throw new Error('Existing leaderboard snapshot is invalid');
  if (rawSnapshot !== undefined && (!(rawSnapshot as { records: unknown[] }).records.every(record => validateRecord(record)) ||
      !((rawSnapshot as {legacyRecords?:unknown[]}).legacyRecords??[]).every(record=>validateLegacyRecord(record)) ||
      !((rawSnapshot as {profiles?:unknown[]}).profiles??[]).every(profile=>validateProfile(profile)))) {
    throw new Error('Existing leaderboard snapshot contains invalid records');
  }
  const rawCursor = await optionalJson(cursorFile);
  const cursor = rawCursor === undefined ? null : parseCursor(rawCursor);
  if (rawCursor !== undefined && !cursor) throw new Error('Existing leaderboard cursor is invalid');

  const legacyRaw=await optionalJson(path.join(root,'leaderboard','v2.json'));
  const legacySnapshot=legacyRaw===undefined?null:parseSnapshot(legacyRaw);
  if(legacyRaw!==undefined&&(!legacySnapshot || !(legacyRaw as {records:unknown[]}).records.every(record=>validateLegacyRecord(record))))throw new Error('Existing legacy leaderboard is invalid');

  const poll = async (since: string, feedTopic=topic): Promise<FeedEvent[]> => {
    const url = new URL(`${baseUrl}/${feedTopic}/json`);
    url.searchParams.set('poll', '1');
    url.searchParams.set('since', since);
    const response = await fetcher(url.toString(), { headers: { Accept: 'application/x-ndjson' }, signal: AbortSignal.timeout(30_000) });
    if (!response.ok) throw new Error(`Leaderboard feed returned HTTP ${response.status}`);
    if (response.headers.get('X-Messages-Truncated') === '1') throw new Error('Leaderboard replay was truncated; cursor was not advanced');
    const body = await response.text();
    if (body.length > 12_000_000) throw new Error('Leaderboard replay exceeds archive size limit');
    return collectMessages(body);
  };

  let events: FeedEvent[];
  if (!cursor) events = await poll('all');
  else {
    // The ID query is incremental. A small timestamp overlap also catches a message
    // replicated late, or an ID that has already aged out of ntfy's 12-hour cache.
    const overlap = String(Math.max(0, cursor.lastEventTime - 120));
    try { events = await poll(cursor.lastEventId); }
    catch (error) {
      if (!/HTTP 400|HTTP 404/.test((error as Error).message)) throw error;
      events = [];
    }
    events.push(...await poll(overlap));
  }
  const unique = [...new Map(events.map(event => [event.id, event])).values()].sort((a, b) => a.time - b.time || a.id.localeCompare(b.id));
  const records = mergeRecords(previous?.records ?? [], unique.flatMap(event => event.record ? [event.record] : []));
  const legacyEvents=await poll('all',options.legacyTopic??LEADERBOARD_CONFIG.legacyTopic);
  const legacyRecords=mergeLegacyRecords(previous?.legacyRecords??[],legacySnapshot?.legacyRecords??[],legacyEvents.flatMap(e=>e.legacyRecord?[e.legacyRecord]:[]));
  const profiles=mergeProfiles(previous?.profiles??[],unique.flatMap(e=>e.profile?[e.profile]:[]));
  const snapshot=makeSnapshot(records,(options.now?.()??new Date()).toISOString(),profiles,legacyRecords);
  const recordsChanged=!previous || JSON.stringify([snapshot.records,snapshot.legacyRecords,snapshot.profiles])!==JSON.stringify([previous.records,previous.legacyRecords,previous.profiles]);
  if(recordsChanged)await writeJson(snapshotFile,snapshot);
  const last = unique.at(-1);
  const nextCursor = last && (!cursor || last.time >= cursor.lastEventTime) ? {
    version: LEADERBOARD_VERSION, lastEventId: last.id, lastEventTime: last.time,
  } : cursor;
  const cursorChanged = nextCursor !== null && JSON.stringify(nextCursor) !== JSON.stringify(cursor);
  if (cursorChanged) await writeJson(cursorFile, nextCursor);
  return { records: records.length, received: unique.length, recordsChanged, cursorChanged };
}

if (process.argv[1] && /archive-leaderboard\.(?:mjs|ts)$/.test(path.basename(process.argv[1])) && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  // The deployed bundle lives in classic/scripts; resolve beside it instead of the repository cwd.
  const deploymentRoot = process.argv[2] ?? path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
  archiveLeaderboard({ root: deploymentRoot }).then(result => console.log(JSON.stringify(result)), error => {
    console.error((error as Error).message);
    process.exitCode = 1;
  });
}
