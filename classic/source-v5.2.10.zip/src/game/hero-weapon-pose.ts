import { WEAPONS, type Hero, type WeaponId } from './types';
import { attackProgress, wristBeat } from './weapon-motion';

type Point = { x: number; y: number };
export interface RangedWeaponPose {
  attacking: boolean; attackProgress: number; lean: number;
  hand: Point; elbow: Point; offHand: Point; offElbow: Point; staffGrip: Point; staffAngle: number;
}
const cleanSheets = new WeakMap<HTMLImageElement, HTMLCanvasElement>();
// These four colors belong exclusively to this source character's sword and hilt.
// Keep the credited PNGs intact; only the cached ranged-body layer omits the sword.
const swordColors = new Set([0x5f4181, 0x442b61, 0x331685, 0x432792]);
export function weaponlessHeroSheet(image: HTMLImageElement): HTMLCanvasElement {
  const cached = cleanSheets.get(image); if (cached) return cached;
  const sheet = document.createElement('canvas');
  sheet.width = image.naturalWidth; sheet.height = image.naturalHeight;
  const c = sheet.getContext('2d')!;
  c.drawImage(image, 0, 0);
  const pixels = c.getImageData(0, 0, sheet.width, sheet.height), data = pixels.data;
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] && swordColors.has((data[i] << 16) | (data[i + 1] << 8) | data[i + 2])) data[i + 3] = 0;
  }
  c.putImageData(pixels, 0, 0); cleanSheets.set(image, sheet); return sheet;
}

const mix = (a: number, b: number, t: number) => a + (b - a) * t;
const easeOut = (t: number) => 1 - (1 - t) ** 3;
function key(p: number, frames: readonly (readonly [number, number])[]): number {
  for (let n = 1; n < frames.length; n++) if (p <= frames[n][0]) {
    const [start, a] = frames[n - 1], [end, b] = frames[n];
    return mix(a, b, easeOut(Math.max(0, Math.min(1, (p - start) / (end - start)))));
  }
  return frames[frames.length - 1][1];
}

// Hand positions in local sprite pixels and the weapon angle from the grip.
// For each gesture the four poses are ready, release, follow-through and rest.
type Grip = readonly [x: number, y: number, angle: number];
type Gesture = readonly [Grip, Grip, Grip, Grip];
const gestures: Partial<Record<WeaponId, Gesture>> = {
  willowSword: [[5,-20,-.65],[25,-24,-.08],[21,-23,-.04],[12,-17,-.31]],
  swallowDart: [[3,-25,-.78],[23,-23,-.08],[16,-16,.28],[12,-14,-.26]],
  frostStaff:  [[7,-18,-.94],[17,-24,-.12],[12,-22,-.35],[12,-19,-1.04]],
  moonMirror:  [[9,-20,-1.02],[16,-29,-.65],[17,-27,-.50],[12,-18,-.40]],
  fan:         [[5,-22,-1.2],[21,-24,-.48],[18,-17,.22],[13,-13,-.64]],
  jadeNeedle:  [[4,-18,-.31],[24,-20,-.06],[15,-19,-.09],[10,-15,-.46]],
  silkFan:     [[3,-13,.88],[23,-23,-.18],[18,-21,.34],[12,-15,-.30]],
  reedJavelin: [[1,-28,-.42],[22,-26,-.03],[18,-19,.19],[13,-18,-1.04]],
  halberd:     [[5,-22,-1.34],[22,-20,-.11],[19,-17,.13],[12,-18,-1.04]],
  ironGauntlet:[[8,-18,-.57],[22,-23,-.04],[17,-20,.05],[13,-14,-.21]],
  prayerBeads: [[8,-15,.43],[20,-24,-.62],[16,-22,-.81],[11,-16,-.22]],
};
/** A quick release followed by recovery matches the existing immediate projectiles.
 * Both actions use the original locomotion body; neither borrows a sword frame. */
export function rangedWeaponPose(h: Hero, now: number, classicAwakening = false): RangedWeaponPose {
  const attacking = h.attackTimer > 0 && h.hp > 0;
  const p = attacking ? attackProgress(h.weapon, h.attackStep, h.attackTimer) : 1;
  const bob = h.grounded && Math.abs(h.vx) < 15 ? Math.sin(now * 2.8) * .35 : 0;
  const grip = gestures[h.weapon];
  if (grip) {
    const sample = (axis: 0 | 1 | 2) => wristBeat(p, grip[0][axis], grip[1][axis], grip[2][axis], grip[3][axis]);
    const hand = {x: sample(0), y: sample(1) + (attacking ? 0 : bob)};
    return { attacking, attackProgress: p, hand, staffGrip: hand, staffAngle: sample(2),
      lean: wristBeat(p,.035,h.attackStep===3 ? -.115 : -.085,-.026,0),
      elbow: {x: Math.max(6, hand.x * .49), y: Math.min(-13, hand.y+5)},
      offHand: {x:-6,y:-15+bob}, offElbow: {x:-6,y:-21} };
  }
  if (attacking && !classicAwakening && (h.weapon === 'disc' || h.weapon === 'ember')) {
    const staff = h.weapon === 'ember';
    const hand = staff
      ? { x: wristBeat(p,4,8,10,12), y: wristBeat(p,-22,-22,-19,-19) }
      : { x: wristBeat(p,11,23,15,13), y: wristBeat(p,-22,-20,-13,-12) };
    return {attacking, attackProgress:p, hand, staffGrip:hand,
      staffAngle: staff ? wristBeat(p,1.16,1.40,.66,.1) : 0,
      lean:wristBeat(p,.018,-.080,-.018,0), elbow:{x:hand.x*.5+1,y:-17},
      offHand:{x:-5,y:-15+bob},offElbow:{x:-6,y:-21}};
  }
  if (WEAPONS[h.weapon].archetype === 'ember' && h.weapon !== 'jadeNeedle') {
    // The same hand keeps the staff throughout: a sharp wrist point, a small
    // recoil, then a quick return to the outside of the silhouette.
    const hand = { x: attacking ? key(p, [[0,-2],[.12,0],[.42,11],[1,12]]) : 12,
      y: attacking ? key(p, [[0,-18],[.12,-17],[.42,-20],[1,-19]]) : -19 + bob };
    return { attacking, attackProgress: p,
      lean: attacking ? key(p, [[0,-.035],[.13,.018],[.48,-.005],[1,0]]) : 0,
      hand, elbow: { x: 7, y: -18 }, offHand: { x: -5, y: -15 + bob }, offElbow: { x: -6, y: -21 },
      staffGrip: hand, staffAngle: attacking ? key(p, [[0,1.25],[.12,1.39],[.45,.04],[1,.1]]) : .1 };
  }
  // A sidearm flick. The release is immediate, the elbow folds rather than
  // leaving both arms stretched out for the full attack window.
  return { attacking, attackProgress: p, lean: attacking ? key(p, [[0,-.055],[.12,-.07],[.38,.012],[1,0]]) : 0,
    hand: { x: attacking ? key(p, [[0,16],[.12,23],[.38,12],[.7,12],[1,13]]) : 13,
      y: attacking ? key(p, [[0,-16],[.12,-18],[.38,-10],[.7,-13],[1,-12]]) : -12 + bob },
    elbow: { x: attacking ? key(p, [[0,8],[.12,11],[.38,6],[1,7]]) : 7, y: -18 },
    offHand: { x: -6, y: -15 + bob }, offElbow: { x: -6, y: -21 },
    staffGrip: { x: 0, y: 0 }, staffAngle: 0 };
}

function arm(c: CanvasRenderingContext2D, shoulder: Point, elbow: Point, hand: Point, palm: boolean) {
  // Pixel steps use the source robe's plum shadows, ivory sleeve and pale glove.
  const segment = (a: Point, b: Point, color: string, size: number) => {
    c.fillStyle = color;
    const steps = Math.max(Math.abs(b.x - a.x), Math.abs(b.y - a.y), 1);
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      c.fillRect(Math.round(mix(a.x, b.x, t) - size / 2), Math.round(mix(a.y, b.y, t) - size / 2), size, size);
    }
  };
  segment(shoulder, elbow, '#49313e', 4); segment(elbow, hand, '#49313e', 3);
  segment(shoulder, elbow, '#b59fa8', 2); segment(elbow, hand, '#d1bfc1', 2);
  c.fillStyle = '#755568'; c.fillRect(Math.round(hand.x) - 3, Math.round(hand.y) - 1, 3, 3);
  c.fillStyle = '#ddcdcb'; c.fillRect(Math.round(hand.x) - 1, Math.round(hand.y) - 1, 3, 3);
  if (palm) c.fillRect(Math.round(hand.x) + 1, Math.round(hand.y) - 2, 1, 2);
}

export function drawRangedArms(c: CanvasRenderingContext2D, h: Hero, pose: RangedWeaponPose): void {
  if (h.weapon === 'blade' || h.hp <= 0) return;
  arm(c, { x: -3, y: -25 }, pose.offElbow, pose.offHand, false);
  arm(c, { x: 4, y: -25 }, pose.elbow, pose.hand, false);
}

/** Qing Ling's source sheets keep her far arm folded across the waist. Pose only
 * the near sleeve, from the actual shoulder in the selected source frame. */
export function jadeSleeve(pose: RangedWeaponPose, shoulder: Point): RangedWeaponPose {
  const upper=9, lower=10;
  const dx=pose.hand.x-shoulder.x, dy=pose.hand.y-shoulder.y;
  const raw=Math.hypot(dx,dy)||1, reach=Math.min(upper+lower-.20,Math.max(2,raw));
  const ux=dx/raw,uy=dy/raw;
  const hand={x:shoulder.x+ux*reach,y:shoulder.y+uy*reach};
  const along=(upper*upper-lower*lower+reach*reach)/(2*reach);
  const bend=Math.sqrt(Math.max(0,upper*upper-along*along));
  const elbow={x:shoulder.x+ux*along-uy*bend,y:shoulder.y+uy*along+ux*bend};
  return {...pose,hand,staffGrip:hand,elbow};
}

export function drawJadeSleeve(c: CanvasRenderingContext2D, shoulder: Point, pose: RangedWeaponPose) {
  const {hand,elbow}=pose;
  const sleeve=(a:Point,b:Point,width:number,ink:string)=>{
    const steps=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)));
    c.fillStyle=ink;
    for(let i=0;i<=steps;i++) c.fillRect(Math.round(mix(a.x,b.x,i/steps)-width/2),Math.round(mix(a.y,b.y,i/steps)-width/2),width,width);
  };
  const cuff={x:mix(elbow.x,hand.x,.78),y:mix(elbow.y,hand.y,.78)};
  sleeve(shoulder,elbow,6,'#20383a'); sleeve(shoulder,elbow,4,'#79988a');
  sleeve(elbow,cuff,5,'#294642'); sleeve(elbow,cuff,3,'#b0c5b5');
  sleeve(cuff,hand,3,'#385652');
  c.fillStyle='#caac91'; c.fillRect(Math.round(hand.x)-1,Math.round(hand.y)-1,3,2);
}
