const ENCODER = new TextEncoder();
const DECODER = new TextDecoder();
const PIPE_ORIGIN = 'https://ppng.io';
const MAX_ENCODED = 160_000;
const wait = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
const hex = (buffer: ArrayBuffer) => Array.from(new Uint8Array(buffer), byte => byte.toString(16).padStart(2, '0')).join('');

type Envelope = { key?: string; payload: unknown; acceptGzip?: boolean };
const GZIP_MIN_BYTES = 4096;

export async function gzipCoopBytes(input: Uint8Array<ArrayBuffer>) {
  const stream = new Blob([input]).stream().pipeThrough(new CompressionStream('gzip'));
  return new Response(stream).arrayBuffer();
}

export async function inflateCoopText(bytes: ArrayBuffer) {
  const reader = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();
  const decoder = new TextDecoder();
  let size = 0, text = '';
  while (true) {
    const chunk = await reader.read();
    if (chunk.done) return text + decoder.decode();
    size += chunk.value.byteLength;
    if (size > MAX_ENCODED) {
      await reader.cancel();
      throw new Error('联机数据太长。');
    }
    text += decoder.decode(chunk.value, {stream:true});
  }
}

// Discovery has one lane; admitted seats each have a separate lane so the
// three guest game streams do not compete for one receiver.
export class CoopPipe {
  private aborts = new Set<AbortController>();
  private closed = false;
  private answering = 0;
  private canInflate = typeof DecompressionStream !== 'undefined';
  private canCompress = typeof CompressionStream !== 'undefined';

  private constructor(private root: string, private key: CryptoKey) {}

  static async open(room: string) {
    const secret = Uint8Array.from(room.slice(3).match(/../g) ?? [], digit => parseInt(digit, 16));
    const key = await crypto.subtle.importKey('raw', secret, 'AES-GCM', false, ['encrypt', 'decrypt']);
    const hash = hex(await crypto.subtle.digest('SHA-256', ENCODER.encode('starhop-coop.v1/' + room)));
    return new CoopPipe(PIPE_ORIGIN + '/starhop-coop-v1/' + hash, key);
  }

  async available() {
    return /^\d+\.\d+/.test(await this.transfer(PIPE_ORIGIN + '/version', undefined, 4200));
  }

  private async seal(message: Envelope, acceptGzip = false) {
    let input = ENCODER.encode(JSON.stringify(message));
    if (input.length > MAX_ENCODED) throw new Error('联机数据太长。');
    if (acceptGzip && input.length >= GZIP_MIN_BYTES && this.canCompress) {
      try { input = new Uint8Array(await gzipCoopBytes(input)); }
      catch { this.canCompress = false; }
    }
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const bytes = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, this.key, input));
    let binary = String.fromCharCode(...iv);
    for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
    const result = btoa(binary);
    if (result.length > MAX_ENCODED) throw new Error('联机数据太长。');
    return result;
  }

  private async openMessage(text: string, acceptGzip = false): Promise<Envelope> {
    if (text.length > MAX_ENCODED) throw new Error('联机数据太长。');
    const bytes = Uint8Array.from(atob(text), char => char.charCodeAt(0));
    const clear = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: bytes.slice(0, 12) }, this.key, bytes.slice(12));
    const bytesClear = new Uint8Array(clear);
    if (acceptGzip && bytesClear[0] === 0x1f && bytesClear[1] === 0x8b) return JSON.parse(await inflateCoopText(clear));
    return JSON.parse(DECODER.decode(clear));
  }

  private async transfer(url: string, payload?: string, timeout = 7200, operation?: AbortSignal) {
    if (this.closed) throw new Error('房间已关闭。');
    const controller = new AbortController();
    const cancel = () => controller.abort();
    if (operation?.aborted) cancel();
    operation?.addEventListener('abort', cancel, { once: true });
    this.aborts.add(controller);
    const timer = setTimeout(cancel, timeout);
    try {
      const response = await fetch(url, payload === undefined
        ? { signal: controller.signal }
        : { method: 'POST', body: payload, signal: controller.signal });
      if (!response.ok) throw new Error('备用联机线路暂未连接。');
      const stream = response.body?.getReader();
      if (!stream) {
        const text = await response.text();
        if (text.length > MAX_ENCODED) throw new Error('联机数据太长。');
        return text;
      }
      const decoder = new TextDecoder();
      let text = '';
      let size = 0;
      while (true) {
        const { value, done } = await stream.read();
        if (done) return text + decoder.decode();
        size += value.byteLength;
        if (size > MAX_ENCODED) {
          void stream.cancel();
          throw new Error('联机数据太长。');
        }
        text += decoder.decode(value, { stream: true });
      }
    } finally {
      clearTimeout(timer);
      operation?.removeEventListener('abort', cancel);
      this.aborts.delete(controller);
    }
  }

  async listen(lane: string, handle: (payload: unknown) => unknown) {
    while (!this.closed) {
      try {
        const message = await this.openMessage(await this.transfer(this.root + '/' + lane, undefined, 80_000));
        if (typeof message.key !== 'string' || !/^[0-9a-f]{32}$/.test(message.key)) continue;
        const reply = handle(message.payload);
        // Reopen the seat lane while a world reply is compressed or in flight.
        // The recipient key belongs to this request, so replies may arrive independently.
        if (this.answering < 12) {
          this.answering++;
          void this.seal({ payload: reply }, message.acceptGzip === true)
            .then(answer => this.transfer(this.root + '/a/' + message.key, answer))
            .catch(() => {}).finally(() => this.answering--);
        }
      } catch {
        if (!this.closed) await wait(360);
      }
    }
  }

  async request(lane: string, payload: unknown) {
    const key = hex(crypto.getRandomValues(new Uint8Array(16)).buffer);
    const operation = new AbortController();
    try {
      const answer = this.transfer(this.root + '/a/' + key, undefined, 7200, operation.signal);
      const acceptGzip = this.canInflate;
      void this.seal({ key, payload, acceptGzip }).then(body => this.transfer(this.root + '/' + lane, body, 7200, operation.signal))
        .catch(() => operation.abort());
      // An authenticated reply already proves delivery. A slow relay POST
      // receipt must not hold the next input or world request.
      const wire = await answer;
      try { return (await this.openMessage(wire, acceptGzip)).payload; }
      catch (error) {
        this.canInflate = false; // The next retry can use the original encrypted JSON envelope.
        throw error;
      }
    } finally {
      operation.abort();
    }
  }

  close() {
    this.closed = true;
    for (const controller of this.aborts) controller.abort();
  }
}
