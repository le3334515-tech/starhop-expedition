import { WEAPONS, type Hero, type Projectile, type Vec, type WeaponArchetype, type WeaponId } from './types';
import { drawMaterialWeapon } from './material-weapon-art';

type VariantWeapon = Exclude<WeaponId, WeaponArchetype>;
const LINE = '#253233';
const LIGHT = '#ece6d2';

export function isVariantWeapon(weapon: WeaponId | undefined): weapon is VariantWeapon {
  if (!weapon) return false;
  const definition = WEAPONS[weapon];
  return !!definition && definition.archetype !== weapon;
}

function shape(c: CanvasRenderingContext2D, points: readonly number[], color: string, border = LINE) {
  c.beginPath();
  c.moveTo(points[0], points[1]);
  for (let i = 2; i < points.length; i += 2) c.lineTo(points[i], points[i + 1]);
  c.closePath();
  c.fillStyle = color;
  c.fill();
  c.strokeStyle = border;
  c.lineWidth = 1;
  c.stroke();
}

function line(c: CanvasRenderingContext2D, points: readonly number[], color: string, width = 1) {
  c.beginPath();
  c.moveTo(points[0], points[1]);
  for (let i = 2; i < points.length; i += 2) c.lineTo(points[i], points[i + 1]);
  c.strokeStyle = color;
  c.lineWidth = width;
  c.stroke();
}

function stone(c: CanvasRenderingContext2D, x: number, y: number, r: number, color: string) {
  c.beginPath();
  c.arc(x,y,r,0,Math.PI * 2);
  c.fillStyle = color;
  c.fill();
  c.lineWidth = 1;
  c.strokeStyle = LINE;
  c.stroke();
}

/** Shen Xiao's cuts leave a thin, silver feather at the edge of his sword. */
export function drawWillowCut(c: CanvasRenderingContext2D, step: number, progress: number) {
  const heavy = step === 3;
  const reverse = step === 2;
  const reach = heavy ? 74 : 57;
  const end = -.89 + progress * 1.78;
  c.save();
  c.translate(8, -25);
  if (reverse) c.scale(1, -1);
  c.globalAlpha *= strikeFlash(progress) * .95;
  c.rotate(end * .43);
  shape(c,[16,-26,38,-22,reach-10,-3,reach,14,reach-12,6,37,-10,18,-17],
    '#8ac0c8','#344d5b');
  line(c,[22,-21,38,-16,reach-9,1,reach,14],'#e0eed9',heavy ? 2.5 : 1.4);
  for (let i = 0; i < (heavy ? 6 : 4); i++) {
    const x = reach - 10 + i * 5 + progress * 10;
    const y = 9 + i * i * .6;
    c.fillStyle = i % 2 ? '#daca98' : '#b6dcd5';
    c.fillRect(Math.round(x), Math.round(y), heavy ? 4 : 3, 2);
  }
  c.restore();
}

/** A brief half-moon opens beside Lu Zhaoyue's staff before each cast. */
export function drawMoonfireCast(c: CanvasRenderingContext2D, step: number, progress: number) {
  const charged = step === 3;
  const radius = (charged ? 14 : 10) + progress * 4;
  c.save();
  c.translate(charged ? 24 : 22, charged ? -35 : -30);
  c.globalAlpha *= strikeFlash(progress) * .88;
  c.rotate(-.36 + progress * .72);
  // Two nested flames leave an opening toward the launched shot.
  c.beginPath(); c.moveTo(radius*.75,-radius);
  c.quadraticCurveTo(-radius*1.62,-radius*.24,-radius*.40,radius);
  c.quadraticCurveTo(-radius*.63,-radius*.18,radius*.75,-radius);
  c.fillStyle='#c5a9d2'; c.fill();
  line(c,[-3,7,-6,2,-4,-4,1,-8],'#eddbcd',1.5);
  shape(c,[-2,2,2,-5,5,-7,4,-2,10,-3,4,4], '#e4b18d','#986777');
  if (charged) line(c,[4,8,11,4,15,-2], '#d9a6ba',1.6);
  c.restore();
}

/** The lance's bright edge starts at the thrust and runs along the shaft's axis. */
export function drawSpearThrust(c: CanvasRenderingContext2D, step: number, progress: number) {
  const beat = strikeFlash(progress);
  if (!beat) return;
  const heavy = step === 3, tip = (heavy ? 86 : 66) + Math.round(progress * 11);
  c.save(); c.globalAlpha *= beat;
  c.translate(0,step === 2 ? -25 : -23);
  shape(c,[21,2,37,-1,tip-13,-3,tip,0,tip-14,2,37,2], '#c8b681','#867856');
  line(c,[32,1,tip-13,-1,tip,0], '#f2ead0',heavy ? 2 : 1.4);
  line(c,[23,5,39,4,48,3], '#92b7b1',1.3);
  if (heavy) line(c,[47,-5,56,-7,54,-4,68,-4], '#e8cc8b',1.5);
  c.restore();
}

/** The open leading edge of the pressure wave follows the grounded punch. */
export function drawMountainPunch(c: CanvasRenderingContext2D, step: number, progress: number) {
  const beat = strikeFlash(progress);
  if (!beat) return;
  const heavy = step === 3;
  c.save(); c.globalAlpha *= beat;
  c.translate((heavy ? 35 : 27)+Math.round(progress*9),step === 2 ? -36 : heavy ? -30 : -37);
  c.scale(heavy ? 1.28 : 1,heavy ? 1.22 : 1);
  shape(c,[-8,-9,1,-8,8,-4,12,0,7,6,0,9,-6,8,1,5,6,0,0,-5], '#d8a374','#84634e');
  line(c,[-4,-8,2,-7,8,-3,10,0,6,4], '#f4d7a3',1.5);
  line(c,[-14,-4,-6,-3], '#e3b689',1.5);
  if (heavy) {
    line(c,[11,-9,17,-5,20,0,17,5], '#c58b60',1.5);
    c.fillStyle='#efc894'; c.fillRect(23,-2,3,2);
  }
  c.restore();
}

export function drawTigerGauntlet(c: CanvasRenderingContext2D, step: number, progress: number) {
  const heavy = step === 3;
  const flash = strikeFlash(progress);
  if (flash === 0) return;
  c.save();
  c.translate((heavy ? 35 : 30) + progress * 8, heavy ? -32 : -36);
  c.globalAlpha *= flash;
  const reach = heavy ? 37 : 27;
  for (let i = 0; i < 3; i++) {
    const x = i * 4, y = i * (heavy ? 11 : 8) - (heavy ? 13 : 10);
    shape(c, [x,y+10,x+7,y+3,x+reach-13,y-4,x+reach,y-7,x+reach-9,y+2,x+13,y+9],
      i === 1 ? '#f5d599' : '#cd9764', '#613e38');
    line(c, [x+10,y+4,x+reach-10,y-4], '#f0c88e', heavy ? 1.7 : 1.2);
  }
  const fragments = [[22,-13],[31,11],[39,-12],[42,9]];
  for (const [i, [x, y]] of fragments.slice(0, heavy ? 4 : 2).entries()) {
    const px = Math.round(x + progress * (i + 4)), py = Math.round(y * (1 + progress * .30));
    const size = i % 2 ? 3 : 2;
    shape(c, [px-size,py,px,py-size,px+size,py,px+1,py+size], i % 2 ? '#b6724c' : '#eeba7d','#614443');
  }
  c.restore();
}

export function strikeFlash(p: number): number {
  return p < .15 ? .30 + p/.15*.70 : Math.max(0,1-(p-.15)/.48);
}

function wristAccent(c: CanvasRenderingContext2D, weapon: VariantWeapon, p: number, heavy: boolean) {
  const alpha = strikeFlash(p);
  if (!alpha || weapon==='ironGauntlet') return;
  const ink = WEAPONS[weapon].color;
  c.save(); c.globalAlpha *= alpha;
  const travel = Math.round(p * 12);
  switch (weapon) {
    case 'willowSword':
      // Sharply tapered foil, with a second short edge catching its flex.
      shape(c,[27,1,40,-3,52+travel,-5,67+travel,-2,53+travel,-2,40,0], '#a6c4a6','#647e75');
      line(c,[33,-1,44,-3,53+travel,-4,66+travel,-2],'#e9eccf',heavy ? 2 : 1.3);
      if (heavy) line(c,[35,4,46,2,54+travel,2],ink,1.4);
      break;
    case 'halberd':
      c.translate(29,0);
      c.rotate(-.6+Math.min(1,p/.45)*.85);
      shape(c,[-15,-21,-2,-20,11,-15,19,-8,22,3,21,13,16,19,18,8,15,0,9,-8,-1,-15], '#bc976c','#7d6856');
      line(c,[-9,-20,1,-18,12,-12,19,-4,21,4,20,12],'#f0d7a4',heavy ? 2.5 : 1.6);
      if (heavy) line(c,[16,-17,24,-10,26,-4],ink,1.6);
      break;
    case 'moonMirror':
      c.translate(12,0); c.strokeStyle=ink; c.lineWidth=1.5;
      c.beginPath(); c.ellipse(0,0,6+travel*.3,11+travel*.26,-.4,-1.48,1.44); c.stroke();
      shape(c,[0,-1,9,-2,24+travel,0,9,2,0,1],'#f1e6da','#bca5ba');
      if (heavy) line(c,[2,-6,10,-4,16,-3],'#cabbd7',1.35);
      break;
    case 'frostStaff':
      c.translate(29,0);
      line(c,[-3,-8,2,-4,4,0,1,4,-4,7],'#a1d0da',1.6);
      shape(c,[1,0,8,-3,22+travel,0,8,2], '#dcebea','#86aebc');
      line(c,[6,-5,8,-9,13,-12],ink,1.4);
      if (heavy) line(c,[7,4,12,8,17,8],ink,1.4);
      break;
    case 'silkFan':
      // Three separate blade points bite across the arc as the wrist turns.
      shape(c,[18,-11,25+travel,-15,35+travel,-16,27+travel,-13],'#deebe0','#739c94');
      line(c,[19,-5,29+travel,-8,35+travel,-8],'#a7cfb6',1.5);
      if(heavy) line(c,[14,1,21+travel,-2,28+travel,-2],'#c9ded2',1.45);
      break;
    case 'prayerBeads':
      c.strokeStyle='#b69461'; c.lineWidth=1.3;
      c.beginPath(); c.moveTo(3,5); c.quadraticCurveTo(10,10,22+travel,-4); c.stroke();
      for (let i=0;i<3;i++) stone(c,10+travel+i*4,5-i*i,1.8, i===2 ? '#f3d69e' : '#bc9b6e');
      break;
    case 'swallowDart':
      shape(c,[4,1,13,-4,25+travel,-3,18,0,9,0,5,4], '#c3977c','#795e57');
      line(c,[10,1,17,-2,25+travel,-3],LIGHT,1.35);
      line(c,[6,5,14,2,20+travel,2],ink,1.2); break;
    case 'jadeNeedle':
      line(c,[6,1,14,-1,35+travel,-1],'#83b6a8',1.6);
      line(c,[17,-1,36+travel,-1],LIGHT,1);
      shape(c,[9,-4,12,-2,15,-3,13,-1,10,-1],ink,'#83ab99');
      break;
    case 'reedJavelin':
      line(c,[6,2,18,2,32+travel,0], '#a2b598',1.7);
      line(c,[9,5,18,5,23,4], '#bfc6a4');
      shape(c,[15,-4,24,-3,33+travel,-3,25,-1],LIGHT,'#8fa593'); break;
  }
  c.restore();
}

export function drawCharacterProjectile(c: CanvasRenderingContext2D, p: Projectile, now: number): boolean {
  if (p.kind === 'fan' && p.weapon === 'fan' && p.ownerCharacter === 'wheel') {
    // One folded-paper wave. Its outside edge matches the wide fan hitbox.
    c.save(); c.rotate(Math.atan2(p.vy,p.vx));
    const radius = p.h * .43, tip = p.w * .4;
    shape(c,[-tip-3,0,-2,-radius*.83,tip*.56,-radius,tip,-radius*.48,tip+1,0,tip,radius*.48,tip*.56,radius,-2,radius*.83],
      '#749e91','#496f69');
    for (const k of [-1,0,1]) line(c,[-tip-1,0,tip*.58,k*radius*.9], '#b5cfb7',1);
    line(c,[tip*.52,-radius,tip,-radius*.48,tip+1,0,tip,radius*.48,tip*.52,radius], '#e2e5c9',p.style==='charged' ? 2 : 1.5);
    line(c,[-tip-10,-3,-tip-4,-4], '#a0c5b3');
    c.restore(); return true;
  }
  if (p.kind !== 'ember') return false;
  if ((p.weapon==='spear' && p.ownerCharacter==='spear') || (p.weapon==='fist' && p.ownerCharacter==='monk')) {
    // A projectile buff lends these melee weapons a small travelling echo.
    c.save(); c.rotate(Math.atan2(p.vy,p.vx));
    if (p.weapon==='spear') {
      shape(c,[-19,1,-8,-1,1,-2,12,0,1,2,-6,1], '#c5b786','#867657');
      line(c,[-11,1,2,-1,11,0], '#ece3c7',1.2);
    } else {
      line(c,[-11,3,-6,1,0,0], '#c59569',1.7);
      shape(c,[-6,-4,0,-5,5,-3,9,0,4,3,5,0,0,-2], '#d6ac7f','#956f55');
    }
    c.restore(); return true;
  }
  const moonfire = p.ownerCharacter === 'staff' && p.weapon === 'ember';
  const snowFeather = p.ownerCharacter === 'blade' && p.weapon === 'blade';
  if (!moonfire && !snowFeather) return false;
  const charged = p.style === 'charged';
  c.save();
  c.rotate(Math.atan2(p.vy, p.vx));
  if (snowFeather) {
    shape(c,[-25,0,-10,-3,5,-4,16,0,6,4,-13,2],'#99c7cc','#344d5b');
    line(c,[-19,0,13,0],'#e0eed9');
    line(c,[-8,1,-18,6,-9,4],'#c6b182',1.4);
  } else {
    const r = charged ? 14 : 10;
    c.scale(r/10,r/10);
    shape(c,[-24,3,-14,0,-20,-5,-9,-4,-5,-8,3,-10,10,-7,14,-1,13,5,7,9,0,10,-7,7,-14,6,-10,4],
      '#8b709b','#554657');
    c.beginPath(); c.moveTo(-3,-8); c.quadraticCurveTo(10,-12,13,-1);
    c.quadraticCurveTo(13,7,3,9); c.quadraticCurveTo(13,-1,-3,-8);
    c.fillStyle = '#ebdcd6'; c.fill();
    shape(c,[-10,3,-5,-1,-1,-2,4,-5,3,-1,7,0,0,4], '#eab28d','#966976');
    const drift=Math.round(Math.sin(now*15+p.id)*2);
    line(c,[-23,6+drift,-19,5+drift,-15,4], '#c2a0ba',1.5);
  }
  c.restore();
  return true;
}

function drawWeaponShape(c: CanvasRenderingContext2D, weapon: VariantWeapon) {
  if (drawMaterialWeapon(c, weapon)) return;
  const tint = WEAPONS[weapon].color;
  switch (weapon) {
    case 'willowSword':
      line(c,[-8,0,5,0],'#816854',3); line(c,[4,-4,4,4],'#dac982',2);
      shape(c,[5,-2,12,-4,26,-3,40,-6,32,0,14,2,5,2],tint);
      line(c,[7,0,24,-1,37,-5],LIGHT);
      break;
    case 'swallowDart':
      shape(c,[-7,0,-11,-6,-3,-3,4,-3,14,0,4,3,-3,3,-11,6],tint);
      line(c,[-4,0,12,0],LIGHT);
      break;
    case 'frostStaff':
      line(c,[-22,2,-9,1,3,-1,24,0],'#424a58',3);
      line(c,[-20,1,-7,0,9,-2,23,-1],'#a09274');
      line(c,[12,-1,22,-6,29,-5,32,-1],'#83adbd',2);
      line(c,[16,0,22,4,30,6,33,2],'#83adbd',2);
      shape(c,[23,-3,32,-6,37,0,32,5,23,2],tint);
      line(c,[27,-2,33,-3,35,0],LIGHT);
      break;
    case 'moonMirror':
      line(c,[-8,0,4,0],'#8c7858',3);
      stone(c,10,0,10,'#b69b72');
      stone(c,10,0,7,tint);
      line(c,[6,-5,12,4],LIGHT,2);
      stone(c,10,-9,1.4,'#f0d29c');
      break;
    case 'jadeNeedle':
      shape(c,[-8,1,-7,-1,21,-1,26,0,21,1],tint);
      line(c,[-5,-2,-5,2],'#d5ab78',2);
      line(c,[2,0,24,0],LIGHT);
      break;
    case 'silkFan':
      // A short jade grip carries three staggered steel pinions on one side.
      // The exposed notches keep the tines legible at touch-screen scale.
      shape(c,[-9,0,-7,-2,5,-2,7,2,-6,3],'#579382','#324c4b');
      line(c,[-7,0,1,-1],'#aac6b1',1.6);
      shape(c,[2,-4,6,-5,9,-2,8,3,4,4,3,1],'#bca779','#4e5547');
      shape(c,[7,-3,12,-6,19,-8,25,-14,34,-19,31,-12,24,-6,18,-3,13,-2,7,2],'#809c9b');
      shape(c,[8,-1,14,-3,21,-3,29,-8,27,-4,20,1,14,2,8,2],'#80a89c');
      shape(c,[8,2,13,1,17,2,24,-1,21,3,14,6,9,5],'#597f77');
      line(c,[10,-3,19,-6,26,-12,32,-16],'#dce8df',1.6);
      line(c,[12,0,19,-1,25,-4],'#c8ddd1',1.3);
      line(c,[12,4,16,4,20,2],'#a6c6b8',1);
      break;
    case 'reedJavelin':
      line(c,[-20,1,28,0],'#886e4c',2.5);
      line(c,[-19,0,28,-1],'#dae1af');
      shape(c,[22,0,28,-4,37,-2,44,0,35,4,28,4],tint);
      line(c,[26,0,41,0],LIGHT);
      shape(c,[-14,1,-21,-4,-18,1,-24,5,-16,3],'#638f78');
      break;
    case 'halberd':
      line(c,[-20,1,25,0],'#765646',3);
      line(c,[-20,0,24,-1],'#cfad7e');
      line(c,[18,-4,18,4],'#edc68d',2);
      shape(c,[21,-3,24,-11,30,-16,34,-12,30,-8,29,-3,42,0,30,4,27,12,21,7,23,1],tint);
      line(c,[24,-9,29,-15,33,-12],LIGHT);
      line(c,[26,2,29,9,26,10],LIGHT);
      break;
    case 'ironGauntlet':
      shape(c,[-5,-4,1,-6,10,-5,14,-2,14,4,7,7,-5,5],tint);
      shape(c,[5,-5,8,-7,11,-5,14,-3,14,0,8,1,6,0],'#edc186');
      line(c,[-2,-4,-2,5],'#544855',2);
      line(c,[10,-5,10,0],'#886040');
      break;
    case 'prayerBeads':
      c.beginPath(); c.ellipse(6,3,10,7,.32,0,Math.PI*2);
      c.lineWidth=1; c.strokeStyle='#dbc390'; c.stroke();
      for (let i=0;i<9;i++) {
        const a=i*Math.PI*2/9;
        const x=6+Math.sin(a)*9, y=3+Math.cos(a)*6;
        stone(c,x,y,i===1 ? 2.35 : 1.85,i%3===0 ? '#876b56' : tint);
      }
      break;
  }
}

/** The grip is placed by the character pose. The weapon follows it in both the room and the race ghost. */
export function drawHeldVariant(c: CanvasRenderingContext2D, hero: Hero, grip: Vec, rotation: number, progress: number) {
  const weapon = hero.weapon;
  if (hero.hp<=0 || !isVariantWeapon(weapon)) return;
  const thrown = weapon==='swallowDart' || weapon==='jadeNeedle' || weapon==='reedJavelin';
  // The projectile already left the palm. Draw a fresh weapon during recovery.
  c.save();
  c.translate(Math.round(grip.x),Math.round(grip.y));
  c.rotate(rotation);
  if (hero.attackTimer > 0) wristAccent(c,weapon,progress,hero.attackStep===3);
  if (!thrown || hero.attackTimer<=0 || progress<.16 || progress>=.66) {
    if (thrown && hero.attackTimer>0 && progress>=.66) c.globalAlpha *= Math.min(1,(progress-.66)/.19);
    drawWeaponShape(c,weapon);
  }
  c.restore();
}

/** Only variant projectiles draw here, so the original three weapons retain their existing animation. */
export function drawVariantProjectile(c: CanvasRenderingContext2D, p: Projectile): boolean {
  const weapon = p.weapon;
  if (!isVariantWeapon(weapon)) return false;
  const tint = WEAPONS[weapon].color;
  const charged = p.style==='charged';
  const angle = Math.atan2(p.vy,p.vx);
  c.save();
  c.rotate(angle);
  if (weapon==='frostStaff') {
    c.scale(charged ? 1.15 : 1,charged ? 1.15 : 1);
    shape(c,[-20,0,-6,-3,-3,-6,4,-4,17,0,3,4,-6,3,-3,2], '#91b6c4','#577989');
    shape(c,[-7,0,0,-2,14,0,1,1], '#e5e9dc','#b3cdd2');
    line(c,[-14,-4,-9,-4,-3,-2], '#a5c8ce',1.4);
    line(c,[-15,4,-9,3,-5,2], '#9bbcaf',1.3);
  } else if (weapon==='jadeNeedle') {
    line(c,[-23,1,-11,0,10,0], '#87ad9e',2);
    shape(c,[-10,1,-6,-2,4,-2,14,0,1,1], '#b6cfbe','#628a80');
    line(c,[-7,0,13,0], '#f0ead1',1.1);
    shape(c,[-17,-4,-12,-2,-8,0,-13,-1], '#77a18f','#618578');
    if(charged) line(c,[-15,4,-11,3,-9,2], '#a8cdb0',1.4);
  } else if (weapon==='reedJavelin') {
    line(c,[-31,2,-19,1,1,0], '#8ca395',1.25);
    c.save(); c.scale(.70,.70); drawWeaponShape(c,weapon); c.restore();
    // The pennon streams behind the weight of the steel head.
    shape(c,[-4,-1,-12,-4,-19,-2,-14,-2,-8,1], '#b5ba8d','#737e60');
    line(c,[-2,0,16,-1,24,0], '#dddcc5',1.1);
  } else if (weapon==='silkFan') {
    if(charged) c.scale(1.20,1.24);
    // The leading quill owns the point. The two shorter echoes shear away
    // behind it, so the attack reads in monochrome as well as in jade.
    shape(c,[-17,-9,-8,-9,-3,-7,-8,-6], '#9ab7a8','#557b74');
    shape(c,[-19,9,-13,5,-5,4,-10,8], '#92b9a6','#557b74');
    shape(c,[-16,3,-7,-3,-3,-4,-4,-6,4,-7,8,-8,7,-10,18,-11,14,-5,7,-1,8,0,0,3,0,5,-9,6,-6,3],
      '#8db8a5','#476f68');
    shape(c,[-12,4,-2,-1,5,-4,17,-10,12,-5,3,0,-5,3], '#dbece0','#b4cdc1');
    line(c,[-17,7,-9,3,0,-1,10,-6], '#e5eee6',charged ? 1.8 : 1.25);
  } else if (weapon==='moonMirror') {
    const span=charged ? 17 : 12;
    shape(c,[-39,0,-12,-2,7,-3,20,0,7,3,-12,2], '#c4b6c7','#827f96');
    line(c,[-31,0,17,0], '#f3e9d8',charged ? 2.2 : 1.4);
    c.strokeStyle='#d0bfd2'; c.lineWidth=1.6;
    c.beginPath(); c.ellipse(6,0,3.5,span,-.17,-1.35,1.46); c.stroke();
    c.beginPath(); c.ellipse(0,0,2,span*.70,-.17,1.7,3.9); c.stroke();
    c.fillStyle='#f1e8dc'; c.fillRect(6,-span,2,2);
  } else if (weapon==='prayerBeads') {
    const lift=p.returning ? -1 : 1;
    c.scale(1,lift);
    c.strokeStyle=p.returning ? '#c7a678' : '#ae926b'; c.lineWidth=1.25;
    c.beginPath(); c.moveTo(-19,4); c.quadraticCurveTo(-12,-4,-1,0); c.stroke();
    stone(c,1,0,p.returning ? 5.5 : 5,'#a57853');
    line(c,[-2,-3,1,-4,4,-3], '#edd5a3',1.6);
    c.fillStyle='#533e38'; c.fillRect(2,0,2,2);
    if (p.returning) { c.fillStyle=tint; c.fillRect(-11,0,2,2); }
  } else if (weapon==='swallowDart') {
    const bank=Math.sin(p.rotation ?? 0) * .32;
    c.rotate(bank);
    line(c,[-22,3,-12,1,-3,1], p.returning ? '#ebcb98' : '#b58f76',1.25);
    shape(c,[-15,-9,-4,-4,4,-4,13,-1,3,0,-4,-1], '#b58976','#685251');
    shape(c,[-14,8,-7,2,0,-2,13,-1,4,2,-4,3], '#d5b593','#7e675b');
    line(c,[-10,5,-4,1,10,-1], '#eeead7',1.35);
    if (p.returning) line(c,[-14,-7,-20,-5,-23,-1], '#ddc6a4',1.35);
  } else if (weapon==='willowSword') {
    shape(c,[-18,1,-6,-2,6,-3,16,0,3,0,-7,2], '#b1c39f','#72877a');
    line(c,[-12,1,5,-2,15,0], LIGHT,1.2);
  } else if (weapon==='halberd') {
    shape(c,[-12,-6,-2,-7,7,-5,13,0,8,5,8,1,2,-2,-6,-4], '#b69573','#746658');
    line(c,[-5,-6,5,-4,12,0], '#e9cf9e',1.4);
  } else {
    // Short brass knuckle marks for the gauntlet's bonus shots.
    line(c,[-12,-3,-3,-3,4,-2],tint,1.6);
    shape(c,[-5,1,3,-1,7,0,10,3,3,2,-5,3], '#e8c18e','#947259');
  }
  c.restore();
  return true;
}

