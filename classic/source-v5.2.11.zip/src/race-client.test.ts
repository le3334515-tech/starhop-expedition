import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { RaceSession, raceRoomFromUrl, raceInviteUrl } from './race-client';
import { parseRaceResponse, RACE_RULESET, sanitizeRaceFrame, type RaceFrame, type RaceResponse } from './race-types';

const config = { seed: 42, modifier: 'standard' as const, weapon: 'ember' as const };
const frame = (seq = 1, x = 100, roomIndex = 0): RaceFrame => ({ seq, roomIndex, x, y: 412, vx: 0, vy: 0, facing: 1,
  grounded: true, weapon: 'ember', attackTimer: .1, attackStep: 1, hp: 5, maxHp: 5, level: 1, animation: 1, phase: 'playing', progress: .1, elapsed: 0 });
function response(): RaceResponse {
  return { ok: true, serverNow: Date.now(), selfId: 'host', token: 'token12345678901234567890', room: {
    id: 'room12345678901234567890', epoch: 1, config, ruleset: RACE_RULESET, createdAt: Date.now(), startAt: null, status: 'waiting',
    host: { id: 'host', name: '甲', readyAt: null, lastSeen: Date.now(), frame: null, finishedAt: null },
    guest: { id: 'guest', name: '乙', readyAt: null, lastSeen: Date.now(), frame: null, finishedAt: null },
  } };
}
let current: RaceResponse, requests: Record<string, unknown>[], failOnce: boolean;
beforeEach(() => {
  vi.useFakeTimers(); vi.setSystemTime(100_000); current = response(); requests = []; failOnce = false;
  const values = new Map<string, string>();
  vi.stubGlobal('sessionStorage', { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => values.set(key, value), removeItem: (key: string) => values.delete(key) });
  vi.stubGlobal('fetch', vi.fn(async (_url, options) => {
    requests.push(JSON.parse(options.body));
    if (failOnce) { failOnce = false; throw new TypeError('offline'); }
    current.serverNow = Date.now(); return { ok: true, status: 200, json: async () => structuredClone(current) };
  }));
});
afterEach(() => { vi.clearAllTimers(); vi.useRealTimers(); vi.unstubAllGlobals(); });

describe('online race protocol and clocks', () => {
  it('checks the rule signature and releases a newly admitted seat on a legacy host', async () => {
    current.selfId = 'guest';
    delete current.room.ruleset;
    const race = new RaceSession('https://race.test/api/race');
    await expect(race.join(current.room.id, '乙')).rejects.toThrow('不同版本');
    expect(requests[0]).toMatchObject({ action:'join', ruleset:RACE_RULESET });
    expect(requests[1]).toMatchObject({ action:'leave', token:current.token });
    expect(race.view).toMatchObject({ connection:'error', room:null, selfId:null });
  });
  it('keeps different per-seat roles without changing the common clock or route', async () => {
    current.room.characterSelection = true;
    current.room.host.character = null;
    current.room.guest!.character = 'spear';
    current.room.guest!.frame = { ...frame(), character:'spear', weapon:'halberd' };
    const start = vi.fn(), race = new RaceSession('https://race.test/api/race', { onStart:start });
    await race.create(config, '甲');
    current.room.host.character = 'wheel';
    await race.chooseCharacter('wheel');
    expect(requests.at(-1)).toMatchObject({ action:'character', character:'wheel' });
    expect(race.view.self?.character).toBe('wheel');
    expect(race.opponentFrame()).toMatchObject({ character:'spear', weapon:'halberd' });
    current.room.startAt = Date.now() + 5000;
    await race.ready();
    await vi.advanceTimersByTimeAsync(5002);
    expect(start).toHaveBeenCalledWith({ ...config, character:'wheel', weapon:'fan' }, 105_000);
    race.updateFrame({ ...frame(3), weapon:'jadeNeedle' });
    await vi.advanceTimersByTimeAsync(220);
    expect(requests.at(-1)?.frame).toMatchObject({ character:'wheel', weapon:'jadeNeedle' });
    await race.leave();
  });

  it('allows classic readiness when the room does not provide character selection', async () => {
    const race = new RaceSession('https://race.test/api/race');
    await race.create(config, '甲');
    expect(race.view.room?.characterSelection).toBeUndefined();
    const previous = requests.length;
    await expect(race.chooseCharacter('wheel')).rejects.toThrow('经典旅人');
    expect(requests).toHaveLength(previous);
    await race.ready();
    expect(requests.at(-1)?.action).toBe('ready');
    expect(sanitizeRaceFrame({ ...frame(), weapon:'silkFan' }).weapon).toBe('blade');
    await race.leave();
  });

  it('starts once at the shared server deadline rather than when either ready reply arrives', async () => {
    const start = vi.fn(), race = new RaceSession('https://race.test/api/race', { onStart: start });
    await race.create(config, '甲');
    current.room.startAt = Date.now() + 5000; current.room.status = 'countdown';
    current.room.host.readyAt = Date.now(); current.room.guest!.readyAt = Date.now();
    await race.ready(); expect(start).not.toHaveBeenCalled(); expect(race.view.countdown).toBe(5);
    await vi.advanceTimersByTimeAsync(4999); race.tick(); expect(start).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(2); race.tick(); expect(start).toHaveBeenCalledTimes(1);
    expect(start).toHaveBeenCalledWith(config, 105_000);
    await vi.advanceTimersByTimeAsync(1000); race.tick(); expect(start).toHaveBeenCalledTimes(1);
    expect(race.elapsed()).toBeCloseTo(1.001);
    await race.leave();
  });

  it('uses the request midpoint to correct a five-second client clock difference', async () => {
    vi.stubGlobal('fetch', async () => {
      const sent = Date.now(); vi.setSystemTime(sent + 80);
      const r = response(); r.serverNow = sent + 40 + 5000;
      return { ok: true, json: async () => r };
    });
    const race = new RaceSession('https://race.test/api/race'); await race.create(config, '甲');
    expect(race.estimatedServerNow() - Date.now()).toBe(5000);
    await race.leave();
  });

  it('buffers received positions and never blends across different rooms', async () => {
    current.room.guest!.frame = frame(1, 100); current.room.guest!.lastSeen = Date.now();
    const race = new RaceSession('https://race.test/api/race'); await race.create(config, '甲');
    current.room.guest!.frame = frame(2, 200); current.room.guest!.lastSeen = Date.now() + 200;
    await vi.advanceTimersByTimeAsync(200); await vi.advanceTimersByTimeAsync(100);
    const ghost = race.opponentFrame()!;
    expect(ghost.x).toBeCloseTo(160); expect(ghost.name).toBe('乙'); expect(ghost.stale).toBe(false);
    current.room.guest!.frame = frame(3, 1200, 1); current.room.guest!.lastSeen = Date.now() + 100;
    await vi.advanceTimersByTimeAsync(100);
    expect(race.opponentFrame()!.roomIndex).toBe(1); expect(race.opponentFrame()!.x).toBe(1200);
    await race.leave();
  });

  it('does not make repeated snapshots of the same sequence look like fresh movement', async () => {
    current.room.guest!.frame = frame(1);
    const race = new RaceSession('https://race.test/api/race'); await race.create(config, '甲');
    await vi.advanceTimersByTimeAsync(2200); expect(race.opponentFrame()!.stale).toBe(true);
    current.room.guest!.leftAt = Date.now(); await vi.advanceTimersByTimeAsync(200);
    expect(race.opponentFrame()).toBeNull(); await race.leave();
  });

  it('moves continuously across one-second ghost packets and holds the last prediction during a dropout', async () => {
    let seq=1;
    const moving=()=>({...frame(seq,100+(seq-1)*100),vx:100,elapsed:seq});
    current.selfId='guest';
    current.room.host.frame=moving();
    const race=new RaceSession('https://race.test/api/race');
    await race.join(current.room.id,'乙');
    let previous=race.opponentFrame()!.x, steady=0, measured=0;
    for(let tick=1; tick<=300; tick++) {
      if(tick % 50 === 0) {seq++; current.room.host.frame=moving();}
      await vi.advanceTimersByTimeAsync(20);
      const x=race.opponentFrame()!.x;
      if(tick>105) {
        measured++;
        if(x>previous+.05) steady++;
        expect(x-previous).toBeGreaterThanOrEqual(-.001);
        expect(x-previous).toBeLessThan(4);
      }
      previous=x;
    }
    expect(steady/measured).toBeGreaterThan(.98);
    await vi.advanceTimersByTimeAsync(1600);
    const held=race.opponentFrame()!.x;
    await vi.advanceTimersByTimeAsync(600);
    expect(race.opponentFrame()).toMatchObject({x:held,stale:true});
    await race.leave();
  });

  it('keeps one countdown alarm while the rendering loop ticks', async () => {
    const race=new RaceSession('https://race.test/api/race');
    await race.create(config,'甲');
    current.room.startAt=Date.now()+5000;
    await race.ready();
    const timeouts=vi.spyOn(globalThis,'setTimeout');
    try {
      for(let i=0;i<40;i++) race.tick();
      expect(timeouts).not.toHaveBeenCalled();
    } finally { timeouts.mockRestore(); }
    await race.leave();
  });

  it('locks the first local finish and sends it immediately without waiting for the next exchange', async () => {
    current.room.startAt = Date.now() - 5000; current.room.status = 'racing';
    const race = new RaceSession('https://race.test/api/race'); await race.create(config, '甲'); race.updateFrame(frame(10));
    const before = requests.length; await race.finish(true);
    expect(requests).toHaveLength(before + 1);
    const done = requests.at(-1)!.frame as RaceFrame;
    expect(done.finished).toBe(true); expect(done.won).toBe(true); expect(done.elapsed).toBe(5);
    await vi.advanceTimersByTimeAsync(2000); await race.finish(false);
    expect((requests.at(-1)!.frame as RaceFrame).won).toBe(true);
    expect(race.elapsed()).toBe(5); await race.leave();
  });

  it('recovers a dropped exchange while preserving the race, then cancels traffic on leave', async () => {
    const race = new RaceSession('https://race.test/api/race'); await race.create(config, '甲');
    failOnce = true; await vi.advanceTimersByTimeAsync(200); expect(race.view.connection).toBe('reconnecting');
    await vi.advanceTimersByTimeAsync(200); expect(race.view.connection).toBe('online');
    await race.leave(); const count = requests.length; await vi.advanceTimersByTimeAsync(3000);
    expect(requests).toHaveLength(count); expect(race.view.room).toBeNull();
  });

  it('clears old finished frames and ghost sequences when a new room epoch starts', async () => {
    current.room.startAt = Date.now() - 5000; current.room.status = 'racing'; current.room.guest!.frame = frame(50);
    const race = new RaceSession('https://race.test/api/race'); await race.create(config, '甲'); race.updateFrame(frame(20)); await race.finish(true);
    current.room.epoch = 2; current.room.startAt = null; current.room.status = 'waiting'; current.room.guest!.frame = null;
    await vi.advanceTimersByTimeAsync(1000); expect(race.view.started).toBe(false); expect(race.opponentFrame()).toBeNull();
    race.updateFrame(frame(1)); current.room.guest!.frame = frame(1, 300); current.room.guest!.lastSeen = Date.now() + 200;
    await vi.advanceTimersByTimeAsync(200); expect((requests.at(-1)!.frame as RaceFrame).finished).toBe(false);
    expect(requests.at(-1)!.epoch).toBe(2);
    expect(race.opponentFrame()!.x).toBe(300); await race.leave();
  });

  it('sends only one reset for repeated clicks and includes the current round', async () => {
    const race = new RaceSession('https://race.test/api/race');
    await race.create(config, '甲');
    await Promise.all([race.reset(),race.reset(),race.reset()]);
    expect(requests.filter(request=>request.action==='reset')).toEqual([
      expect.objectContaining({ epoch:1 }),
    ]);
    await race.leave();
  });

  it('rejects broken room messages and normalizes hostile ghost coordinates and strings', () => {
    expect(() => parseRaceResponse({ ...current, selfId: 'spectator' })).toThrow();
    expect(() => parseRaceResponse({ ...current, room: { ...current.room, config: { ...config, modifier: 'evil' } } })).toThrow();
    const clean = sanitizeRaceFrame({ ...frame(), x: Infinity, y: -999999, vx: NaN, roomIndex: 99, weapon: 'gun', facing: -100, progress: 10 });
    expect(clean.x).toBe(-100); expect(clean.y).toBe(-500); expect(clean.vx).toBe(0); expect(clean.roomIndex).toBe(7);
    expect(clean.weapon).toBe('blade'); expect(clean.facing).toBe(-1); expect(clean.progress).toBe(1);
  });

  it('round-trips room invitations without changing the existing solo challenge parser', () => {
    const url = raceInviteUrl('room12345678901234567890', 'https://game.test/classic/?v=4.5#c=old');
    expect(new URL(url).searchParams.get('race')).toBe('room12345678901234567890');
    expect(raceRoomFromUrl('https://game.test/#race=room12345678901234567890')).toBe('room12345678901234567890');
    expect(raceRoomFromUrl(url)).toBe('room12345678901234567890');
    expect(raceRoomFromUrl('https://game.test/#c=old')).toBeNull();
    expect(raceRoomFromUrl('https://game.test/#race=bad')).toBeNull();
  });
});
