import './style.css';
import './hud.css';
import './controls.css';
import './upgrade-ui.css';
import './combat-hud.css';
import './leaderboard-ui.css';
import './route-preview.css';
import { refreshRoutePreview } from './route-preview';
import { UpgradeSelectionGate } from './upgrade-selection';
import './race-ui.css';
import './race-integration.css';
import './mobile-entry.css';
import './coop-ui.css';
import './achievement-ui.css';
import { ACHIEVEMENTS, ExpeditionAchievements, type AchievementMode } from './achievements';
import { achievementBook, achievementFeedback } from './achievement-ui';
import { CoopSession, coopInviteUrl, coopRoomFromUrl, type CoopView, type CoopCharacterId } from './coop-transport';
import { CoopPlay } from './coop-play';
import { COOP_CHARACTERS, COOP_CHARACTER_IDS, awakeningName } from './coop-characters';
import { coopHud, coopLobby, coopResult, getCoopPortrait, renderRoleCards } from './coop-ui';
import { COOP_ELITE_ROOM_INDEX, COOP_WARDEN_NAME } from './game/coop-levels';
import { openPanel, closePanel } from './modal';
import { getWeaponCombo } from './game/weapon-combos';
import { RaceSession, RACE_ENDPOINT, raceInviteUrl, raceRoomFromUrl, type RaceView } from './race-client';
import { renderRaceRoom, renderRaceHud, renderRaceSummary } from './race-ui';
import { renderUpgradeScreen, renderBuffSeals, upgradePreview } from './upgrade-ui';
import { CONTROL_ACTIONS, CONTROL_NAMES, keyLabel, type ControlAction } from './controls';
import { GameEngine, UPGRADES, SYNERGIES } from './game/engine';
import { GameRenderer } from './game/renderer';
import { loadArt, artLoadState, artImage } from './game/art-assets';
import { drawArtBackground } from './game/environment-art';
import { scoreCue } from './game/score';
import { BOSS_ASCENSION_TIME, BOSS_TRANSFORM_TIME, WARDEN_ENTRANCE_TIME, isWardenEntrance, openingAscension, openingSeal } from './game/boss-seal';
import { GameAudio } from './game/audio';
import { AWAKENING_DURATION, MODIFIERS, SOLO_WEAPON_IDS, WEAPONS, EXPEDITION_ROOM_COUNT, getCharacterWeapons, isCharacterId, isLoadoutWeapon, isSoloWeapon, weaponTier, type GameConfig, type WeaponId, type ModifierId, type Phase, type GameResult } from './game/types';
import { expeditionOrder, EXPEDITION_TITLES } from './game/levels';
import { GameInput, EMPTY_INPUT, mergeInput, withoutEdges } from './input';
import { TouchLayout } from './touch-layout';
import { icon, escapeHtml as esc } from './icons';
import { getDailySeed, randomSeed, encodeChallenge, decodeChallenge, makeChallengeUrl, formatTime, getPlayerName, setPlayerName, getRecords, saveRecord, clearRecords, type Challenge } from './social';
import { LiveLeaderboard } from './leaderboard';
import { MODIFIER_IDS, compareRecords, recordHero } from './leaderboard-core';
import { installStory } from './story';
import { coopChapter, GUARDIAN_FAREWELL, ELITE_CLEAR_LINE } from './coop-story';

document.querySelector<HTMLDivElement>('#app')!.innerHTML = `
  <a class="skip-link" href="#game-shell">跳到游戏</a>
  <header class="site-header">
    <button class="brand" data-action="home" aria-label="星跃远征，回到大厅"><span class="brand-mark">${icon('star')}</span><span>星跃远征<small>STARHOP / EXPEDITION</small></span></button>
    <nav aria-label="主导航"><button class="nav-button active" data-action="home">远征大厅</button><button class="nav-button" data-action="leaderboard">通关排行榜<span class="nav-dot"></span></button><button class="nav-button" data-action="records">远征记录</button><button class="nav-button achievement-launch" data-action="achievements">成就 <small id="achievement-count"></small></button></nav>
    <div class="header-tools"><span class="live-label"><i></i> 冒险随时发生</span><button class="icon-button" id="sound-button" data-action="sound" title="关闭声音" aria-label="关闭声音">${icon('sound')}</button><button class="icon-button" data-action="fullscreen" title="全屏游戏" aria-label="全屏游戏">${icon('fullscreen')}</button></div>
  </header>
  <main>
    <div class="eyebrow-line"><span><i></i> 山海旧梦 · 机械余烬 / STARHOP</span><div><button class="text-button" data-action="controls">${icon('keyboard')} 操作设置</button> <button class="text-button" data-action="help">操作指南</button></div></div>
    <section class="game-shell" id="game-shell" tabindex="-1" aria-label="星跃远征游戏区域">
      <canvas id="game" width="960" height="540" aria-label="像素横版动作冒险画面">你的浏览器需要支持 Canvas 才能运行本游戏。</canvas>
      <div class="vignette" aria-hidden="true"></div><div class="frame-corner tl"></div><div class="frame-corner tr"></div><div class="frame-corner bl"></div><div class="frame-corner br"></div>
      <div id="menu-screen" class="menu-screen">
        <div class="menu-copy"><div class="menu-kicker"><span class="mini-star">✦</span> 循星换境，踏破八境</div><h1>星跃<span>远征<span class="title-star">✦</span></span></h1><div class="title-english">STARHOP EXPEDITION</div><p class="menu-description">八境星灯熄灭，姐姐的留音自遗境传来。<br>循灯踏过遗境，寻回被余烬掩埋的真相。</p><button class="primary-button start-button" data-action="start">开启远征 ${icon('arrow')}</button><div class="menu-meta"><span>${icon('flag')} 八幕完整远征</span><span>三连重斩 · 精准闪避</span></div></div>
        <div class="expedition-pass"><div class="pass-heading"><span class="pass-symbol">${icon('star')}</span><span>八境行牒<small>THE EIGHT REALMS</small></span><span class="pass-number">01 — 08</span></div><div class="pass-world">雾竹山门<span>GATE OF MIST & BAMBOO</span></div><div class="pass-divider"></div><div class="pass-route">${Array.from({length:7},()=>'<span class="route-dot"></span>').join('')}<span class="route-boss">${icon('flag')}</span></div><div class="pass-detail"><span id="seed-label">今日远征</span><strong id="seed-number">#000000</strong></div><button class="pass-refresh" data-action="new-seed">${icon('refresh')} 换一条路线</button></div>
        <span class="world-caption">以星为刃，向余烬深处。<i></i></span>
      </div>
      <div class="hud" id="hud" hidden>
        <div class="hero-hud" aria-label="旅人状态"><span class="avatar-mini" aria-hidden="true"></span><div class="hero-status"><div class="hero-hud-top"><strong id="hero-name">星际旅人</strong><span id="level-label">LV. 1</span></div><div class="vitality-row"><span class="hud-stat-label">生命</span><div class="hearts" id="hearts" aria-label="生命"></div><span class="hud-stat-value" id="health-value">5 / 5</span></div><div class="experience-row"><span class="hud-stat-label">修为</span><div class="xp-track" id="xp-track" role="progressbar" aria-label="升级修为" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i id="xp-bar"></i></div><span class="hud-stat-value" id="xp-value">0 / 9</span></div></div></div>
        <div class="room-hud"><small id="room-count">01 / 04</small><strong id="room-name">萤火林地</strong><span id="run-timer">00:00.00</span></div>
        <div class="run-hud"><span class="coin-counter">${icon('coin')} <strong id="coins">0</strong></span><button class="hud-pause icon-button" data-action="pause" aria-label="暂停游戏">${icon('pause')}</button></div>
        <div class="weapon-hud" id="weapon-hud"></div>
        <div class="dash-hud"><span>闪避 <kbd>SHIFT</kbd></span><i><b id="dash-fill"></b></i><small class="guard-status" id="guard-status">格挡就绪</small></div>
        <button class="resonance-hud" id="resonance-button" data-action="awaken" aria-label="星陨觉醒，积满星能后按Q"><span class="resonance-emblem">${icon('star')}</span><span class="resonance-copy"><strong id="resonance-title">星陨觉醒 <kbd>Q</kbd></strong><i><b id="resonance-fill"></b></i><small id="resonance-value">战斗积攒星能</small></span></button>
        <button class="build-hud" data-action="build" aria-label="查看本局星图与羁绊">${icon('star')} <span>本局星图</span><b id="synergy-count">0 / 3</b></button>
        <button class="control-settings-button" data-action="controls" aria-label="操作设置与自定义键位" title="操作设置与自定义键位">${icon('keyboard')}</button>
      </div>
      <div id="coop-roster" class="coop-roster" aria-label="合作队伍状态" hidden></div>
      <div class="boss-hud" id="boss-hud" hidden><div><span>遗迹守门人</span><strong id="boss-name">余烬守卫</strong><span id="boss-phase">PHASE I</span></div><div class="boss-track"><i id="boss-fill"></i></div><small id="boss-tactic">观察预警，格挡或闪避后反击</small></div>
      <div class="room-announcement" id="announcement" aria-live="polite"><span id="announcement-title"></span><small id="coop-story-line" hidden></small></div>
      <div class="objective-hud" id="objective-hud" hidden><span class="objective-seal" aria-hidden="true">令</span><div class="objective-copy"><span id="enemy-count"></span><small id="objective-hint"></small><div class="objective-track"><i id="objective-fill"></i></div></div></div>
      <div class="first-run-hint" id="first-run-hint" hidden><span><kbd>A</kbd><kbd>D</kbd> 移动</span><span><kbd>SPACE</kbd> 跳跃</span><span><kbd>J</kbd> 攻击</span><span><kbd>SHIFT</kbd> 闪避</span></div>
      <div class="portal-prompt" id="portal-prompt" hidden>出口已开启 <span>走进星门 / <kbd>E</kbd></span></div>
      <div class="phase-screen" id="phase-screen" hidden></div>
      <div class="buff-seal-hud" id="buff-seal-hud" role="list" aria-label="本局已获得的修行印记" hidden></div>
      <div class="touch-edit-toolbar" id="touch-edit-toolbar" hidden><span>${icon('keyboard')} 拖动按键，放到顺手的位置</span><label>大小<input id="touch-edit-scale" type="range" min="75" max="140" value="100" aria-label="按键大小"></label><label>透明度<input id="touch-edit-opacity" type="range" min="25" max="95" value="65" aria-label="按键透明度"></label><button class="small-button" data-action="reset-controls">重置</button><button class="small-button touch-save" data-action="save-controls">${icon('check')} 保存布局</button></div>
      <div class="touch-controls" id="touch-controls" hidden aria-label="触屏控制"><button class="touch-stick" data-touch="move" aria-label="移动摇杆，左右拖动"><span class="touch-stick-knob"></span><span class="touch-stick-label">移 动</span></button><button class="touch-awaken" data-touch="overdrive" aria-label="星陨觉醒">${icon('star')}</button><div class="touch-actions"><button data-touch="dash" class="touch-dash" aria-label="无敌闪避">${icon('bolt')}</button><button data-touch="guard" class="touch-guard" aria-label="精准格挡">${icon('shield')}</button><button data-touch="attack" class="touch-attack" aria-label="攻击">${icon('blade')}</button><button data-touch="jump" class="touch-jump" aria-label="跳跃">${icon('jump')}</button></div></div>
      <div class="stage-bottom" id="stage-bottom"><span><i></i> 东方幻想 · 八境远征</span><span>FOLLOW THE EMBER <b>↗</b></span></div>
    </section>
    <nav class="mobile-lobby-actions" aria-label="远征与好友操作"></nav>
    <div class="coop-mobile-slot"></div>
    <section class="loadout-grid" aria-label="远征配置">
      <div class="loadout-panel"><div class="section-label"><span>01 / 旅人与兵器</span><small id="solo-loadout-mode"></small></div><div id="solo-role-launch"></div><div class="weapon-list" id="weapon-list"></div></div>
      <div class="rules-panel"><div class="section-label"><label for="modifier-select">02 / 远征规则</label><span class="tiny-spark">✦</span></div><div class="rule-selector"><span id="rule-icon">${icon('star')}</span><select id="modifier-select" aria-label="选择远征规则">${Object.entries(MODIFIERS).map(([id,m])=>`<option value="${id}">${m.name}</option>`).join('')}</select></div><p id="rule-description">${MODIFIERS.standard.description}</p></div>
      <div class="friends-panel"><div class="section-label"><span>03 / 好友战书</span>${icon('users')}</div><p id="friend-description">你的下一位对手，<br><strong>就在好友列表里。</strong></p><div class="friend-actions"><button class="small-button" data-action="share">双人竞速 ${icon('arrow')}</button><button class="text-button" data-action="import">接受战书</button></div><div class="coop-launch-row"><button class="small-button coop-launch" data-action="coop">${icon('users')} 四人合作远征 ${icon('arrow')}</button></div></div>
    </section>
    <section class="combat-preview" aria-label="战斗技巧"><span>打出你的节奏。</span><p><b>三连重斩</b> 按住攻击，第三刀重击 <i>✦</i> <b>换武追击</b> 切换后的首击强化 <i>✦</i> <b>完美闪避</b> 擦过攻击，抓住反击窗口</p><button class="text-button" data-action="leaderboard">${icon('trophy')} 挑战全服前十 ${icon('arrow')}</button></section>
    <section class="world-atlas" aria-label="八幕远征地图"><div class="atlas-heading"><h2>八境巡礼</h2><span>由雾入城，由城入天</span><small>EIGHT REALMS / ONE EXPEDITION</small></div><ol>${EXPEDITION_TITLES.map((title,index)=>`<li class="atlas-card atlas-${index}" data-realm="${index}"><span class="atlas-landmark" aria-hidden="true"></span><span class="atlas-number">${String(index+1).padStart(2,'0')}</span><strong>${esc(title[0])}</strong><small>${esc(title[1])}</small></li>`).join('')}</ol></section>
    <footer><span>把这场冒险，交给下一个朋友。<span class="footer-star">✦</span></span><div><button class="text-button" data-action="credits">素材鸣谢</button><button class="text-button" data-action="daily">${icon('moon')} 今日同图挑战</button><span class="version">v5.2.12 · 玄阙同征</span></div></footer>
  </main>
  <dialog id="dialog" aria-labelledby="dialog-title"><div id="dialog-content"></div></dialog>
  <div class="toast" id="toast" role="status" aria-live="polite"></div>
`;

const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
const audio = new GameAudio();
const engine = new GameEngine({ sound: name => audio.play(name) });
const renderer = new GameRenderer($<HTMLCanvasElement>('game'));
let artReady = false;
let soloAvatar = '';
let displayedAvatar = '';
const startButton = document.querySelector<HTMLButtonElement>('[data-action="start"]')!;
startButton.disabled = true;
startButton.textContent = '正在载入画卷…';
void loadArt((loaded, total) => { startButton.textContent = `正在载入画卷 ${Math.round(loaded / total * 100)}%`; }).then(() => {
  artReady = true;
  startButton.disabled = false;
  startButton.innerHTML = `开启远征 ${icon('arrow')}`;
  const portrait = artImage('actors/hero-idle.png');
  if (portrait) {
    const crop = document.createElement('canvas'); crop.width = 64; crop.height = 64;
    const context = crop.getContext('2d')!; context.imageSmoothingEnabled = false;
    context.drawImage(portrait, 76, 68, 42, 42, 0, 0, 64, 64);
    const avatar = document.querySelector<HTMLElement>('.avatar-mini')!;
    avatar.classList.add('has-sprite'); soloAvatar = crop.toDataURL();
    avatar.style.backgroundImage = `url("${soloAvatar}")`; displayedAvatar = soloAvatar;
  }
  document.querySelectorAll<HTMLElement>('.atlas-card').forEach(card => {
    const theme = Number(card.dataset.realm);
    const preview = document.createElement('canvas'); preview.width = 320; preview.height = 180;
    const context = preview.getContext('2d')!; context.scale(1 / 3, 1 / 3);
    if (drawArtBackground(context, 260, theme, 4)) {
      card.classList.add('has-art');
      card.querySelector<HTMLElement>('.atlas-landmark')!.style.backgroundImage = `url("${preview.toDataURL()}")`;
    }
  });
  if (coopDialogOpen) openCoopRoom();
  refreshSoloLoadout();
  if (artLoadState().failed.length) toast('部分画面未能载入，请刷新页面重试。');
});
const leaderboard = new LiveLeaderboard();
const achievements = new ExpeditionAchievements(getRecords());
let stopLeaderboardUpdates: (() => void) | null = null;
let leaderboardRule: ModifierId = 'standard';
let leaderboardScope: 'overall' | 'hero' = 'overall';
let leaderboardHero: CoopCharacterId = 'traveller';
let leaderboardRoute: 'current' | 'history' | 'legacy' = 'current';
let renameInProgress = false;
let uploadStatus: 'idle' | 'sending' | 'submitted' | 'pending' | 'rejected' = 'idle';
let currentUploadId: string | null = null;
let seed = getDailySeed();
let modifier: ModifierId = 'standard';
const SOLO_LOADOUT_KEY = 'starhop.solo-loadout.v1';
const soloPreference = readSoloPreference();
let soloRole = soloPreference.role;
let weapon = preferredSoloWeapon(soloRole);
let startedRunConfig: GameConfig | null = null;
let achievementMode: AchievementMode = { kind:'solo' };
let challenge: Challenge | null = null;
let seedKind = '今日远征';
let playerName = getPlayerName();
let previousPhase: Phase | null = null;
let previousUpgradeKey = '';
let savedResult: GameResult | null = null;
let resumeAfterDialog = false;
let virtualLandscape = false;
let landscapeAttempt = 0;
let toastTimeout: ReturnType<typeof setTimeout>;
const dialog = $<HTMLDialogElement>('dialog');
// Move the actual actions, so there is one button and one listener for each.
const mobileActions = document.querySelector<HTMLElement>('.mobile-lobby-actions')!;
const actionHomes = ['.pass-refresh', '.friends-panel [data-action="share"]', '.friends-panel [data-action="import"]'].map(selector => {
  const button = document.querySelector<HTMLButtonElement>(selector)!;
  const home = document.createComment('lobby action');
  button.before(home);
  return { button, home };
});
const coopLaunch = document.querySelector<HTMLButtonElement>('.coop-launch')!;
const coopDesktop = document.querySelector<HTMLElement>('.coop-launch-row')!;
const coopMobile = document.querySelector<HTMLElement>('.coop-mobile-slot')!;
function layoutLobbyActions() {
  const compact = isTouchDevice();
  (compact ? coopMobile : coopDesktop).append(coopLaunch);
  for (const { button, home } of actionHomes) {
    if (compact && button.parentElement !== mobileActions) mobileActions.append(button);
    if (!compact && button.parentElement === mobileActions) home.after(button);
  }
}
layoutLobbyActions();
const touchLayout = new TouchLayout($('game-shell'),$('touch-controls'));
const upgradeSelection = new UpgradeSelectionGate();
let raceDialogOpen = false;
let invitedRoomId: string | null = null;
let addressRoomId: string | null = null;
function clearRaceAddress() {
  addressRoomId = null;
  const url = new URL(location.href);
  if (!url.searchParams.has('race') && !url.hash.startsWith('#race=')) return;
  url.searchParams.delete('race');
  if (url.hash.startsWith('#race=')) url.hash = '';
  try { history.replaceState(null, '', url); } catch { /* Some embedded browsers deny history changes. */ }
}
let raceDialogKey = '';
let raceHudKey = '';
let raceSummaryKey = '';
let raceSequence = 0;
let raceFinishSent = false;
let raceStartAllowed = false;
let previousRaceStart: number | null = null;
const liveRace = new RaceSession(RACE_ENDPOINT, {
  onChange: view => raceChanged(view),
  onStart: (config, startAt) => {
    if (!raceStartAllowed) return;
    if (liveRace.view.self?.frame) {
      raceStartAllowed = false; raceDialogOpen = false;
      void liveRace.leave();
      clearRaceAddress();
      showDialog('这一局已中断', '<p class="dialog-description">刷新页面后，本局闯关进度没有保留。请重新发起一场，邀请好友再出发。</p><button class="primary-button" data-action="share">重新发起竞速</button>');
      return;
    }
    seed = config.seed; modifier = config.modifier;
    challenge = null; seedKind = '双人竞速'; raceSequence = 0; raceFinishSent = false;
    raceDialogOpen = false; closeDialog(false); refreshConfig();
    beginRun({ ...config, buffSeed: (config.seed ^ (startAt >>> 0)) >>> 0 }, {kind:'race'});
    toast('竞速开始 · 同关可见对方幽影，各自独立闯关。');
  },
  onError: message => toast(message),
});
let coopPlay: CoopPlay | null = null;
let coopDialogOpen = false;
let coopInviteId: string | null = null;
let coopDialogKey = '';
let coopHudKey = '';
const coopSession = new CoopSession({
  onChange: updateCoopRoom,
  onStart: room => {
    coopDialogOpen = false;
    closeDialog(false);
    input.clear(); pendingInput = { ...EMPTY_INPUT }; accumulator = 0;
    savedResult = null; previousPhase = null; previousWeaponTier = 1;
    audio.resetScore();
    coopPlay = new CoopPlay(coopSession, engine, room, name=>audio.play(name));
    updateOrientation();
    if (!isTouchDevice()) $('game-shell').scrollIntoView({block:'center'});
    $('game-shell').focus({preventScroll:true});
  },
  onGuestMessage: (seat, value) => coopPlay?.acceptInput(seat, value),
  onHostMessage: value => coopPlay?.acceptWorld(value),
});
let controlsMenuPaused = false;
const input = new GameInput(() => engine.state.phase === 'playing' && !dialog.hasAttribute('open'), key => {
  if (engine.state.phase === 'upgrade') return;
  if(touchLayout.editing){if(key==='Escape')finishControlEdit();return;}
  if (key === 'Escape') { if (dialog.hasAttribute('open')) closeDialog(); else togglePause(); }
  else if (key === 'KeyP') togglePause();
  else if (key.startsWith('Digit') && !dialog.hasAttribute('open')) {
    const id = getCharacterWeapons(currentCharacter())[Number(key.slice(-1))-1];
    if (id) selectWeapon(id);
  }
}, () => { if (!coopPlay || coopSession.view.isHost) engine.requestGuard(); });
try { audio.setMuted(localStorage.getItem('starhop-muted') === 'true'); } catch { /* persistence is optional */ }

function toast(text: string) {
  clearTimeout(toastTimeout); $('toast').textContent = text; $('toast').classList.add('visible');
  toastTimeout = setTimeout(() => $('toast').classList.remove('visible'), 3600);
}
function chooseUpgrade(id: string) {
  if (engine.state.phase !== 'upgrade') return;
  const upgrade = engine.state.upgradeChoices.find(item => item.id === id);
  if (!upgrade) return;
  const preview = upgradePreview(upgrade, engine.state.hero);
  input.clear(); pendingInput = { ...EMPTY_INPUT }; accumulator = 0;
  if (coopPlay) coopPlay.chooseUpgrade(id);
  else engine.chooseUpgrade(id);
  toast(`「${upgrade.name}」已入行牒 · ${preview.label} ${preview.before} → ${preview.after}`);
  $('game-shell').focus({preventScroll:true});
}
function updateSoundButton() {
  $('sound-button').innerHTML = icon(audio.muted ? 'muted' : 'sound');
  $('sound-button').setAttribute('aria-label', audio.muted ? '开启声音' : '关闭声音');
  $('sound-button').setAttribute('title', audio.muted ? '开启声音' : '关闭声音');
  $('sound-button').setAttribute('aria-pressed', String(!audio.muted));
  const pauseSound=document.querySelector<HTMLButtonElement>('.pause-tools [data-action="sound"]');
  if(pauseSound) pauseSound.innerHTML=`${icon(audio.muted?'muted':'sound')} ${audio.muted?'开启声音':'关闭声音'}`;
}
type SoloPreference = {
  role: CoopCharacterId | null;
  weapon: (typeof SOLO_WEAPON_IDS)[number];
  roleWeapons: Partial<Record<CoopCharacterId, WeaponId>>;
};
function readSoloPreference(): SoloPreference {
  try {
    const saved = JSON.parse(localStorage.getItem(SOLO_LOADOUT_KEY) ?? 'null') as Partial<Record<keyof SoloPreference, unknown>> | null;
    const storedWeapons = saved?.roleWeapons;
    const roleWeapons: SoloPreference['roleWeapons'] = {};
    if (storedWeapons && typeof storedWeapons === 'object') {
      for (const id of COOP_CHARACTER_IDS) {
        const candidate = (storedWeapons as Partial<Record<CoopCharacterId, unknown>>)[id];
        if (isLoadoutWeapon(id, candidate)) roleWeapons[id] = candidate;
      }
    }
    return { role:isCharacterId(saved?.role) ? saved.role : 'traveller', weapon:SOLO_WEAPON_IDS.find(id => id === saved?.weapon) ?? 'blade',roleWeapons };
  } catch { return { role:'traveller',weapon:'blade',roleWeapons:{} }; }
}
function saveSoloPreference() {
  try { localStorage.setItem(SOLO_LOADOUT_KEY,JSON.stringify(soloPreference)); } catch { /* Selection remains usable for this visit. */ }
}
function preferredSoloWeapon(role: CoopCharacterId | null): WeaponId {
  if (!role) return soloPreference.weapon;
  return soloPreference.roleWeapons[role] ?? (role === 'traveller' ? soloPreference.weapon : getCharacterWeapons(role)[0]);
}
function soloConfig(): GameConfig {
  return { seed,modifier,weapon:isLoadoutWeapon(soloRole,weapon) ? weapon : preferredSoloWeapon(soloRole),
    ...(soloRole ? {character:soloRole} : {}) };
}
function soloRoleLaunch(fromGuide = false) {
  const id = soloRole ?? 'traveller';
  const role = COOP_CHARACTERS[id];
  const name = role.name;
  const description = `起手 · ${WEAPONS[soloConfig().weapon].name}`;
  const portrait = getCoopPortrait(id) || (id==='traveller' ? soloAvatar : '');
  return `<button type="button" class="solo-role-launch ${fromGuide ? 'solo-guide-loadout' : ''}" data-action="solo-role-open" ${fromGuide ? 'data-role-origin="guide"' : ''} aria-haspopup="dialog" aria-label="选择单人旅人，当前${name}" style="--role-tint:${role.color}">
    <span class="solo-role-token" aria-hidden="true" ${portrait ? `style="--portrait:url('${portrait}')"` : ''}>${portrait ? '' : icon(role.icon)}</span>
    <span><strong>${name} · 更换旅人</strong><small>${description}</small></span>${icon('arrow')}
  </button>`;
}
function refreshSoloLoadout() {
  $('solo-role-launch').innerHTML = soloRoleLaunch();
  $('solo-loadout-mode').textContent = '途中可用 1 · 2 · 3 切换';
  const weapons = $('weapon-list');
  const current = soloConfig().weapon;
  weapons.innerHTML = getCharacterWeapons(soloRole).map((id,index) => {
    const w = WEAPONS[id];
    return `<button class="weapon-option ${current === id ? 'selected' : ''}" data-weapon="${id}" aria-pressed="${current === id}" style="--weapon-color:${w.color}"><span class="weapon-symbol">${icon(w.icon)}</span><span><strong>${w.name}</strong><small>${w.subtitle}</small></span><kbd>${index+1}</kbd></button>`;
  }).join('');
}
function openSoloRoles(fromGuide: boolean) {
  if (engine.state.phase !== 'menu') return;
  if (coopSession.view.room) { openCoopRoom(); return; }
  if (liveRace.view.room) { openRaceRoom(); return; }
  showDialog('选择单人旅人', `<p class="dialog-description">每位旅人各持三种兵器。选好旅人后，可在大厅更换起手兵器。</p>
    ${renderRoleCards({hero:engine.state.hero,selected:soloRole,action:'solo-role-pick',label:'选择单人旅人'})}
    <div class="coop-room-actions solo-role-continue"><button class="primary-button" data-action="${fromGuide ? 'solo-role-to-guide' : 'close-dialog'}">${fromGuide ? '返回开局' : '完成选择'} ${icon('check')}</button></div>`, true);
  dialog.querySelector<HTMLButtonElement>('[data-action="solo-role-pick"][aria-pressed="true"]')?.focus({preventScroll:true});
}
function selectSoloRole(value: string | undefined) {
  if (engine.state.phase !== 'menu' || !isCharacterId(value)) return;
  const changed = (soloRole ?? 'traveller') !== value;
  if (changed || !challenge) soloRole = value;
  if (changed) weapon = preferredSoloWeapon(value);
  soloPreference.role = value;
  saveSoloPreference();
  if (changed && challenge) { challenge = null; seedKind = '自选挑战'; }
  dialog.querySelectorAll<HTMLButtonElement>('[data-action="solo-role-pick"]').forEach(button => {
    button.setAttribute('aria-pressed',String(button.dataset.role === value));
  });
  refreshConfig();
  if (changed) audio.play('select');
}
function startRulePicker() {
  const choices = MODIFIER_IDS.map(id => {
    const rule = MODIFIERS[id];
    return `<button type="button" class="start-rule" data-start-rule="${id}" aria-pressed="${id === modifier}">
      <span class="start-rule-name">${icon(rule.icon)} <strong>${rule.name}</strong></span>
      <small>${rule.description}</small>
    </button>`;
  }).join('');
  return `<section class="start-rules" aria-labelledby="start-rules-title">
    <h3 id="start-rules-title">远征规则</h3>
    <div class="start-rule-grid" role="group" aria-label="选择远征规则">${choices}</div>
  </section>`;
}
function selectExpeditionRule(value: string | undefined) {
  if (engine.state.phase !== 'menu' || !MODIFIER_IDS.includes(value as ModifierId) || value === modifier) return;
  modifier = value as ModifierId;
  challenge = null;
  seedKind = '自选挑战';
  refreshConfig();
  audio.play('select');
}
function refreshConfig() {
  refreshRoutePreview(seed);
  $('seed-label').textContent = seedKind;
  $('seed-number').textContent = `#${seed.toString(36).toUpperCase().padStart(6,'0')}`;
  $<HTMLSelectElement>('modifier-select').value = modifier;
  $('rule-icon').innerHTML = icon(MODIFIERS[modifier].icon);
  $('rule-description').textContent = MODIFIERS[modifier].description;
  dialog.querySelectorAll<HTMLButtonElement>('[data-start-rule]').forEach(button => {
    button.setAttribute('aria-pressed', String(button.dataset.startRule === modifier));
  });
  $('hero-name').textContent = playerName;
  refreshSoloLoadout();
  const rival = challenge?.rival;
  $('friend-description').innerHTML = rival ? `<span class="rival-tag">${icon('flag')} 收到好友战书</span><br><strong>${esc(rival.name)}</strong> · ${formatTime(rival.result.time)}<br><span class="rival-score">${rival.result.score.toLocaleString()} 分，等你超越。</span>` : challenge ? `收到一份远征邀请。<br><strong>相同路线，一起出发。</strong>` : '你的下一位对手，<br><strong>就在好友列表里。</strong>';
  updateSoundButton();
}
function currentCharacter() {
  if (coopPlay) return coopSession.view.room?.players.find(person => person.seat === coopSession.view.seat)?.role;
  return engine.state.phase === 'menu' ? soloRole : engine.state.character;
}
function selectWeapon(id: WeaponId) {
  if (!isLoadoutWeapon(currentCharacter(), id)) return;
  if (coopPlay) {
    if (engine.state.phase === 'playing') coopPlay.equipWeapon(id);
    return;
  }
  if (coopSession.view.room) { openCoopRoom(); return; }
  if (engine.state.phase === 'menu' && liveRace.view.room) { openRaceRoom(); return; }
  if (['playing','paused'].includes(engine.state.phase)) { engine.equipWeapon(id); }
  else if (engine.state.phase === 'menu') {
    weapon = id;
    if (soloRole) soloPreference.roleWeapons[soloRole] = id;
    if ((!soloRole || soloRole === 'traveller') && isSoloWeapon(id)) soloPreference.weapon = id;
    saveSoloPreference();
    if (challenge && id !== challenge.weapon) { challenge = null; seedKind = '自选挑战'; }
  } else return;
  if (engine.state.phase === 'menu') {
    audio.play('select');
    refreshConfig();
  }
}
function beginRun(config?: GameConfig, mode: AchievementMode = {kind:'solo'}) {
  if (coopSession.view.room) { openCoopRoom(); return; }
  if (liveRace.view.room && !liveRace.view.started) { openRaceRoom(); return; }
  if (!artReady) { toast('画卷正在载入，请稍候。'); return; }
  landscapeAttempt++; setVirtualLandscape(false);
  closeDialog(false); input.clear(); pendingInput = { ...EMPTY_INPUT }; accumulator = 0;
  savedResult = null;
  uploadStatus = 'idle';
  currentUploadId = null;
  void audio.unlock();
  audio.resetScore();
  const run = config ?? soloConfig();
  engine.start({ ...run, buffSeed: run.buffSeed ?? randomSeed() });
  achievementMode = mode;
  const started = engine.state;
  startedRunConfig = { seed:started.seed,modifier:started.modifier,weapon:started.hero.weapon,
    ...(started.character ? {character:started.character} : {}) };
  previousWeaponTier = 1;
  updateOrientation();
  // The stage already fits the screen. Request native fullscreen only from its own button.
  $('game-shell').focus({preventScroll:true});
}
function togglePause() {
  if (dialog.hasAttribute('open')) return;
  if (coopPlay && engine.state.phase === 'playing') {
    showDialog('合作远征', '<p class="dialog-description">战斗仍在进行。回到关卡可继续协作。</p><div class="coop-room-actions"><button class="text-button" data-action="home">离开队伍</button><button class="primary-button" data-action="close-dialog">返回战斗</button></div>');
    return;
  }
  if (engine.state.phase === 'playing') { engine.pause(); input.clear(); }
  else if (engine.state.phase === 'paused') { engine.resume(); input.clear(); $('game-shell').focus({preventScroll:true}); }
}
function goHome() {
  leaveCoop();
  if (liveRace.view.room) { raceStartAllowed = false; raceDialogOpen = false; clearRaceAddress(); void liveRace.leave(); }
  landscapeAttempt++;
  if(touchLayout.editing)finishControlEdit(false);
  closeDialog(false); input.clear(); engine.state.phase = 'menu';
  engine.state.result = null; previousPhase = null; pendingInput = { ...EMPTY_INPUT };
  setVirtualLandscape(false);
  refreshConfig();
  document.body.classList.remove('mobile-playing');
  if(isTouchDevice()&&fullscreenElement()) void exitFullscreen();
  unlockOrientation();
}
function isTouchDevice(): boolean { return matchMedia('(pointer:coarse)').matches || (navigator.maxTouchPoints>0&&Math.min(innerWidth,innerHeight)<600); }
function setVirtualLandscape(enabled: boolean) {
  if(virtualLandscape === enabled) return;
  virtualLandscape = enabled;
  document.body.classList.toggle('virtual-landscape', enabled);
  touchLayout.setLandscapeRotation(enabled);
  renderer.resize();
}
type FullscreenDocument = Document & { webkitFullscreenElement?: Element; webkitExitFullscreen?: () => void | Promise<void> };
type FullscreenStage = HTMLElement & { webkitRequestFullscreen?: () => void | Promise<void> };
function fullscreenElement() { return document.fullscreenElement || (document as FullscreenDocument).webkitFullscreenElement; }
async function exitFullscreen() {
  const exit = document.exitFullscreen || (document as FullscreenDocument).webkitExitFullscreen;
  try { await exit?.call(document); } catch { /* The browser may already have left fullscreen. */ }
}
function unlockOrientation() { try { screen.orientation?.unlock?.(); } catch { /* Optional browser capability. */ } }
async function settleDisplayRequest(request: () => void | Promise<void>) {
  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    await Promise.race([Promise.resolve(request()), new Promise<void>(resolve => { timeout=setTimeout(resolve,700); })]);
  } catch { /* The game already uses the landscape fallback if a browser rejects this request. */ }
  finally { clearTimeout(timeout); }
}
function updateOrientation() {
  const active=engine.state.phase!=='menu';
  const touch=isTouchDevice();
  document.body.classList.toggle('mobile-playing',touch&&active);
  setVirtualLandscape(touch&&active&&innerHeight>innerWidth);
}
async function enterLandscape(feedback = true) {
  const attempt = ++landscapeAttempt;
  void audio.unlock();
  // Enter a playable landscape view immediately, even when native requests are missing or never settle.
  if(isTouchDevice() && engine.state.phase!=='menu' && innerHeight>innerWidth) setVirtualLandscape(true);
  updateOrientation();
  if(feedback) toast('已切换横屏，横向握持手机即可游玩。');
  // Fullscreen a non-rotating ancestor; fullscreen UA rules would remove the stage's rotation.
  const stage = (isTouchDevice() ? document.documentElement : $('game-shell')) as FullscreenStage;
  const request = stage.requestFullscreen || stage.webkitRequestFullscreen;
  if(!fullscreenElement() && request) {
    await settleDisplayRequest(() => {
      const pending = Promise.resolve(request.call(stage));
      void pending.then(() => {
        if(attempt !== landscapeAttempt && engine.state.phase==='menu' && fullscreenElement()===stage) void exitFullscreen();
      }, () => {});
      return pending;
    });
  }
  if(attempt !== landscapeAttempt || engine.state.phase==='menu') return;
  const orientation = screen.orientation as ScreenOrientation & { lock?: (type:string) => Promise<void> };
  if(orientation?.lock) await settleDisplayRequest(() => {
    const pending = orientation.lock!('landscape');
    void pending.then(() => { if(attempt !== landscapeAttempt) unlockOrientation(); }, () => {});
    return pending;
  });
  if(attempt===landscapeAttempt) updateOrientation();
}
function showDialog(title: string, body: string, wide = false) {
  stopLeaderboardUpdates?.(); stopLeaderboardUpdates = null;
  leaderboard.close();
  if (!dialog.hasAttribute('open')) {
    resumeAfterDialog = !coopPlay && engine.state.phase === 'playing';
    if (resumeAfterDialog) engine.pause();
  }
  input.clear();
  dialog.classList.remove('guide-dialog');
  dialog.classList.remove('leaderboard-dialog');
  dialog.classList.toggle('wide', wide);
  $('dialog-content').innerHTML = `<div class="dialog-heading"><div><span class="dialog-eyebrow">STARHOP / EXPEDITION</span><h2 id="dialog-title">${title}</h2></div><button class="icon-button" data-action="close-dialog" aria-label="关闭">${icon('close')}</button></div>${body}`;
  openPanel(dialog, () => closeDialog());
}
function closeDialog(resume = true) {
  coopDialogOpen = false;
  raceDialogOpen = false;
  stopLeaderboardUpdates?.(); stopLeaderboardUpdates = null;
  leaderboard.close();
  if (!dialog.hasAttribute('open')) return;
  waitingBinding=null;
  closePanel(dialog);
  if (resume && resumeAfterDialog && engine.state.phase === 'paused') engine.resume();
  resumeAfterDialog = false; input.clear();
}
dialog.addEventListener('cancel', e => { e.preventDefault(); closeDialog(); });
dialog.addEventListener('click', e => { if (e.target === dialog) { const r=dialog.getBoundingClientRect(); if ((e as MouseEvent).clientX<r.left || (e as MouseEvent).clientX>r.right || (e as MouseEvent).clientY<r.top || (e as MouseEvent).clientY>r.bottom) closeDialog(); } });

function getChallenge(): Challenge {
  const s = engine.state;
  const config = s.phase !== 'menu' && !coopPlay && startedRunConfig ? startedRunConfig : soloConfig();
  const result = s.result?.won ? s.result : undefined;
  return { v:1, ...config, ...(result ? {weapon:result.weapon, rival:{name:playerName,result}} : {}) };
}
function openShare() {
  const data = getChallenge();
  const url = makeChallengeUrl(data);
  const code = encodeChallenge(data);
  const shareHint = /^https?:$/.test(location.protocol) && !/^(localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\]|192\.168\.|10\.|172\.(1[6-9]|2[0-9]|3[01])\.)/.test(location.hostname)
    ? '把链接发给朋友，电脑或手机打开即可挑战。手机横屏游玩更舒服，也可以按自己的手型调整按键。'
    : '同一 Wi-Fi 下，朋友可打开与你相同的局域网地址；远程分享请使用公开游戏网站。离线游玩也可以发送游戏文件和挑战码。';
  showDialog('下一位对手，是你的朋友。', `<div class="share-illustration">${icon('flag')}<span>CHALLENGE ACCEPTED?</span></div><p class="dialog-description">${data.rival ? `你已用 <strong>${formatTime(data.rival.result.time)}</strong> 完成远征。把纪录交给朋友，看谁能更快击败守卫。` : '发送这份战书，朋友会进入相同的地图、规则和起手武器。自由选择强化，搭出各自的战斗流派。'}</p><div class="share-summary">${data.character ? `<span>${COOP_CHARACTERS[data.character].name}</span>` : ''}<span>${MODIFIERS[data.modifier].name}</span><span>${WEAPONS[data.weapon].name}</span><span>#${data.seed.toString(36).toUpperCase()}</span></div><label class="field-label" for="share-url">挑战链接</label><div class="copy-field"><input id="share-url" readonly value="${esc(url)}" aria-label="挑战链接"><button class="small-button" data-action="copy-url">${icon('copy')} 复制</button></div><p class="field-hint">${shareHint}</p><details class="share-code"><summary>使用挑战码</summary><textarea id="share-code" readonly aria-label="挑战码">${esc(code)}</textarea><button class="text-button" data-action="copy-code">${icon('copy')} 复制挑战码</button></details><label class="field-label" for="player-name">你的旅人签名</label><div class="copy-field"><input id="player-name" maxlength="12" value="${esc(playerName)}" autocomplete="nickname"><button class="small-button" data-action="save-name">保存签名</button></div><p class="field-hint">好友纪录由战书携带。本机记录保存在当前浏览器。</p>`);
}
function raceLink(view = liveRace.view): string {
  const page = location.protocol === 'file:' ? 'https://le3334515-tech.github.io/starhop-expedition/classic/' : location.href;
  return view.room ? raceInviteUrl(view.room.id, page) : '';
}
function syncRoomAddress(view: RaceView) {
  if (!view.room || addressRoomId === view.room.id || !/^https?:$/.test(location.protocol)) return;
  addressRoomId = view.room.id;
  const address = raceLink(view);
  if (location.href !== address) {
    try { history.replaceState(null, '', address); } catch { /* The copyable link remains available. */ }
  }
}
function roomRenderKey(view: RaceView) {
  return JSON.stringify([view.connection, view.error, view.room?.id, view.room?.startAt, view.room?.status,
    view.room?.characterSelection, view.choosingCharacter, view.self?.character, view.opponent?.character,
    view.self?.readyAt, view.opponent?.readyAt, view.opponent?.name, view.opponent?.leftAt, view.self?.finishedAt, view.opponent?.finishedAt]);
}
function openCoopRoom() {
  const view = coopSession.view;
  const focused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const role = focused?.dataset.coopRole;
  const action = focused?.dataset.action;
  const scrollTop = coopDialogOpen ? dialog.scrollTop : 0;
  showDialog('玄阙同征 · 四人合作', coopLobby(view, view.room ? coopInviteUrl(view.room.id, location.href) : '', view.isHost, engine.state.hero), true);
  dialog.scrollTop = scrollTop;
  coopDialogOpen = true;
  coopDialogKey = JSON.stringify(view);
  const restored = role ? dialog.querySelector<HTMLElement>(`[data-coop-role="${role}"]:not(:disabled)`)
    : action?.startsWith('coop-') ? Array.from(dialog.querySelectorAll<HTMLButtonElement>('[data-action]')).find(button => button.dataset.action === action && !button.disabled) : null;
  restored?.focus({preventScroll:true});
}
function updateCoopRoom(view: CoopView) {
  if (view.room) {
    const url = new URL(location.href);
    if (url.searchParams.get('coop') !== view.room.id) {
      url.searchParams.set('coop', view.room.id); url.searchParams.delete('race'); url.hash = '';
      history.replaceState(null, '', url);
    }
  }
  if (coopDialogOpen && JSON.stringify(view) !== coopDialogKey) openCoopRoom();
  if (coopPlay && view.connection === 'error' && !view.room && !coopDialogOpen) {
    coopPlay.stop(); coopPlay = null;
    engine.state.phase = 'menu'; previousPhase = null;
    showDialog('队伍连接已断开', `<p class="dialog-description">${esc(view.error ?? '房间已关闭。')}</p><button class="small-button" data-action="coop-leave">返回大厅</button>`);
  }
}
function leaveCoop() {
  if (!coopPlay && !coopInviteId && coopSession.view.connection === 'idle' && !coopSession.view.room) return;
  coopDialogOpen = false; coopInviteId = null;
  coopPlay?.stop(); coopPlay = null;
  void coopSession.leave();
  const url = new URL(location.href);
  if (url.searchParams.has('coop')) {
    url.searchParams.delete('coop');
    history.replaceState(null, '', url);
  }
}
async function connectCoop(id: string | null = null) {
  if (coopPlay || engine.state.phase !== 'menu') return;
  if (location.protocol === 'file:') {
    showDialog('打开在线合作远征', '<p class="dialog-description">组队邀请从在线版发出。</p><a class="primary-button" href="https://le3334515-tech.github.io/starhop-expedition/classic/?v=5.2.12">打开公共游戏</a>');
    return;
  }
  if (coopSession.view.room && (!id || id === coopSession.view.room.id)) { openCoopRoom(); return; }
  coopInviteId = id;
  if (liveRace.view.room || liveRace.view.connection === 'connecting') {
    raceStartAllowed = false; raceDialogOpen = false;
    clearRaceAddress(); await liveRace.leave();
  }
  raceDialogOpen = false;
  coopDialogOpen = true;
  try {
    if (id) await coopSession.join(id, playerName);
    else await coopSession.create({ seed, modifier: 'standard', weapon: 'blade' }, playerName);
  } catch (error) {
    if (error instanceof Error) toast(error.message);
  } finally {
    if (coopDialogOpen) openCoopRoom();
  }
}
function coopAction(action: () => void) {
  try { action(); } catch (error) { if (error instanceof Error) toast(error.message); }
}
function openRaceRoom() {
  const view = liveRace.view;
  if (!view.room && view.connection !== 'connecting' && view.connection !== 'error') { void createOnlineRace(); return; }
  const focused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const role = focused?.dataset.role, action = focused?.dataset.raceAction;
  const scrollTop = raceDialogOpen ? dialog.scrollTop : 0;
  showDialog('二人同道 · 在线竞速', renderRaceRoom(view, raceLink(view), engine.state.hero), true);
  raceDialogOpen = true;
  $('dialog-content').insertAdjacentHTML('beforeend', '<button class="text-button race-solo-share" data-action="solo-share">只分享同图挑战 / 通关纪录</button>');
  dialog.scrollTop = scrollTop;
  const restored = role ? Array.from(dialog.querySelectorAll<HTMLButtonElement>('[data-action="race-role"]:not(:disabled)')).find(button => button.dataset.role === role)
    : action ? Array.from(dialog.querySelectorAll<HTMLButtonElement>('[data-race-action]:not(:disabled)')).find(button => button.dataset.raceAction === action) : null;
  restored?.focus({preventScroll:true});
  raceDialogKey = roomRenderKey(view);
}
function raceChanged(view: RaceView) {
  if (view.room) {
    syncRoomAddress(view);
    if (previousRaceStart !== null && view.room.startAt === null) {
      engine.state.phase = 'menu'; previousPhase = null; raceFinishSent = false; raceDialogOpen = true;
    }
    previousRaceStart = view.room.startAt;
    if (!view.started && engine.state.phase === 'menu' &&
        (seedKind !== '双人竞速' || seed !== view.room.config.seed || modifier !== view.room.config.modifier)) {
      seed = view.room.config.seed; modifier = view.room.config.modifier;
      seedKind = '双人竞速'; challenge = null; refreshConfig();
    }
    if (view.countdown && !view.started && engine.state.phase === 'menu') raceDialogOpen = true;
  } else previousRaceStart = null;
  if (raceDialogOpen && roomRenderKey(view) !== raceDialogKey) openRaceRoom();
  updateRaceWidgets(view);
}
async function createOnlineRace(mode: 'auto' | 'server' = 'auto') {
  if (coopPlay) return;
  leaveCoop();
  if (liveRace.view.room) { openRaceRoom(); return; }
  raceStartAllowed = true; raceDialogOpen = true; raceDialogKey = '';
  invitedRoomId = null;
  const config = getChallenge();
  const startingWeapon = isSoloWeapon(config.weapon) ? config.weapon : soloPreference.weapon;
  try {
    await liveRace.create({ seed: config.seed, modifier: config.modifier, weapon: startingWeapon, character:config.character }, playerName, mode);
    if (raceDialogOpen) openRaceRoom();
  }
  catch { if (raceDialogOpen) openRaceRoom(); }
}
async function joinOnlineRace(roomId: string) {
  if (coopPlay) return;
  leaveCoop();
  invitedRoomId = roomId;
  if (liveRace.view.room?.id === roomId) { openRaceRoom(); return; }
  if (liveRace.view.room) await liveRace.leave();
  raceStartAllowed = true; raceDialogOpen = true; raceDialogKey = '';
  try { await liveRace.join(roomId, playerName); if (raceStartAllowed && liveRace.view.room) openRaceRoom(); }
  catch { if (raceStartAllowed) openRaceRoom(); }
}
function updateRaceWidgets(view = liveRace.view) {
  let hud = document.getElementById('race-hud');
  if (!hud) { hud = document.createElement('div'); hud.id = 'race-hud'; hud.className = 'race-hud'; hud.setAttribute('aria-label', '双人竞速进度'); $('game-shell').append(hud); }
  hud.hidden = !view.room || !view.started || engine.state.phase !== 'playing';
  const key = JSON.stringify([view.connection, Math.floor(view.elapsed * 10), view.opponent?.frame?.seq, view.opponent?.finishedAt, view.opponentAgeMs != null && view.opponentAgeMs > 3500]);
  if (!hud.hidden && key !== raceHudKey) { hud.innerHTML = renderRaceHud(view); raceHudKey = key; }
  const countdown = dialog.querySelector('[data-race-countdown]');
  if (raceDialogOpen && countdown) countdown.textContent = view.countdown ? String(view.countdown) : view.started ? '竞速进行中' : view.opponent ? '两人准备后同步倒数' : '等候一位同道';
  let badge = document.getElementById('race-room-return');
  if (!badge) { badge = document.createElement('button'); badge.id = 'race-room-return'; badge.className = 'text-button'; badge.dataset.action = 'race-room'; badge.textContent = '返回竞速房间'; document.querySelector('.friend-actions')!.append(badge); }
  badge.hidden = !view.room;
  const summary = document.getElementById('race-result-summary');
  const summaryKey = JSON.stringify([view.room?.id, view.room?.startAt, view.self?.finishedAt, view.opponent?.finishedAt, view.opponent?.frame?.roomIndex]);
  if (summary && summaryKey !== raceSummaryKey) { summary.innerHTML = renderRaceSummary(view) || '<p>正在同步双人竞速成绩…</p>'; raceSummaryKey = summaryKey; }
}
function updateRaceFrame() {
  liveRace.tick();
  const view = liveRace.view, state = engine.state, h = state.hero;
  if (view.room && view.started && state.phase !== 'menu') {
    liveRace.updateFrame({ seq: ++raceSequence, roomIndex: state.roomIndex, x: h.x, y: h.y, vx: h.vx, vy: h.vy,
      facing: h.facing, grounded: h.grounded, weapon: h.weapon, attackTimer: h.attackTimer, attackStep: h.attackStep,
      hp: h.hp, maxHp: h.maxHp, level: h.level, animation: h.animation, phase: state.phase, character:state.character,
      progress: state.phase === 'victory' ? 1 : Math.min(.99, h.x / state.room.width),
      elapsed: liveRace.elapsed() });
    if (!raceFinishSent && (state.phase === 'victory' || state.phase === 'gameover')) {
      raceFinishSent = true; void liveRace.finish(state.phase === 'victory').catch(() => {});
    }
  }
  if (view.room) updateRaceWidgets(view);
}
async function copyField(id: string) {
  const field = $<HTMLInputElement | HTMLTextAreaElement>(id);
  try { await navigator.clipboard.writeText(field.value); toast(id === 'share-code' ? '挑战码已复制，发给朋友吧。' : '战书链接已复制，下一位对手就位。'); }
  catch {
    field.focus(); field.select(); field.setSelectionRange(0, field.value.length);
    let copied = false;
    try { copied = document.execCommand('copy'); } catch { /* Manual selection stays available. */ }
    toast(copied ? '已复制，可以发给好友了。' : '已选中，长按复制后发给好友。');
  }
}
function openImport() {
  showDialog('接下这份战书', `<p class="dialog-description">粘贴好友发送的挑战链接或挑战码。准备好进入同一场冒险。</p><label class="field-label" for="import-code">挑战链接 / 房间码 / 挑战码</label><textarea id="import-code" rows="4" placeholder="把朋友的战书粘贴在这里…" spellcheck="false"></textarea><p id="import-error" class="field-error" role="alert"></p><button class="primary-button full-width" data-action="accept-challenge">接受挑战 ${icon('arrow')}</button>`);
}
function acceptChallenge(text: string, start = false): boolean {
  const coopId = coopRoomFromUrl(text);
  if (coopId) { closeDialog(false); void connectCoop(coopId); return true; }
  const roomId = raceRoomFromUrl(text) ?? (/^\s*R-([A-Za-z0-9_-]{12,128})\s*$/.exec(text)?.[1] ?? null);
  if (roomId) { closeDialog(false); void joinOnlineRace(roomId); return true; }
  try {
    const imported = decodeChallenge(text);
    const oldRoute=!!imported.rival && imported.rival.result.roomsCleared!==EXPEDITION_ROOM_COUNT;
    if(oldRoute)delete imported.rival;
    closeDialog(false); goHome();
    challenge = imported; seed=imported.seed; modifier=imported.modifier; weapon=imported.weapon;
    soloRole = imported.character ?? null;
    seedKind = '好友挑战';
    refreshConfig();
    if (location.hash) history.replaceState(null,'',`${location.pathname}${location.search}`);
    toast(oldRoute ? '这是旧四幕战书，已载入同一种子；本次挑战为新版八幕路线。' : imported.rival ? `收到 ${imported.rival.name} 的战书，目标 ${formatTime(imported.rival.result.time)}` : '战书已就绪，开启远征即可挑战。');
    if (start) beginRun();
    return true;
  } catch (error) {
    const message = error instanceof Error ? error.message : '战书无法读取，请检查内容。';
    if (dialog.hasAttribute('open') && document.getElementById('import-error')) $('import-error').textContent = message;
    else toast(message);
    return false;
  }
}
function openLeaderboard(rule: ModifierId = modifier) {
  leaderboardRule = rule;
  const heroes = COOP_CHARACTER_IDS.map(id => `<button type="button" data-board-hero="${id}" aria-pressed="false" style="--board-hero-color:${COOP_CHARACTERS[id].color}">${COOP_CHARACTERS[id].name}</button>`).join('');
  showDialog('通关排行榜', `
    <div class="leaderboard-routes" role="group" aria-label="排行榜路线">
      <button data-board-route="current" aria-pressed="true">八境归星 <small>当前路线</small></button>
      <button data-board-route="history" aria-pressed="false">v4.1 八幕 <small>历史榜</small></button>
      <button data-board-route="legacy" aria-pressed="false">旧四幕 <small>历史榜</small></button>
    </div>
    <div id="leaderboard-scopes" class="leaderboard-scopes" role="group" aria-label="榜单类型">
      <button type="button" data-board-scope="overall" aria-pressed="true">${icon('trophy')} 总排行榜</button>
      <button type="button" data-board-scope="hero" aria-pressed="false">${icon('users')} 英雄排行榜</button>
    </div>
    <div id="leaderboard-heroes" class="leaderboard-heroes" role="group" aria-label="选择英雄" hidden>${heroes}</div>
    <div class="leaderboard-toolbar">
      <span class="leaderboard-connection" id="leaderboard-connection" role="status">正在连接成绩服务…</span>
      <button class="text-button" data-action="refresh-leaderboard">${icon('refresh')} 刷新成绩</button>
    </div>
    <div class="leaderboard-tabs" role="group" aria-label="排行榜规则">${MODIFIER_IDS.map(id=>`<button data-board-rule="${id}" aria-pressed="${id===rule}">${icon(MODIFIERS[id].icon)} ${MODIFIERS[id].name}</button>`).join('')}</div>
    <div id="leaderboard-entries" aria-live="polite" aria-atomic="true"></div>
    <p class="leaderboard-detail" id="leaderboard-detail"></p>
    <div class="leaderboard-signature">
      <label for="leaderboard-name">你的上榜昵称</label>
      <div><input id="leaderboard-name" maxlength="24" value="${esc(playerName)}" autocomplete="nickname"><button class="small-button" data-action="save-leaderboard-name">保存昵称 ${icon('check')}</button></div>
      <p id="nickname-status" class="nickname-status" role="status"></p>
      <small>完成单人八境后自动提交成绩。改名会同步到已有纪录。</small>
    </div>`, true);
  dialog.classList.add('leaderboard-dialog');
  stopLeaderboardUpdates = leaderboard.subscribe(renderLeaderboard);
  renderLeaderboard();
  leaderboard.open();
}
function renderLeaderboard() {
  if (!dialog.hasAttribute('open') || !document.getElementById('leaderboard-entries')) return;
  const state = leaderboard.getState();
  const current = leaderboardRoute === 'current';
  const heroBoard = current && leaderboardScope === 'hero';
  const boardError = state.error || (leaderboardRoute === 'legacy' ? state.legacyError : leaderboardRoute === 'history' ? state.historicalError : null);
  const candidates = leaderboardRoute === 'legacy' ? state.legacyRecords
    : leaderboardRoute === 'history' ? state.historicalRecords
    : heroBoard ? state.heroRecords : state.records;
  const entries = candidates.filter(record => record.result.modifier === leaderboardRule
    && (!heroBoard || recordHero(record) === leaderboardHero)).sort(compareRecords).slice(0,10);
  const live = state.connection === 'live';
  const label = live ? '实时成绩已连接' : state.connection === 'polling' ? '成绩已同步'
    : state.loading ? '正在连接成绩服务…' : '本机缓存纪录';
  $('leaderboard-connection').textContent = label;
  $('leaderboard-connection').classList.toggle('connected', live || state.connection === 'polling');
  $('leaderboard-scopes').hidden = !current;
  $('leaderboard-heroes').hidden = !heroBoard;
  const setActive = (attribute: string, value: string) => {
    document.querySelectorAll<HTMLElement>(`[${attribute}]`).forEach(button =>
      button.setAttribute('aria-pressed', String(button.getAttribute(attribute) === value)));
  };
  setActive('data-board-rule', leaderboardRule);
  setActive('data-board-route', leaderboardRoute);
  setActive('data-board-scope', leaderboardScope);
  setActive('data-board-hero', leaderboardHero);
  const own = leaderboard.getPlayerId();
  const hero = COOP_CHARACTERS[leaderboardHero];
  const title = heroBoard ? hero.name + '榜' : current ? '总排行榜' : '历史成绩';
  const boardName = `<h3 class="leaderboard-list-title">${title}<span>${MODIFIERS[leaderboardRule].name} · 前十</span></h3>`;
  $('leaderboard-entries').innerHTML = boardName + (entries.length ? `
    <div class="leaderboard-head"><span>名次</span><span>玩家</span><span>英雄</span><span>通关时间</span></div>
    <ol class="leaderboard-list">${entries.map((record,index)=>{
      const character = COOP_CHARACTERS[recordHero(record)];
      return `<li class="leaderboard-row ${record.playerId===own?'is-you':''}">
        <span class="leaderboard-rank ${index<3?'podium':''}">${index===0 ? icon('trophy') : String(index+1).padStart(2,'0')}</span>
        <div class="leaderboard-player"><strong>${esc(record.name)}${record.playerId===own?'<em>你</em>':''}</strong><small>${WEAPONS[record.result.weapon].name} · LV.${record.result.level}</small></div>
        <span class="leaderboard-hero" style="--board-hero-color:${character.color}">${character.name}</span>
        <time>${formatTime(record.result.time)}</time>
      </li>`;
    }).join('')}</ol>` : `
    <div class="leaderboard-empty">${icon('trophy')}
      <h3>${state.loading?'正在读取通关成绩…':boardError?'成绩暂时无法读取':'暂无通关成绩'}</h3>
      <p>${boardError?'请稍后刷新。':state.loading?'正在连接排行榜。':heroBoard?`用${hero.name}完成这套规则的八境远征即可上榜。`:'完成这套规则的远征后即可上榜。'}</p>
    </div>`);
  const updated = state.lastUpdated ? new Date(state.lastUpdated).toLocaleTimeString('zh-CN',{hour12:false}) : '';
  const detail = boardError ? boardError : updated ? `最近同步 ${updated}` : '';
  const pending = state.pending ? ` · ${state.pending} 条成绩等待上传` : '';
  $('leaderboard-detail').textContent = detail + pending + (state.pendingRenames ? ' · 昵称等待同步' : '');
  updateRenameStatus();
}
function updateRenameStatus() {
  const status=document.getElementById('nickname-status');
  if(!status)return;
  const state=leaderboard.getState(), rename=state.lastRename;
  status.textContent=renameInProgress?'正在同步昵称…':rename?.status==='pending'?(state.error?.includes('昵称')?state.error:'昵称已在本机应用，正在等待联网同步。'):rename && rename.name===playerName?'昵称已同步，已有上榜纪录也已更新。':'';
  document.querySelectorAll<HTMLButtonElement>('[data-action="save-leaderboard-name"],[data-action="save-name"]').forEach(button=>button.disabled=renameInProgress);
}
async function saveNickname(fieldId: 'leaderboard-name'|'player-name') {
  if(renameInProgress)return;
  playerName=setPlayerName($<HTMLInputElement>(fieldId).value);
  $<HTMLInputElement>(fieldId).value=playerName; refreshConfig();
  renameInProgress=true; updateRenameStatus();
  try {
    const result=await leaderboard.rename(playerName);
    toast(result.status==='pending'?result.error||'昵称已保存，联网后会自动同步到榜单。':'昵称已同步，已有上榜纪录也会更新。');
    if(fieldId==='player-name' && document.getElementById('player-name'))openShare();
  } catch { toast('昵称已在本机保存，请稍后点击刷新重试同步。'); }
  finally { renameInProgress=false; updateRenameStatus(); renderLeaderboard(); }
}
function updateUploadStatus() {
  const element=document.getElementById('result-upload-status');
  if(element)element.textContent=uploadStatus==='pending' ? leaderboard.getState().error||'成绩暂未上传成功，正在等待重试。' : {idle:'通关后自动提交共享排行榜',sending:'正在提交真实通关成绩…',submitted:'成绩已上传 · 按最好用时参与排名',rejected:'这份成绩尚未满足完整通关条件。'}[uploadStatus];
  const retry=document.getElementById('retry-leaderboard');
  if(retry)retry.hidden=uploadStatus!=='pending';
}
function submitVictory(result: GameResult) {
  uploadStatus='sending';
  void leaderboard.submit(playerName,result).then(outcome=>{
    if(savedResult!==result)return;
    currentUploadId=outcome.record?.runId||null;
    uploadStatus=outcome.status==='duplicate'?'submitted':outcome.status;
    updateUploadStatus();
  }).catch(()=>{
    if(savedResult!==result)return;
    uploadStatus='pending';updateUploadStatus();
  });
}
leaderboard.subscribe(()=>{
  updateRenameStatus();
  const submission=leaderboard.getState().lastSubmission;
  if(currentUploadId && submission?.runId===currentUploadId){uploadStatus=submission.status==='duplicate'?'submitted':submission.status;updateUploadStatus();}
});
function refreshAchievementCount() {
  $('achievement-count').textContent = `${achievements.unlocked.size}/${ACHIEVEMENTS.length}`;
}
function openAchievements() {
  refreshAchievementCount();
  showDialog('远征成就', achievementBook(achievements.unlocked), true);
}
function showAchievementFeedback(overlay: HTMLElement, result: GameResult, mode: AchievementMode) {
  const unlocked = achievements.complete(result, mode);
  if (!unlocked.length) return;
  refreshAchievementCount();
  const panel = overlay.querySelector('.result-panel');
  panel?.classList.add('has-achievements');
  panel?.querySelector('.result-actions, button[data-action=home]')?.insertAdjacentHTML('beforebegin', achievementFeedback(unlocked));
}
function openRecords() {
  const records = getRecords();
  const wins = records.filter(r=>r.result.won);
  const best = wins.length ? Math.min(...wins.map(r=>r.result.time)) : null;
  showDialog('每次出发，都算数。', `<div class="records-summary"><div><span>远征次数</span><strong>${records.length.toString().padStart(2,'0')}</strong></div><div><span>击败守卫</span><strong>${wins.length.toString().padStart(2,'0')}</strong></div><div><span>最快通关</span><strong>${best === null ? '—' : formatTime(best)}</strong></div></div><div class="records-heading"><h3>本机远征记录</h3><span>最近 ${records.length} 次 · 最多保存 50 次</span></div>${records.length ? `<div class="record-list">${records.slice(0,15).map(r=>`<div class="record-row"><span class="record-result ${r.result.won ? 'won':''}">${icon(r.result.won ? 'trophy':'flag')}</span><div><strong>${r.result.won ? '远征成功':'未竟的远征'}</strong><small>${esc(r.name)}${r.result.character ? ' · ' + COOP_CHARACTERS[r.result.character].name : ''} · ${MODIFIERS[r.result.modifier].name}</small></div><div class="record-numbers"><strong>${r.result.score.toLocaleString()} <small>分</small></strong><small>${formatTime(r.result.time)}</small></div><button class="icon-button" data-replay-seed="${r.result.seed}" data-character="${r.result.character ?? ''}" data-modifier="${r.result.modifier}" data-weapon="${r.result.weapon}" aria-label="再次挑战这条路线" title="再次挑战">${icon('refresh')}</button></div>`).join('')}</div><button class="text-button danger-text" data-action="clear-records">清空本机记录</button>` : `<div class="empty-records">${icon('flag')}<h3>第一条纪录，等你写下。</h3><p>开启远征后，冒险结果会自动保存在这里。</p><button class="small-button" data-action="close-dialog">回到冒险</button></div>`}`, true);
}
function openHelp(beforeStart = false) {
  const chosen = currentCharacter();
  const combo = getWeaponCombo(chosen);
  const signature = chosen && chosen !== 'traveller' ? COOP_CHARACTERS[chosen] : null;
  const kit = getCharacterWeapons(chosen).map(id => WEAPONS[id]);
  const gear = WEAPONS[engine.state.phase === 'menu' ? soloConfig().weapon : engine.state.hero.weapon];
  const row = (symbol: string, title: string, keys: string, detail: string) => `<div class="guide-row"><span class="guide-symbol">${icon(symbol)}</span><div><h3>${title}</h3><div class="guide-keys">${keys}</div><p>${detail}</p></div></div>`;
  const keyboard = [
    row('arrow', '左右移动', `<kbd>${esc(input.keyLabel('left'))}</kbd><kbd>${esc(input.keyLabel('right'))}</kbd>`, '左右移动，按键可以在操作设置中修改。'),
    row('jump', '跳跃 / 二段跳', `<kbd>${esc(input.keyLabel('jump'))}</kbd>`, '一跳即可上普通平台，长按可上更高平台；空中再按二段跳探索高处捷径。落地前提前按下也能接跳。'),
    row('arrow', '从平台下落', `<kbd>${esc(input.keyLabel('drop'))}</kbd>`, '站在悬空的单向平台上，按一下即可落到下一层。'),
    signature ? row(gear.icon, signature.name + ' · ' + gear.name, `<kbd>${esc(input.keyLabel('attack'))}</kbd>`, gear.description) : row('blade', '攻击 / 三连重斩', `<kbd>${esc(input.keyLabel('attack'))}</kbd>`, '按住连续攻击。短刃第三刀为重斩，更擅长破甲；落到敌人头顶也能踩踏。'),
    row('bolt', '闪避 / 精准反击', `<kbd>${esc(input.keyLabel('dash'))}</kbd>`, '向面朝方向冲刺，短暂无敌。迎着攻击精准闪避，可获得短暂反击强化。'),
    row('shield', '精准格挡', `<kbd>${esc(input.keyLabel('guard'))}</kbd>`, '面朝攻击到来方向，在命中前格挡。按下立即格挡，无需等冲刺结束；精准窗口为 0.24 秒，成功后获得反击机会。'),
    signature ? row(signature.icon, combo?.name ?? '切换随身兵器', kit.map((w,i) => `<kbd>${esc(input.keyLabel((`weapon${i+1}`) as ControlAction))}</kbd> ${w.name}`).join(' '), combo?.description ?? '切换后的第一击获得追击加成。') : row('disc', '切换武器 / 回锋引烬', `<kbd>${esc(input.keyLabel('weapon1'))}</kbd> 短刃 <kbd>${esc(input.keyLabel('weapon2'))}</kbd> 法杖 <kbd>${esc(input.keyLabel('weapon3'))}</kbd> 飞轮`, '法杖命中守卫后会留下灼印。切飞轮，让回程飞轮引爆灼印、打断蓄力。修为 LV.4 / LV.7 时三种兵器同步进阶。'),
    row('star', awakeningName(chosen), `<kbd>${esc(input.keyLabel('overdrive'))}</kbd>`, '星能积满 100 后释放，强化战斗能力并无敌 6 秒。'),
    row('flag', '进入下一幕', `<kbd>${esc(input.keyLabel('interact'))}</kbd><span>或直接走入星门</span>`, '击败本幕全部敌人后开启星门；按 E 时需靠近星门。'),
    row('pause', '暂停 / 继续', `<kbd>Esc</kbd><span>或</span><kbd>${esc(input.keyLabel('pause'))}</kbd>`, '随时暂停休息；再次按下即可继续。'),
  ].join('');
  const touch = [
    row('arrow', '左右移动', '◉ <span>左手摇杆</span>', '拖动左侧摇杆控制移动，松开自动回中；可以同时按右侧战斗键。'),
    row('jump', '跳跃 / 二段跳', `${icon('jump')}<span>跳跃按钮</span>`, '点击跳跃可直接跃上普通平台，长按跳得更高；空中再点一次，二段跳探索高处捷径。'),
    row('arrow', '从平台下落', '<span>摇杆向下</span>', '站在悬空的单向平台上，向下推摇杆即可落到下一层。'),
    signature ? row(gear.icon, signature.name + ' · ' + gear.name, icon(signature.icon) + '<span>攻击按钮</span>', gear.description) : row('blade', '攻击 / 三连重斩', `${icon('blade')}<span>剑形按钮</span>`, '按住剑形按钮连续攻击，松开停止。短刃第三刀重斩，更擅长破甲。'),
    row('bolt', '闪避 / 精准反击', `${icon('bolt')}<span>闪电按钮</span>`, '点闪电向面朝方向冲刺，短暂无敌。精准穿过攻击后，抓住强化反击机会。'),
    row('shield', '精准格挡', `${icon('shield')}<span>盾形按钮</span>`, '面朝攻击方向，在命中前点盾形按钮精准格挡；Boss 也能格挡。'),
    signature ? row(signature.icon, combo?.name ?? '切换随身兵器', kit.map(w => icon(w.icon)).join('') + '<span>点按武器栏</span>', combo?.description ?? '点对应的武器格切换，切换后的第一击获得追击加成。') : row('disc', '切换武器 / 回锋引烬', `${icon('blade')}${icon('ember')}${icon('disc')}<span>武器栏</span>`, '点武器栏切换。法杖命中守卫留下灼印，回程飞轮命中时会引爆灼印并打断蓄力。'),
    row('star', awakeningName(chosen), `${icon('star')}<span>星形按钮</span>`, '星能积满 100 后点星形按钮，强化战斗能力并无敌 6 秒。'),
    row('flag', '进入下一幕', '<span>走入开启的星门</span>', '击败本幕全部敌人后星门开启，走进星门自动进入下一幕。'),
    row('pause', '暂停 / 调整按键', `${icon('pause')}${icon('keyboard')}<span>暂停 / 键盘图标</span>`, '点右上角暂停；点键盘图标可拖动按键、调整大小和透明度。'),
  ].join('');
  const deviceSwitch = `<div class="guide-device-switch" role="group" aria-label="选择操作设备">
    <button class="guide-device" data-guide-device="keyboard" aria-pressed="false">${icon('keyboard')} 电脑键盘</button>
    <button class="guide-device" data-guide-device="touch" aria-pressed="false">${icon('rotate')} 手机触屏</button>
  </div>`;
  showDialog(beforeStart ? '开启远征' : '操作指南 · 准备好再出发', `
    ${beforeStart ? '' : deviceSwitch}
    <div class="guide-body">
      ${beforeStart ? `${soloRoleLaunch(true)}${startRulePicker()}${deviceSwitch}` : ''}
      <section id="guide-keyboard" class="guide-panel" aria-label="电脑键盘操作">
        <p class="guide-intro">先记住 <strong>${esc(input.keyLabel('left'))} / ${esc(input.keyLabel('right'))} 移动、${esc(input.keyLabel('jump'))} 跳跃、${esc(input.keyLabel('attack'))} 攻击</strong>，就能开始冒险。</p>
        <div class="guide-grid">${keyboard}</div>
      </section>
      <section id="guide-touch" class="guide-panel" aria-label="手机触屏操作" hidden>
        <p class="guide-intro">开局<strong>自动进入横屏</strong>：左手移动，右手跳跃和战斗。图标与游戏内按钮一致。</p>
        <div class="guide-grid">${touch}</div>
      </section>
      <div class="guide-objective">${icon('flag')}<p><strong>本局目标</strong>击败守卫 → 进入星门 → 穿过八幕并挑战最终 Boss。拾取经验升级后，择取一道星纹；局内成长每局重新开始。</p></div>
    </div>
    <div class="guide-footer">
      <span>${beforeStart ? '向下滚动查看全部操作，确认后才开始计时。' : '大厅上方的「操作指南」可随时查看。'}</span>
      <button class="primary-button" data-action="${beforeStart ? 'confirm-start' : 'close-dialog'}">${beforeStart ? '开始远征' : '我明白了，返回游戏'} ${icon('arrow')}</button>
    </div>`, true);
  dialog.classList.add('guide-dialog');
  setGuideDevice(isTouchDevice() ? 'touch' : 'keyboard');
}
function setGuideDevice(device: string) {
  if (device !== 'keyboard' && device !== 'touch') return;
  document.querySelectorAll<HTMLButtonElement>('[data-guide-device]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.guideDevice === device)));
  $('guide-keyboard').hidden = device !== 'keyboard';
  $('guide-touch').hidden = device !== 'touch';
  document.querySelector('.guide-body')?.scrollTo(0, 0);
}
function openBuild() {
  const h=engine.state.hero;
  const collected=h.upgrades;
  const count=(id:string)=>collected.filter(value=>value===id).length;
  showDialog('把星光，连成你的打法。', `<p class="dialog-description">每次升级选择一颗星。集齐对应强化，羁绊自动生效。按 <kbd>${esc(input.keyLabel('overdrive'))}</kbd> 释放${awakeningName(currentCharacter())}，让手中的兵器进入六秒超载。</p><div class="build-stats"><span>等级<strong>LV.${h.level}</strong></span><span>基础伤害<strong>${Math.round(h.damage*100)}%</strong></span><span>基础攻速<strong>${h.attackSpeed.toFixed(2)}×</strong></span><span>觉醒次数<strong>${engine.state.overdriveCount}</strong></span></div><h3 class="build-section-title">星座羁绊 <small>${engine.state.synergies.length} / ${SYNERGIES.length} 已点亮</small></h3><div class="synergy-list">${SYNERGIES.map(s=>`<div class="synergy-card ${engine.state.synergies.includes(s.id)?'activated':''}" style="--synergy-color:${s.color}"><span class="synergy-symbol">${icon(engine.state.synergies.includes(s.id)?'star':'link')}</span><div><h3>${s.name}<small>${engine.state.synergies.includes(s.id)?'已激活':'尚未集齐'}</small></h3><p>${s.description}</p><div class="synergy-recipe">${s.requires.map(requirement=>`<span class="${requirement.split('|').some(id=>count(id)>0)?'collected':''}">${requirement.split('|').map(id=>UPGRADES.find(u=>u.id===id)?.name||id).join(' / ')}</span>`).join('<b>＋</b>')}</div></div></div>`).join('')}</div><h3 class="build-section-title">本局强化 <small>${collected.length} 次选择</small></h3><div class="relic-grid">${UPGRADES.map(u=>`<div class="relic-card ${count(u.id)?'owned':''}" style="--relic-color:${u.color}"><span>${icon(u.icon)}</span><div><strong>${u.name}</strong><p>${u.description}</p></div><b>${count(u.id)?`×${count(u.id)}`:'—'}</b></div>`).join('')}</div>`,true);
}
let waitingBinding: ControlAction | null = null;
function refreshControlPrompts() {
  document.querySelector('.dash-hud kbd')!.textContent=input.keyLabel('dash');
  $('first-run-hint').innerHTML=`<span><kbd>${esc(input.keyLabel('left'))}</kbd><kbd>${esc(input.keyLabel('right'))}</kbd> 移动</span><span><kbd>${esc(input.keyLabel('jump'))}</kbd> 跳跃</span><span><kbd>${esc(input.keyLabel('attack'))}</kbd> 攻击</span><span><kbd>${esc(input.keyLabel('guard'))}</kbd> 格挡</span>`;
  const portal=$('portal-prompt').querySelector('span');
  if(portal)portal.innerHTML=isTouchDevice()?'走进星门，自动进入下一幕':`走进星门 / <kbd>${esc(input.keyLabel('interact'))}</kbd>`;
  $('resonance-button').setAttribute('aria-label',`${awakeningName(currentCharacter())}，积满星能后按 ${input.keyLabel('overdrive')}`);
  hudWeaponKey='';
}
function openControls() {
  waitingBinding=null;
  const settings=touchLayout.settings;
  const bindings=input.bindings;
  showDialog('让操作，长在顺手的位置。', `<p class="dialog-description">键盘按你的习惯改，手机左手摇杆、右手战斗。设置会自动保存在当前浏览器。</p><h3 class="keyboard-controls-title">电脑键位</h3><div class="keyboard-bindings">${CONTROL_ACTIONS.map(action=>`<button class="key-binding" data-binding="${action}" aria-label="修改${CONTROL_NAMES[action]}按键"><span>${CONTROL_NAMES[action]}</span><kbd>${esc(keyLabel(bindings[action][0]))}</kbd></button>`).join('')}</div><p id="binding-status" class="binding-status" role="status">点击一项，再按新按键；Esc 始终保留为暂停 / 返回。</p><button class="text-button" data-action="reset-keyboard">${icon('refresh')} 恢复默认键位</button><h3 class="touch-controls-title">手机触屏</h3><div class="control-preview"><span class="control-preview-left">◉ 左手摇杆</span><span class="control-preview-right">${icon('shield')} ${icon('blade')} ${icon('jump')}</span></div><label class="control-range-label" for="control-scale">摇杆与按键大小 <output id="control-scale-value">${Math.round(settings.scale*100)}%</output></label><input class="control-range" id="control-scale" type="range" min="75" max="140" value="${Math.round(settings.scale*100)}"><label class="control-range-label" for="control-opacity">透明度 <output id="control-opacity-value">${Math.round(settings.opacity*100)}%</output></label><input class="control-range" id="control-opacity" type="range" min="25" max="95" value="${Math.round(settings.opacity*100)}"><button class="primary-button full-width" data-action="edit-controls">拖动摇杆与按键 ${icon('arrow')}</button><div class="control-setting-actions"><button class="text-button" data-action="reset-controls">${icon('refresh')} 恢复默认布局</button><button class="text-button" data-action="close-dialog">完成</button></div><p class="field-hint">摇杆与战斗键可以同时操作。横屏与竖屏位置分别保存，下次游玩自动恢复。</p>`);
}
function startBindingCapture(action: ControlAction) {
  waitingBinding=action;input.clear();
  document.querySelectorAll<HTMLElement>('[data-binding]').forEach(button=>{const target=button.dataset.binding===action;button.classList.toggle('waiting',target);if(target)button.querySelector('kbd')!.textContent='请按键';});
  const status=$('binding-status');status.classList.remove('error');status.textContent=`为「${CONTROL_NAMES[action]}」按一个新键，Esc 取消。`;
}
window.addEventListener('keydown',e=>{
  if(!waitingBinding||!dialog.hasAttribute('open'))return;
  e.preventDefault();e.stopImmediatePropagation();
  if(e.repeat)return;
  if(e.code==='Escape'){waitingBinding=null;openControls();return;}
  const action=waitingBinding;
  const result=input.rebind(action,e.code);
  if(!result.ok){const status=$('binding-status');status.classList.add('error');status.textContent=result.conflict?`「${keyLabel(e.code)}」已用于${CONTROL_NAMES[result.conflict]}，请选另一个键。`:'这个按键不能绑定，请换一个键。';return;}
  waitingBinding=null;openControls();refreshControlPrompts();$('binding-status').textContent=`${CONTROL_NAMES[action]}已改为 ${keyLabel(e.code)}，已自动保存。`;
},true);
function startControlEdit() {
  controlsMenuPaused=resumeAfterDialog||engine.state.phase==='playing';
  closeDialog(false);
  if(engine.state.phase==='playing')engine.pause();
  input.clear();
  updatePhase();
  touchLayout.beginEdit();
  $('game-shell').classList.add('editing-controls');
  $('touch-controls').hidden=false;$('phase-screen').hidden=true;
  $('touch-edit-toolbar').hidden=false;
  $<HTMLInputElement>('touch-edit-scale').value=String(Math.round(touchLayout.settings.scale*100));
  $<HTMLInputElement>('touch-edit-opacity').value=String(Math.round(touchLayout.settings.opacity*100));
}
function finishControlEdit(resume=true) {
  touchLayout.endEdit();$('game-shell').classList.remove('editing-controls');$('touch-edit-toolbar').hidden=true;
  input.clear();
  if(resume&&controlsMenuPaused&&engine.state.phase==='paused')engine.resume();
  controlsMenuPaused=false;previousPhase=null;updatePhase();updateOrientation();
  if(resume)toast('按键布局已保存，下次会自动恢复。');
}
function resultScreen(result: GameResult): string {
  const rival = challenge?.rival;
  const sameChallenge = challenge && result.seed === challenge.seed && result.modifier === challenge.modifier && result.weapon === challenge.weapon && result.character === challenge.character && (!rival || rival.result.roomsCleared===result.roomsCleared);
  let comparison = '';
  if (rival && sameChallenge) {
    const delta = rival.result.time - result.time;
    comparison = `<div class="rival-comparison">${icon('users')}<span>${result.won ? Math.abs(delta)<.01 ? `与 ${esc(rival.name)} 的纪录 <strong>打成平手</strong>！` : delta > 0 ? `比 ${esc(rival.name)} 快了 <strong>${delta.toFixed(2)} 秒</strong>！` : `距离 ${esc(rival.name)} 的纪录还有 <strong>${Math.abs(delta).toFixed(2)} 秒</strong>` : `${esc(rival.name)} 的目标纪录：${formatTime(rival.result.time)}`}</span></div>`;
  }
  return `<div class="result-panel ${result.won?'victory':'defeat'}"><div class="result-emblem">${icon(result.won?'trophy':'flag')}</div><span class="overlay-kicker">${result.won?'EXPEDITION COMPLETE':'ONE MORE ADVENTURE?'}</span><h2>${result.won?'星光属于你。':'下次，会更远。'}</h2><p>${result.won?'余烬守卫已倒下。现在，把这份战书交给朋友。':`你已走过 ${result.roomsCleared} 段遗迹，新的搭配正在下一次远征里等你。`}</p><div class="result-stats"><div><span>远征得分</span><strong>${result.score.toLocaleString()}</strong></div><div><span>冒险用时</span><strong>${formatTime(result.time)}</strong></div><div><span>击败敌人</span><strong>${result.kills}</strong></div><div><span>最终等级</span><strong>LV.${result.level}</strong></div></div>${comparison}${result.won?`<div class="result-ranking"><span id="result-upload-status" role="status">正在提交真实通关成绩…</span><button class="text-button" id="retry-leaderboard" data-action="refresh-leaderboard" hidden>重试上传</button><button class="text-button" data-action="leaderboard">${icon('trophy')} 查看通关前十 ${icon('arrow')}</button></div>`:''}<div class="result-actions"><button class="primary-button" data-action="${result.won?'share':'restart'}">${result.won?'向好友下战书':'再来一次'} ${icon(result.won?'arrow':'refresh')}</button><button class="secondary-button" data-action="${result.won?'restart':'share'}">${result.won?'再战同一路线':'邀请好友挑战'}</button></div><button class="text-button" data-action="home">${icon('arrowLeft')} 回到远征大厅</button></div>`;
}
function updatePhase() {
  const s = engine.state;
  const upgradeKey=s.phase==='upgrade'?`${s.hero.level}:${s.upgradeChoices.map(u=>u.id).join(',')}`:'';
  if (s.phase === previousPhase && upgradeKey === previousUpgradeKey) return;
  previousUpgradeKey=upgradeKey;
  previousPhase = s.phase;
  upgradeSelection.close();
  input.clear(); pendingInput = { ...EMPTY_INPUT };
  const menu = s.phase === 'menu';
  $('menu-screen').hidden = !menu;
  $('hud').hidden = menu;
  $('stage-bottom').hidden = !menu;
  $('touch-controls').hidden = s.phase !== 'playing' && !touchLayout.editing;
  updateOrientation();
  $('game-shell').dataset.phase = s.phase;
  coopLaunch.hidden = !menu;
  $<HTMLSelectElement>('modifier-select').disabled = !menu;
  document.querySelectorAll<HTMLButtonElement>('[data-action="new-seed"],[data-action="daily"]').forEach(b=>b.disabled=!menu);
  if (s.phase === 'menu' || s.phase === 'victory' || s.phase === 'gameover') audio.resetScore();
  const overlay = $('phase-screen');
  overlay.hidden = !['paused','upgrade','victory','gameover'].includes(s.phase);
  overlay.className = `phase-screen ${s.phase === 'upgrade' ? 'upgrade-screen jade-upgrade-screen':''}`;
  if (s.phase === 'paused') overlay.innerHTML = `<div class="pause-panel"><div class="pause-symbol">${icon('pause')}</div><span class="overlay-kicker">TAKE A LITTLE BREATH</span><h2>冒险，稍候片刻。</h2><p>月光还在，旅程也还在。</p><button class="primary-button" data-action="pause">继续远征 ${icon('play')}</button><div class="pause-secondary"><button class="text-button" data-action="restart">${icon('refresh')} 重新挑战</button><button class="text-button" data-action="home">${icon('arrowLeft')} 回到大厅</button></div><div class="pause-tools"><button class="text-button" data-action="sound">${icon(audio.muted?'muted':'sound')} 切换声音</button><button class="text-button" data-action="fullscreen">${icon('fullscreen')} 切换全屏</button><button class="text-button" data-action="controls">${icon('keyboard')} 按键布局</button></div><span class="pause-hint">按 ESC 或 ${esc(input.keyLabel('pause'))} 继续</span></div>`;
  else if (s.phase === 'upgrade') {
    overlay.innerHTML = renderUpgradeScreen(s.upgradeChoices, s.hero);
    upgradeSelection.open(overlay, chooseUpgrade);
  } else if ((s.phase === 'victory' || s.phase === 'gameover') && s.result && coopPlay) {
    const party = coopPlay.party();
    overlay.innerHTML = coopResult(s.result, party);
    const players = party.filter(member => member.connected).length;
    showAchievementFeedback(overlay, { ...s.result, character:s.character, deaths:s.deaths, maxCombo:s.maxCombo,
      overdriveCount:s.overdriveCount }, {kind:'coop', players});
  } else if ((s.phase === 'victory' || s.phase === 'gameover') && s.result) {
    if (savedResult !== s.result) { saveRecord(playerName,s.result); savedResult=s.result; if(s.result.won)submitVictory(s.result); }
    overlay.innerHTML = resultScreen(s.result);
    showAchievementFeedback(overlay, s.result, achievementMode);
    if (liveRace.view.room) overlay.querySelector('.result-stats')?.insertAdjacentHTML('beforebegin', '<div id="race-result-summary"></div>');
    raceSummaryKey = '';
    updateUploadStatus();
  } else overlay.innerHTML = '';
}
let heartsKey = '';
let hudWeaponKey = '';
let previousWeaponTier = 1;
let hudBuffKey = '';
function updateHud() {
  const s=engine.state,h=s.hero;
  const roster = $('coop-roster');
  const players = coopPlay?.party() ?? [];
  roster.hidden = !coopPlay || s.phase !== 'playing';
  const rosterHtml = roster.hidden ? '' : coopHud(players);
  if (rosterHtml !== coopHudKey) { roster.innerHTML = rosterHtml; coopHudKey = rosterHtml; }
  const selfRole = coopPlay ? players.find(person => person.seat === coopSession.view.seat)?.role : s.character;
  $('hero-name').textContent = selfRole ? COOP_CHARACTERS[selfRole].name : playerName;
  const avatar = selfRole && selfRole !== 'traveller' ? getCoopPortrait(selfRole) : soloAvatar;
  if (displayedAvatar !== avatar) {
    displayedAvatar = avatar;
    document.querySelector<HTMLElement>('.avatar-mini')!.style.backgroundImage = avatar ? `url("${avatar}")` : '';
  }
  const buffHud=$('buff-seal-hud');
  buffHud.hidden=s.phase!=='playing'||h.upgrades.length===0;
  const buffKey=`${h.upgrades.join(',')}:${h.shield}`;
  if(buffKey!==hudBuffKey){hudBuffKey=buffKey;buffHud.innerHTML=renderBuffSeals(UPGRADES,h);}
  if (s.phase === 'menu') { previousWeaponTier=1; $('boss-hud').hidden=true; $('portal-prompt').hidden=true; $('objective-hud').hidden=true; $('first-run-hint').hidden=true; $('game-shell').classList.remove('awakened'); $('announcement').classList.remove('visible'); return; }
  $('level-label').textContent=`LV. ${h.level}`;
  const hpKey=`${h.hp}-${h.maxHp}-${h.shield}`;
  if (hpKey!==heartsKey) { heartsKey=hpKey; $('hearts').innerHTML=Array.from({length:h.maxHp},(_,i)=>`<span class="heart ${i<h.hp?'filled':''}" aria-hidden="true"></span>`).join('')+(h.shield>0?`<span class="shield-charge">${icon('shield')} ${h.shield}</span>`:''); $('hearts').setAttribute('aria-label',`生命 ${h.hp} / ${h.maxHp}`); $('health-value').textContent=`${h.hp} / ${h.maxHp}`; }
  const xpProgress=Math.min(100,h.xp/h.xpNeeded*100);
  $('xp-bar').style.width=`${xpProgress}%`;
  $('xp-track').setAttribute('aria-valuenow',String(Math.round(xpProgress)));
  $('xp-value').textContent=`${h.xp} / ${h.xpNeeded}`;
  $('room-count').textContent=`${(s.roomIndex+1).toString().padStart(2,'0')} / ${s.roomCount.toString().padStart(2,'0')}`;
  $('room-name').textContent=s.room.name; $('run-timer').textContent=formatTime(s.time); $('coins').textContent=s.coins.toString();
  const dashCooldown=s.overdrive>0?.38:Math.max(.7,1.35-h.upgrades.filter(id=>id==='stride').length*.15);
  $('dash-fill').style.width=`${Math.max(0,Math.min(100,(1-h.dashCooldown/dashCooldown)*100))}%`;
  const guardActive=h.guardTimer>0;
  $('guard-status').textContent=guardActive?'格挡生效':h.guardCooldown>0?`格挡恢复 ${h.guardCooldown.toFixed(1)}s`:`格挡 ${input.keyLabel('guard')} · 就绪`;
  const guardButton=document.querySelector<HTMLButtonElement>('[data-touch="guard"]');
  if(guardButton){
    guardButton.dataset.guardState=guardActive?'active':h.guardCooldown>0?'cooldown':'ready';
    guardButton.style.setProperty('--guard-ready',`${Math.round(Math.max(0,Math.min(1,1-h.guardCooldown/.36))*100)}%`);
    guardButton.setAttribute('aria-label',guardActive?'格挡生效':h.guardCooldown>0?'格挡恢复中':'精准格挡，按下立即生效');
  }
  const awakened=s.overdrive>0;
  const resonanceReady=s.resonance>=100;
  $('resonance-button').classList.toggle('ready',resonanceReady&&!awakened);
  $('resonance-button').classList.toggle('awakened',awakened);
  $('game-shell').classList.toggle('awakened',awakened);
  const awakening = awakeningName(selfRole);
  const resonanceTitle = awakened ? awakening + ' · 超载中' : `${awakening} <kbd>${esc(input.keyLabel('overdrive'))}</kbd>`;
  if ($('resonance-title').innerHTML !== resonanceTitle) {
    $('resonance-title').innerHTML=resonanceTitle;
    $('resonance-button').setAttribute('aria-label', awakening + '，积满星能后释放');
    document.querySelector('[data-touch="overdrive"]')?.setAttribute('aria-label', awakening);
  }
  $('resonance-value').textContent=awakened?`无敌 ${s.overdrive.toFixed(1)} 秒`:resonanceReady?`按 ${input.keyLabel('overdrive')} / 点击觉醒`:`${Math.floor(s.resonance)} / 100 星能`;
  $('resonance-fill').style.width=`${awakened?s.overdrive/AWAKENING_DURATION*100:s.resonance}%`;
  $('synergy-count').textContent=`${s.synergies.length} / 3`;
  const alive=s.enemies.filter(enemy=>!enemy.dead);
  $('objective-hud').hidden=s.phase!=='playing';
  const boss = s.boss;
  const entrance = boss && isWardenEntrance(boss);
  const eliteTrial = s.coopPartySize !== undefined && s.roomIndex === COOP_ELITE_ROOM_INDEX;
  const trial = s.roomIndex < s.roomCount - 1 ? '神殿试炼' : '最终试炼';
  const trialPhase = entrance ? '王庭封门' : boss?.phase === 3 ? (boss.kind === 'warden' ? '王刃裁天' : '天烬降临') : boss?.form === 2 ? '黑化形态' : '第一形态';
  $('enemy-count').textContent = s.roomCleared ? '星门已开启'
    : s.room.isBoss ? `${trial} · ${trialPhase}` : `${eliteTrial ? '校场清剿' : '守卫讨伐'} · ${s.enemies.length-alive.length} / ${s.enemies.length}`;
  const objectiveProgress=s.room.isBoss&&s.boss?1-s.boss.hp/s.boss.maxHp:s.enemies.length?1-alive.length/s.enemies.length:1;
  $('objective-fill').style.width=`${Math.max(0,Math.min(100,objectiveProgress*100))}%`;
  const nearest=[...alive].sort((a,b)=>Math.abs(a.x-h.x)-Math.abs(b.x-h.x))[0];
  $('objective-hint').textContent=s.roomCleared?'向右前往星门 →':s.room.isBoss?'观察预警，格挡或闪避后反击':nearest&&Math.abs(nearest.x-h.x)>600?`${nearest.x<h.x?'←':'→'} 寻找剩余的守卫`:eliteTrial?'击败精英与随从，在星门会合':'击败本幕守卫，开启下一道星门';
  $('first-run-hint').hidden=!(s.phase==='playing'&&s.roomIndex===0&&s.time<10);
  const tier=weaponTier(h), tierGlyph=['Ⅰ','Ⅱ','Ⅲ'][tier-1], nextTier=tier===3?'兵器已至三阶':`修为 LV.${tier===1?4:7} 自动进阶`;
  if(tier>previousWeaponTier&&s.phase==='playing'){previousWeaponTier=tier;toast(`兵器进阶 · ${tier===2?'二阶':'三阶'}战技已觉醒，三种武器同步升级。`);}
  const weaponKey=`${h.weapon}-${tier}-${selfRole ?? 'classic'}`;
  if (hudWeaponKey !== weaponKey) {
    const attackButton = document.querySelector<HTMLButtonElement>('[data-touch="attack"]')!;
    attackButton.innerHTML = icon(WEAPONS[h.weapon].icon);
    attackButton.setAttribute('aria-label', WEAPONS[h.weapon].name + '攻击');
  }
  if (hudWeaponKey !== weaponKey) {
    hudWeaponKey = weaponKey;
    $('weapon-hud').innerHTML = getCharacterWeapons(selfRole).map((id, i) => {
      const w = WEAPONS[id], key = esc(input.keyLabel((`weapon${i+1}`) as ControlAction));
      const equipped = h.weapon === id;
      return `<button class="hud-weapon ${equipped ? 'equipped' : ''}" data-weapon="${id}" style="--weapon-color:${w.color}" title="${w.name} · ${tier}阶 · ${nextTier} · ${key}" aria-pressed="${equipped}" aria-label="切换${w.name}，当前${tier}阶"><kbd>${key}</kbd>${icon(w.icon)}<span>${w.name}</span><em class="weapon-tier" aria-hidden="true">${tierGlyph}</em></button>`;
    }).join('');
  }
  $('boss-hud').hidden=!(boss && boss.active && boss.hp>0 && s.phase==='playing');
  if (boss) {
    $('boss-fill').style.width=`${Math.max(0,boss.hp/boss.maxHp*100)}%`;
    const dark=boss.form===2;
    if (dark) $('boss-hud').style.setProperty('--boss-guard',`${Math.max(0,boss.guard/boss.maxGuard)*100}%`);
    const bossName = boss.kind === 'warden' ? COOP_WARDEN_NAME : dark ? '玄烬魔君' : '余烬守卫';
    const phaseName = entrance ? '降临' : dark ? (boss.phase === 3 ? '最终形态' : boss.mode === 'transition' ? '黑化觉醒' : '第二形态') : '第一形态';
    $('boss-name').textContent = bossName;
    $('boss-phase').textContent = phaseName;
    $('boss-hud').classList.toggle('dark-form',dark);
    $('boss-hud').classList.toggle('ascended-form',dark&&boss.phase===3);
    $('boss-hud').classList.toggle('transforming',dark&&boss.mode==='transition');
    $('boss-hud').setAttribute('aria-label',`${bossName}，${phaseName}，生命${Math.ceil(boss.hp)}/${boss.maxHp}`);
    $('boss-hud').classList.toggle('exposed',boss.exposed>0);
    $('boss-tactic').textContent=entrance ? '王庭封门 · 重剑即将落地' : boss.mode==='stagger'?'破甲！抓紧全力输出':boss.exposed>0?'破绽窗口 · 反击增伤':boss.mode==='transition'?(boss.phase===2?'余烬化墨 · 满血觉醒，准备迎战':'天烬降临 · 注意交错金线'):boss.mode==='windup'?{charge:boss.phase===3&&boss.chain>0?'连环冲锋 · 闪避并离开杖印':'冲锋预警 · 格挡或穿越闪避',leap:'跃击预警 · 离开落点',slam:'震地预警 · 跳过地波',barrage:'弹幕预警 · 保持移动',rift:'地裂墨柱 · 离开脚下印记',rain:'墨雨将至 · 移动寻找间隙',eclipse:'天烬裁决 · 躲入无印空隙'}[boss.intent as 'charge'] ?? '星锁预警 · 观察落点后闪避':dark&&boss.guard>0?`玄甲 ${Math.ceil(boss.guard)} / ${boss.maxGuard} · 格挡或重斩破甲`:`护甲 ${Math.ceil(boss.guard)} / ${boss.maxGuard} · 格挡与连斩可破甲`;
  }
  $('portal-prompt').hidden=!(s.roomCleared && (!s.room.isBoss || Boolean(coopPlay && s.roomIndex < s.roomCount-1)) && s.phase==='playing');
  const clock=coopPlay?.chapterClock;
  let line='', title=s.announcementTimer > 0 ? s.announcement : '';
  if (clock?.room===s.roomIndex) {
    story.observeCoopChapter(s.seed,s.roomIndex,s.room.theme,s.phase==='victory');
    if (s.phase==='playing') {
      const afterClear=clock.clearedAt!==null && clock.time-clock.clearedAt<6.8;
      if (afterClear && s.room.isBoss && s.roomIndex < s.roomCount-1) {
        title='余烬守卫'; line=GUARDIAN_FAREWELL;
      } else if (afterClear && eliteTrial) {
        title='玄阙校场'; line=ELITE_CLEAR_LINE;
      } else if (entrance) {
        title=COOP_WARDEN_NAME; line=coopChapter(s.roomIndex,s.room.theme).line;
      } else if (clock.clearedAt===null && clock.time-clock.enteredAt < 6.8 && !boss?.active) {
        const page=coopChapter(s.roomIndex,s.room.theme);
        line=boss?.kind==='warden'?'行牒的红绳忽然绷紧，殿门后传来一声剑鸣。':page.line;
        title ||= s.room.name;
      }
    }
  }
  const subtitle=$('coop-story-line'), heading=$('announcement-title');
  if (subtitle.textContent!==line) subtitle.textContent=line;
  subtitle.hidden=!line;
  if (heading.textContent!==title) heading.textContent=title;
  $('announcement').classList.toggle('visible',Boolean(title || line) && s.phase==='playing');
}

document.addEventListener('click', e => {
  const button=(e.target as HTMLElement).closest<HTMLElement>('[data-action],[data-coop-role],[data-race-action],[data-weapon],[data-upgrade],[data-replay-seed],[data-guide-device],[data-start-rule],[data-board-rule],[data-board-route],[data-board-scope],[data-board-hero],[data-binding]');
  if (!button || button.hasAttribute('disabled')) return;
  const role = button.dataset.coopRole as CoopCharacterId | undefined;
  if (role && COOP_CHARACTER_IDS.includes(role)) { coopAction(() => coopSession.selectRole(role)); return; }
  if (button.dataset.raceAction) {
    const action = button.dataset.raceAction;
    if (action === 'switch-server') {
      if (liveRace.view.room && (liveRace.view.selfId !== 'host' || liveRace.view.opponent || liveRace.view.started)) return;
      raceDialogOpen = false; raceStartAllowed = false;
      clearRaceAddress();
      void liveRace.leave().then(() => createOnlineRace('server'));
    }
    else if (action === 'new-direct') { clearRaceAddress(); void createOnlineRace(); }
    else if (action === 'copy') void copyField('race-invite');
    else if (action === 'copy-code') void copyField('race-code');
    else if (action === 'retry') { if (invitedRoomId) void joinOnlineRace(invitedRoomId); else void createOnlineRace(); }
    else if (action === 'ready') { if (!artReady) toast('画卷正在载入，请稍候再准备。'); else { void audio.unlock(); void liveRace.ready(liveRace.view.self?.readyAt == null).catch(() => {}); } }
    else if (action === 'leave') { raceStartAllowed = false; closeDialog(); void liveRace.leave(); clearRaceAddress(); }
    else if (action === 'reset' && liveRace.view.self?.finishedAt && liveRace.view.opponent?.finishedAt) { raceDialogOpen = true; void liveRace.reset().catch(() => {}); }
    return;
  }
  if (button.dataset.action === 'race-role') {
    const character = button.dataset.role;
    if (character === 'classic' || isCharacterId(character))
      void liveRace.chooseCharacter(character === 'classic' ? null : character).catch(() => {});
    return;
  }
  if (button.dataset.boardRoute==='current'||button.dataset.boardRoute==='history'||button.dataset.boardRoute==='legacy') { leaderboardRoute=button.dataset.boardRoute; renderLeaderboard(); return; }
  if (button.dataset.boardScope === 'overall' || button.dataset.boardScope === 'hero') {
    leaderboardScope = button.dataset.boardScope;
    renderLeaderboard();
    return;
  }
  if (isCharacterId(button.dataset.boardHero)) {
    leaderboardHero = button.dataset.boardHero;
    renderLeaderboard();
    return;
  }
  if (button.dataset.boardRule && MODIFIER_IDS.includes(button.dataset.boardRule as ModifierId)) { leaderboardRule=button.dataset.boardRule as ModifierId; renderLeaderboard(); return; }
  if (button.dataset.binding && CONTROL_ACTIONS.includes(button.dataset.binding as ControlAction)) { startBindingCapture(button.dataset.binding as ControlAction); return; }
  if (button.dataset.guideDevice) { setGuideDevice(button.dataset.guideDevice); return; }
  if (button.dataset.startRule) { selectExpeditionRule(button.dataset.startRule); return; }
  if (button.dataset.replaySeed) {
    goHome();
    seed = Number(button.dataset.replaySeed);
    modifier = button.dataset.modifier as ModifierId;
    soloRole = isCharacterId(button.dataset.character) ? button.dataset.character : null;
    weapon = isLoadoutWeapon(soloRole, button.dataset.weapon) ? button.dataset.weapon : getCharacterWeapons(soloRole)[0];
    challenge = null;
    seedKind = '再次挑战';
    refreshConfig();
    beginRun();
    return;
  }
  if (button.dataset.weapon) { selectWeapon(button.dataset.weapon as WeaponId); return; }
  if (button.dataset.upgrade) return;
  switch(button.dataset.action) {
    case 'start': if(engine.state.phase==='menu') { if (coopSession.view.room) openCoopRoom(); else if (liveRace.view.room) openRaceRoom(); else openHelp(true); } break;
    case 'confirm-start': if(engine.state.phase==='menu') beginRun(); break;
    case 'solo-role-open': openSoloRoles(button.dataset.roleOrigin === 'guide'); break;
    case 'solo-role-pick': selectSoloRole(button.dataset.role); break;
    case 'solo-role-to-guide': if(engine.state.phase==='menu') openHelp(true); break;
    case 'restart': if (liveRace.view.room) { openRaceRoom(); toast('竞速中不能单独重开；两人结束后可再赛一场。'); } else beginRun(); break;
    case 'home': goHome(); break;
    case 'pause': togglePause(); break;
    case 'sound': void audio.unlock(); audio.setMuted(!audio.muted); try {localStorage.setItem('starhop-muted',String(audio.muted));}catch{} updateSoundButton(); break;
    case 'fullscreen': if(fullscreenElement()) void exitFullscreen(); else if(isTouchDevice()&&engine.state.phase!=='menu') void enterLandscape(); else { const stage=(isTouchDevice()?document.documentElement:$('game-shell')) as FullscreenStage; const request=stage.requestFullscreen||stage.webkitRequestFullscreen; if(request) void settleDisplayRequest(()=>request.call(stage)); else toast('开始游戏后会自动进入横屏。'); } break;
    case 'coop': case 'coop-retry': void connectCoop(button.dataset.action==='coop-retry' ? coopInviteId : null); break;
    case 'coop-copy': void copyField('coop-invite'); break;
    case 'coop-leave': goHome(); break;
    case 'coop-ready': {
      if (!artReady) { toast('画卷正在载入，请稍候再准备。'); break; }
      void audio.unlock();
      const self = coopSession.view.room?.players.find(player => player.seat === coopSession.view.seat);
      coopAction(() => coopSession.setReady(!self?.ready)); break;
    }
    case 'coop-start': void audio.unlock(); coopAction(() => coopSession.start()); break;
    case 'share': if (liveRace.view.connection !== 'connecting') void createOnlineRace(); break;
    case 'solo-share': closeDialog(false); openShare(); break;
    case 'race-room': openRaceRoom(); break;
    case 'copy-url': void copyField('share-url'); break;
    case 'copy-code': void copyField('share-code'); break;
    case 'import': openImport(); break;
    case 'accept-challenge': acceptChallenge($<HTMLTextAreaElement>('import-code').value); break;
    case 'leaderboard': openLeaderboard(engine.state.result?.modifier||modifier); break;
    case 'refresh-leaderboard': void leaderboard.refresh(); toast('正在同步最新成绩，并重试待上传的纪录。'); break;
    case 'save-leaderboard-name': void saveNickname('leaderboard-name'); break;
    case 'records': openRecords(); break;
    case 'achievements': openAchievements(); break;
    case 'help': openHelp(); break;
    case 'credits': showDialog('画卷背后的创作者', `<p class="dialog-description">这次远征使用了来自 itch.io 的角色、场景与特效，并进行了场景编排、调色和动画接入。</p><div class="art-credits"><p><strong><a href="https://luizmelo.itch.io/" target="_blank" rel="noopener">LuizMelo</a></strong> · Martial Hero / Martial Hero 2 / Monsters Creatures Fantasy / Evil Wizard / Evil Wizard 2<br>角色与战斗动画 · CC0</p><p><strong><a href="https://merchant-shade.itch.io/free-16x16-weapon-rpg-icons" target="_blank" rel="noopener">Kurt Gabriel Sotelo（Shade）</a></strong> · Free 16x16 Weapon RPG Icons<br>三件兵器沿用该素材的像素底稿 · CC0，已裁帧、调色并对齐握点。霜枝杖与柳叶软剑为本项目原创。</p><p><strong>合作远征 · LuizMelo</strong> · <a href="https://luizmelo.itch.io/fantasy-warrior" target="_blank" rel="noopener">Fantasy Warrior</a> / <a href="https://luizmelo.itch.io/huntress" target="_blank" rel="noopener">Huntress</a> / <a href="https://luizmelo.itch.io/evil-wizard-3" target="_blank" rel="noopener">Evil Wizard 3</a> / <a href="https://luizmelo.itch.io/hero-knight" target="_blank" rel="noopener">Hero Knight</a><br>合作角色与镇星王的动作底稿 · CC0</p><p><strong>玄阙校场 · LuizMelo</strong> · <a href="https://luizmelo.itch.io/hero-knight-2" target="_blank" rel="noopener">Hero Knight 2</a> / <a href="https://luizmelo.itch.io/martial-hero-3" target="_blank" rel="noopener">Martial Hero 3</a><br>精英守军动作 · CC0，已调色并对齐动作落脚点。</p><p><strong><a href="https://karsiori.itch.io/free-pixel-art-lantern-pack" target="_blank" rel="noopener">karsiori · Free Pixel Art Lantern Pack</a></strong><br>巡炉灯魇的灯身与火芯 · CC0，已重调配色并补画灯穗。</p><p><strong><a href="https://chierit.itch.io/elementals-ground-monk" target="_blank" rel="noopener">chierit · Elementals: Ground Monk</a></strong><br>铜衣武僧动作 · <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener">CC BY 4.0</a>，已裁帧、对齐并调色。</p><p><strong><a href="https://anokolisa.itch.io/sidescroller-pixelart-sprites-asset-pack-forest-16x16" target="_blank" rel="noopener">Anokolisa</a></strong> · Legacy Fantasy High Forest<br>森林、遗迹与自然道具 · 作者商用许可</p><p><strong><a href="https://ansimuz.itch.io/" target="_blank" rel="noopener">ansimuz</a></strong> · Magic Cliffs / Gothicvania Town<br>海崖、城镇与多层背景 · CC0</p><p><strong><a href="https://szadiart.itch.io/pixel-platformer-castle" target="_blank" rel="noopener">Szadi art.</a></strong> · Castle Platformer<br>城堡、瓦片与火把 · 作者商用许可</p><p><strong>Pimen</strong> · <a href="https://pimen.itch.io/pixel-battle-effects" target="_blank" rel="noopener">Pixel Battle Effects</a> / <a href="https://pimen.itch.io/cutting-and-healing" target="_blank" rel="noopener">Cutting and Healing</a><br>斩击与命中特效 · <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener">CC BY 4.0</a>，已做帧条整理及调色。</p><p>远征配乐由本项目作曲，使用 <a href="https://versilian-studios.com/vcsl/" target="_blank" rel="noopener">Versilian 音色库（CC0）</a> 的实录乐器。完整素材与许可见项目说明。</p></div>`, true); break;
    case 'build': openBuild(); break;
    case 'awaken': if(engine.state.resonance>=100) input.trigger('overdrive'); else toast('攻击、击败敌人与拾取经验，都能积攒星能。'); break;
    case 'controls': openControls(); break;
    case 'reset-keyboard': input.resetBindings();openControls();refreshControlPrompts();toast('已恢复默认键位。');break;
    case 'edit-controls': startControlEdit(); break;
    case 'save-controls': finishControlEdit(); break;
    case 'reset-controls': touchLayout.reset();if(dialog.hasAttribute('open'))openControls();else{$<HTMLInputElement>('touch-edit-scale').value='100';$<HTMLInputElement>('touch-edit-opacity').value='65';}toast('已恢复默认拇指布局。');break;
    case 'close-dialog': closeDialog(); break;
    case 'save-name': void saveNickname('player-name'); break;
    case 'clear-records': clearRecords(); openRecords(); toast('本机记录已清空。'); break;
    case 'daily': if(engine.state.phase!=='menu')return; seed=getDailySeed(); seedKind='今日远征'; challenge=null; refreshConfig(); toast('今日同图挑战已就绪。'); break;
    case 'new-seed': {
      if (engine.state.phase !== 'menu') return;
      if (liveRace.view.room) { openRaceRoom(); return; }
      const oldOrder = expeditionOrder(seed).join(',');
      let nextSeed = randomSeed();
      while (expeditionOrder(nextSeed).join(',') === oldOrder) nextSeed = (nextSeed + 1) >>> 0;
      seed = nextSeed; seedKind='重排路线'; challenge=null; refreshConfig(); audio.play('select');
      const [first, second] = expeditionOrder(seed);
      toast(`新路线 · ${EXPEDITION_TITLES[first][0]} → ${EXPEDITION_TITLES[second][0]}`); break;
    }
  }
});
$('modifier-select').addEventListener('change', e => selectExpeditionRule((e.target as HTMLSelectElement).value));
document.addEventListener('input',e=>{
  const el=e.target as HTMLInputElement;
  if(el.id==='control-scale'||el.id==='touch-edit-scale'){touchLayout.setScale(Number(el.value)/100);if(document.getElementById('control-scale-value'))$('control-scale-value').textContent=`${el.value}%`;}
  else if(el.id==='control-opacity'||el.id==='touch-edit-opacity'){touchLayout.setOpacity(Number(el.value)/100);if(document.getElementById('control-opacity-value'))$('control-opacity-value').textContent=`${el.value}%`;}
});
window.addEventListener('blur',()=>{ input.clear(); if (!coopPlay && !isTouchDevice() && engine.state.phase === 'playing') engine.pause(); });
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(!coopPlay&&engine.state.phase==='playing')engine.pause();input.clear();audio.setMusic(false);}});
window.addEventListener('resize',()=>{layoutLobbyActions();renderer.resize();updateOrientation();});
screen.orientation?.addEventListener?.('change',updateOrientation);
window.addEventListener('orientationchange',updateOrientation);
document.addEventListener('fullscreenchange',()=>{renderer.resize();updateOrientation();});
document.addEventListener('webkitfullscreenchange',()=>{renderer.resize();updateOrientation();});
window.addEventListener('hashchange',()=>{const roomId = raceRoomFromUrl(location.href); if (roomId) void joinOnlineRace(roomId); else if(location.hash.startsWith('#c='))acceptChallenge(location.href);});

let accumulator=0, previousTime=performance.now(), pendingInput={...EMPTY_INPUT};
let nextCoopHud=0;
const story = installStory(engine, { clearInput: () => { input.clear(); pendingInput={...EMPTY_INPUT}; accumulator=0; }, route: () => expeditionOrder(seed), skipScenes: () => Boolean(liveRace.view.room) });
function frame(now: number) {
  const delta=Math.min(.05,(now-previousTime)/1000); previousTime=now;
  if (!coopPlay) story.update();
  accumulator+=delta;
  pendingInput=mergeInput(pendingInput,input.read());
  while(accumulator>=1/60) { if (coopPlay) coopPlay.tick(1/60,dialog.hasAttribute('open')?EMPTY_INPUT:pendingInput); else engine.update(1/60,pendingInput); pendingInput=withoutEdges(pendingInput); accumulator-=1/60; }
  updatePhase();
  if (engine.state.phase === 'paused') $('phase-screen').hidden = story.open || dialog.hasAttribute('open') || touchLayout.editing;
  const state = engine.state;
  if (state.boss && !state.boss.active) audio.warmGuardian();
  const cue = scoreCue(coopPlay && state.phase==='upgrade' ? {...state,phase:'playing'} : state);
  const transitionOffset = state.boss && isWardenEntrance(state.boss)
    ? WARDEN_ENTRANCE_TIME - state.boss.timer
    : state.boss && openingAscension(state.boss)
    ? BOSS_ASCENSION_TIME - state.boss.timer
    : state.boss && openingSeal(state.boss) ? BOSS_TRANSFORM_TIME - state.boss.timer : undefined;
  audio.setMusic(document.hidden ? null : cue, transitionOffset);
  updateRaceFrame();
  const visual = coopPlay?.display(delta);
  renderer.render(visual?.state ?? state,now/1000,liveRace.opponentFrame(),visual?.party);
  // World snapshots are slower than the canvas. Keep mobile layout and
  // accessibility updates off the intervening animation frames.
  if (!coopPlay || now >= nextCoopHud) {
    if (coopPlay) nextCoopHud=now+32;
    updateHud();
  }
  requestAnimationFrame(frame);
}
refreshConfig(); refreshAchievementCount(); refreshControlPrompts(); renderer.resize();
if(location.hash.startsWith('#c=')) acceptChallenge(location.href);
const invitedCoop = coopRoomFromUrl(location.href);
const invitedRace = raceRoomFromUrl(location.href);
if (invitedCoop) void connectCoop(invitedCoop);
else if (invitedRace) void joinOnlineRace(invitedRace);
requestAnimationFrame(frame);
// Development-only inspection allows input and complete-run checks without changing production gameplay.
if(import.meta.env.DEV) Object.assign(window,{__STARHOP__:{engine,beginRun,getChallenge,acceptChallenge,renderer,artLoadState,story,coopSession,get coopPlay(){return coopPlay;}}});

