import { artImage } from './art-assets';
import { CLEAVE_LIFE, judgmentArea, quakeOrigin, QUAKE_LIFE, QUAKE_SPEED } from './court-attacks';
import type { RegionalEnemyProfile } from './enemy-catalog';
import type { Enemy, Projectile } from './types';

function ticks(c: CanvasRenderingContext2D, x: number, y: number, side: number, count: number, step: number) {
  for (let i = 0; i < count; i++) {
    const px = Math.round(x + side * i * step);
    c.fillRect(px, y, 3, 2);
    c.fillRect(px - side * 3, y - 2, 3, 2);
  }
}

function tell(c: CanvasRenderingContext2D, e: Enemy, profile: RegionalEnemyProfile, progress: number) {
  const foot = Math.round(e.y + e.h);
  c.save();
  c.globalAlpha *= .66 + .34 * progress;
  if (profile.ability === 'shieldquake') {
    for (const side of [-1, 1]) {
      const origin = quakeOrigin(e, side);
      const start = Math.round(side < 0 ? origin.x : origin.x + origin.w);
      const reach = Math.round(QUAKE_LIFE * QUAKE_SPEED);
      c.fillStyle = '#8b7255';
      c.fillRect(side < 0 ? start - reach : start, foot - 3, reach, 2);
      c.fillStyle = '#ddb782';
      ticks(c, start + side * 14, foot - 5, side, 6, (reach - 26) / 6);
      c.fillRect(start + side * reach, foot - 9, 2, 8);
    }
  } else {
    const a = judgmentArea(e), x = Math.round(a.x), y = Math.round(a.y);
    c.fillStyle = 'rgba(171,78,60,.15)';
    c.fillRect(x, y, a.w, a.h);
    c.fillStyle = '#e4ad89';
    for (const edge of [x, x + a.w - 2]) {
      c.fillRect(edge, foot - 13, 2, 12);
      c.fillRect(edge, y, 2, 9);
    }
    c.fillStyle = '#c46e58';
    c.fillRect(x, foot - 3, a.w, 3);
    const center = x + a.w / 2;
    for (let i=0; i<3; i++) {
      const top = y + 8 + i * 16 + Math.round(progress * 11);
      for (let n=0; n<4; n++) {
        c.fillRect(center - 8 + 2 * n, top + 2*n, 3, 2);
        c.fillRect(center + 6 - 2 * n, top + 2*n, 3, 2);
      }
    }
  }
  c.restore();
}

/** Both source packs have a 39px standing pose. All action cells share the same foot. */
export function drawCourtElite(c: CanvasRenderingContext2D, e: Enemy, profile: RegionalEnemyProfile): boolean {
  const heavy = profile.ability === 'shieldquake';
  const winding = e.aiMode === 'windup', striking = e.aiMode === 'attack';
  const warning = 1 - Math.min(1, (e.aiTimer ?? 0) / profile.warning);
  if (winding) tell(c, e, profile, warning);
  const action = winding || striking ? 'strike' : e.hurt > .07 ? 'hurt' : Math.abs(e.vx) > 8 ? 'run' : 'idle';
  const sheet = artImage('actors/' + profile.id + '-' + action + '.png');
  if (!sheet) return false;
  const count = sheet.naturalWidth / 128, apex = 4;
  let frame = Math.floor(e.timer * (action === 'idle' ? 6 : 10) + e.id) % count;
  if (winding) frame = Math.min(apex - 1, Math.floor(warning * apex));
  if (striking) {
    const swing = 1 - Math.min(1, (e.aiTimer ?? 0) / (heavy ? .46 : .42));
    frame = Math.min(count - 1, apex + Math.floor(swing * (count - apex)));
  }
  const scale = e.h / 39, foot = Math.round(e.y + e.h), center = Math.round(e.x + e.w / 2);
  c.save();
  c.translate(center, foot);
  c.fillStyle = '#12252880';
  c.beginPath(); c.ellipse(0, 0, e.w * .66, 4, 0, 0, Math.PI*2); c.fill();
  c.scale(e.facing || 1, 1);
  c.imageSmoothingEnabled = false;
  if (e.hurt > .1) c.filter = 'brightness(1.6)';
  c.drawImage(sheet, frame*128, 0, 128, 86, -Math.round(64*scale), -Math.round(82*scale), Math.round(128*scale), Math.round(86*scale));
  c.restore();
  return true;
}

export function drawCourtAttack(c: CanvasRenderingContext2D, p: Projectile): boolean {
  if (p.style !== 'court-quake' && p.style !== 'court-cleave') return false;
  c.save();
  const foot = Math.round(p.y + p.h);
  if (p.style === 'court-quake') {
    c.translate(Math.round(p.x + p.w / 2), foot);
    c.scale(Math.sign(p.vx), 1);
    const pulse = Math.floor((QUAKE_LIFE - p.life) * 18) % 3;
    for (const [x, height, width] of [[-14,8,5],[-8,14,6],[-1,21,7],[7,12,6]]) {
      const h = height - pulse;
      c.fillStyle = '#654b43'; c.fillRect(x,-h,width,h);
      c.fillStyle = '#b79c70'; c.fillRect(x+2,-h,width-2,h-3);
      c.fillStyle = '#e1c497'; c.fillRect(x+width-2,-h-1,2,5);
    }
  } else {
    const x = Math.round(p.x + p.w/2), top = Math.round(p.y), age = 1 - p.life / CLEAVE_LIFE;
    c.fillStyle = age < .55 ? 'rgba(173,74,56,.45)' : 'rgba(173,74,56,.27)';
    c.fillRect(p.x, top, p.w, p.h);
    // A single descending blade, with stepped edges and a solid point at floor level.
    for (let dy = 0; dy < p.h; dy += 4) {
      const half = Math.min(11, Math.floor((p.h - dy) / 3));
      const tilt = Math.round((1 - dy / p.h) * 12);
      c.fillStyle = '#9e5146'; c.fillRect(x-half+tilt,top+dy,half*2+2,4);
      c.fillStyle = '#f1c49f'; c.fillRect(x-half+tilt+1, top+dy, Math.min(half,4),4);
    }
    c.fillStyle = '#e5a784'; c.fillRect(p.x,foot-3,p.w,3);
  }
  c.restore();
  return true;
}
