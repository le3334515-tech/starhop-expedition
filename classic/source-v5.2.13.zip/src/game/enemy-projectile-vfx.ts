import { enemyProfile, REGIONAL_ENEMIES, type RegionalAbility, type RegionalEnemyProfile } from './enemy-catalog';
import { regionalRiftArea, regionalStarfallSpawn } from './enemy-variants';
import type { Enemy, Impact, Projectile, Rect } from './types';

const OUTLINE = '#253438';
const CREAM = '#f5e9c3';
const VERMILION = '#cb7759';
const JADE = '#91c9b5';
const VIOLET = '#a88dab';
const GOLD = '#d8b276';
const TAU = Math.PI * 2;
const CASTING_ABILITIES = new Set<RegionalAbility>(['needle','fan','hex','rift','tide','orbit','bomb','burst','starfall']);

function pixel(c: CanvasRenderingContext2D, x: number, y: number, w = 2, h = w) {
  c.fillRect(Math.round(x), Math.round(y), Math.max(1,Math.round(w)), Math.max(1,Math.round(h)));
}

function shape(c: CanvasRenderingContext2D, points: readonly number[], fill: string) {
  c.beginPath();
  c.moveTo(points[0], points[1]);
  for (let i=2;i<points.length;i+=2) c.lineTo(points[i],points[i+1]);
  c.closePath();
  c.fillStyle=fill; c.fill();
}

function arc(c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, a: number, b: number, color: string, weight = 1) {
  c.beginPath(); c.ellipse(x,y,w,h,0,a,b);
  c.lineWidth=weight; c.strokeStyle=color; c.stroke();
}

function aimAngle(e: Enemy): number {
  if (e.targetX === undefined || e.targetY === undefined) return e.facing < 0 ? Math.PI : 0;
  return Math.atan2(e.targetY-e.y-e.h/2,e.targetX-e.x-e.w/2);
}

function casterMark(c: CanvasRenderingContext2D, profile: RegionalEnemyProfile, progress: number, quiet: boolean) {
  const rise=Math.round(progress*6);
  c.fillStyle=profile.color;
  switch (profile.ability) {
    case 'needle':
      pixel(c,-15,-1,28+rise,2);
      shape(c,[13+rise,-4,21+rise,0,13+rise,4],CREAM);
      pixel(c,-12,-5,3,3); pixel(c,-12,3,3,3);
      break;
    case 'fan':
      for (const offset of [-1,0,1]) {
        c.save(); c.rotate(offset*(.37-.15*progress));
        shape(c,[5,-5,15+rise,-4,21+rise,0,15+rise,4,5,5,9,0],VERMILION);
        pixel(c,12+rise,-1,6,2);
        c.restore();
      }
      break;
    case 'hex':
    case 'rift':
      shape(c,[0,-14-rise,14+rise,0,0,14+rise,-14-rise,0],OUTLINE);
      c.strokeStyle=profile.color; c.lineWidth=2;
      c.beginPath(); c.moveTo(-15-rise,0); c.lineTo(0,-15-rise); c.lineTo(15+rise,0); c.lineTo(0,15+rise); c.closePath(); c.stroke();
      pixel(c,-1,-10,2,20); pixel(c,-5,-3,10,2);
      break;
    case 'tide':
    case 'orbit':
      for (const side of [-1,1]) arc(c,side*(8+rise),0,14,8,side===1?-1.9:.1,side===1?1.1:3.1,profile.color,2);
      shape(c,[0,-7,5,2,2,6,-3,6,-5,2],CREAM);
      break;
    case 'bomb':
      shape(c,[-8,-7,3,-10,10,-4,9,7,-3,10,-9,4],OUTLINE);
      c.fillStyle=profile.color;
      pixel(c,-6,1,12,4); pixel(c,0,-10,2,9); pixel(c,3,-13-rise,3,3);
      if (!quiet) pixel(c,-5,-9-rise,2,2);
      break;
    case 'burst':
      for(let n=0;n<6;n++){
        const angle=n*TAU/6;
        const r=13+rise;
        shape(c,[Math.cos(angle)*(r-4),Math.sin(angle)*(r-4),
          Math.cos(angle-.14)*r,Math.sin(angle-.14)*r,
          Math.cos(angle)*(r+5),Math.sin(angle)*(r+5),
          Math.cos(angle+.14)*r,Math.sin(angle+.14)*r],n%2?GOLD:profile.color);
      }
      break;
    case 'starfall':
      shape(c,[-10,-8,-6,-13,6,-13,10,-8,6,10,0,15,-6,10],OUTLINE);
      pixel(c,-5,-8,10,15); pixel(c,-8,-5,2,9); pixel(c,6,-5,2,9);
      c.fillStyle=CREAM; pixel(c,-2,-5,4,8);
      break;
  }
}

function strikeLane(c: CanvasRenderingContext2D, area: Rect, tone: string, urgency: number, live: boolean) {
  const {x,y,w,h}=area;
  c.save();
  c.fillStyle=live ? OUTLINE : tone;
  c.globalAlpha*=live ? .46 : .08+urgency*.11;
  pixel(c,x,y,w,h);
  c.globalAlpha=live ? .92 : .60+urgency*.32;
  c.fillStyle=tone;
  if (live) {
    pixel(c,x,y,2,h); pixel(c,x+w-2,y,2,h);
  } else {
    for(let d=0;d<h;d+=18){
      pixel(c,x,y+d,2,Math.min(7,h-d)); pixel(c,x+w-2,y+d,2,Math.min(7,h-d));
    }
  }
  pixel(c,x,y+h-4,w,2);
  c.restore();
}

function fallingTell(c: CanvasRenderingContext2D, spawn: Rect, targetY: number, palette: string, progress: number) {
  const {x,y,w}=spawn;
  const run=Math.max(64,targetY-y+18);
  c.save();
  c.fillStyle=palette; c.globalAlpha*=.58+progress*.36;
  for(const edge of [x,x+w-2]) {
    for(let offset=0;offset<run;offset+=20) pixel(c,edge,y+offset,2,Math.min(6,run-offset));
  }
  for(let i=0;i<3;i++) {
    const py=y+i*14+3;
    shape(c,[x+4,py,x+w/2,py+4,x+w-4,py,x+w/2,py+8],i===0?CREAM:palette);
  }
  c.restore();
}

export function drawEnemyTargetVfx(c: CanvasRenderingContext2D, e: Enemy, roomWidth: number, camera: number, viewportWidth: number) {
  if (e.dead || e.aiMode!=='windup' || e.targetX===undefined) return;
  if (e.targetX<camera-64 || e.targetX>camera+viewportWidth+64) return;
  const profile=enemyProfile(e);
  if (!profile) return;
  const progress=1-Math.min(1,(e.aiTimer ?? 0)/profile.warning);
  if (profile.ability==='rift') strikeLane(c,regionalRiftArea(e.targetX,roomWidth),profile.color,progress,false);
  if (profile.ability==='starfall' && e.targetY!==undefined) {
    fallingTell(c,regionalStarfallSpawn(e.targetX,e.targetY),e.targetY,profile.color,progress);
  }
}

/** Small source-side seals establish the spell family before its projectile is visible. */
export function drawEnemyCastVfx(c: CanvasRenderingContext2D, e: Enemy, quiet: boolean) {
  if (e.dead || (e.aiMode!=='windup' && e.aiMode!=='attack')) return;
  const profile=enemyProfile(e);
  if (!profile || !CASTING_ABILITIES.has(profile.ability)) return;
  const releasing=e.aiMode==='attack', cue=e.attackCue;
  const progress=releasing ? 1 : 1-Math.min(1,(e.aiTimer ?? 0)/profile.warning);
  const age=cue ? Math.max(0,e.timer-cue.at) : 0;
  if (releasing && (!cue || age>.17)) return;
  c.save();
  c.globalAlpha*=releasing ? 1-age/.17 : .6+.32*progress;
  c.translate(Math.round(releasing&&cue ? cue.x : e.x+e.w/2),
    Math.round(releasing&&cue ? cue.y : e.y+e.h/2));
  const aimed=profile.ability==='needle' || profile.ability==='fan';
  if (aimed) c.rotate(releasing&&cue ? cue.angle : aimAngle(e));
  if (releasing && !quiet) c.scale(1+age,1+age);
  casterMark(c,profile,progress,quiet);
  c.restore();
}

function groundWave(c: CanvasRenderingContext2D, p: Projectile, water: boolean, quiet: boolean) {
  const {w,h}=p;
  const alpha=c.globalAlpha;
  c.translate(Math.round(p.x+(p.vx<0?w:0)),Math.round(p.y));
  c.scale(p.vx<0?-1:1,1);
  const tint=water ? JADE : GOLD;
  if (!quiet) {
    c.fillStyle=water ? '#467d7b' : '#887655';
    c.globalAlpha*=.48;
    pixel(c,-12,h-5,20,2); pixel(c,-19,h-2,23,2);
    c.globalAlpha=alpha;
  }
  if (water) {
    shape(c,[0,h-3,w*.25,h-7,w*.4,5,w*.54,2,w*.78,2,w-1,7,w*.72,5,w*.64,10,w,h-4,w,h,0,h],OUTLINE);
    shape(c,[2,h-3,w*.30,h-8,w*.48,4,w*.77,4,w-2,7,w*.73,7,w*.61,11,w-1,h-2],tint);
    c.fillStyle=CREAM; pixel(c,w*.54,4,w*.25,2);
  } else {
    shape(c,[0,h-2,5,h-5,9,3,13,3,16,h-4,21,5,w,5,w,h,0,h],OUTLINE);
    c.fillStyle=tint;
    pixel(c,1,h-3,w-2,2); pixel(c,8,5,3,h-7); pixel(c,12,2,3,7); pixel(c,w-5,5,3,h-6);
    c.fillStyle=CREAM; pixel(c,11,1,3,2); pixel(c,w-4,4,2,2);
  }
}

function boltBody(c: CanvasRenderingContext2D, p: Projectile, profile: RegionalEnemyProfile, quiet: boolean) {
  const scale=Math.max(1,p.w/2);
  c.scale(scale/8,scale/8);
  const tone=p.color ?? profile.color;
  const ability=profile.ability;
  if (!quiet) {
    const alpha=c.globalAlpha;
    c.fillStyle=tone; c.globalAlpha*=.4;
    pixel(c,-19,-1,14,2); pixel(c,-13,3,7,2);
    c.globalAlpha=alpha;
  }
  switch (ability) {
    case 'needle':
      shape(c,[-12,0,-4,-2,2,-2,8,-4,9,0,8,4,2,2,-4,2],OUTLINE);
      shape(c,[-10,0,2,-1,8,-3,8,3,2,1],tone);
      c.fillStyle=CREAM; pixel(c,2,-1,6,2);
      if (profile.id==='gale-archer') shape(c,[-10,-5,-2,-1,-4,1,-10,5,-7,0],JADE);
      if (profile.id==='astral-archer') { c.fillStyle=GOLD; pixel(c,1,-3,2,6); }
      break;
    case 'starfall':
      shape(c,[-11,-2,-7,-4,1,-4,2,-7,7,-5,8,0,7,5,2,7,1,4,-7,4,-11,2],OUTLINE);
      shape(c,[-8,0,2,-3,3,-5,6,-3,7,0,6,3,3,5,2,3],tone);
      c.fillStyle=CREAM; pixel(c,3,-2,3,4);
      break;
    case 'tide':
    case 'orbit':
      shape(c,[-11,0,-6,-2,-1,-6,4,-7,8,-4,8,3,3,7,-2,6,-7,2],OUTLINE);
      shape(c,[-9,0,-4,-1,0,-4,4,-5,7,-3,7,3,3,5,-1,4,-6,1],tone);
      arc(c,1,0,4,3,-2.7,1.4,CREAM,1.4);
      break;
    case 'hex':
      // A folded talisman rides an ink wake. Leave its dark center open so the
      // silhouette stays legible next to the solid lantern and water bolts.
      shape(c,[-13,-4,-7,-3,-2,-6,1,-8,7,-5,8,1,5,7,1,8,-3,4,-7,3,-11,5],'#292e39');
      shape(c,[-10,-3,-5,-1,0,-6,6,-4,7,0,5,5,1,7,-3,3,-7,3,-9,5,-4,1],tone);
      shape(c,[0,-4,5,-2,5,3,1,5,-2,1],'#4c4259');
      c.fillStyle=CREAM; pixel(c,1,-3,3,1); pixel(c,2,1,2,2);
      break;
    case 'rift':
      shape(c,[-12,4,-5,-1,0,-6,5,-6,8,-1,6,4,1,7,-5,4],OUTLINE);
      shape(c,[-9,4,-2,-2,3,-6,7,-1,5,3,0,6,-2,3],VIOLET);
      shape(c,[-4,3,2,-2,5,-4,4,0,1,2],CREAM);
      break;
    case 'fan':
      shape(c,[-11,4,-7,-3,-1,-7,4,-6,8,-2,8,3,4,6,-2,6],OUTLINE);
      shape(c,[-8,3,-4,-2,0,-5,4,-4,7,0,6,4,2,5],VERMILION);
      shape(c,[-5,2,1,-2,5,-1,6,1,3,4],CREAM);
      break;
    case 'burst':
      shape(c,[-9,0,-3,-3,-1,-8,3,-5,8,-4,7,3,2,8,-2,5,-7,3],OUTLINE);
      shape(c,[-7,0,-2,-2,0,-6,3,-4,7,-3,5,2,2,6,-2,3],tone);
      c.fillStyle=CREAM; pixel(c,0,-2,4,4);
      break;
    case 'bomb':
      shape(c,[-8,-3,-5,-7,3,-8,7,-4,8,3,5,7,-4,7,-8,4],OUTLINE);
      shape(c,[-7,-2,-4,-5,3,-6,5,-3,6,3,3,5,-3,5,-6,3],VERMILION);
      c.fillStyle=GOLD; pixel(c,-5,1,10,2); pixel(c,0,-4,2,8);
      c.fillStyle=CREAM; pixel(c,3,-4,4,2); pixel(c,7,-6,2,2);
      break;
    case 'hop':
      shape(c,[-8,1,-5,-4,-2,-7,3,-6,7,-4,8,2,5,6,-2,7],OUTLINE);
      shape(c,[-7,1,-1,-5,3,-4,7,-3,7,2,3,5,-1,4],tone);
      c.fillStyle=CREAM; pixel(c,0,-2,2,2); pixel(c,4,0,2,2); pixel(c,-3,1,2,2);
      break;
    case 'guard':
      shape(c,[-8,-5,1,-7,7,-4,8,0,7,4,1,7,-8,5,-6,0],OUTLINE);
      shape(c,[-6,-4,1,-5,6,-3,7,0,6,3,1,5,-6,4,-4,0],tone);
      c.fillStyle=CREAM; pixel(c,2,-3,2,6); pixel(c,0,-1,5,2);
      break;
  }
}

export function drawEnemyProjectileVfx(c: CanvasRenderingContext2D, p: Projectile, quiet: boolean): boolean {
  const profile=p.enemyVariant && REGIONAL_ENEMIES[p.enemyVariant];
  if (!profile || p.owner!=='enemy' || p.style==='court-quake' || p.style==='court-cleave') return false;
  if (p.kind==='rift') {
    strikeLane(c,p,profile.color,1-Math.min(1,(p.delay ?? 0)/.65),!p.delay);
    if (!p.delay) {
      c.save(); c.globalAlpha*=.83;
      const x=p.x+p.w/2;
      shape(c,[x-5,p.y+hFraction(p,.05),x+3,p.y+hFraction(p,.27),x-1,p.y+hFraction(p,.42),x+8,p.y+hFraction(p,.61),
        x+2,p.y+p.h-2,x-4,p.y+hFraction(p,.77),x+1,p.y+hFraction(p,.58),x-9,p.y+hFraction(p,.40),x-2,p.y+hFraction(p,.22)],VIOLET);
      c.restore();
    }
    return true;
  }
  c.save();
  if (p.kind==='shockwave') groundWave(c,p,profile.id==='tide-shell',quiet);
  else if (!p.delay || p.delay<=0) {
    c.translate(Math.round(p.x+p.w/2),Math.round(p.y+p.h/2));
    c.rotate(Math.atan2(p.vy,p.vx));
    boltBody(c,p,profile,quiet);
  }
  c.restore();
  return true;
}

function hFraction(area: Rect, value: number) { return Math.round(area.h*value); }

export function drawEnemyImpactVfx(c: CanvasRenderingContext2D, effect: Impact, quiet: boolean): boolean {
  const profile=effect.enemyVariant && REGIONAL_ENEMIES[effect.enemyVariant];
  if (!profile) return false;
  const age=1-Math.max(0,effect.life/effect.maxLife);
  const spread=8+age*17;
  const wet=profile.id.startsWith('tide-');
  const ash=profile.id.startsWith('forge-') || profile.id.startsWith('skyforge-') || profile.id.startsWith('lantern-');
  c.save();
  c.translate(Math.round(effect.x),Math.round(effect.y));
  c.globalAlpha*=1-age;
  if (wet) arc(c,0,0,spread,spread*.54,0,TAU,profile.color,2);
  const count=quiet?4:6;
  for (let i=0;i<count;i++) {
    const angle=i*TAU/count+.21;
    const x=Math.cos(angle)*spread, y=Math.sin(angle)*spread*.7;
    c.fillStyle=i%2?profile.color:CREAM;
    if (ash) pixel(c,x,y-age*8,i%2?2:3,4);
    else shape(c,[x-3,y,x,y-3,x+3,y,x,y+3],c.fillStyle);
  }
  c.restore();
  return true;
}

