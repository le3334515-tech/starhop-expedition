import { describe, expect, it } from 'vitest';
import { CoopPlay } from './coop-play';
import type { PartyTraveller } from './coop-play';
import type { CoopRoom, CoopSeat, CoopSession, CoopView } from './coop-transport';
import { GameEngine } from './game/engine';
import { EMPTY_INPUT, type SoundName } from './game/types';

function party(onSound?: (sound: SoundName) => void) {
  const room: CoopRoom = {
    id: 'weapon-room',
    config: { seed:42,modifier:'standard',weapon:'blade' },
    status: 'running',
    startAt: 0,
    players: [
      { seat:0,name:'房主',color:'#fff',ready:true,connected:true,role:'blade' },
      { seat:1,name:'客人',color:'#ffe',ready:true,connected:true,role:'staff' },
    ],
  };
  const session = (seat: CoopSeat, send: (data:unknown)=>void, broadcast: (data:unknown)=>void) => {
    const view: CoopView = { connection:'online',room,seat,isHost:seat===0,error:null };
    return { view,send,broadcast } as CoopSession;
  };
  const hostEngine = new GameEngine(), guestEngine = new GameEngine();
  let world: unknown;
  let input: unknown;
  const ignore = () => {};
  const host = new CoopPlay(session(0,ignore,data => { world = data; }),hostEngine,room);
  const guest = new CoopPlay(session(1,data => { input = data; },ignore),guestEngine,room,onSound);
  host.tick(.2,EMPTY_INPUT);
  host.tick(.09,EMPTY_INPUT);
  return {
    host,guest,hostEngine,guestEngine,get world() { return world; },
    get input() { return input; },
    nextInput() { guest.tick(.05,EMPTY_INPUT); return input as { kind:'input'; seq:number; bits:number; room:number; weapon?:string }; },
    nextWorld() { host.tick(.09,EMPTY_INPUT); return world; },
  };
}

describe('co-op weapon authority', () => {
  it('shows the invited player’s own jump and attack before a round trip', () => {
    const p = party();
    p.guest.acceptWorld(p.world);
    for(let i=0;i<4;i++) {
      p.host.tick(1/60,EMPTY_INPUT);
      p.guest.tick(1/60,EMPTY_INPUT);
      p.host.acceptInput(1,p.input);
    }
    p.guest.acceptWorld(p.nextWorld());
    const initial = p.guestEngine.state.hero;
    p.guest.tick(1/60,{...EMPTY_INPUT,right:true,jumpHeld:true,jumpPressed:true,attackPressed:true});
    const predicted = p.guest.display(1/60).state.hero;
    expect(predicted.x).toBeGreaterThan(initial.x);
    expect(predicted.y).toBeLessThan(initial.y);
    expect(predicted.attackTimer).toBeGreaterThan(0);
    expect(p.guestEngine.state.hero).toBe(initial);
    expect(p.guestEngine.state.projectiles).toHaveLength(0);
    for(let i=0;i<8;i++)p.guest.tick(1/60,{...EMPTY_INPUT,right:true,jumpHeld:true});
    p.guest.acceptWorld(p.nextWorld()); // delayed update with no acknowledgement of the jump
    expect(p.guest.display(1/60).state.hero.y).toBeLessThan(initial.y-20);
    p.hostEngine.forceCoopRoom(1);
    p.guest.acceptWorld(p.nextWorld());
    expect(p.guest.display(1/60).state.hero).toMatchObject({attackTimer:0});
  });
  it('keeps invited movement and jump responsive through a 750 ms snapshot gap', () => {
    const p = party();
    p.guest.acceptWorld(p.world);
    const state = p.guestEngine.state;
    for (let i = 0; i < 44; i++) p.guest.tick(1 / 60, EMPTY_INPUT);
    const before = p.guest.display(1 / 60).state.hero;
    p.guest.tick(1 / 60, { ...EMPTY_INPUT, right: true, jumpHeld: true, jumpPressed: true });
    const after = p.guest.display(1 / 60).state.hero;
    expect(after.x).toBeGreaterThan(before.x);
    expect(after.y).toBeLessThan(before.y);
    expect(state.hero.x).toBe(before.x);
  });

  it('keeps a moving teammate animating through three missed world frames', () => {
    const p = party();
    const world = p.world as { people: PartyTraveller[] };
    const teammate = world.people.find(person => person.seat === 0)!;
    teammate.hero = { ...teammate.hero, x: 140, vx: 260, grounded: true };
    p.guest.acceptWorld(world);
    let before = 0, after = 0;
    for (let frame = 1; frame <= 13; frame++) {
      p.guest.tick(1 / 60, EMPTY_INPUT);
      const view = p.guest.display(1 / 60).party.people.find(person => person.seat === 0)!;
      if (frame === 10) before = view.hero.x;
      if (frame === 13) after = view.hero.x;
    }
    expect(after - before).toBeGreaterThan(9);
    expect(teammate.hero.x).toBe(140);
  });

  it('eases a same-room correction after a long snapshot gap without a visible teleport', () => {
    const p = party();
    p.guest.acceptWorld(p.world);
    const before = p.guest.display(1 / 60).state.hero.x;
    const update = p.nextWorld() as { people: PartyTraveller[] };
    const own = update.people.find(person => person.seat === 1)!;
    own.hero = { ...own.hero, x: before + 117, vx: 0 };
    p.guest.acceptWorld(update);
    const first = p.guest.display(1 / 60).state.hero.x;
    expect(Math.abs(first - before)).toBeLessThan(12);
    let last = first;
    for (let frame = 0; frame < 38; frame++) last = p.guest.display(1 / 60).state.hero.x;
    expect(last).toBeCloseTo(own.hero.x, 1);
    expect(p.guestEngine.state.hero.x).toBe(own.hero.x);
  });

  it('does not restart the same swing or the running clock when a world pose is older', () => {
    const p = party();
    const initial = p.world as { people: PartyTraveller[] };
    const start = initial.people.find(person => person.seat === 1)!;
    start.hero = { ...start.hero, animation: 2, attackStep: 1, attackTimer: .13 };
    p.guest.acceptWorld(initial);
    const before = p.guest.display(1 / 60).state.hero;

    const update = p.nextWorld() as { people: PartyTraveller[] };
    const after = update.people.find(person => person.seat === 1)!;
    after.hero = { ...after.hero, animation: 1.98, attackStep: 1, attackTimer: .2 };
    p.guest.acceptWorld(update);
    const drawing = p.guest.display(1 / 60).state.hero;
    expect(drawing.animation).toBeGreaterThan(before.animation);
    expect(drawing.attackTimer).toBeLessThan(before.attackTimer);

    const another = p.nextWorld() as { people: PartyTraveller[] };
    const second = another.people.find(person => person.seat === 1)!;
    second.hero = { ...second.hero, attackStep: 2, attackTimer: .19 };
    p.guest.acceptWorld(another);
    expect(p.guest.display(1 / 60).state.hero.attackTimer).toBe(.19);
  });

  it('does not rewind another runner when a delayed world arrives behind their drawn pose', () => {
    const p = party();
    const world = p.world as { motionTime: number; people: PartyTraveller[] };
    const runner = world.people.find(person => person.seat === 0)!;
    const start = 140, velocity = 260;
    runner.hero = { ...runner.hero, x: start, vx: velocity, grounded: true };
    p.guest.acceptWorld(world);
    for (let frame = 0; frame < 13; frame++) {
      p.guest.tick(1 / 60, EMPTY_INPUT);
      p.guest.display(1 / 60);
    }
    const before = p.guest.display(1 / 60).party.people[0].hero.x;
    const newer = p.nextWorld() as typeof world;
    const teammate = newer.people.find(person => person.seat === 0)!;
    teammate.hero = { ...teammate.hero, x: start + velocity * (newer.motionTime - world.motionTime), vx: velocity, grounded: true };
    p.guest.acceptWorld(newer);
    expect(p.guest.display(1 / 60).party.people[0].hero.x).toBeGreaterThanOrEqual(before);
  });

  it('updates only the requesting seat and rejects a different character’s weapons', () => {
    const p = party();
    expect(p.guestEngine.state.hero.weapon).toBe('ember');
    p.guest.equipWeapon('halberd');
    expect(p.nextInput().weapon).toBeUndefined();

    p.guest.equipWeapon('moonMirror');
    const first = p.nextInput();
    p.host.acceptInput(1,{ ...first,weapon:'halberd' });
    p.guest.acceptWorld(p.nextWorld());
    expect(p.guestEngine.state.hero.weapon).toBe('ember');

    p.host.acceptInput(1,p.nextInput());
    p.host.equipWeapon('willowSword');
    p.guest.acceptWorld(p.nextWorld());
    expect(p.guestEngine.state.hero.weapon).toBe('moonMirror');
    expect(p.hostEngine.state.hero.weapon).toBe('willowSword');
    expect(p.nextInput().weapon).toBeUndefined();
  });

  it('keeps the latest requested weapon until the host acknowledges that request', () => {
    const p = party();
    const originalWorld = p.world;
    p.guest.equipWeapon('frostStaff');
    p.host.acceptInput(1,p.nextInput());
    const swappedWorld = p.nextWorld();

    p.guest.equipWeapon('ember');
    p.guest.acceptWorld(originalWorld);
    const latest = p.nextInput();
    expect(latest.weapon).toBe('ember');
    p.guest.acceptWorld(swappedWorld);
    expect(p.nextInput().weapon).toBe('ember');
    p.host.acceptInput(1,latest);
    p.guest.acceptWorld(p.nextWorld());
    expect(p.guestEngine.state.hero.weapon).toBe('ember');
    expect(p.nextInput().weapon).toBeUndefined();
  });

  it('plays a retained hit once even when the guest misses the original snapshot', () => {
    const sounds: SoundName[] = [];
    const p = party(name => sounds.push(name));
    const world = p.world as {tick:number; status:({sounds:SoundName[]; contactBeat?:{tick:number;name:SoundName}} | null)[]};
    world.status[1]!.sounds = [];
    world.status[1]!.contactBeat = { tick:world.tick, name:'staffFinisher' };
    p.guest.acceptWorld({...world,tick:world.tick+2});
    p.guest.acceptWorld({...world,tick:world.tick+3});
    expect(sounds).toEqual(['staffFinisher']);
  });

  it('replicates separate upgrade selections for each traveller', () => {
    const p = party();
    p.hostEngine.state.enemies.forEach(enemy => { enemy.dead = true; });
    p.guest.acceptWorld(p.nextWorld());
    const roomHost = p.hostEngine.state, roomGuest = p.guestEngine.state;
    const first = roomHost.upgradeChoices[0]?.id;
    const second = roomGuest.upgradeChoices.find(upgrade => upgrade.id !== first)?.id;
    expect(first && second).toBeTruthy();

    p.host.chooseUpgrade(first!);
    p.guest.acceptWorld(p.nextWorld());
    expect(roomGuest.phase).toBe('upgrade');
    expect(roomGuest.hero.upgrades).toEqual([]);
    p.guest.chooseUpgrade(second!);
    p.host.acceptInput(1,p.nextInput());
    p.guest.acceptWorld(p.nextWorld());
    expect(roomHost.hero.upgrades).toEqual([first]);
    expect(roomGuest.hero.upgrades).toEqual([second]);
    expect(p.guest.party().map(player => player.hero.upgrades)).toEqual([[first],[second]]);
  });
});
