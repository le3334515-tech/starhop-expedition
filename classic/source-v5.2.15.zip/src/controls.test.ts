import { describe, expect, it } from 'vitest';
import { bindingConflict, defaultBindings, parseBindings, stickVector } from './controls';
import { EMPTY_INPUT, mergeInput, withoutEdges } from './input';

describe('editable keyboard profiles', () => {
  it('restores a complete profile and keeps reset defaults independent', () => {
    const bindings = defaultBindings(); bindings.jump = ['KeyC'];
    expect(parseBindings({ v: 1, bindings }).jump).toEqual(['KeyC']);
    expect(defaultBindings().jump[0]).toBe('Space');
  });
  it('detects conflicts in aliases and rejects damaged or reserved profiles', () => {
    const bindings = defaultBindings();
    expect(bindingConflict(bindings, 'jump', 'KeyX')).toBe('attack');
    expect(bindingConflict(bindings, 'jump', 'KeyC')).toBeNull();
    bindings.jump = ['Escape'];
    expect(parseBindings({ v: 1, bindings })).toEqual(defaultBindings());
    bindings.jump = ['KeyD'];
    expect(parseBindings({ v: 1, bindings })).toEqual(defaultBindings());
    expect(parseBindings({ v: 9, bindings: {} })).toEqual(defaultBindings());
  });
  it('loads a new drop key alongside older custom bindings', () => {
    const {drop: _drop, ...old} = defaultBindings();
    old.attack = ['KeyS'];
    const bindings = parseBindings({v:1,bindings:old});
    expect(bindings.attack).toEqual(['KeyS']);
    expect(bindings.drop[0]).toBe('ArrowDown');
    expect(defaultBindings().drop[0]).toBe('KeyS');
  });
});
describe('joystick stage coordinates', () => {
  it('filters center noise, clamps motion, and preserves diagonal direction', () => {
    expect(stickVector(4, 2, 50)).toEqual({ x: 0, y: 0 });
    expect(stickVector(100, 0, 50)).toEqual({ x: 1, y: 0 });
    const diagonal = stickVector(100, 100, 50);
    expect(Math.hypot(diagonal.x, diagonal.y)).toBeCloseTo(1);
    expect(diagonal.x).toBeCloseTo(diagonal.y);
  });
  it('rotates portrait screen motion into the landscape game direction', () => {
    expect(stickVector(0, 50, 50, true).x).toBe(1);
    expect(stickVector(0, -50, 50, true).x).toBe(-1);
    expect(stickVector(50, 0, 50, true).y).toBe(-1);
    expect(stickVector(NaN, 0, 50)).toEqual({ x: 0, y: 0 });
  });
});
it('buffers a parry edge across render frames and consumes it exactly once', () => {
  const pending = mergeInput({ ...EMPTY_INPUT, guardPressed: true }, { ...EMPTY_INPUT });
  expect(pending.guardPressed).toBe(true);
  expect(withoutEdges(pending).guardPressed).toBe(false);
});
