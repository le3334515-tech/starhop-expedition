import { describe, expect, it } from 'vitest';
import { CoopPlay } from './coop-play';
import type { CoopRoom, CoopSession } from './coop-transport';
import { GameEngine } from './game/engine';
import { EMPTY_INPUT, type CharacterId, type Projectile } from './game/types';

function party() {
  const roles = ['traveller', 'wheel', 'spear', 'monk'] as const satisfies readonly CharacterId[];
  const room: CoopRoom = {
    id: 'four-shared-projectiles',
    config: { seed: 42, modifier: 'standard', weapon: 'blade' },
    status: 'running',
    startAt: 1,
    players: [
      { seat: 0, role: roles[0], name: '房主', color: '#89dbc0', ready: true, connected: true },
      { seat: 1, role: roles[1], name: '客人一', color: '#ffb476', ready: true, connected: true },
      { seat: 2, role: roles[2], name: '客人二', color: '#93c6ff', ready: true, connected: true },
      { seat: 3, role: roles[3], name: '客人三', color: '#eca4d6', ready: true, connected: true },
    ],
  };
  const engine = new GameEngine();
  const session = {
    view: { connection: 'online', room, seat: 0, isHost: true, error: null },
    broadcast() {},
  } as unknown as CoopSession;
  const host = new CoopPlay(session, engine, room);
  host.tick(.2, EMPTY_INPUT);
  const guests = Array.from(host['actors'].values()).slice(1).map(actor => actor.engine.state.hero);
  for (const hero of guests) {
    Object.assign(hero, { x: 290, y: 412, invincible: 0, grounded: true });
  }
  return { host, guests, world: engine.state };
}

function volley(kind: Projectile['kind'], id: number, x: number): Projectile {
  return { id, kind, x, y: 421, w: 12, h: 14, vx: 0, vy: 0, life: 1, damage: 1, owner: 'enemy', hitIds: [] };
}

describe('four-seat shared enemy projectiles', () => {
  it('retires a guarded projectile before simulating the rest of the party', () => {
    const { host, guests, world } = party();
    guests[0].guardTimer = .1;
    const defended = volley('enemy', 1, 308);
    const untouched = volley('enemy', 2, 605);
    world.projectiles = [defended, untouched];
    host.tick(1 / 60, EMPTY_INPUT);
    expect(guests[0].counterTimer).toBeGreaterThan(1);
    expect(guests.map(hero => hero.hp)).toEqual([5, 5, 5]);
    expect(defended.life).toBe(0);
    expect(untouched.life).toBeCloseTo(1 - 1 / 60);
  });

  it('lets a lingering rift hit several players without accelerating its lifetime', () => {
    const { host, guests, world } = party();
    const rift = volley('rift', 1, 308);
    world.projectiles = [rift];
    host.tick(1 / 60, EMPTY_INPUT);
    expect(guests.map(hero => hero.hp)).toEqual([4, 4, 4]);
    expect(rift.life).toBeCloseTo(1 - 1 / 60);
  });
});
