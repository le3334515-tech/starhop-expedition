import { afterEach, describe, expect, it, vi } from 'vitest';
import { CoopPipe, inflateCoopText } from './coop-pipe';
import { CoopSession, type CoopRoom } from './coop-transport';

const room: CoopRoom = { id: 'c4_'+'38'.repeat(16), config:{seed:5,modifier:'standard',weapon:'blade'},
  players:[{seat:0,name:'房主',color:'#89dbc0',ready:true,connected:true,role:'traveller'},
    {seat:1,name:'访客',color:'#ffb476',ready:true,connected:true,role:'staff'}], status:'running',startAt:1 };
const freshReply = (ack = 0) => ({ok:true,room,hostTime:Date.now(),ack});
type Poll = {messages:{id:number;json:string}[];inputOnly?:boolean};
afterEach(() => { vi.clearAllTimers(); vi.useRealTimers(); vi.unstubAllGlobals(); });

describe('cooperative transport pacing', () => {
  it('shares one compressed frame across opted-in peers, keeps only the latest pending frame, and serves legacy peers', async()=>{
    const peers=Array.from({length:3},()=>({open:true,dataChannel:{bufferedAmount:0},send:vi.fn()}));
    const host=new CoopSession();
    Object.assign(host,{started:true,model:{room,seat:0,isHost:true,connection:'online',error:null},
      members:new Map(peers.map((peer,i)=>[i+1,{peer,worldGzip:i<2}]))});
    const data='世界状态'.repeat(1500);
    for(let tick=1;tick<=8;tick++) host.broadcast({tick,data});
    await vi.waitFor(()=>expect(peers[0].send).toHaveBeenCalledTimes(2));
    expect(peers[0].send.mock.calls.map(([p])=>[p.kind,p.id])).toEqual([['world-gzip',1],['world-gzip',8]]);
    const packet=peers[0].send.mock.lastCall![0];
    expect(peers[1].send.mock.lastCall![0].bytes).toBe(packet.bytes);
    expect(JSON.parse(await inflateCoopText(packet.bytes))).toEqual({tick:8,data});
    expect(peers[2].send).toHaveBeenCalledTimes(8);
    expect(peers[2].send.mock.lastCall![0].kind).toBe('world');
    const onHostMessage=vi.fn(), guest=new CoopSession({onHostMessage});
    Object.assign(guest,{started:true,uplink:peers[0],model:{room,seat:1,isHost:false,connection:'online',error:null}});
    const receiver=guest as unknown as {receivePeer(peer:unknown,packet:unknown):void;rawWorld:boolean};
    receiver.receivePeer(peers[0],packet);
    await vi.waitFor(()=>expect(onHostMessage).toHaveBeenCalledWith({tick:8,data}));
    receiver.receivePeer(peers[0],{...packet,id:9,bytes:new ArrayBuffer(3)});
    await vi.waitFor(()=>expect(receiver.rawWorld).toBe(true));
    receiver.receivePeer(peers[0],{kind:'world',message:{id:10,json:'{"tick":10}'}});
    expect(onHostMessage).toHaveBeenLastCalledWith({tick:10});
  });

  it('keeps one fresh world behind congestion and always sends room control', () => {
    const send=vi.fn(), peer={open:true, dataChannel:{bufferedAmount:32000}, bufferSize:0, send};
    const host=new CoopSession();
    Object.assign(host,{started:true, model:{room,seat:0,isHost:true,connection:'online',error:null},
      members:new Map([[1,{peer,player:room.players[1],ack:0}]])});
    for(let tick=1;tick<=20;tick++) host.broadcast({tick});
    expect(send).not.toHaveBeenCalled();
    Object.assign(peer.dataChannel,{bufferedAmount:0}); peer.bufferSize=1;
    host.broadcast({tick:21});
    expect(send).not.toHaveBeenCalled();
    (host as unknown as {updateMembers():void}).updateMembers();
    expect(send).toHaveBeenCalledWith(expect.objectContaining({kind:'room'}));
    peer.bufferSize=0;
    host.broadcast({tick:22});
    expect(send.mock.calls.filter(([p])=>p.kind==='world').map(([p])=>JSON.parse(p.message.json))).toEqual([{tick:22}]);
  });

  it('keeps replaceable frames apart from congested reliable control for each direct guest', () => {
    const host = new CoopSession();
    const peer = {open:true, dataChannel:{bufferedAmount:32000}, send:vi.fn()};
    const worldLane = {readyState:'open', bufferedAmount:0, send:vi.fn()};
    const slowLane = {readyState:'open', bufferedAmount:9000, send:vi.fn()};
    Object.assign(host,{started:true, model:{room,seat:0,isHost:true,connection:'online',error:null},
      members:new Map([[1,{peer,worldLane,worldReady:true}],[2,{peer,worldLane:slowLane,worldReady:true}]])});
    host.broadcast({tick:1});
    expect(worldLane.send).toHaveBeenCalledTimes(1);
    expect(slowLane.send).not.toHaveBeenCalled();
    expect(peer.send).not.toHaveBeenCalled();

    const onHostMessage=vi.fn(), guest=new CoopSession({onHostMessage});
    Object.assign(guest,{started:true});
    const receiver=guest as unknown as {receiveWorldFrame(value:unknown):void};
    slowLane.bufferedAmount=0;
    host.broadcast({tick:2});
    receiver.receiveWorldFrame(slowLane.send.mock.lastCall![0]);
    receiver.receiveWorldFrame(worldLane.send.mock.calls[0][0]);
    expect(onHostMessage.mock.calls).toEqual([[{tick:2}]]);
  });

  it.each([false,true])('delivers and acknowledges a button while a world is delayed only with fast-input negotiation=%s', async supported => {
    vi.useFakeTimers();
    const calls: Poll[]=[];
    let finish!: () => void;
    const pipe={request: (_lane:string, req:Poll)=>{
      calls.push(req);
      if(req.inputOnly) return Promise.resolve(freshReply(req.messages.at(-1)?.id));
      return new Promise(resolve=>{finish=()=>resolve(freshReply(req.messages.at(-1)?.id));});
    }};
    const guest=new CoopSession();
    Object.assign(guest,{started:true,pipeOnly:true,fastInput:supported,pipe,roomId:room.id,token:'token',
      model:{room,seat:1,isHost:false,connection:'online',error:null}});
    const controls=guest as unknown as {poll():Promise<void>;input:{id:number;json:string}[]};
    const polling=controls.poll();
    guest.send({kind:'input',bits:16,seq:1,room:1,weapon:'ember'});
    await vi.advanceTimersByTimeAsync(1);
    expect(calls.filter(c=>c.inputOnly)).toHaveLength(Number(supported));
    expect(controls.input).toHaveLength(supported ? 0 : 1);
    finish(); await polling;
    expect(controls.input).toHaveLength(supported ? 0 : 1);
    // A fast connection starts another normal poll after 70 ms, including RTT.
    await vi.advanceTimersByTimeAsync(70);
    expect(calls.filter(c=>!c.inputOnly)).toHaveLength(2);
    expect(calls.at(-1)?.messages).toHaveLength(supported ? 0 : 1);
    finish(); await vi.advanceTimersByTimeAsync(1);
    expect(controls.input).toHaveLength(0);
  });

  it('coalesces repeated holds yet retains direction changes, button edges, and gear selections across prolonged stalls', () => {
    const guest=new CoopSession();
    Object.assign(guest,{started:true,model:{room,seat:1,isHost:false,connection:'reconnecting',error:null}});
    let seq=0;
    const press=(bits:number,more={})=>guest.send({kind:'input',room:1,bits,seq:++seq,...more});
    press(1);press(1);press(0);press(16);
    for(let n=0;n<300;n++)press(2);
    press(2,{weapon:'ember'});press(2,{upgrade:{id:'vigor',level:2}});press(2,{drop:true});press(0);
    const retained=(guest as unknown as {input:{json:string}[]}).input.map(m=>JSON.parse(m.json));
    expect(retained.map(m=>m.bits)).toEqual([1,0,16,2,2,2,2,0]);
    expect(retained[4].weapon).toBe('ember');expect(retained[5].upgrade.id).toBe('vigor');
    expect(retained[6].drop).toBe(true);
    expect(retained[0].seq).toBe(2);
  });
});

type Cipher = {
  seal(envelope:{payload:unknown},gzip?:boolean):Promise<string>;
  openMessage(wire:string,gzip?:boolean):Promise<{payload:unknown}>;
  key: CryptoKey;
};
describe('encrypted cooperative relay', () => {
  it('streams a large encrypted world before upload completion', async () => {
    const pipe=await CoopPipe.open(room.id);
    expect(pipe.canPushWorld).toBe(true);
    let posted: ReadableStream | undefined;
    let stopped = false;
    vi.stubGlobal('fetch',(_url:string,options:RequestInit)=>{
      if (options.method !== 'POST') return Promise.resolve(new Response(posted));
      posted = options.body as ReadableStream;
      return new Promise(resolve => options.signal?.addEventListener('abort',()=>{
        stopped = true; resolve(new Response('',{status:499}));
      },{once:true}));
    });
    const close = pipe.pushWorldStream('abc',()=>{}), received=vi.fn();
    const watch = pipe.watchWorldStream('abc',received,new AbortController().signal);
    const world={id:7,json:JSON.stringify({tick:7,data:'世界'.repeat(4500)})};
    pipe.pushWorld(world);
    await vi.waitFor(()=>expect(received).toHaveBeenCalledWith(world));
    expect(stopped).toBe(false);
    close?.();
    expect(stopped).toBe(true);
    await watch;
  });

  it('decodes only the latest frame when a streaming proxy combines chunks', async () => {
    const pipe=await CoopPipe.open(room.id);
    const cipher=pipe as unknown as Cipher;
    const frames=await Promise.all([1,2,3].map(tick=>cipher.seal({payload:{tick}})));
    vi.stubGlobal('fetch',()=>Promise.resolve(new Response(new ReadableStream({
      start(writer){
        const bytes=new TextEncoder();
        writer.enqueue(bytes.encode(frames[0].slice(0,15)));
        writer.enqueue(bytes.encode(frames[0].slice(15)+'\n'+frames[1]+'\n'+frames[2]));
        writer.enqueue(bytes.encode('\n'));
        writer.close();
      },
    }))));
    const received=vi.fn();
    await pipe.watchWorldStream('abc',received,new AbortController().signal);
    expect(received.mock.calls).toEqual([[{tick:2}],[{tick:3}]]);
  });

  it('delivers a valid world without waiting on the relay upload receipt', async()=>{
    const pipe=await CoopPipe.open(room.id), fixture=pipe as unknown as Cipher & {
      transfer:(url:string,body?:string,timeout?:number,signal?:AbortSignal)=>Promise<string>;
    };
    const acknowledgement=await fixture.seal({payload:{tick:12}});
    let reply!: (value:string)=>void, uploadAborted=false;
    fixture.transfer=(_url,body,_timeout,signal)=>new Promise((resolve,reject)=>{
      if (body === undefined) reply=resolve;
      else {
        signal?.addEventListener('abort',()=>{ uploadAborted=true; reject(new Error('closed')); },{once:true});
        reply(acknowledgement);
      }
    });
    expect(await pipe.request('s1',{action:'poll'})).toEqual({tick:12});
    expect(uploadAborted).toBe(true);
  });

  it('compresses a negotiated large snapshot and accepts the original encrypted envelope from older rooms',async()=>{
    const pipe=await CoopPipe.open(room.id), cipher=pipe as unknown as Cipher;
    const world={payload:{snapshot:{json:JSON.stringify(Array.from({length:300},(_,id)=>({id,x:217.5,y:442,kind:'sentry',hp:27,active:true})))}}};
    const plain=await cipher.seal(world,false), compressed=await cipher.seal(world,true);
    expect(compressed.length).toBeLessThan(plain.length*.3);
    expect(compressed).not.toContain('sentry');
    expect(await cipher.openMessage(compressed,true)).toEqual(world);
    expect(await cipher.openMessage(plain,true)).toEqual(world);
    expect(await cipher.openMessage(plain)).toEqual(world);
    await expect(cipher.openMessage(compressed)).rejects.toThrow();
    const wrong=await CoopPipe.open('c4_'+'48'.repeat(16));
    await expect((wrong as unknown as Cipher).openMessage(compressed,true)).rejects.toThrow();
  });

  it('limits the size of decompressed data even with a valid encryption key',async()=>{
    const cipher=await CoopPipe.open(room.id) as unknown as Cipher;
    const gzip=await new Response(new Blob(['x'.repeat(160001)]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer();
    const iv=crypto.getRandomValues(new Uint8Array(12));
    const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv},cipher.key,gzip);
    const wire=btoa(String.fromCharCode(...iv,...new Uint8Array(ciphertext)));
    await expect(cipher.openMessage(wire,true)).rejects.toThrow('联机数据太长');
  });
});

