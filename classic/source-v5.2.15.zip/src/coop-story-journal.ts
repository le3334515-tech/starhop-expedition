import { COOP_EPILOGUE, COOP_PROLOGUE, coopChapter, coopStoryRoute } from './coop-story';
import { COOP_ROOM_COUNT } from './game/coop-levels';

const storageKey = 'starhop.story.coop.v1';

/** Chapters are collected by identity. Their display order comes from the latest expedition. */
export function createCoopJournal() {
  const unlocked = new Set<string>([COOP_PROLOGUE.key]);
  let seed: number | undefined;
  let previous: { seed: number; index: number; theme: number; won: boolean } | undefined;

  function restore() {
    try {
      const raw = localStorage.getItem(storageKey);
      if (!raw) return;
      const saved = JSON.parse(raw);
      if (Array.isArray(saved?.keys)) {
        for (const key of saved.keys) if (typeof key === 'string') unlocked.add(key);
      }
      if (Number.isSafeInteger(saved?.seed)) seed = saved.seed;
    } catch { /* Memory remains usable in private or embedded browsers. */ }
  }
  restore();

  return {
    has(key: string) { return unlocked.has(key); },
    pages() { return coopStoryRoute(seed ?? 0); },
    observe(routeSeed: number, index: number, theme: number, won: boolean) {
      if (!Number.isSafeInteger(routeSeed) || !Number.isInteger(index) || index < 0 || index >= COOP_ROOM_COUNT ||
          !Number.isInteger(theme) || theme < 0 || theme > 7) return;
      if (previous?.seed === routeSeed && previous.index === index && previous.theme === theme && previous.won === won) return;
      previous = { seed: routeSeed, index, theme, won };
      const key = coopChapter(index, theme).key;
      const finished = won && index === COOP_ROOM_COUNT - 1;
      if (seed === routeSeed && unlocked.has(key) && (!finished || unlocked.has(COOP_EPILOGUE.key))) return;
      restore();
      seed = routeSeed;
      unlocked.add(key);
      if (finished) unlocked.add(COOP_EPILOGUE.key);
      try { localStorage.setItem(storageKey, JSON.stringify({ seed, keys: [...unlocked] })); } catch { /* Keep this session's pages. */ }
    },
  };
}
