import { describe, expect, it } from 'vitest';
import { COOP_EPILOGUE, COOP_PROLOGUE, ELITE_CLEAR_LINE, GUARDIAN_FAREWELL, coopChapter, coopStoryRoute } from './coop-story';
import { COOP_ELITE_ROOM_INDEX, COOP_ROOM_COUNT, COOP_WARDEN_ROOM_INDEX, createCoopRoom } from './game/coop-levels';

describe('the cooperative chronicle', () => {
  it('follows the actual seeded route and keeps unlocked chapters attached to their realms', () => {
    const stableKeys = new Map<string, string>();
    const ordinaryOrders = new Set<string>();
    for (const seed of [0, 1, 17, 42, 20261125, 0xffffffff]) {
      const route = coopStoryRoute(seed);
      expect(route).toHaveLength(COOP_ROOM_COUNT + 2);
      expect(route[0]).toBe(COOP_PROLOGUE);
      expect(route.at(-1)).toBe(COOP_EPILOGUE);
      expect(new Set(route.map(page => page.key)).size).toBe(route.length);
      const chapters = route.slice(1, -1);
      ordinaryOrders.add(chapters.slice(0, 8).map(page => page.key).join(','));
      for (const [stage, page] of chapters.entries()) {
        const { room } = createCoopRoom(seed, stage, 2);
        expect(page.title).toContain(room.name);
        expect(coopChapter(stage, room.theme)).toEqual(page);
        if (stableKeys.has(room.name)) expect(page.key).toBe(stableKeys.get(room.name));
        else stableKeys.set(room.name, page.key);
      }
      expect(chapters[4].key).toBe('realm-7');
      expect(chapters[COOP_ELITE_ROOM_INDEX].key).toBe('muster');
      expect(chapters[COOP_WARDEN_ROOM_INDEX].key).toBe('throne');
    }
    expect(stableKeys.size).toBe(COOP_ROOM_COUNT);
    expect(ordinaryOrders.size).toBeGreaterThan(1);
  });

  it('gives each distinct location a voiced cue and a full journal entry', () => {
    const route = coopStoryRoute(42);
    for (const page of route) {
      expect(page.speaker.trim()).not.toBe('');
      expect(page.text.length).toBeGreaterThanOrEqual(2);
    }
    const cues = [...route.map(page => page.line), GUARDIAN_FAREWELL, ELITE_CLEAR_LINE];
    expect(new Set(cues).size).toBe(cues.length);
    for (const cue of cues) {
      expect(Array.from(cue).length).toBeGreaterThan(0);
      expect(Array.from(cue).length).toBeLessThanOrEqual(30);
    }
  });
});
