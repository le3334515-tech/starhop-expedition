import { COOP_EXTRA_REALMS, COOP_ROOM_COUNT, coopRealmThemes } from './game/coop-levels';
import { EXPEDITION_TITLES } from './game/levels';
import { EXPEDITION_ROOM_COUNT } from './game/types';

export type CoopStoryPage = {
  key: string;
  title: string;
  speaker: string;
  line: string;
  text: string[];
};

export const COOP_PROLOGUE: CoopStoryPage = {
  key: 'prologue', title: '序 · 一线余温', speaker: '阿萤',
  line: '灯都亮了。你看，这根红绳怎么还在冒烟？',
  text: [
    '八境复明后的第一个傍晚，旧街的灯铺照常点灯。阿萤弯腰拣起行牒，系在牒上的红绳烫了她的手。绳结在纸上烙出两个倒写的小字，玄阙。',
    '柜台上的八盏灯同时矮了一截。阿萤留下照看灯火，把行牒递出门去。「带上它。每过一道星门，替我看看，灯芯究竟朝哪边倒。」',
  ],
};

const classic: Omit<CoopStoryPage, 'key' | 'title'>[] = [
  {
    speaker: '守山人', line: '听竹筒里头，有人隔着山点卯呢。',
    text: [
      '山门边的竹筒原是传报山火用的。守山人把一头贴到耳上，另一头竟报出一串早就撤掉的哨名。每念完一个，竹叶上的灯影就暗一寸。',
      '行牒贴近筒口，那边只剩自己的回声。竹节上一圈旧烙痕映进了纸里。',
    ],
  }, {
    speaker: '灯铺老人', line: '这灯我亲手糊的，灯影怎么会朝着火？',
    text: [
      '老人把朱灯转了半圈。灯芯端端正正，桌上的影子却还朝着山外。他掀开底座，多年前钉进去的王庭铜钱正热得发红。',
      '「那年家家领这样的灯座，说是替守夜人省油。」老人用火钳拔出铜钱，端来一小碗清油，灯影终于落回了墙上。',
    ],
  }, {
    speaker: '栈道守桥人', line: '风往谷里走，那串铃偏往山上响。',
    text: [
      '栈道上挂着两排风铃。下排顺风响，上排却从谷底一只只响回山巅。守桥人递来一截磨亮的铁索，索股间夹着细得像头发的铜丝。',
      '行牒上的红绳碰到铜丝，铃声就停了一拍。有人借着拉桥的索，往山上递令。',
    ],
  }, {
    speaker: '守钟僧', line: '别敲。再听一声，是钟底下在答。',
    text: [
      '钟槌已经用布裹好，钟底仍传来两声闷响。守钟僧点亮一盏矮灯，照出钟腹铸着的一行小字，「王庭发令，八境应声」。',
      '那八个字比环轨碑文新得多。僧人用湿纸捶下拓片夹进行牒，又把灯挪到阶边，照着来路。',
    ],
  }, {
    speaker: '引水人', line: '伸手摸摸，逆着水走的这一股是热的。',
    text: [
      '水庭的回流渠还在转。引水人拿木瓢撇开浮叶，渠壁一条针眼粗的裂纹竟渗着热水。水光穿过那条裂纹，一丝丝往天上游。',
      '他揉了团河泥暂时堵住裂纹。水里的星光重新连成一线，行牒的纸边也留下一道湿亮的弧。',
    ],
  }, {
    speaker: '机坊炉工', line: '炉膛是冷的，隔墙那副风箱却没停过。',
    text: [
      '炉工把铁钳搁上砧台，让钳柄贴着墙。墙那边传来一吸一吐的风箱声。每吐一次，门前星灯就缺一角光。',
      '旧炉账上还有一处从未封账的炉口，名叫赤铸悬城。炉工用炭笔圈出它，把那页账纸塞进行牒。',
    ],
  }, {
    speaker: '阿萤的留音', line: '数一遍，八道环都在转。多出来的是那根针。',
    text: [
      '天仪运转平稳，八道环影严丝合缝。只有刻度盘上方一根细针，钉死在「玄阙」二字上，满盘星火平白漏给了它一线。',
      '阿萤在留音里轻轻敲了两下针座。「这是后来钉上去的。我修环，你替我找钉针的人。」',
    ],
  }, {
    speaker: '余烬守卫', line: '是你啊。这身甲再碎一回，王印就困不住我了。',
    text: [
      '余烬守卫坐在碎甲旁，本来正用左手修一把竹椅。殿外传来点卯声。他右腕的王印冒起黑火，散落的甲片一块块扣回身上，连椅腿也被踩断了。',
      '他看见行牒上的红绳，趁铁面还没有合拢，把修椅子的小刀推到一旁。「打碎这身甲，王印就没处落了。我还得回来把椅子修好呢。」',
    ],
  },
];

export const GUARDIAN_FAREWELL = '腕上总算轻了。带上碎印，去赤铸炉找印模。';
export const ELITE_CLEAR_LINE = '最后一柄军刀落地。王庭门后，有人拔剑了。';

const extra: Omit<CoopStoryPage, 'title'>[] = [
  {
    key: 'skyforge', speaker: '赤铸炉工', line: '碎印给我。看这圈缺口，正合炉心那副模。',
    text: [
      '走遍八境，行牒上的灯痕终于围成整圆。守卫的碎印落入圆心，纸上显出赤铸悬城的炉门。风箱一开，铁模里正凝起另一枚一模一样的王印。',
      '炉工把碎印敲进模缝。铁模裂开，星火沿运炭的轨道奔向断月星桥。「炉子能熄，令还能再下。你得沿桥到那把剑跟前去。」',
    ],
  }, {
    key: 'moonbridge', speaker: '守桥卒的留声', line: '过桥看脚下。王庭把半轮月亮也铆进桥里了。',
    text: [
      '断月星桥的铜铆钉一盏盏亮起来，照出桥面旧日的车辙。赤铸炉送来的军印曾经从这里运进王庭，如今倒流的星火循着同一条路回家。',
      '桥那一头站满了披甲的人。直到星光落上第一顶头盔，校场的点卯鼓才响起来。',
    ],
  }, {
    key: 'muster', speaker: '禁军点卯官', line: '玄甲列前，赤刃殿后。校场今日，只许进。',
    text: [
      '点卯官的名册摊在鼓架上，纸已烂了半面。玄甲重卫仍按着各自的名字举盾。赤刃刑武肩扛一柄重刀，等盾沿齐平才双手举刀过顶。',
      '鼓每响一轮，王庭的门就落下一道闩。只有穿过禁军守着的校场，才能赶在最后一道闩落下前踏进殿门。',
    ],
  }, {
    key: 'throne', speaker: '玄阙镇星王', line: '孤亲手封的门。八境借去的火，今夜该还了。',
    text: [
      '最后一道门闩落在身后。玄阙镇星王倒提王剑，剑尖贴着地，殿里八道灯影一齐跪向御座。他把八境重燃的那一天，算作欠下新贡的第一天。',
      '星门已封，王印的母印就在剑格中央。阿萤在红绳另一端拍了一下手，像小时候隔着院墙打暗号。灯还亮着。',
    ],
  },
];

export const COOP_EPILOGUE: CoopStoryPage = {
  key: 'epilogue', title: '终 · 灯归万户', speaker: '阿萤',
  line: '你听，今夜第一声响的是卖早点的梆子。',
  text: [
    '王剑落在御阶下，剑格里的母印裂成两半。殿门自己开了。积在王庭屋瓦上的星光沿断桥、旧炉和八道环轨流回山下，禁军校场再也没有响起点卯鼓。',
    '阿萤在旧街灯铺门前解下行牒的红绳，把它系在新糊的灯穗上。点起灯时，灯芯不偏不倚，照着摊主揭开第一笼热馒头。',
    '余烬守卫拎着修好的竹椅走来，在铺门口坐下。这一回，他给自己买了一份早饭。',
  ],
};

const numerals = ['一','二','三','四','五','六','七','八','九','十','十一','十二'];

export function coopChapter(stage: number, theme: number): CoopStoryPage {
  if (!Number.isInteger(stage) || stage < 0 || stage >= COOP_ROOM_COUNT) throw new RangeError('Unknown cooperative chapter');
  const heading = `第${numerals[stage]}境 · `;
  if (stage < EXPEDITION_ROOM_COUNT) {
    if (!Number.isInteger(theme) || !classic[theme]) throw new RangeError('Unknown cooperative realm');
    return { ...classic[theme], key: `realm-${theme}`, title: heading + EXPEDITION_TITLES[theme][0] };
  }
  const index = stage - EXPEDITION_ROOM_COUNT;
  return { ...extra[index], title: heading + COOP_EXTRA_REALMS[index] };
}

export function coopStoryRoute(seed: number): CoopStoryPage[] {
  return [COOP_PROLOGUE, ...coopRealmThemes(seed).map((theme, stage) => coopChapter(stage, theme)), COOP_EPILOGUE];
}
