import classicIdle from '../assets/art/actors/hero-idle.png?inline';

/** Local, credited artwork. Keep the classic body immediately available if an action sheet fails. */
const idlePath = '../assets/art/actors/hero-idle.png';
const sheets = import.meta.glob(['../assets/art/**/*.png', '!../assets/art/actors/hero-idle.png'],
  { eager: true, query: '?url', import: 'default' }) as Record<string, string>;
const urls = { ...sheets, [idlePath]: classicIdle };
const images = new Map<string, HTMLImageElement>();
let pending: Promise<void> | undefined;
let loaded = 0;
let failed: string[] = [];

export function artImage(name: string): HTMLImageElement | undefined {
  const image = images.get(name);
  return image?.complete && image.naturalWidth > 0 ? image : undefined;
}

export function artLoadState() { return { loaded, total: Object.keys(urls).length, failed: [...failed] }; }

export function loadArt(onProgress?: (loaded: number, total: number) => void): Promise<void> {
  if (pending) return pending;
  const entries = Object.entries(urls);
  pending = Promise.all(entries.map(([key, url]) => new Promise<void>((resolve) => {
    const name = key.replace('../assets/art/', '');
    const image = new Image();
    images.set(name, image);
    image.onload = () => { loaded++; onProgress?.(loaded, entries.length); resolve(); };
    image.onerror = () => { loaded++; failed.push(name); onProgress?.(loaded, entries.length); resolve(); };
    image.src = url;
  }))).then(() => undefined);
  return pending;
}
