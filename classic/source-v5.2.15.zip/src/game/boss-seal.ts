import type { Boss } from './types';

export const BOSS_TRANSFORM_TIME = 3.2;
export const WARDEN_ENTRANCE_TIME = 3.2;
export const WARDEN_LANDING_FRACTION = .68;
export const isWardenEntrance = (b: Boss) => b.kind === 'warden' && b.phase === 1 && b.mode === 'transition';
export const entranceProgress = (b: Boss) => Math.min(1, Math.max(0, 1 - b.timer / WARDEN_ENTRANCE_TIME));
export const BOSS_ASCENSION_TIME = 2.8;
export const BOSS_ASCENSION_IMPACT = 1.82;
export const ECLIPSE_WINDUP = .8;
export const ECLIPSE_WIDTH = 52;
export const sealProgress = (b: Boss) => Math.min(1, Math.max(0, 1 - b.timer / BOSS_TRANSFORM_TIME));
export const openingSeal = (b: Boss) => b.form===2 && b.phase===2 && b.mode==='transition';
export const openingAscension = (b: Boss) => b.form === 2 && b.phase === 3 && b.mode === 'transition';
export const ascensionProgress = (b: Boss) => Math.min(1, Math.max(0, 1 - b.timer / BOSS_ASCENSION_TIME));
export const ease = (a:number,b:number,t:number) => { const x=Math.min(1,Math.max(0,(t-a)/(b-a))); return x*x*(3-2*x); };

/** Shift the entire pattern at arena edges, keeping safe gaps between every hitbox. */
export function eclipseLanes(b: Boss, roomWidth: number): number[] {
  const spacing = 100, radius = b.kind === 'warden' ? 3 : 2;
  const center = Math.min(roomWidth - 80 - spacing * radius, Math.max(420 + spacing * radius, b.targetX + b.w / 2));
  return Array.from({ length: radius * 2 + 1 }, (_, index) => center + (index - radius) * spacing);
}
