import { ease } from './boss-seal';
import type { AwakeningOrigin } from './hero-awakening-art';
import { AWAKENING_DURATION, type CharacterId, type Hero } from './types';

type Signature = Exclude<CharacterId, 'traveller'>;
type Point = readonly [number, number];
const TAU = Math.PI * 2;
const PALETTE = {
  blade: '#edb6a6',
  staff: '#e3cbf0',
  wheel: '#b6edb5',
  spear: '#b7e7ed',
  monk: '#e5b777',
} as const satisfies Record<Signature, string>;

export function hasSignatureUltimate(character?: CharacterId | null): character is Signature {
  return character != null && character !== 'traveller';
}

function path(c: CanvasRenderingContext2D, points: readonly Point[], close = false) {
  c.beginPath();
  c.moveTo(Math.round(points[0][0]),Math.round(points[0][1]));
  for (let i=1; i<points.length; i++) c.lineTo(Math.round(points[i][0]),Math.round(points[i][1]));
  if (close) c.closePath();
}

function flat(c: CanvasRenderingContext2D, color: string, points: readonly Point[]) {
  c.fillStyle=color;
  path(c,points,true);
  c.fill();
}

function spark(c: CanvasRenderingContext2D, x: number, y: number, width: number) {
  c.fillRect(Math.round(x-width),Math.round(y),width*2+1,1);
  c.fillRect(Math.round(x),Math.round(y-width),1,width*2+1);
}

function sword(c: CanvasRenderingContext2D, x: number, y: number, angle: number, scale: number) {
  c.save(); c.translate(x,y); c.rotate(angle); c.scale(scale,scale);
  flat(c,'#623e4a',[[0,-31],[4,-22],[3,2],[9,4],[6,8],[2,7],[2,14],[0,17],[-2,14],[-2,7],[-6,8],[-9,4],[-3,2],[-4,-22]]);
  flat(c,'#edb6a6',[[0,-28],[3,-20],[2,0],[0,4],[-2,0],[-3,-20]]);
  flat(c,'#fff0ce',[[0,-21],[1,-17],[1,1],[0,3],[-1,1]]);
  flat(c,'#d6a274',[[-7,4],[0,5],[7,4],[5,6],[1,6],[1,13],[-1,13],[-1,6],[-5,6]]);
  c.restore();
}

function spear(c: CanvasRenderingContext2D, x: number, y: number, angle: number, scale: number) {
  c.save(); c.translate(x,y); c.rotate(angle); c.scale(scale,scale);
  flat(c,'#183744',[[0,-30],[4,-20],[2,-8],[2,22],[-2,22],[-2,-8],[-4,-20]]);
  flat(c,'#ccebf1',[[0,-28],[3,-20],[0,-9],[-3,-20]]);
  flat(c,'#78aebc',[[0,-11],[1,-10],[1,22],[0,22]]);
  flat(c,'#d5c492',[[0,-10],[5,-8],[3,-5],[-1,-8],[-4,-6],[-5,-9]]);
  c.restore();
}

function crescent(c: CanvasRenderingContext2D, x: number, y: number, radius: number, tilt = 0) {
  c.save(); c.translate(x,y); c.rotate(tilt);
  c.fillStyle='#f2deb7'; c.strokeStyle='#beaadf'; c.lineWidth=1;
  c.beginPath();
  c.arc(0,0,radius,Math.PI*.45,Math.PI*1.55);
  c.quadraticCurveTo(-radius*.94,0,Math.cos(Math.PI*.45)*radius,Math.sin(Math.PI*.45)*radius);
  c.fill(); c.stroke(); c.restore();
}

function feather(c: CanvasRenderingContext2D, x: number, y: number, tilt: number, scale: number) {
  c.save(); c.translate(x,y); c.rotate(tilt); c.scale(scale,scale);
  flat(c,'#1e524d',[[0,-17],[5,-8],[5,3],[1,11],[-1,15],[-6,2],[-7,-6]]);
  flat(c,'#79bb9b',[[0,-15],[4,-7],[2,4],[-1,9],[-5,1],[-6,-6]]);
  flat(c,'#c8e9b7',[[0,-13],[0,1],[-2,7],[-1,-1]]);
  c.strokeStyle='#d1ce96'; c.lineWidth=1; path(c,[[-4,-4],[0,-2],[3,-6]]); c.stroke();
  c.restore();
}

function fan(c: CanvasRenderingContext2D, x: number, y: number, reveal: number) {
  const segments=10, radius=73;
  const points: Point[]=[];
  for (let i=0;i<=segments;i++) {
    const a=-Math.PI/2+(-1+i/segments*2)*1.16*reveal;
    points.push([Math.cos(a)*radius,Math.sin(a)*radius]);
  }
  c.save(); c.translate(x,y);
  flat(c,'#316457',[[0,0],...points,[0,-2]]);
  c.strokeStyle='#b6dca9'; c.lineWidth=1.4; path(c,points); c.stroke();
  c.strokeStyle='#d7cb93'; c.lineWidth=1;
  for (let i=0;i<points.length;i+=2){ path(c,[[0,0],points[i]]); c.stroke(); }
  c.restore();
}

function fist(c: CanvasRenderingContext2D, x: number, y: number, scale: number) {
  c.save(); c.translate(x,y); c.scale(scale,scale);
  flat(c,'#663f38',[[-26,-5],[-22,-27],[-10,-38],[17,-37],[28,-27],[27,-9],[16,2],[9,16],[-13,16],[-17,5]]);
  flat(c,'#ae6c4e',[[-23,-11],[-19,-24],[-10,-33],[15,-32],[24,-24],[23,-11],[12,0],[9,7],[-11,7],[-17,0]]);
  flat(c,'#d59664',[[-18,-17],[-15,-27],[14,-27],[20,-21],[18,-14],[8,-8],[-1,-5],[-7,-12]]);
  c.strokeStyle='#f5d3a3';c.lineWidth=1.4;
  path(c,[[-21,-23],[-10,-34],[15,-33],[24,-25],[22,-12],[10,1]]); c.stroke();
  path(c,[[-12,-31],[-13,-21],[-7,-17],[3,-21],[3,-29]]); c.stroke();
  path(c,[[9,-31],[9,-21],[15,-17],[20,-22]]); c.stroke();
  c.restore();
}

function floorShape(c: CanvasRenderingContext2D, role: Signature, scale: number, ripple: boolean) {
  const w=(ripple ? 58 : 28)*scale;
  switch(role) {
    case 'blade':
      for (const i of [-1,1]) {
        path(c,[[i*w,-2],[i*w*.49,-8],[0,-3],[i*w*.49,3],[i*w,0]]);
        c.stroke();
      }
      break;
    case 'staff':
      c.beginPath(); c.ellipse(0,0,w,Math.max(1,w*.18),0,.13,Math.PI*.98); c.stroke();
      c.beginPath(); c.ellipse(0,1,w*.72,Math.max(1,w*.12),0,Math.PI*1.1,TAU+.04); c.stroke();
      break;
    case 'wheel':
      for (const dy of [-4,0,4]) {
        path(c,[[-w,dy],[-w*.45,dy-3],[w*.32,dy+3],[w,dy]]); c.stroke();
      }
      break;
    case 'spear':
      for (let i=-2;i<=2;i++) {
        const x=i*w*.40;
        path(c,[[x-7,2],[x,-4],[x+7,2],[x,5]]); c.stroke();
      }
      break;
    case 'monk':
      path(c,[[-w,-1],[-w*.7,-7],[w*.66,-7],[w,-1],[w*.7,5],[-w*.65,5]],true); c.stroke();
      if(ripple) {
        path(c,[[-w*.68,-4],[-w*.44,-19],[-w*.27,-14],[0,-31],[w*.18,-13],[w*.31,-18],[w*.60,-4]]);
        c.stroke();
      }
  }
}

function openingShape(c: CanvasRenderingContext2D, role: Signature, reveal: number, travel: number, quiet: boolean) {
  switch(role) {
    case 'blade': {
      const reach=62 - travel*20;
      for (let i=-2;i<=2;i++) {
        const corner=i*reach*.50;
        const y=-62-Math.abs(i)*6+travel*9;
        c.strokeStyle='#bd7880'; c.lineWidth=1;
        path(c,[[corner,y-30],[corner*.55,y+7]]); c.stroke();
        sword(c,corner,y,i*.22+.14,Math.max(.15,reveal)*(.95-Math.abs(i)*.08));
      }
      break;
    }
    case 'staff': {
      const y=-72-travel*10, r=Math.max(2,37*reveal);
      c.strokeStyle='#bfade1';c.lineWidth=1.25;
      c.beginPath();c.arc(0,y,r,-.25,TAU-.48);c.stroke();
      c.beginPath();c.arc(0,y,r+6,.47,TAU+.2);c.stroke();
      crescent(c,0,y,Math.max(2,23*reveal),-.4);
      c.strokeStyle='#d9c1db';
      for(let i=0;i<7;i++){
        const a=i*TAU/7, x=Math.cos(a)*(r+13), dy=Math.sin(a)*(r+13);
        path(c,[[x,y+dy],[x*.91,y+dy*.91]]);c.stroke();
      }
      break;
    }
    case 'wheel':
      fan(c,0,-36,Math.max(.08,reveal));
      for (const side of [-1,1]) {
        feather(c,side*(28+travel*29),-72+travel*17,side*(.65+travel),Math.max(.15,reveal));
      }
      break;
    case 'spear':
      for(let i=-2;i<=2;i++){
        const x=i*(27+reveal*2), y=-117+travel*81+Math.abs(i)*13;
        c.strokeStyle='#b6e2e4';c.lineWidth=1;
        path(c,[[x,y-34],[x,y+3]]);c.stroke();
        spear(c,x,y,Math.PI+i*.045,Math.max(.12,reveal)*(.95- Math.abs(i)*.08));
      }
      break;
    case 'monk':
      fist(c,0,-76+travel*17,Math.max(.13,reveal));
      break;
  }
  c.fillStyle=PALETTE[role];
  // Sparse motes stay close to the activation point.
  if (!quiet) for (let i=0;i<7;i++) {
    const dir=i%2 ? -1 : 1;
    spark(c,dir*(21+i*7)*reveal,-45+(i%3)*11+travel*13,1+i%2);
  }
}

function groundRelease(c: CanvasRenderingContext2D, role: Signature, reach: number) {
  const w = 30 + reach * 87;
  switch (role) {
    case 'blade':
      for (const side of [-1, 1]) {
        flat(c, PALETTE.blade, [[0, 0], [side * w * .34, -6], [side * w, -17], [side * w * .43, -2]]);
      }
      break;
    case 'staff':
      c.beginPath();
      c.ellipse(0, -3, w * .82, 6, 0, 0, Math.PI);
      c.ellipse(0, -3, w * .82, 15, 0, Math.PI, TAU);
      c.closePath();
      c.stroke();
      for (const side of [-1, 1]) {
        flat(c, '#f2deb7', [[side * w * .78, -11], [side * w, -4], [side * w * .74, -2], [side * w * .86, -5]]);
      }
      break;
    case 'wheel':
      for (const side of [-1, 1]) {
        flat(c, PALETTE.wheel, [[side * 9, -6], [side * w * .42, -20], [side * w, -40],
          [side * w * .81, -23], [side * w * .38, -12]]);
        flat(c, '#72ba97', [[side * 12, -3], [side * w * .52, -15], [side * w * .95, -20], [side * w * .54, -10]]);
      }
      break;
    case 'spear':
      for (let i = -2; i <= 2; i++) {
        const x = i * w * .4;
        const h = (1 - Math.abs(i) * .16) * (28 - reach * 16);
        flat(c, PALETTE.spear, [[x - 6, 0], [x, -h], [x + 4, -5], [x + 10, 1]]);
      }
      break;
    case 'monk':
      path(c, [[-w, 3], [-w * .75, -7], [-w * .31, -4], [-8, 1], [12, -6], [w * .38, -4], [w * .69, -12], [w, -9]]);
      c.stroke();
      for (const side of [-1, 1]) {
        const x = side * w * .59;
        flat(c, '#d6a275', [[x - 6, -7], [x - 3, -17 + reach * 3], [x + 3, -13], [x + 4, -6]]);
      }
      break;
  }
}

function retainedShape(c: CanvasRenderingContext2D, role: Signature, drift: number, closing: number) {
  const bend=1-closing*.52;
  switch(role) {
    case 'blade':
      sword(c,-26*bend,-50+drift, -.38,.56*bend);
      sword(c,30*bend,-48-drift,.49,.48*bend);
      break;
    case 'staff':
      crescent(c,-28*bend,-61-drift, 10*bend,-.43);
      c.strokeStyle='#baaddb';c.lineWidth=1;
      c.beginPath();c.arc(-28*bend,-61-drift,14*bend, -1.3,2.39);c.stroke();
      c.fillStyle='#f7d99a';spark(c,28*bend,-58+drift,2);
      break;
    case 'wheel':
      feather(c,-27*bend,-48+drift,-1.06,.68*bend);
      feather(c,29*bend,-55-drift,.92,.56*bend);
      break;
    case 'spear':
      spear(c,-29*bend,-49+drift,.17,.65*bend);
      spear(c,33*bend,-35-drift,-.64,.39*bend);
      break;
    case 'monk':
      fist(c,-29*bend,-48+drift,.35*bend);
      fist(c,30*bend,-30-drift,.29*bend);
      break;
  }
}

/** Visual only. Cast from the activation point, with a smaller travelling seal afterward. */
export function drawCharacterUltimate(
  c: CanvasRenderingContext2D, role: Signature, hero: Hero, origin: AwakeningOrigin, age: number,
  strength: number, quiet: boolean, layer: 'ground' | 'seal',
) {
  if (hero.hp <= 0 || strength <= .02 || age < 0 || age >= AWAKENING_DURATION) return;
  const fade=1-ease(AWAKENING_DURATION-.62,AWAKENING_DURATION,age);
  const reveal=ease(.01,.16,age), travel=ease(.18,.60,age);
  const opening=reveal*(1-ease(.4,.76,age));
  const release=ease(.14,.24,age)*(1-ease(.26,.58,age));
  const sustain=ease(.3,.62,age)*fade;
  const closing=ease(AWAKENING_DURATION-.75,AWAKENING_DURATION-.23,age);
  c.save();
  const alpha=c.globalAlpha*strength;
  if (opening > .01) {
    c.save(); c.translate(Math.round(origin.x),Math.round(origin.foot));
    c.globalAlpha=alpha*opening*(layer==='ground'?.62:.87);
    if(layer==='ground') {
      c.strokeStyle=PALETTE[role];c.lineWidth=1.5;
      floorShape(c,role,.46+travel*.72,true);
      if (release > .01) {
        c.globalAlpha=alpha*release*(quiet?.46:.82);
        c.lineWidth=2;
        groundRelease(c,role,quiet?.36:travel);
      }
    } else openingShape(c,role,reveal,travel,quiet);
    c.restore();
  }
  if (sustain > .01) {
    c.translate(Math.round(hero.x+hero.w/2),Math.round(hero.y+hero.h));
    c.globalAlpha=alpha*sustain*(layer==='ground'?.48:.65);
    if (layer==='ground') {
      c.strokeStyle=PALETTE[role];c.lineWidth=1.2;
      floorShape(c,role,1-closing*.22,false);
    } else retainedShape(c,role,quiet?0:Math.sin(age*5)*4,closing);
  }
  c.restore();
}
