import { describe, expect, it } from 'vitest';
import { BOSS_AWAKENED_HP, BOSS_MAX_HP, BOSS_TRANSFORM_TIME, GameEngine } from './engine';
import { EMPTY_INPUT, type Boss, type Enemy, type WeaponId } from './types';

const target = (x: number, hp = 100, id = 70): Enemy => ({ id, kind: 'sentry', x, y: 406, w: 32, h: 42, vx: 0, vy: 0, hp, maxHp: hp, facing: -1, timer: 0, hurt: 0, dead: false, originX: x, originY: 406, attackCooldown: 99 });
function arena(weapon: WeaponId = 'blade') {
  const game = new GameEngine(); game.start({ seed: 42, modifier: 'standard', weapon });
  const s = game.state;
  s.room.platforms = [{ x: 0, y: 448, w: s.room.width, h: 120, kind: 'ground' }];
  s.room.hazards = []; s.pickups = []; s.enemies = [target(1900)];
  Object.assign(s.hero, { x: 300, y: 412, grounded: true, critChance: 0, invincible: 0 });
  return game;
}
function advance(game: GameEngine, seconds: number, held = false) {
  for (let n = 0; n < Math.ceil(seconds * 120); n++) game.update(1 / 120, { ...EMPTY_INPUT, attackHeld: held });
}
function bossArena(weapon: WeaponId = 'blade') {
  const game = arena(weapon), s = game.state;
  s.room.isBoss = true; s.enemies = [];
  s.hero.x = 700;
  s.boss = { x: 755, y: 330, w: 104, h: 118, hp: BOSS_MAX_HP, maxHp: BOSS_MAX_HP, phase: 1, form: 1, mode: 'idle', timer: 99, vx: 0, vy: 0, facing: -1, hurt: 0, attackCount: 0, active: true, intent: 'charge', targetX: 700, chain: 0, guard: 30, maxGuard: 30, exposed: 0 } satisfies Boss;
  return game;
}

describe('staff balance against the guardian', () => {
  it.each([[0, 2], [2, 3.1]])('scales staff cast step %i once against Boss health and preserves armor damage', (step, damage) => {
    const game = bossArena('ember'), s = game.state, boss = s.boss!;
    Object.assign(s.hero, { x: 460, attackStep: step, comboWindow: 1 });
    Object.assign(boss, { form: 2, phase: 2, hp: BOSS_AWAKENED_HP, maxHp: BOSS_AWAKENED_HP, guard: 56, maxGuard: 56 });

    game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    expect(s.projectiles).toHaveLength(1);
    expect(s.projectiles[0].damage).toBeCloseTo(damage);
    game.equipWeapon('disc');
    advance(game, .7);

    expect(boss.hp).toBeCloseTo(BOSS_AWAKENED_HP - damage * .35 * .91);
    expect(boss.guard).toBeCloseTo(56 - damage * .8);
  });

  it('reduces staff splash against Boss health while preserving the slash weapon’s star shards', () => {
    const staff = bossArena('ember'), blade = bossArena('blade');
    for (const game of [staff, blade]) {
      const s = game.state, boss = s.boss!;
      s.hero.x = 460;
      if (game === staff) {
        s.room.platforms.push({ x: boss.x - 35, y: 360, w: 12, h: 88, kind: 'stone' });
      } else {
        s.hero.extraProjectiles = 1;
      }
      game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
      if (game === blade) game.equipWeapon('ember');
      advance(game, .7);
    }
    expect(staff.state.boss!.hp).toBeCloseTo(BOSS_MAX_HP - 2 * .75 * .91);
    expect(blade.state.boss!.hp).toBeCloseTo(BOSS_MAX_HP - 1.4);
  });

  it('keeps the base staff hit and burn on an ordinary enemy', () => {
    const game = arena('ember'), s = game.state;
    const opponent = target(470);
    s.enemies = [opponent];
    game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    for (let frame = 0; frame < 65 && opponent.hp === opponent.maxHp; frame++) advance(game, 1 / 120);
    expect(opponent.maxHp - opponent.hp).toBeCloseTo(2);
    expect(opponent.burnDamage).toBeCloseTo(.3);
  });
});

describe('v4.4 responsive defense, weapons and a true second form', () => {
  it('starts guard synchronously during hitstop and cancels a dash before the next tick', () => {
    const game = arena(), s = game.state;
    s.hitstop = .09; s.hero.dashTimer = .15; s.hero.attackTimer = .2;
    expect(game.requestGuard()).toBe(true);
    expect(s.hero.guardTimer).toBe(.24); expect(s.hero.dashTimer).toBe(0);
    expect(s.hero.attackTimer).toBe(0);
    game.update(.01, EMPTY_INPUT);
    expect(s.hero.guardTimer).toBe(.24);
  });
  it('also accepts simulated guard edges before a frozen physics frame', () => {
    const game = arena(); game.state.hitstop = .08;
    game.update(.01, { ...EMPTY_INPUT, guardPressed: true });
    expect(game.state.hero.guardTimer).toBe(.24);
  });
  it('keeps guard active when an older dash edge reaches the same or first unfrozen frame', () => {
    const same = arena();
    same.requestGuard();
    same.update(1 / 120, { ...EMPTY_INPUT, dashPressed: true, guardPressed: true });
    expect(same.state.hero.guardTimer).toBeGreaterThan(.2);
    expect(same.state.hero.dashTimer).toBe(0);
    const frozen = arena(); frozen.state.hitstop = .06;
    frozen.update(.01, { ...EMPTY_INPUT, dashPressed: true });
    frozen.requestGuard(); advance(frozen, .09);
    expect(frozen.state.hero.guardTimer).toBeGreaterThan(.18);
    expect(frozen.state.hero.dashTimer).toBe(0);
  });
  it('buffers a guard pressed just before cooldown ends rather than losing it', () => {
    const game = arena(); game.state.hero.guardCooldown = .07;
    expect(game.requestGuard()).toBe(false); advance(game, .08);
    expect(game.state.hero.guardTimer).toBeGreaterThan(.2);
    game.pause(); game.state.hero.guardTimer = 0;
    expect(game.requestGuard()).toBe(false);
  });
  it('clears an unfulfilled guard buffer when pausing instead of guarding after resume', () => {
    const game = arena(); game.state.hero.guardCooldown = .07;
    game.requestGuard(); game.pause(); game.resume(); advance(game, .1);
    expect(game.state.hero.guardTimer).toBe(0);
  });
  it('lets the staff pierce and explode through multiple enemies in one shot', () => {
    const game = arena('ember'), s = game.state;
    s.enemies = [target(410, 2, 70), target(550, 2, 71), target(1900, 100, 72)];
    game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true }); advance(game, .6);
    expect(s.enemies[0].dead).toBe(true); expect(s.enemies[1].dead).toBe(true);
  });
  it('fires a larger charged explosion on the third staff attack', () => {
    const game = arena('ember');
    for (let n = 0; n < 3; n++) { game.state.hero.attackCooldown = 0; game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true }); }
    const shots = game.state.projectiles;
    expect(shots.some(p => p.style === 'charged')).toBe(true);
    expect(shots.find(p => p.style === 'charged')!.damage).toBeGreaterThan(shots[0].damage);
  });
  it('keeps the charged staff shot above the floor and hits a short ground pack at range', () => {
    const game = arena('ember'), s = game.state;
    s.enemies = [target(540, 50, 70), target(610, 50, 71), target(1900, 100, 72)];
    for (const e of s.enemies.slice(0, 2)) { e.h = 30; e.y = 418; }
    Object.assign(s.hero, { level: 7, attackStep: 2, comboWindow: 1 });
    game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true }); advance(game, .48);
    expect(s.enemies.slice(0, 2).every(e => e.hp < 50 && (e.burnTime ?? 0) > 0)).toBe(true);
  });
  it('gives the disc a useful twin throw at rank one and projectile clearing at rank three', () => {
    const game = arena('disc'), s = game.state;
    game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    expect(s.projectiles.filter(p => p.kind === 'disc')).toHaveLength(2);
    s.hero.level = 7;
    const wheel = s.projectiles[0];
    s.projectiles.push({ id: 999, kind: 'enemy', owner: 'enemy', x: wheel.x, y: wheel.y, w: 24, h: 24, vx: 0, vy: 0, life: 3, damage: 1, hitIds: [] });
    game.update(1 / 120, EMPTY_INPUT);
    expect(s.projectiles.some(p => p.id === 999)).toBe(false);
  });
  it('upgrades weapon moves at levels four and seven, not only their labels', () => {
    const one = arena('ember'), four = arena('ember'); four.state.hero.level = 4;
    for (const game of [one, four]) game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    expect(four.state.projectiles.length).toBe(one.state.projectiles.length + 1);
    expect(four.state.projectiles[0].pierce).toBeGreaterThan(one.state.projectiles[0].pierce!);
  });
  it('gives upgraded blades a real reach and damage increase', () => {
    const one = arena(), four = arena(), seven = arena();
    four.state.hero.level = 4; seven.state.hero.level = 7;
    for (const game of [one, four, seven]) {
      game.state.enemies = [target(405, 100)];
      game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    }
    expect(one.state.enemies[0].hp).toBe(100);
    expect(four.state.enemies[0].hp).toBeLessThan(100);
    expect(seven.state.enemies[0].hp).toBeLessThan(four.state.enemies[0].hp);
  });
  it('gives the dark form real armor, while full posture damage still opens a shorter punish window', () => {
    const armored = bossArena(), broken = bossArena();
    for (const game of [armored, broken]) {
      Object.assign(game.state.boss!, { form: 2, phase: 2, hp: BOSS_AWAKENED_HP, maxHp: BOSS_AWAKENED_HP, guard: 48, maxGuard: 48 });
    }
    broken.state.boss!.guard = .1;
    for (const game of [armored, broken]) game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    expect(armored.state.boss!.hp).toBeCloseTo(BOSS_AWAKENED_HP - 1.593 * .35);
    expect(armored.state.boss!.guard).toBeCloseTo(48 - 1.593 * .8);
    expect(broken.state.boss!.mode).toBe('stagger');
    expect(broken.state.boss!.timer).toBeCloseTo(.7);
    broken.state.hitstop = 0; broken.state.hero.attackCooldown = 0;
    const before = broken.state.boss!.hp;
    broken.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    expect(before - broken.state.boss!.hp).toBeGreaterThan(1.5);
  });
  it('refills a second health bar at first-form defeat, protects the transformation, and wins only after that form dies', () => {
    const game = bossArena(), s = game.state, b = s.boss!;
    b.hp = 1; game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    expect(b.form).toBe(2); expect(b.hp).toBe(BOSS_AWAKENED_HP); expect(b.maxHp).toBe(BOSS_AWAKENED_HP);
    expect(b.mode).toBe('transition'); expect(b.timer).toBeCloseTo(BOSS_TRANSFORM_TIME);
    expect(s.result).toBeNull(); expect(s.roomCleared).toBe(false);
    advance(game, .7, true); expect(b.hp).toBe(BOSS_AWAKENED_HP);
    advance(game, 2.1); b.hp = 1; b.phase = 3; b.mode = 'idle'; b.timer = 99; b.guard = 0;
    s.hero.x = b.x - 55; s.hero.y = 412; s.hero.facing = 1; s.hero.attackCooldown = 0; s.hitstop = 0;
    game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    expect(b.mode).toBe('dead'); expect(s.result?.won).toBe(true);
  });
  it('gives the awakened form delayed rift pillars and ink rain rather than only faster old moves', () => {
    const game = bossArena(), s = game.state, b = s.boss!;
    b.form = 2; b.phase = 2; b.hp = b.maxHp;
    for (const intent of ['rift', 'rain'] as const) {
      s.projectiles = []; b.mode = 'windup'; b.intent = intent; b.timer = 0; b.targetX = 720;
      game.update(1 / 120, EMPTY_INPUT);
      expect(s.projectiles.length).toBeGreaterThanOrEqual(3);
      expect(s.projectiles.every(p => p.style === 'ink' && p.delay! > 0)).toBe(true);
      expect(s.projectiles.some(p => p.kind === 'rift')).toBe(intent === 'rift');
    }
  });
});
