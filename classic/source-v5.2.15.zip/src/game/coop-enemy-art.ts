import type { CoopEnemyAppearance } from './enemy-catalog';
import { drawForgeCrab } from './forge-crab-art';
import { drawForgeLantern } from './forge-lantern-art';
import { drawMoonKite } from './moon-kite-art';
import type { Enemy } from './types';

const SIZE = 40;
const CENTER = 20;
const FOOT = 36;

let raster: CanvasRenderingContext2D | null = null;
const NATIVE_HEIGHT: Record<CoopEnemyAppearance, number> = {
  'forge-crab': 25,
  'forge-lantern': 30,
  'moon-kite': 28,
};

/** Co-op sprites share a foot anchor and the original enemies’ pixel-density range. */
export function drawCoopEnemy(c: CanvasRenderingContext2D, e: Enemy, appearance: CoopEnemyAppearance): boolean {
  if (!raster) {
    const surface = c.canvas.ownerDocument.createElement('canvas');
    surface.width = surface.height = SIZE;
    raster = surface.getContext('2d');
  }
  if (!raster) return false;
  raster.clearRect(0, 0, SIZE, SIZE);
  raster.save();
  raster.translate(CENTER, FOOT);
  if (appearance === 'forge-lantern') {
    if (!drawForgeLantern(raster, e)) {
      raster.restore();
      return false;
    }
  } else if (appearance === 'forge-crab') drawForgeCrab(raster, e);
  else drawMoonKite(raster, e);
  if (e.hurt > .085) {
    raster.globalCompositeOperation = 'source-atop';
    raster.fillStyle = '#ffd99b66';
    raster.fillRect(-CENTER, -FOOT, SIZE, SIZE);
  }
  raster.restore();

  const x = Math.round(e.x + e.w / 2), foot = Math.round(e.y + e.h);
  const airborne = e.kind === 'bat';
  const scale = e.h / NATIVE_HEIGHT[appearance];
  c.save();
  c.translate(x, foot);
  if (!airborne) {
    c.fillStyle = '#15252260';
    c.beginPath();
    c.ellipse(0, 0, e.w * .51, 3, 0, 0, Math.PI * 2);
    c.fill();
  }
  c.scale(e.facing || 1, 1);
  c.imageSmoothingEnabled = false;
  const float = appearance === 'moon-kite' ? 3 : 0;
  c.drawImage(raster.canvas, -CENTER * scale, -FOOT * scale + float, SIZE * scale, SIZE * scale);
  c.restore();
  return true;
}
