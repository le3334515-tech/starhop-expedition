import { COOP_CHARACTERS } from '../coop-characters';
import type { CoopCharacterId, CoopSeat } from '../coop-transport';
import type { PartyTraveller } from '../coop-play';
import { drawArtHero } from './actor-art';
import { artImage } from './art-assets';
import { drawArtSlash } from './effect-art';
import { rangedWeaponPose } from './hero-weapon-pose';
import { attackProgress, attackSheetFrame, SHEET_RELEASE_END } from './weapon-motion';
import { WEAPONS, type Hero, type Projectile, type WeaponId } from './types';
import { drawHeldVariant, drawMoonfireCast, drawMountainPunch, drawSpearThrust, drawTigerGauntlet, drawWillowCut, isVariantWeapon } from './weapon-visuals';

export interface CoopFrame {
  people: readonly PartyTraveller[];
  seat: CoopSeat | null;
  shots: readonly Projectile[];
}
const kit = {
  blade: { file: 'coop-warrior', anchorX:81, anchorY:101, scale:1.20, contact:[4,2,4] },
  staff: { file: 'coop-staff', anchorX:69, anchorY:97, scale:1.04, contact:[4,4,9] },
  spear: { file: 'coop-huntress', anchorX:75, anchorY:97, scale:1.42, contact:[3,3,2] },
  monk: { file: 'coop-monk', anchorX:32, anchorY:84, scale:1.50, contact:[1,1,6] },
} as const;
const TAU = Math.PI * 2;
const weaponPalette = {
  blade: new Set([0xd2ddf7,0xb6cadf,0xc6d6f3]),
  staff: new Set([0x502d1c,0xdcddce,0xadadad,0x424242]),
  spear: new Set([0x5b737c,0x829ba1,0xb6c4c6,0xc6d9e3,0xecf1ec,0xd6e3e2,0xf9f9f9]),
};
const cleanCostumes = new WeakMap<HTMLImageElement, HTMLCanvasElement>();
const cleanStaffCasts = new WeakMap<HTMLImageElement, HTMLCanvasElement>();

const staffCloth = new Set([0x312841,0x9f8fb7,0x971a1a,0x3f3a57,0xb42626,0xb4a9c6,0x5a0808,0xdfdfdf,0xfefdff,0xff0707,0xcacaca]);
function costumeLayer(image: HTMLImageElement, role: 'blade' | 'staff' | 'spear', pose: string, keepStaff=false): HTMLCanvasElement {
  const cache=keepStaff ? cleanStaffCasts : cleanCostumes;
  const cached = cache.get(image);
  if (cached) return cached;
  const canvas = document.createElement('canvas');
  canvas.width=image.naturalWidth; canvas.height=image.naturalHeight;
  const ctx=canvas.getContext('2d')!;
  ctx.drawImage(image,0,0);
  const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);
  const colors=weaponPalette[role];
  const casting = role==='staff' && pose.startsWith('attack');
  const tile=image.naturalHeight;
  const {data}=pixels;
  for (let i=0;i<data.length;i+=4) {
    if (!data[i+3]) continue;
    const r=data[i], g=data[i+1], b=data[i+2];
    const rgb=(r<<16)|(g<<8)|b;
    if (keepStaff && colors.has(rgb)) continue;
    if (colors.has(rgb) || (casting && (!staffCloth.has(rgb) || (i/4%tile)>95)) ||
        (!keepStaff && role==='staff' && rgb===0xff0707 && (i/4%tile)>80) ||
        role==='spear' && r>170 && g>185 && b>=r-3 ||
        role==='blade' && r>185 && g>=r && b>g+4) data[i+3]=0;
  }
  ctx.putImageData(pixels,0,0);
  cache.set(image,canvas);
  return canvas;
}

// The gauntlet wraps the actual knuckles in the monk's hand-painted sheets.
// Coordinates are taken before the sprite's anchor and 1.5x display scale.
const monkHand: Record<string, readonly (readonly [number,number])[]> = {
  idle:[[42,63],[43,63],[42,62],[42,62],[41,63],[42,63]],
  attack1:[[35,64],[53,59],[55,59],[55,59],[44,63],[42,63]],
  attack2:[[31,65],[51,59],[51,59],[46,65],[56,60],[56,60],[44,63],[42,63]],
  attack3:[[34,69],[30,64],[30,56],[29,56],[29,56],[43,52],[59,62],[59,62],[59,62],[59,62],[59,62],[44,63],[42,63]],
  run:[[32,66],[24,63],[21,58],[27,64],[38,69],[42,62],[43,58],[40,65]],
  jump:[[40,68],[40,68],[40,68]], fall:[[42,56],[42,56],[42,56]],
};

type Socket = readonly [number, number];
type ClipFrame = readonly [clip:string,frame:number];
type SocketTable = Record<string, readonly Socket[]>;
// Source-space hand sockets measured in the native sheets. Locomotion,
// casting and follow-through all move the weapon with the painted hand.
const sockets: Record<keyof typeof kit, SocketTable> = {
  monk:monkHand,
  staff:{
    idle:[[85,60],[85,60],[87,61],[87,61],[87,61],[87,61],[85,60],[85,60],[85,60],[85,60]],
    run:[[85,65],[85,67],[83,67],[79,67],[78,67],[78,68],[82,69],[83,68]],
    jump:[[87,56]],fall:[[82,59]],hurt:[[74,58],[80,59],[84,60]],
    attack1:[[82,59],[58,44],[57,44],[79,49],[92,56],[87,60],[85,60]],
    attack2:[[85,60],[82,59],[76,54],[58,44],[57,44],[57,44],[57,44],[79,49],[93,55],[92,56],[87,60],[87,60],[85,60]],
  },
  spear:{
    idle:[[77,73],[77,74],[77,75],[77,76],[77,76],[77,75],[77,73],[77,73]],
    run:[[80,79],[79,78],[80,79],[81,80],[82,79],[82,78],[81,79],[80,79]],
    jump:[[78,71]],fall:[[82,64]],hurt:[[78,72],[79,73],[80,75]],
    attack3:[[77,79],[78,82],[80,80],[71,57],[70,57],[68,57],[94,74]],
  },
  blade:{
    idle:[[78,81],[78,82],[78,82],[78,84],[79,84],[79,84],[79,83],[79,83],[79,82],[78,81]],
    run:[[77,72],[77,75],[76,76],[76,72],[80,73],[81,74],[80,76],[79,75]],
    jump:[[77,72]],fall:[[77,71]],hurt:[[72,81],[73,81],[76,80]],
    attack1:[[71,80]],attack3:[[49,55],[58,50],[61,46],[55,57],[86,62],[105,89],[102,87],[100,86]],
  },
};

// Four authored poses per action: anticipation, contact, follow-through, settle.
// These choices use the whole pose (feet, torso, sleeves and head) at each beat.
const gestures: Partial<Record<WeaponId, readonly [ClipFrame,ClipFrame,ClipFrame,ClipFrame]>> = {
  willowSword:[['attack1',0],['attack3',7],['attack3',7],['idle',0]],
  swallowDart:[['attack1',0],['run',0],['run',1],['idle',0]],
  frostStaff:[['attack1',1],['attack1',4],['attack1',5],['idle',0]],
  moonMirror:[['attack2',2],['attack2',8],['attack1',5],['idle',0]],
  reedJavelin:[['attack3',3],['attack3',6],['attack3',6],['idle',0]],
  halberd:[['attack3',4],['attack3',2],['attack3',1],['idle',0]],
  spear:[['attack3',1],['attack3',2],['run',1],['idle',0]],
  prayerBeads:[['attack1',0],['attack2',1],['attack2',3],['idle',0]],
};

export function drawCoopHero(ctx: CanvasRenderingContext2D, role: CoopCharacterId, hero: Hero, now: number, awakened: boolean) {
  if (role === 'wheel' || role === 'traveller') {
    const drawn = drawArtHero(ctx, hero, now, 1, awakened, role === 'wheel' ? 'jade' : 'classic');
    if (drawn && role === 'traveller') drawArtSlash(ctx, hero, now);
    return drawn;
  }
  const style = kit[role], timer = hero.attackTimer, step = Math.max(1, hero.attackStep);
  const variant = isVariantWeapon(hero.weapon);
  const {archetype}=WEAPONS[hero.weapon];
  const useAttackSheet = !variant || archetype==='fist';
  const progress = attackProgress(hero.weapon, step, timer);
  const attacking = timer > 0;
  const gesture = gestures[hero.weapon];
  let authored: ClipFrame | undefined;
  let pose = 'idle', phase = hero.animation * 8;
  if (hero.hp <= 0) { pose = 'death'; phase = 8; }
  else if (hero.invincible > 1.07 && hero.invincible <= 1.31 && Math.abs(hero.vx) > 160) { pose = 'hurt'; phase = (1.31-hero.invincible)*10; }
  else if (attacking && gesture && progress < SHEET_RELEASE_END) {
    const beat = progress < .12 ? 0 : progress < .40 ? 1 : progress < .69 ? 2 : 3;
    authored=gesture[beat]; pose=authored[0];
  } else if (attacking && useAttackSheet && progress < SHEET_RELEASE_END) { pose = `attack${role === 'staff' ? (step === 3 ? 2 : 1) : step}`; }
  else if (!hero.grounded && hero.dashTimer <= 0) { pose = hero.vy < 0 ? 'jump' : 'fall'; phase = Math.abs(hero.vy) > 100 ? 0 : 1; }
  else if (Math.abs(hero.vx) > 14 || hero.dashTimer > 0) { pose = 'run'; phase = hero.animation * 13; }
  const image = artImage(`actors/${style.file}-${pose}.png`);
  if (!image) return false;
  const tile = image.naturalHeight, count = Math.floor(image.naturalWidth / tile);
  const frame = authored ? authored[1] : pose.startsWith('attack') ? attackSheetFrame(progress, style.contact[step-1], count)
    : pose === 'death' ? count - 1 : Math.floor(Math.max(0, phase)) % count;
  const tint = COOP_CHARACTERS[role].color;
  ctx.save();
  ctx.translate(Math.round(hero.x+hero.w/2), Math.round(hero.y+hero.h));
  ctx.fillStyle = '#08171890';
  ctx.beginPath(); ctx.ellipse(0, 2, 15, 3, 0, 0, TAU); ctx.fill();
  if (awakened || hero.guardTimer > 0) {
    ctx.strokeStyle = tint; ctx.lineWidth = 1.5; ctx.globalAlpha *= .72;
    ctx.beginPath(); ctx.arc(0,-26,30, now*.85, now*.85+5.25); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  ctx.scale(hero.facing, 1);
  if (hero.invincible > 0 && Math.floor(now * 13) % 2 === 0) ctx.globalAlpha = .66;
  if (hero.hp <= 0) ctx.globalAlpha = .67;
  ctx.imageSmoothingEnabled = false;
  const wrist = variant ? rangedWeaponPose(hero, now) : null;
  if (authored && wrist) ctx.transform(1,0,wrist.lean*.42,1,0,0);
  const {scale} = style;
  const cast=role==='staff' && !variant && pose.startsWith('attack');
  const art=cast ? costumeLayer(image,'staff',pose,true) : variant && role!=='monk' ? costumeLayer(image,role,pose) : image;
  const handTrack=sockets[role][pose] ?? sockets[role].idle;
  const hand=hero.weapon==='swallowDart' && authored && pose==='run' ? [92,frame===0?68:71]
    : handTrack[frame] ?? handTrack[0];
  // Beads use the monk's open-hand strike, with the baked dust sliced off at the sleeve.
  const width=hero.weapon==='prayerBeads' && pose.startsWith('attack') ? hand[0]+3 : tile;
  ctx.drawImage(art, frame * tile,0,width,tile,-style.anchorX*scale,-style.anchorY*scale,width*scale,tile*scale);
  ctx.filter = 'none';
  if (wrist && hero.hp>0) {
    const grip = {x:(hand[0]-style.anchorX)*scale,y:(hand[1]-style.anchorY)*scale};
    drawHeldVariant(ctx,hero,grip,wrist.staffAngle,progress);
  }
  if (attacking && hero.hp > 0) {
    if (role === 'blade' && hero.weapon === 'blade') drawWillowCut(ctx, step, progress);
    if (role === 'staff' && hero.weapon === 'ember') drawMoonfireCast(ctx, step, progress);
  }
  if (attacking && hero.hp>0 && hero.weapon==='ironGauntlet') drawTigerGauntlet(ctx,step,progress);
  if (attacking && hero.hp>0 && hero.weapon==='fist') drawMountainPunch(ctx,step,progress);
  if (attacking && hero.hp>0 && hero.weapon==='spear') drawSpearThrust(ctx,step,progress);
  ctx.restore(); return true;
}

export function drawTravellerBadge(ctx: CanvasRenderingContext2D, p: PartyTraveller, hero: Hero, local: boolean) {
  if (!p.role) return;
  const character = COOP_CHARACTERS[p.role], y = Math.round(hero.y) - (p.role === 'staff' ? 20 : character.gender === '女' ? 24 : 14);
  const x = Math.round(hero.x+hero.w/2);
  ctx.save(); ctx.font = '10px sans-serif'; ctx.textAlign = 'center';
  const label = hero.hp > 0 ? (local ? `${character.name} · 你` : character.name) : p.aid > 0 ? '救援中' : '倒地';
  const size = Math.ceil(ctx.measureText(label).width) + 12;
  ctx.fillStyle = '#0c2526e8'; ctx.fillRect(x-size/2,y-12,size,15);
  ctx.fillStyle = character.color; ctx.fillRect(x-size/2,y+2,size,1);
  ctx.fillText(label,x,y-1);
  if (p.aid > 0) { ctx.fillStyle = '#f6d38d'; ctx.fillRect(x-size/2,y+3,size*Math.min(1,p.aid/1.15),2); }
  ctx.restore();
}
