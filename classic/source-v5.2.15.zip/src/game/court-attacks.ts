import type { Enemy, Projectile, Rect } from './types';

export const QUAKE_SPEED = 235;
export const QUAKE_LIFE = 1.12;
export const CLEAVE_LIFE = .24;

export function quakeOrigin(e: Enemy, side: number): Rect {
  const center = e.x + e.w / 2;
  return { x: side < 0 ? center - 28 : center, y: e.y + e.h - 22, w: 28, h: 22 };
}

export function judgmentArea(e: Enemy): Rect {
  const center = e.targetX ?? e.x + e.w / 2;
  return { x: center - 30, y: e.y + e.h - 154, w: 60, h: 154 };
}

export function emitCourtAttack(e: Enemy, nextId: () => number): Projectile[] {
  const common = { owner: 'enemy' as const, vy: 0, damage: 2 };
  if (e.variant === 'court-vanguard') {
    return [-1, 1].map(side => ({ ...common, ...quakeOrigin(e, side), id: nextId(), kind: 'shockwave',
      style: 'court-quake', vx: side * QUAKE_SPEED, life: QUAKE_LIFE, hitIds: [] }));
  }
  return [{ ...common, ...judgmentArea(e), id: nextId(), kind: 'rift', style: 'court-cleave',
    vx: 0, life: CLEAVE_LIFE, hitIds: [] }];
}
