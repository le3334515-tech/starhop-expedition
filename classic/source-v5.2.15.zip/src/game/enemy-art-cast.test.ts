import { describe, expect, it, vi } from 'vitest';
import { drawRegionalEnemy } from './enemy-art';
import { REGIONAL_ENEMIES } from './enemy-catalog';
import type { Enemy } from './types';

vi.mock('./art-assets',()=>({artImage:(path:string)=>({width:path.includes('duelist') ? 800 : 1200})}));

function sourceRect(id:string, phase:'windup'|'attack', time:number) {
  const profile=REGIONAL_ENEMIES[id];
  const e:Enemy={id:3,variant:id,hp:3,maxHp:3,w:32,h:profile.height,x:100,y:400,dead:false,
    originX:100,originY:400,vx:0,vy:0,hurt:0,timer:time,kind:'sentry',facing:1,attackCooldown:2,
    aiMode:phase,aiTimer:.01,attackCue:{x:116,y:420,facing:1,angle:.1,duration:.32,at:time-.08}};
  const drawImage=vi.fn();
  const ctx=new Proxy({drawImage},{get:(o,k)=>Reflect.get(o,k)??(()=>{})}) as unknown as CanvasRenderingContext2D;
  expect(drawRegionalEnemy(ctx,e,time)).toBe(true);
  return drawImage.mock.calls[0].slice(1,5);
}

describe('regional enemy cast sheets',()=>{
  it.each(['crypt-wraith','tide-mage','astral-seer','lantern-scribe','forge-smith','lantern-seer'])(
    '%s keeps the caster hand and leaves the orange source missile out of both phases',id=>{
      for(const phase of ['windup','attack'] as const) expect(sourceRect(id,phase,1)[2]).toBe(86);
    });
  it.each(['gale-duelist','crypt-keeper','astral-duelist'])(
    '%s keeps the full baked white slash out of windup and body-contact poses',id=>{
      for(const time of [1,2.23]) {
        expect(sourceRect(id,'windup',time)[0]).toBe(200);
        expect(sourceRect(id,'attack',time)[0]).toBe(600);
      }
    });
});
