import { artImage } from './art-assets';
import { drawTintedSprite } from './sprite-tints';
import type { Enemy } from './types';
import { enemyProfile, isCourtElite } from './enemy-catalog';
import { drawCourtElite } from './court-elite-art';
import { drawCoopEnemy } from './coop-enemy-art';

const TAU = Math.PI * 2;
const pixel = (c: CanvasRenderingContext2D, x: number, y: number, w = 2, h = w) => c.fillRect(Math.round(x), Math.round(y), w, h);
const BODY = {
  mushroom: { size: 150, anchorX: 75, anchorY: 101, bodyHeight: 37 },
  eye: { size: 150, anchorX: 75, anchorY: 101, bodyHeight: 29 },
  skeleton: { size: 150, anchorX: 75, anchorY: 101, bodyHeight: 51 },
  goblin: { size: 150, anchorX: 75, anchorY: 101, bodyHeight: 36 },
  wizard: { size: 150, anchorX: 75, anchorY: 100, bodyHeight: 55 },
  duelist: { size: 200, anchorX: 100, anchorY: 128, bodyHeight: 56 },
} as const;

/** Newly sourced CC0 sheets share the original LuizMelo pixel-art family. */
export function drawRegionalEnemy(c: CanvasRenderingContext2D, e: Enemy, now: number, reuse = false): boolean {
  const profile = enemyProfile(e); if (!profile) return false;
  if (isCourtElite(e) && drawCourtElite(c, e, profile, reuse)) return true;
  if (profile.appearance && drawCoopEnemy(c, e, profile.appearance)) {
    return true;
  }
  const skin = profile.skin, body = BODY[skin];
  const locomotion = skin === 'eye' ? 'flight' : Math.abs(e.vx)>8 ? (skin==='skeleton' ? 'walk' : 'run') : 'idle';
  let action = locomotion;
  const winding=e.aiMode==='windup', attacking=e.aiMode==='attack';
  const cue=e.attackCue, age=cue ? Math.max(0,e.timer-cue.at) : 0;
  if (winding || attacking) action='attack';
  // A shove and a dash cause body contact. Their source attack sheets also
  // contain 80px-wide baked sword flashes that would announce a fictitious hit.
  if (profile.ability==='guard' && e.aiMode!=='recover') action='shield';
  if (attacking && age>.11 && (profile.ability==='rush' || profile.ability==='blink')) action=locomotion;
  if (e.hurt > .06) action = 'hurt';
  const image = artImage(`actors/${skin}-${action}.png`); if (!image) return false;
  const frames = Math.max(1, Math.floor(image.width / body.size));
  let frame = Math.floor(e.timer * (action === 'idle' ? 7 : 10) + e.id) % frames;
  if (winding && (action==='attack' || action==='shield')) {
    const wind=1-Math.min(1,(e.aiTimer??0)/profile.warning);
    // Duelist frame 2 is already the full white slash. Frames 0–1 draw back.
    const last=skin==='duelist' ? 1 : 2;
    frame=Math.min(last,Math.floor(wind*(last+1)),frames-1);
  } else if(attacking && action==='shield') frame=frames-1;
  else if(attacking && action==='attack') {
    // Use the actual release on every client. Keep broad baked slashes out
    // of projectile casts and body-contact moves; existing sprite sockets and
    // the synchronized enemy VFX now show the true weapon/direction.
    const release=skin==='duelist' ? 3 : skin==='skeleton'||skin==='goblin' ? 5
      : skin==='wizard' ? 2+Number(age>.10) : 6+Number(age>.10);
    frame=Math.min(frames-1,release);
  }
  const x = Math.round(e.x + e.w / 2), foot = Math.round(e.y + e.h);
  c.save();
  if (e.kind !== 'bat') {
    c.globalAlpha = .2; c.fillStyle = '#102622'; c.beginPath(); c.ellipse(x, foot, 16, 3, 0, 0, TAU); c.fill(); c.globalAlpha = 1;
  }
  if (e.kind === 'bat' && skin === 'wizard') {
    c.strokeStyle = `${profile.color}88`; c.lineWidth = 1;
    c.beginPath(); c.ellipse(x, foot + 3, 17, 4, 0, 0, TAU); c.stroke();
    c.fillStyle = profile.color;
    for (let i = 0; i < 3; i++) { const t = (now * .6 + i / 3) % 1; c.globalAlpha = (1 - t) * .6; pixel(c, x - 11 + i * 10, foot + t * 17, 2, 3); }
    c.globalAlpha = 1;
  }
  c.translate(x, foot); c.scale(e.facing || 1, 1);
  const scale = e.h / body.bodyHeight;
  if (skin === 'eye') c.translate(0, 8 * scale);
  let filter = '';
  if (e.hurt > .06) filter = 'brightness(2.7) saturate(.4)';
  else if (e.variant?.startsWith('tide-')) filter = 'hue-rotate(90deg) saturate(.65)';
  else if (e.variant?.startsWith('crypt-')) filter = 'saturate(.55) brightness(.85)';
  else if (e.variant === 'forge-cinder' || e.variant === 'forge-bulwark') filter = 'sepia(.7) saturate(1.6)';
  c.imageSmoothingEnabled = false;
  // All four wizard cast poses keep the coat, crown and outstretched hand in
  // columns 59–85. The source's detached orange fireball starts at 85/86.
  // The regional effect and actual projectile supply the appropriate spell.
  const width = skin==='wizard' && action==='attack' ? 86 : body.size;
  drawTintedSprite(c, image, frame * body.size, width, body.size,
    -body.anchorX * scale, -body.anchorY * scale, width * scale, body.size * scale, filter, reuse && width === body.size);
  // A small regional sign supplements a genuinely different sprite/pose, not a recolor substitute.
  c.fillStyle = profile.color; c.globalAlpha = .72;
  if (profile.ability === 'needle') {
    c.strokeStyle = profile.color; c.lineWidth = 2;
    c.beginPath(); c.moveTo(12, -31); c.lineTo(21, -23); c.lineTo(14, -14); c.stroke();
    pixel(c, 10, -24, 16, 2);
  }
  if (profile.ability === 'groundwave') {
    pixel(c, 15, -25, 3, 15); pixel(c, 12, -27, 10, 5); pixel(c, 11, -13, 10, 4);
  }
  if (profile.ability === 'starfall') {
    pixel(c, 15, -38, 2, 26); pixel(c, 12, -40, 8, 7); c.fillStyle = '#f1d4a0'; pixel(c, 15, -39, 2, 4);
  }
  if (profile.ability === 'bomb') { pixel(c, 17, -16, 5, 5); pixel(c, 19, -20, 2, 3); }
  if (profile.ability === 'guard' && e.aiMode !== 'attack' && e.aiMode !== 'recover') {
    c.strokeStyle = '#dfd7b3'; c.lineWidth = 2; c.beginPath(); c.moveTo(19, -37); c.lineTo(26, -31); c.lineTo(25, -15); c.lineTo(19, -9); c.lineTo(13, -15); c.lineTo(12, -31); c.closePath(); c.stroke();
  }
  if (profile.ability === 'rift' || profile.ability === 'hex') {
    c.strokeStyle = profile.color; c.lineWidth = 1;
    c.beginPath(); c.arc(0, -e.h * .52, 23, now * .6, now * .6 + 4.8); c.stroke();
  }
  if (profile.ability === 'tide' || profile.ability === 'orbit') {
    c.strokeStyle = '#b0decb'; c.lineWidth = 1;
    c.beginPath(); c.ellipse(0, 2, 20, 4, 0, 0, TAU); c.stroke();
  }
  if (profile.ability === 'blink') {
    for (let i = 0; i < 3; i++) { c.fillStyle = profile.color; pixel(c, -18 - i * 4, -e.h + 8 + i * 7, 3, 1); }
  }
  c.restore();
  if ((e.emberMark ?? 0) > 0) {
    const y = e.y - 19 + Math.sin(now * 6) * 2;
    c.save();
    c.fillStyle = '#552b30'; pixel(c, x - 5, y - 3, 10, 8);
    c.fillStyle = '#eda275'; pixel(c, x - 1, y - 5, 2, 12); pixel(c, x - 4, y - 1, 8, 5);
    c.fillStyle = '#ffe7a8'; pixel(c, x - 1, y, 2, 3);
    c.restore();
  }
  return true;
}
