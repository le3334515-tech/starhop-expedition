import { describe, expect, it } from 'vitest';
import { drawEnemyMeleeVfx } from './enemy-melee-vfx';
import type { Enemy } from './types';

function enemy(variant: string, overrides: Partial<Enemy> = {}): Enemy {
  return {id:5,variant,kind:'sentry',x:130,y:350,w:32,h:36,hp:3,maxHp:3,dead:false,
    timer:4,hurt:0,originX:130,originY:350,vx:0,vy:0,facing:1,attackCooldown:1,
    aiMode:'windup',aiTimer:.25,targetX:201,targetY:396,...overrides};
}

function pen() {
  const rotations:number[]=[],translations:number[][]=[],marks:number[][]=[];
  const xy=(...point:number[])=>marks.push(point);
  const ctx={globalAlpha:1,save(){},restore(){},scale(){},translate(x:number,y:number){translations.push([x,y]);},
    rotate(angle:number){rotations.push(angle);},beginPath(){},closePath(){},fill(){},stroke(){},
    moveTo:xy,lineTo:xy,fillRect:xy} as unknown as CanvasRenderingContext2D;
  return {ctx,rotations,translations,marks};
}

describe('regional melee accents',()=>{
  it.each(['bamboo-sprout','bamboo-moth','gale-wing','moonbridge-kite','lantern-raider',
    'gale-duelist','crypt-bulwark','forge-bulwark','skyforge-crab','astral-duelist','crypt-keeper','tide-shell'])(
    'renders the windup and release of %s from a snapshot without mutating it',variant=>{
      for(const aiMode of ['windup','attack'] as const) for(const reduced of [false,true]) {
        const e=enemy(variant,{aiMode,vx:132,vy:85,
          attackCue:{at:3.85,x:116,y:358,angle:.07,duration:.45,facing:1}});
        const copy=structuredClone(e),brush=pen();
        expect(drawEnemyMeleeVfx(brush.ctx,e,reduced)).toBe(true);
        expect(brush.marks.length).toBeGreaterThan(3);
        expect(brush.marks.flat().every(Number.isFinite)).toBe(true);
        expect(e).toEqual(copy);
      }
    });
  it('points diving tells at the locked target, then orients the wake to the velocity',()=>{
    const e=enemy('bamboo-moth',{vx:-46,vy:152}), wind=pen(),strike=pen();
    drawEnemyMeleeVfx(wind.ctx,e);
    expect(wind.rotations[0]).toBeCloseTo(Math.atan2(396-368,201-146));
    e.aiMode='attack'; drawEnemyMeleeVfx(strike.ctx,e);
    expect(strike.rotations[0]).toBeCloseTo(Math.atan2(152,-46));
  });
  it('anchors the ground-wave accent at the real release on the floor, even for an elevated caster',()=>{
    const e=enemy('crypt-keeper',{aiMode:'attack',facing:-1,attackCue:{x:148,y:368,facing:-1,angle:3.14,duration:.32,at:3.88}});
    const p=pen(); drawEnemyMeleeVfx(p.ctx,e);
    const [[x,y],[localX,localY]]=p.translations;
    expect(x-localX).toBe(152); expect(y+localY).toBe(448);
  });
  it('reserves battle effects for active melee enemies',()=>{
    for(const e of [enemy('bamboo-warden'),enemy('court-executioner'),enemy('bamboo-sprout',{dead:true}),
      enemy('bamboo-sprout',{aiMode:'recover'}),enemy('bamboo-sprout',{aiMode:'patrol'})]){
      const p=pen(); expect(drawEnemyMeleeVfx(p.ctx,e)).toBe(false); expect(p.marks).toHaveLength(0);
    }
  });
});
