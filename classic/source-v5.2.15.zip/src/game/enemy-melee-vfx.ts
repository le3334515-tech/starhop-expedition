import { enemyProfile } from './enemy-catalog';
import type { Enemy } from './types';

type Ink = CanvasRenderingContext2D;
type Point = readonly [number, number];
const clamp = (n: number, hi = 1) => Math.max(0, Math.min(hi, n));
const ivory = '#ece0bb';

function line(c: Ink, color: string, width: number, points: readonly Point[]) {
  c.strokeStyle = color; c.lineWidth = width;
  c.beginPath(); c.moveTo(Math.round(points[0][0]), Math.round(points[0][1]));
  for (let i=1;i<points.length;i++) c.lineTo(Math.round(points[i][0]),Math.round(points[i][1]));
  c.stroke();
}

function blade(c: Ink, color: string, a: Point, b: Point, edge: Point) {
  c.fillStyle = color; c.beginPath();
  c.moveTo(Math.round(a[0]),Math.round(a[1])); c.lineTo(Math.round(b[0]),Math.round(b[1]));
  c.lineTo(Math.round(edge[0]),Math.round(edge[1])); c.closePath(); c.fill();
}

function leaf(c: Ink, x: number, y: number, length: number, color: string) {
  c.fillStyle=color; x=Math.round(x); y=Math.round(y);
  c.fillRect(x,y,length-2,2); c.fillRect(x+2,y-2,length-3,2); c.fillRect(x+length-2,y-4,2,2);
}

// Scoped to ambient enemies. Elite priority tells and both bosses use their own artwork.
const abilities = new Set(['hop','dive','rush','leap','guard','blink','groundwave']);

/** Draw in world coordinates behind the enemy. The brushwork at the front stays
 * on the moving body. Everything behind the body is a wake, never a hit region. */
export function drawEnemyMeleeVfx(c: Ink, e: Enemy, reducedMotion = false): boolean {
  const profile=enemyProfile(e);
  if (!profile || !abilities.has(profile.ability) || e.dead || e.hp<=0 ||
      (e.aiMode!=='windup' && e.aiMode!=='attack')) return false;

  const wind=e.aiMode==='windup', cue=wind ? undefined : e.attackCue;
  const progress=wind ? clamp(1-(e.aiTimer??0)/profile.warning)
    : cue ? clamp((e.timer-cue.at)/Math.max(.01,cue.duration)) : .34;
  const cx=e.x+e.w/2, cy=e.y+e.h/2, side=(cue?.facing ?? e.facing) || 1;
  const foot=e.h/2, edge=e.w/2;
  const moved=cue ? Math.hypot(cx-cue.x,cy-cue.y) : Math.hypot(e.vx,e.vy)*.07;
  const tail=clamp(moved,reducedMotion ? 11 : 35);
  const t=reducedMotion ? .55 : progress;
  const tint=profile.color;
  c.save(); c.translate(Math.round(cx),Math.round(cy));
  c.lineCap='butt'; c.lineJoin='bevel';
  c.globalAlpha *= wind ? .62+.35*progress : .93-.31*progress;

  if (profile.ability==='dive') {
    // A dive follows an actual 2D vector. A recovering/knocked-back enemy
    // trails behind its current velocity, even when it crosses the locked aim.
    const locked=e.targetX!==undefined && e.targetY!==undefined
      ? Math.atan2(e.targetY-cy,e.targetX-cx) : side>0 ? 0 : Math.PI;
    const angle=wind ? locked : Math.hypot(e.vx,e.vy)>1 ? Math.atan2(e.vy,e.vx) : cue?.angle ?? locked;
    c.rotate(angle);
    const rim=Math.min(edge,foot);
    if (wind) {
      for (const sign of [-1,1]) {
        line(c,tint,2,[[0,sign*(rim+5-t*3)],[6,sign*(rim+3-t*3)],[rim-1,sign*(rim-2-t*4)]]);
      }
      line(c,ivory,2,[[rim+2,-3],[rim+5,0],[rim+2,3]]);
    } else {
      // Copper quills on the kite, swept forks on the gale eye, bamboo leaves on the moth.
      for (const sign of [-1,1]) {
        const y=sign*rim*.72;
        if (e.variant==='moonbridge-kite') {
          blade(c,'#b29b73',[-rim-tail,y+sign*2],[-rim+6,y-sign*3],[-rim+1,y+sign*2]);
          line(c,tint,1.5,[[-rim-tail*.65,y],[-rim+3,y-sign*2]]);
        } else if (e.variant==='gale-wing') {
          line(c,tint,2,[[-rim-tail,y+sign*3],[-rim-3,y+sign*3],[-rim+5,y]]);
          if(!reducedMotion) line(c,ivory,1,[[-rim-tail*.75,y+sign*6],[-rim+1,y+sign*5]]);
        } else leaf(c,-rim-tail*.90,y,Math.max(5,tail*.58),'#a6c4a8');
      }
    }
    c.restore(); return true;
  }

  c.scale(side,1);
  switch (profile.ability) {
    case 'hop': {
      // Spore motes tuck beneath the cap, then shed along the mushroom's actual arc.
      const n=reducedMotion ? 2 : 4;
      for(let i=0;i<n;i++) {
        const sign=i%2 ? 1 : -1;
        const x=wind ? sign*(edge+7-t*6+i) : -edge-tail*(.25+i*.2);
        const y=wind ? foot-3-i*3-t*2 : clamp(-e.vy*.045,12)-i*3+foot*.45;
        leaf(c,x,y,i%2 ? 6 : 8,i%2 ? tint : '#7d9d7b');
      }
      if(wind) line(c,ivory,1.5,[[-7,-foot-2],[0,-foot-4-t*2],[7,-foot-2]]);
      break;
    }
    case 'rush': {
      if(wind) {
        // Woven red sash folds into two sharp pleats as the raider lowers its shoulder.
        const fold=4+t*5;
        line(c,'#b96f54',3,[[-edge-8,-6],[-edge,0],[-edge-fold,3],[-edge+3,9]]);
        line(c,ivory,1.5,[[edge-4,0],[edge+1,2],[edge-1,7]]);
      } else {
        blade(c,'#984e47',[-edge-tail,-4],[-edge+5,-6],[-edge+1,1]);
        line(c,'#d79a6e',2,[[-edge-tail*.83,2],[-edge-3,1],[-edge+4,-3]]);
        if(!reducedMotion) line(c,'#b66e50',2,[[-edge-tail*.62,foot-2],[-edge,foot-4]]);
      }
      break;
    }
    case 'leap': {
      const lift=wind ? 3+t*4 : 0;
      if(wind) {
        line(c,'#94b2a0',2.5,[[-edge-9,foot-2],[-edge-2,foot-3],[-edge+3,foot-7]]);
        blade(c,tint,[edge-3,-foot+9],[edge+4,-foot-lift],[edge+4,-foot+5]);
        line(c,ivory,1.5,[[edge,-foot+3],[edge+4,-foot-4]]);
      } else {
        // Only the knife's edge glints. The wind ribbons follow the actual jump tangent.
        const rise=clamp(Math.abs(e.vy)*.045,12)*Math.sign(-e.vy);
        line(c,'#87ab9c',2,[[-edge-tail,4+rise],[-edge-3,4],[-edge+3,1]]);
        if(!reducedMotion) line(c,tint,1.5,[[-edge-tail*.67,9+rise],[-edge+1,8]]);
        blade(c,ivory,[edge-3,-6],[edge+2,-1],[edge-2,5]);
      }
      break;
    }
    case 'guard': {
      // The front shield flares on impact. The forge guard's hot rivets and
      // the crypt guard's bronze bell rim use the same short beat.
      const shield=edge-1, forge=e.variant==='forge-bulwark'||e.variant==='skyforge-crab';
      const shade=forge ? '#955e49' : '#867a58';
      const rim: Point[]=[[shield-5,-foot+7],[shield+3,-foot+12],[shield+3,7],[shield-4,foot-4]];
      line(c,shade,4,rim); line(c,tint,1.6,rim);
      if(wind) {
        c.fillStyle=ivory;
        const pin=Math.round(-foot+9+t*(foot-3));
        c.fillRect(Math.round(shield+2),pin,3,3);
      } else {
        const recoil=1-t;
        for(const sign of [-1,1]) {
          const y=sign*(5+recoil*4);
          line(c,tint,2,[[shield+1,y],[shield+4,y+sign*3]]);
        }
        if(!reducedMotion) leaf(c,-edge-tail*.67,foot-1,7,shade);
      }
      break;
    }
    case 'blink': {
      if(wind) {
        const d=7-4*t;
        for(const sign of [-1,1]) line(c,tint,1.6,[[sign*(edge+d),-6],[sign*(edge+d-3),-1],[sign*(edge+d),4]]);
        c.fillStyle=ivory; c.fillRect(Math.round(edge-2),-5,2,5);
      } else {
        // Interrupted star-script afterimages end behind the actual sword arm.
        const n=reducedMotion ? 1 : 3;
        for (let i=0;i<n;i++) {
          const x=-edge-tail*(i+1)/(n+1), y=-foot+6+i*3;
          line(c,i ? '#a68d68' : tint,2,[[x+3,y],[x,y+5],[x,y+10]]);
          line(c,i ? '#897e63' : tint,1.5,[[x,foot-7],[x-3,foot-3]]);
        }
        line(c,ivory,1.5,[[edge-3,-4],[edge+1,-1],[edge-1,3]]);
      }
      break;
    }
    case 'groundwave': {
      // Both current waves spawn in the floor lane at y=448. Anchor the
      // vibration to that lane even when the caster stands on a higher platform.
      const sink=448-Math.round(cy), tide=e.variant==='tide-shell';
      // shoot() starts a 16px shot at center-8, then sets its width to 24px.
      const origin=wind ? 4*side : ((cue?.x??cx)+4-Math.round(cx))*side;
      c.translate(Math.round(origin),sink);
      if(wind) {
        const gather=9-t*5;
        for(let i=0;i<(reducedMotion ? 2 : 3);i++) {
          const x=edge*.60+i*gather;
          line(c,tide ? '#5b897f' : '#806b50',3,[[x,-2],[x+3,-6],[x+7,-2]]);
          line(c,tint,1.5,[[x,-3],[x+3,-6],[x+7,-3]]);
        }
      } else {
        const wave=edge*.76+17*t;
        if(tide) {
          line(c,'#84baaf',2,[[-4,-2],[1,-5],[6,-5],[9,-2],[wave+4,-2]]);
          if(!reducedMotion) leaf(c,3,-6-t*4,6,ivory);
        } else {
          for(const sign of [-1,1]) {
            line(c,tint,2,[[sign*3,-3],[sign*(wave*.6),-5],[sign*wave,-4]]);
            c.fillStyle='#96815e'; c.fillRect(Math.round(sign*wave),-2,3,2);
          }
        }
      }
      break;
    }
  }
  c.restore();
  return true;
}
