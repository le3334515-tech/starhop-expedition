import { describe, expect, it } from 'vitest';
import { BOSS_AWAKENED_HP, BOSS_MAX_HP, BOSS_TRANSFORM_TIME, GameEngine, UPGRADES } from './engine';
import { BOSS_ASCENSION_TIME, ECLIPSE_WIDTH, eclipseLanes } from './boss-seal';
import { createRoom, createThemedRoom, expeditionOrder } from './levels';
import { EMPTY_INPUT, EXPEDITION_ROOM_COUNT, getCharacterWeapons, type CharacterId, type Enemy, type GameConfig, type InputState, type WeaponId } from './types';

const CONFIG: GameConfig = { seed: 20261116, modifier: 'standard', weapon: 'blade' };
const input = (patch: Partial<InputState> = {}): InputState => ({ ...EMPTY_INPUT, ...patch });
function advance(engine: GameEngine, seconds: number, keys: Partial<InputState> = {}) {
  const frames = Math.ceil(seconds * 120);
  for (let n = 0; n < frames; n++) engine.update(seconds / frames, input({ ...keys, jumpPressed: n === 0 && !!keys.jumpPressed, dashPressed: n === 0 && !!keys.dashPressed, attackPressed: n === 0 && !!keys.attackPressed }));
}
function enemy(x = 360, hp = 2): Enemy {
  return { id: 71, kind: 'sentry', x, y: 406, w: 32, h: 42, vx: 0, vy: 0, hp, maxHp: hp,
    facing: -1, timer: 0, hurt: 0, dead: false, originX: x, originY: 406, attackCooldown: 99 };
}
function arena(weapon: WeaponId = 'blade') {
  const game = new GameEngine();
  game.start({ ...CONFIG, weapon });
  const s = game.state;
  s.room.platforms = [{ x: 0, y: 448, w: s.room.width, h: 120, kind: 'ground' }];
  s.room.hazards = [];
  s.pickups = [];
  s.enemies = [enemy(1800, 100)];
  s.hero.x = 300; s.hero.y = 412; s.hero.grounded = true;
  return game;
}
function settleUpgrades(game: GameEngine) {
  while (game.state.phase === 'upgrade') game.chooseUpgrade(game.state.upgradeChoices[0].id);
}
function grant(game: GameEngine, id: string) {
  game.state.phase = 'upgrade';
  game.state.upgradeChoices = [UPGRADES.find(upgrade => upgrade.id === id)!];
  game.chooseUpgrade(id);
}

describe('seeded expedition and controls', () => {
  it('reproduces every room, enemy and pickup for a challenge seed', () => {
    for (let index = 0; index < EXPEDITION_ROOM_COUNT; index++) expect(createRoom(44512, index)).toEqual(createRoom(44512, index));
    expect(createRoom(44512, 0).room.platforms).not.toEqual(createRoom(44513, 0).room.platforms);
  });

  it('has traversable floor gaps and a reachable exit in every room', () => {
    for (let seed = 1; seed <= 30; seed++) for (let index = 0; index < EXPEDITION_ROOM_COUNT; index++) {
      const room = createRoom(seed, index).room;
      const ground = room.platforms.filter(p => p.kind === 'ground').sort((a, b) => a.x - b.x);
      for (let n = 1; n < ground.length; n++) expect(ground[n].x - ground[n - 1].x - ground[n - 1].w).toBeLessThanOrEqual(120);
      expect(ground.some(p => room.exit.x >= p.x && room.exit.x + room.exit.w <= p.x + p.w)).toBe(true);
      expect(room.spawn.x).toBeGreaterThan(0);
    }
  });

  it('offers three distinct authored routes per act with safe enemy spawns and reachable high routes', () => {
    for (let index = 0; index < EXPEDITION_ROOM_COUNT; index++) {
      const layouts = new Set<string>();
      for (let seed = 1; seed <= 90; seed++) {
        const { room, enemies } = createThemedRoom(seed, index, index);
        layouts.add(JSON.stringify({ platforms: room.platforms, hazards: room.hazards }));
        const ground = room.platforms.filter(p => p.kind === 'ground');
        for (const e of enemies.filter(e => e.kind !== 'bat')) {
          expect(ground.some(p => e.x >= p.x && e.x + e.w <= p.x + p.w), `seed=${seed},act=${index},enemy=${e.kind}`).toBe(true);
          expect(room.hazards.some(hazard => hazard.kind === 'spikes' && e.x < hazard.x + hazard.w && e.x + e.w > hazard.x)).toBe(false);
        }
        const reached = new Set(ground);
        let changed = true;
        while (changed) {
          changed = false;
          for (const destination of room.platforms) if (!reached.has(destination)) {
            for (const origin of reached) {
              const horizontalGap = Math.max(0, destination.x - (origin.x + origin.w), origin.x - (destination.x + destination.w));
              const climb = origin.y - destination.y;
              // Below the standard double-jump envelope; moon can travel higher.
              if (climb <= 165 && horizontalGap <= 210) { reached.add(destination); changed = true; break; }
            }
          }
        }
        for (const p of room.platforms) expect(reached.has(p), `unreachable platform: seed=${seed}, act=${index}, x=${p.x}, y=${p.y}`).toBe(true);
      }
      expect(layouts.size).toBe(3);
    }
  });

  it('contains eight distinct traversable encounters and reserves the final scene for the boss', () => {
    const contents = Array.from({ length: EXPEDITION_ROOM_COUNT }, (_, index) => createRoom(CONFIG.seed, index));
    expect(contents).toHaveLength(8);
    expect(new Set(contents.map(({ room }) => room.name)).size).toBe(8);
    expect(new Set(contents.map(({ room }) => room.theme)).size).toBe(8);
    expect(new Set(contents.map(({ room }) => JSON.stringify({ platforms: room.platforms, hazards: room.hazards }))).size).toBe(8);
    expect(contents.filter(({ room }) => room.isBoss)).toHaveLength(1);
    for (const { room, enemies } of contents.slice(0, -1)) {
      expect(room.isBoss).toBe(false);
      expect(enemies.length).toBeGreaterThanOrEqual(4);
      expect(room.width).toBeGreaterThan(1800);
      expect(room.width).toBeLessThanOrEqual(2500);
    }
    expect(contents.at(-1)!.room.isBoss).toBe(true);
    expect(() => createRoom(1, EXPEDITION_ROOM_COUNT)).toThrow(RangeError);
  });

  it('moves, accelerates, stops and remains on the ground', () => {
    const game = arena();
    advance(game, .8, { right: true });
    expect(game.state.hero.x).toBeGreaterThan(470);
    expect(game.state.hero.grounded).toBe(true);
    advance(game, .4);
    expect(game.state.hero.vx).toBe(0);
    expect(game.state.hero.y + game.state.hero.h).toBe(448);
  });

  it('supports a double jump but prevents an immediate third jump', () => {
    const game = arena();
    advance(game, .2, { jumpPressed: true, jumpHeld: true });
    expect(game.state.hero.y).toBeLessThan(350);
    game.update(1 / 120, input({ jumpPressed: true, jumpHeld: true }));
    expect(game.state.hero.jumps).toBe(2);
    const secondVelocity = game.state.hero.vy;
    game.update(1 / 120, input({ jumpPressed: true, jumpHeld: true }));
    expect(game.state.hero.vy).toBeGreaterThan(secondVelocity);
  });

  it('makes a held jump higher than a tapped jump', () => {
    const held = arena(); const tapped = arena();
    advance(held, .3, { jumpPressed: true, jumpHeld: true });
    tapped.update(1 / 120, input({ jumpPressed: true, jumpHeld: true }));
    advance(tapped, .3);
    expect(held.state.hero.y).toBeLessThan(tapped.state.hero.y - 35);
  });

  it('allows a coyote jump just after leaving a ledge', () => {
    const game = arena();
    game.state.room.platforms = [{ x: 0, y: 448, w: 340, h: 100, kind: 'ground' }];
    game.state.hero.x = 338;
    advance(game, .045, { right: true });
    expect(game.state.hero.grounded).toBe(false);
    expect(game.state.hero.coyote).toBeGreaterThan(0);
    game.update(1 / 120, input({ right: true, jumpPressed: true, jumpHeld: true }));
    expect(game.state.hero.vy).toBeLessThan(-400);
    expect(game.state.hero.jumps).toBe(1);
  });

  it('buffers a jump immediately before landing', () => {
    const game = arena();
    const h = game.state.hero;
    h.y = 400; h.vy = 160; h.grounded = false; h.jumps = 2;
    advance(game, .09, { jumpPressed: true, jumpHeld: true });
    expect(h.vy).toBeLessThan(0);
    expect(h.grounded).toBe(false);
  });

  it('dashes quickly, blocks contact damage and enforces cooldown', () => {
    const game = arena();
    game.state.enemies = [enemy(345, 100)];
    const hp = game.state.hero.hp;
    advance(game, .15, { right: true, dashPressed: true });
    expect(game.state.hero.x).toBeGreaterThan(370);
    expect(game.state.hero.hp).toBe(hp);
    const cooldown = game.state.hero.dashCooldown;
    game.update(1 / 120, input({ dashPressed: true }));
    expect(game.state.hero.dashCooldown).toBeLessThan(cooldown);
  });

  it.each(['standard', 'haste', 'moon'] as const)('shortens actual dash travel while retaining the invulnerability window in %s', modifier => {
    const game = arena();
    game.state.modifier = modifier;
    const h = game.state.hero;
    const startX = h.x;
    advance(game, .18, { dashPressed: true, right: true });
    const displacement = h.x - startX;
    // Previously .18 s at 670 px/s = 120.6 px; the shorter step travels about 93.6 px.
    expect(displacement).toBeCloseTo(93.6, 3);
    expect(displacement).toBeGreaterThan(90);
    expect(displacement).toBeLessThan(99);
    expect(displacement / 120.6).toBeLessThan(.82);
    expect(h.invincible).toBeGreaterThan(.04);
    expect(h.dashCooldown).toBeGreaterThan(1.15);
    advance(game, .03);
    expect(h.dashTimer).toBe(0);
    expect(h.invincible).toBeGreaterThan(0);
  });

  it('fully launches from a spring after releasing jump before landing on it', () => {
    const game = arena();
    game.state.room.platforms.push({ x: 380, y: 424, w: 48, h: 24, kind: 'spring' });
    let launched = false;
    let launchY = 0;
    let peak = 448;
    for (let n = 0; n < 180; n++) {
      const h = game.state.hero;
      const right = h.x < 389;
      const wasFalling = h.vy >= 0;
      game.update(1 / 120, input({ right, jumpPressed: n === 0, jumpHeld: n < 22 }));
      // Detect a landing-to-bounce reversal; ordinary jumps can now also
      // exceed the old -650 speed threshold.
      if (!launched && wasFalling && h.vy < -650 && n > 10) { launched = true; launchY = h.y; }
      if (launched) peak = Math.min(peak, h.y);
    }
    expect(launched).toBe(true);
    expect(launchY - peak).toBeGreaterThan(170);
  });

  it('stops the simulation clock while paused and resumes it', () => {
    const game = arena();
    advance(game, .1);
    game.pause();
    const time = game.state.time; const x = game.state.hero.x;
    advance(game, 1, { right: true });
    expect(game.state.time).toBe(time);
    expect(game.state.hero.x).toBe(x);
    game.resume(); advance(game, .1, { right: true });
    expect(game.state.time).toBeGreaterThan(time);
  });
});

describe('character loadouts', () => {
  const kits: [CharacterId, WeaponId][] = [
    ['blade', 'blade'], ['staff', 'ember'], ['wheel', 'fan'],
    ['spear', 'spear'], ['traveller', 'blade'], ['monk', 'fist'],
  ];

  it.each(kits)('gives %s the %s starting weapon and its own switchable slots', (character, weapon) => {
    const game = new GameEngine();
    game.start({ ...CONFIG, character, weapon: 'fan' });
    expect(game.state.character).toBe(character);
    expect(game.state.roomCount).toBe(EXPEDITION_ROOM_COUNT);
    expect(game.state.hero.weapon).toBe(weapon);
    game.equipWeapon('sabre');
    expect(game.state.hero.weapon).toBe(weapon);
    for (const slot of getCharacterWeapons(character).slice(1)) {
      game.equipWeapon(slot);
      expect(game.state.hero.weapon).toBe(slot);
    }
  });

  it('retains a selected character and upgrades on gates, results and replay', () => {
    const game = new GameEngine();
    game.start({ ...CONFIG, character: 'wheel' });
    grant(game, 'edge');

    const { hero, room } = game.state;
    game.state.enemies = [];
    hero.x = room.exit.x;
    hero.y = room.exit.y + room.exit.h - hero.h;
    game.update(1 / 120, input({ interactPressed: true }));
    expect(game.state.roomIndex).toBe(1);
    expect(game.state.character).toBe('wheel');
    expect(game.state.hero).toMatchObject({ weapon: 'fan', upgrades: ['edge'] });

    game.state.hero.hp = 1;
    game.state.hero.invincible = 0;
    game.state.hero.y = 600;
    game.update(1 / 120, EMPTY_INPUT);
    const result = game.state.result!;
    expect(result).toMatchObject({ won: false, character: 'wheel', weapon: 'fan' });
    game.start(result);
    expect(game.state.character).toBe('wheel');
    expect(game.state.hero).toMatchObject({ weapon: 'fan', upgrades: [] });
  });

  it('keeps legacy weapon switching and restricts multiplayer seats to their own kit', () => {
    const game = new GameEngine();
    game.start({ ...CONFIG, character: 'spear' });
    game.start({ ...CONFIG, weapon: 'ember' });
    expect(game.state.character).toBeUndefined();
    game.equipWeapon('disc');
    expect(game.state.hero.weapon).toBe('disc');

    game.startCoop({ ...CONFIG, character: 'spear', weapon: 'fist' }, 2);
    expect(game.state.hero.weapon).toBe('spear');
    game.equipWeapon('reedJavelin');
    expect(game.state.hero.weapon).toBe('reedJavelin');
    game.equipWeapon('disc');
    expect(game.state.hero.weapon).toBe('reedJavelin');

    game.startCoop({ ...CONFIG, weapon: 'fist' }, 2);
    game.equipWeapon('disc');
    expect(game.state.hero.weapon).toBe('fist');
  });

  it('preserves all three classic attacks and switch timings for the red-hat traveller', () => {
    const classic = new GameEngine(), redHat = new GameEngine();
    classic.start(CONFIG);
    redHat.start({ ...CONFIG, character: 'traveller' });
    for (const weapon of ['blade', 'ember', 'disc'] as const) {
      for (const game of [classic, redHat]) {
        const h = game.state.hero;
        h.attackCooldown = 0;
        game.equipWeapon(weapon);
        game.update(1 / 120, input({ attackPressed: true, jumpPressed: true }));
      }
      expect(redHat.state.hero).toEqual(classic.state.hero);
      expect(redHat.state.projectiles).toEqual(classic.state.projectiles);
    }
  });

  it('fires a different projectile count, spread and effect when switching within a kit', () => {
    const game = new GameEngine();
    game.start({ ...CONFIG, character: 'wheel', weapon: 'jadeNeedle' });
    game.update(1/120,input({attackPressed:true}));
    const [needle]=game.state.projectiles;
    expect(needle).toMatchObject({weapon:'jadeNeedle',kind:'ember',vx:936});
    expect(needle.burn).toBeUndefined();

    game.equipWeapon('silkFan');
    game.state.hero.attackCooldown=0;
    game.update(1/120,input({attackPressed:true}));
    const silk=game.state.projectiles.filter(projectile=>projectile.weapon==='silkFan');
    expect(silk).toHaveLength(2);
    expect(silk[0].kind).toBe('fan');
    expect(silk[0].vy).toBeLessThan(0);
    expect(silk[1].vy).toBeGreaterThan(0);
  });
});

describe('Huai Yue damage', () => {
  it.each([
    ['fist', 1.512, 7.2],
    ['ironGauntlet', 2.1735, 4.6575],
    ['prayerBeads', 2.412, 2.412],
  ] as const)('applies the %s balance through live hits in the first room', (weapon, openingDamage, halfSecondDamage) => {
    const game = new GameEngine();
    game.start({ ...CONFIG, seed: 26, character: 'monk', weapon });
    const s = game.state, h = s.hero;
    expect(s.room.name).toBe('雾竹山门');
    const target = s.enemies.find(e => e.kind === 'sentry' && s.room.platforms.some(p =>
      p.kind === 'ground' && e.x - p.x >= 170 && p.x + p.w - e.x >= 225
    ) && s.room.hazards.every(hazard => hazard.x + hazard.w < e.x - 175 || hazard.x > e.x + 220))!;
    const floor = s.room.platforms.find(p => p.kind === 'ground' && target.x >= p.x && target.x <= p.x + p.w)!;
    target.hp *= 2;
    target.maxHp *= 2;
    expect(target.hp).toBe(12);
    s.enemies = [target];
    s.pickups = [];
    h.x = target.x - 39;
    h.y = floor.y - h.h;
    h.grounded = true;
    h.critChance = 0;

    game.update(1 / 120, input({ attackPressed: true, attackHeld: true }));
    expect(target.maxHp - target.hp).toBeCloseTo(openingDamage, 4);
    for (let frame = 1; frame < 60; frame++) {
      const distance = target.x + target.w / 2 - h.x - h.w / 2;
      const direction = Math.sign(distance) || 1;
      const close = Math.abs(distance) <= 45 && h.facing === direction;
      game.update(1 / 120, input({ attackHeld: true, right: !close && direction > 0, left: !close && direction < 0 }));
    }
    expect(target.maxHp - target.hp).toBeCloseTo(halfSecondDamage, 4);
    expect(h.level).toBe(1);
    expect(h.upgrades).toHaveLength(0);
  });
});

describe('weapons, pickups and upgrades', () => {
  it.each<WeaponId>(['blade', 'ember', 'disc'])('%s defeats a real target through its attack simulation', weapon => {
    const game = arena(weapon);
    game.state.enemies = [enemy(weapon === 'blade' ? 355 : 470)];
    advance(game, 2.2, { attackHeld: true });
    expect(game.state.kills).toBe(1);
    expect(game.state.enemies[0].dead).toBe(true);
    expect(game.state.hero.hp).toBe(5);
  });

  it('a single disc hits both going out and coming back', () => {
    const game = arena('disc');
    game.state.enemies = [enemy(470, 2)];
    game.update(1 / 120, input({ attackPressed: true }));
    advance(game, 1.5);
    expect(game.state.kills).toBe(1);
    expect(game.state.enemies[0].dead).toBe(true);
  });

  it('stomps an enemy and bounces upward', () => {
    const game = arena();
    game.state.enemies = [enemy(320, 2)];
    const h = game.state.hero;
    h.x = 320; h.y = 355; h.vy = 250; h.grounded = false; h.jumps = 1;
    advance(game, .1, { jumpHeld: true });
    expect(game.state.kills).toBe(1);
    expect(h.vy).toBeLessThan(0);
  });

  it('collects experience, offers deterministic choices and applies the selection', () => {
    const a = arena(); const b = arena();
    for (const game of [a, b]) {
      game.state.hero.xp = 9;
      game.state.pickups = [{ id: 99, kind: 'xp', x: 310, y: 420, w: 11, h: 11, value: 5, vy: 0, bob: 0, collected: false }];
      game.update(1 / 120, input());
    }
    expect(a.state.phase).toBe('upgrade');
    expect(a.state.hero.level).toBe(2);
    expect(a.state.upgradeChoices).toEqual(b.state.upgradeChoices);
    const selected = a.state.upgradeChoices[0].id;
    a.chooseUpgrade('missing');
    expect(a.state.phase).toBe('upgrade');
    a.chooseUpgrade(selected);
    expect(a.state.phase).toBe('playing');
    expect(a.state.hero.upgrades).toContain(selected);
    expect(a.state.hero.xp).toBe(4);
  });

  it('refreshes the buff draft independently of the route and preserves a shared run draft', () => {
    const game = arena();
    const draft = (buffSeed: number) => {
      game.start({ ...CONFIG, buffSeed });
      game.grantCoopXP(game.state.hero.xpNeeded);
      return game.state.upgradeChoices.map(choice => choice.id);
    };
    const a = draft(1);
    expect(new Set(a).size).toBe(3);
    expect(draft(2)).not.toEqual(a);
    expect(game.state.seed).toBe(CONFIG.seed);
    expect(draft(1)).toEqual(a);
  });

  it('keeps one-heart challenges at one heart and excludes max-health upgrades', () => {
    const game = arena();
    game.start({ ...CONFIG, modifier: 'iron' });
    expect(game.state.hero.hp).toBe(1);
    game.state.hero.xp = 9;
    game.state.pickups = [{ id: 99, kind: 'xp', x: 110, y: 420, w: 11, h: 11, value: 5, vy: 0, bob: 0, collected: false }];
    game.update(1 / 120, input());
    expect(game.state.upgradeChoices.some(choice => choice.id === 'vigor')).toBe(false);
  });

  it('respawns a fall at a safe checkpoint and records the fall', () => {
    const game = arena();
    const h = game.state.hero;
    h.x = 1000; h.y = 595; h.vy = 400;
    game.update(1 / 120, input());
    expect(h.hp).toBe(4);
    expect(h.x).toBe(game.state.room.checkpoint.x);
    expect(h.y).toBeLessThan(448);
    expect(game.state.deaths).toBe(1);
  });

  it('shield consumes a hit before health and defeat produces a complete result', () => {
    const game = arena();
    const h = game.state.hero;
    h.shield = 1; h.hp = 1;
    game.state.enemies = [enemy(300, 100)];
    game.update(1 / 120, input());
    expect(h.shield).toBe(0);
    expect(h.hp).toBe(1);
    h.invincible = 0; h.x = 300; h.y = 412; h.vy = 0;
    game.state.enemies[0].x = 300;
    game.update(1 / 120, input());
    expect(game.state.phase).toBe('gameover');
    expect(game.state.result?.won).toBe(false);
    expect(game.state.result?.seed).toBe(CONFIG.seed);
  });
});

function reachBoss(game: GameEngine) {
  for (let index = 0; index < EXPEDITION_ROOM_COUNT - 1; index++) {
    const s = game.state;
    s.pickups = [];
    s.hero.x = 300; s.hero.y = 412; s.hero.grounded = true; s.hero.invincible = 100;
    // Compact the encounter to test transitions without waiting for traversal.
    s.enemies.forEach((e, n) => { e.x = 348 + n; e.y = 414; e.hp = .1; e.vx = e.vy = 0; e.originX = e.x; });
    advance(game, .35, { attackHeld: true });
    settleUpgrades(game);
    advance(game, .1, { attackHeld: true });
    settleUpgrades(game);
    expect(s.roomCleared).toBe(true);
    s.hero.x = s.room.exit.x; s.hero.y = 412;
    game.update(1 / 120, input({ interactPressed: true }));
    settleUpgrades(game);
    expect(s.roomIndex).toBe(index + 1);
  }
  expect(game.state.boss).not.toBeNull();
}

function bossArena() {
  const game = new GameEngine(); game.start(CONFIG);
  reachBoss(game);
  const s = game.state;
  s.hero.x = 700; s.hero.invincible = 100; s.hero.critChance = 0;
  s.hero.attackStep = 0; s.hero.comboWindow = 0; s.hero.attackTimer = 0; s.hero.attackCooldown = 0;
  s.pickups = []; s.hitstop = 0;
  game.update(1 / 120, input());
  return game;
}

describe('combat impact and expressive controls', () => {
  it('freezes physics on a real hit while the stopwatch and impact effects keep running', () => {
    const game = arena();
    const s = game.state, h = s.hero;
    h.critChance = 0; s.enemies = [enemy(355, 100)];
    game.update(1 / 120, input({ attackPressed: true }));
    expect(s.hitstop).toBeGreaterThan(0);
    expect(s.impacts.some(impact => impact.kind === 'hit')).toBe(true);
    const before = { time: s.time, x: h.x, enemyX: s.enemies[0].x, cooldown: h.attackCooldown, life: s.impacts[0].life };
    game.update(.02, input({ right: true }));
    expect(s.time - before.time).toBeCloseTo(.02);
    expect(h.x).toBe(before.x);
    expect(s.enemies[0].x).toBe(before.enemyX);
    expect(h.attackCooldown).toBe(before.cooldown);
    expect(s.impacts[0].life).toBeLessThan(before.life);
    advance(game, .08, { right: true });
    expect(h.x).toBeGreaterThan(before.x);
  });

  it('preserves a jump pressed during hitstop and performs it as soon as physics resumes', () => {
    const game = arena();
    game.state.hero.critChance = 0; game.state.enemies = [enemy(355, 100)];
    game.update(1 / 120, input({ attackPressed: true }));
    game.update(.01, input({ jumpPressed: true, jumpHeld: true }));
    expect(game.state.hero.grounded).toBe(true);
    game.update(.05, input({ jumpHeld: true }));
    expect(game.state.hero.grounded).toBe(false);
    expect(game.state.hero.jumps).toBe(1);
    expect(game.state.hero.vy).toBeLessThan(-400);
  });

  it('holding blade attacks creates a three-hit chain whose finisher hits harder and launches its target', () => {
    const game = arena(), s = game.state, h = s.hero;
    const target = enemy(355, 100);
    s.enemies = [target]; h.critChance = 0;
    const strikes: { step: number; damage: number }[] = [];
    for (let frame = 0; frame < 240 && strikes.length < 3; frame++) {
      target.x = 355; target.vx = 0; target.y = 406; target.vy = 0;
      const hp = target.hp, step = h.attackStep;
      game.update(1 / 120, input({ attackHeld: true }));
      if (h.attackStep !== step) strikes.push({ step: h.attackStep, damage: hp - target.hp });
    }
    expect(strikes.map(strike => strike.step)).toEqual([1, 2, 3]);
    expect(strikes.map(strike => strike.damage)).toEqual([expect.closeTo(1.593), expect.closeTo(1.829), expect.closeTo(3.304)]);
    expect(strikes[2].damage).toBeGreaterThan(strikes[0].damage * 2);
    expect(target.vx).toBeGreaterThan(300);
    expect(target.vy).toBeLessThan(0);
    expect(s.impacts.some(impact => impact.kind === 'heavy')).toBe(true);
    advance(game, 1.2);
    expect(h.attackStep).toBe(0);
  });

  it('makes the finisher reach beyond the ordinary blade slash', () => {
    const game = arena(), s = game.state;
    s.hero.critChance = 0; s.enemies = [enemy(416, 100)];
    const hitSteps: number[] = [];
    for (let frame = 0; frame < 180 && s.enemies[0].hp === 100; frame++) {
      const hp = s.enemies[0].hp;
      game.update(1 / 120, input({ attackHeld: true }));
      if (s.enemies[0].hp < hp) hitSteps.push(s.hero.attackStep);
    }
    expect(hitSteps).toEqual([3]);
    expect(s.enemies[0].hp).toBeCloseTo(96.696);
  });

  it('rewards a weapon swap once without allowing swaps to cancel attack cooldown', () => {
    const game = arena('blade'), s = game.state, h = s.hero;
    game.equipWeapon('ember');
    const resonance = s.resonance;
    game.update(1 / 120, input({ attackPressed: true }));
    expect(s.projectiles[0].damage).toBeCloseTo(2.6);
    expect(h.swapBoost).toBe(0);
    const cooldown = h.attackCooldown;
    for (let n = 0; n < 5; n++) { game.equipWeapon('disc'); game.equipWeapon('ember'); }
    expect(h.attackCooldown).toBe(cooldown);
    expect(h.swapBoost).toBe(0);
    expect(s.resonance).toBe(resonance);
    game.update(1 / 120, input({ attackPressed: true }));
    expect(s.projectiles).toHaveLength(1);
    advance(game, .5);
    game.update(1 / 120, input({ attackPressed: true }));
    expect(s.projectiles.at(-1)?.damage).toBeCloseTo(2);
  });

  it('grants a counter only when an early dash actually avoids a hit, then consumes it on one attack', () => {
    const empty = arena();
    empty.update(1 / 120, input({ dashPressed: true }));
    expect(empty.state.resonance).toBe(0);
    expect(empty.state.hero.counterTimer).toBe(0);
    const game = arena(), s = game.state, h = s.hero;
    s.enemies = [enemy(330, 100)]; h.critChance = 0;
    game.update(1 / 120, input({ right: true, dashPressed: true }));
    expect(h.hp).toBe(5);
    expect(h.counterTimer).toBeGreaterThan(0);
    expect(s.resonance).toBe(20);
    advance(game, .05, { right: true });
    expect(s.resonance).toBe(20);
    s.enemies = [enemy(h.x + 55, 100)];
    game.update(1 / 120, input({ attackPressed: true }));
    expect(s.enemies[0].hp).toBeCloseTo(100 - 1.593 * 1.5);
    expect(h.counterTimer).toBe(0);
  });
});

describe('boss counterplay and escalation', () => {
  it.each([2, 3])('phase %i warns before every chained charge and includes aimed barrage', phase => {
    const game = bossArena(), s = game.state, b = s.boss!;
    b.form = 2; b.phase = phase; b.maxHp = BOSS_AWAKENED_HP;
    b.hp = phase === 2 ? b.maxHp * .6 : b.maxHp * .25;
    advance(game, 1.1);
    let chargeEntries = 0, chargeWarnings = 0, volleyProjectiles = 0;
    let previousMode = b.mode;
    const projectileIds = new Set<number>();
    for (let frame = 0; frame < 120 * 20; frame++) {
      game.update(1 / 120, input());
      if (b.mode !== previousMode) {
        if (b.mode === 'charge') chargeEntries++;
        if (b.mode === 'windup' && b.intent === 'charge') {
          chargeWarnings++;
          expect(b.timer).toBeGreaterThanOrEqual(.43);
        }
        previousMode = b.mode;
      }
      for (const p of s.projectiles) if (p.kind === 'enemy' && !projectileIds.has(p.id)) {
        projectileIds.add(p.id); volleyProjectiles++;
      }
    }
    expect(chargeEntries).toBeGreaterThanOrEqual(phase);
    expect(chargeWarnings).toBeGreaterThanOrEqual(chargeEntries);
    expect(volleyProjectiles).toBeGreaterThanOrEqual(phase === 2 ? 6 : 15);
    expect(b.attackCount).toBeGreaterThanOrEqual(4);
  });

  it('locks the leap marker during its warning and lands at that marker after the hero moves', () => {
    const game = bossArena(), s = game.state, b = s.boss!;
    b.attackCount = 1; b.timer = 0;
    game.update(1 / 120, input());
    expect(b.intent).toBe('leap'); expect(b.mode).toBe('windup');
    const target = b.targetX;
    expect(Math.abs(target - b.x)).toBeLessThanOrEqual(380);
    advance(game, .5, { right: true });
    expect(s.hero.x).toBeGreaterThan(800);
    expect(b.targetX).toBe(target);
    for (let frame = 0; frame < 240 && b.mode !== 'recover'; frame++) game.update(1 / 120, input());
    expect(b.mode).toBe('recover');
    expect(Math.abs(b.x - target)).toBeLessThan(10);
    expect(b.y + b.h).toBe(448);
  });

  it('charges away from arena walls instead of immediately cancelling its attack', () => {
    const game = bossArena(), s = game.state, b = s.boss!;
    b.x = 420; b.attackCount = 0; b.timer = 0; s.hero.x = 1000;
    advance(game, .9);
    expect(b.mode).toBe('charge');
    const before = b.x;
    advance(game, .1);
    expect(b.mode).toBe('charge');
    expect(b.x).toBeGreaterThan(before + 35);
  });

  it('breaks armor with real attacks, opens a stronger punish window, and restores the guard afterward', () => {
    const game = bossArena(), s = game.state, b = s.boss!, h = s.hero;
    b.timer = 20; b.guard = 1;
    h.x = b.x - 65; h.y = 412; h.facing = 1; h.attackCooldown = 0;
    game.update(1 / 120, input({ attackPressed: true }));
    const firstDamage = b.maxHp - b.hp;
    expect(b.mode).toBe('stagger'); expect(b.guard).toBe(0);
    expect(s.impacts.some(impact => impact.kind === 'break')).toBe(true);
    advance(game, .4);
    const hp = b.hp;
    game.update(1 / 120, input({ attackPressed: true }));
    expect(hp - b.hp).toBeCloseTo(firstDamage / 1.35 * 1.55 * 1.6);
    expect(hp - b.hp).toBeGreaterThan(firstDamage);
    advance(game, 1.5);
    expect(b.guard).toBe(b.maxGuard);
    expect(b.mode).not.toBe('stagger');
  });

  it('lets a timed jump clear a real ground shockwave', () => {
    const game = bossArena(), s = game.state, b = s.boss!, h = s.hero;
    b.mode = 'slam'; b.intent = 'slam'; b.timer = 0; b.x = 900;
    h.x = 700; h.invincible = 0;
    game.update(1 / 120, input());
    expect(s.projectiles.filter(p => p.kind === 'shockwave')).toHaveLength(2);
    advance(game, .5);
    game.update(1 / 120, input({ jumpPressed: true, jumpHeld: true }));
    advance(game, .6, { jumpHeld: true });
    expect(h.hp).toBe(5);
    expect(h.dashCooldown).toBe(0);
    expect(s.projectiles.some(p => p.kind === 'shockwave' && p.x < h.x)).toBe(true);
  });
});

describe('complete expedition and final boss', () => {
  it('opens late gates without automatically healing while early gates still grant a heart', () => {
    for (const realm of [0, 4, 6]) {
      const game = arena(), s = game.state;
      s.roomIndex = realm; s.hero.hp = 2; s.enemies = []; s.pickups = [];
      game.update(1 / 120, input());
      expect(s.roomCleared).toBe(true);
      expect(s.hero.hp).toBe(realm < 4 ? 3 : 2);
    }
  });

  it('doubles the health of every ordinary spawn across the standard expedition', () => {
    const game = new GameEngine();
    game.start(CONFIG);
    for (let index = 0; index < 7; index++) {
      const s = game.state, base = createRoom(CONFIG.seed, index);
      expect(s.roomIndex).toBe(index);
      expect(s.enemies.map(({hp, maxHp}) => [hp, maxHp])).toEqual(base.enemies.map(e => [e.hp * 2, e.maxHp * 2]));
      s.enemies = [];
      s.hero.x = s.room.exit.x;
      s.hero.y = s.room.exit.y + 25;
      game.update(1 / 120, input({ interactPressed: true }));
      if (s.phase === 'upgrade') {
        settleUpgrades(game);
        game.update(1 / 120, input({ interactPressed: true }));
      }
    }
    expect(game.state.boss).toMatchObject({ hp: 600, maxHp: 600 });
  });

  it('opens the gate only when enemies are defeated, then loads the next room', () => {
    const game = arena();
    game.state.hero.x = game.state.room.exit.x;
    game.update(1 / 120, input({ interactPressed: true }));
    expect(game.state.roomIndex).toBe(0);
    game.state.enemies = [];
    advance(game, .02, { interactPressed: true });
    expect(game.state.roomIndex).toBe(1);
    expect(game.state.room.name).toBe(createRoom(CONFIG.seed, 1).room.name);
    expect(game.state.enemies.length).toBeGreaterThan(0);
  });

  it('progresses through all rooms and the boss telegraphs charge, leap and shockwaves', () => {
    const game = new GameEngine(); game.start(CONFIG);
    reachBoss(game);
    const s = game.state;
    s.hero.x = 700; s.hero.invincible = 100;
    const modes = new Set<string>();
    let shockwaveSeen = false;
    for (let n = 0; n < 1800; n++) {
      game.update(1 / 120, input());
      modes.add(s.boss!.mode);
      if (s.projectiles.some(p => p.kind === 'shockwave')) shockwaveSeen = true;
    }
    expect(s.boss!.active).toBe(true);
    expect(modes).toContain('windup');
    expect(modes).toContain('charge');
    expect(modes).toContain('jump');
    expect(modes).toContain('recover');
    expect(shockwaveSeen).toBe(true);
  });

  it('telegraphs both phase transitions, then defeats the boss through combat and records victory', () => {
    const sounds: string[] = [];
    const game = new GameEngine({ sound: name => sounds.push(name) }); game.start(CONFIG);
    reachBoss(game);
    const s = game.state;
    const b = s.boss!;
    s.hero.x = b.x - 65; s.hero.y = 412; s.hero.invincible = 100; s.hero.facing = 1;
    s.hero.attackCooldown = 0; s.hero.damage = 2;
    expect(b.maxHp).toBe(BOSS_MAX_HP);
    b.hp = 1;
    advance(game, .1, { attackHeld: true });
    expect(b.phase).toBe(2);
    expect(b.mode).toBe('transition');
    expect(b.form).toBe(2); expect(b.hp).toBe(BOSS_AWAKENED_HP);
    const transitioningHp = b.hp;
    advance(game, .4, { attackHeld: true });
    expect(b.hp).toBe(transitioningHp);
    advance(game, BOSS_TRANSFORM_TIME);
    b.hp = b.maxHp / 2 + 1; b.guard = 0; b.timer = 99;
    s.hero.damage = b.maxHp * 2;
    s.hero.attackCooldown = 0; s.hero.x = b.x - 55;
    advance(game, .08, { attackPressed: true });
    expect(b.phase).toBe(3);
    expect(b.mode).toBe('transition');
    expect(b.hp).toBe(b.maxHp / 2);
    expect(s.result).toBeNull();
    advance(game, .35, { attackHeld: true });
    expect(b.hp).toBe(b.maxHp / 2);
    advance(game, BOSS_ASCENSION_TIME - .30);
    expect(b.phase).toBe(3);
    expect(b.mode).not.toBe('transition');
    b.hp = 1; s.hero.attackCooldown = 0;
    s.hero.x = b.x - 65; s.hero.y = 412; s.hero.facing = 1;
    advance(game, .55, { attackHeld: true });
    expect(s.phase).toBe('victory');
    expect(b.mode).toBe('dead');
    expect(s.result?.won).toBe(true);
    expect(s.result?.roomsCleared).toBe(EXPEDITION_ROOM_COUNT);
    expect(s.result?.score).toBeGreaterThan(5000);
    expect(sounds).toContain('win');
    const finalTime = s.result!.time;
    advance(game, 2);
    expect(s.result!.time).toBe(finalTime);
  });

  it('leaves a warned seal at the old target as a final-form chain winds up again', () => {
    const game = bossArena(), s = game.state, b = s.boss!;
    Object.assign(b, { form: 2, phase: 3, hp: BOSS_AWAKENED_HP / 2, maxHp: BOSS_AWAKENED_HP,
      intent: 'charge', mode: 'charge', chain: 2, timer: 0, targetX: 700 });
    s.hero.x = 1030;
    game.update(1 / 120, input());
    const seal = s.projectiles.find(p => p.kind === 'rift' && p.style === 'ink');
    expect(seal).toBeDefined();
    expect(seal!.x + seal!.w / 2).toBe(700 + b.w / 2);
    expect(seal!.delay).toBeGreaterThan(.55);
    expect(b.mode).toBe('windup');
    expect(b.timer).toBeCloseTo(.44);
    expect(b.targetX).not.toBe(700);
  });

  it('shows a locked warning before the two waves of final-form pillars, with gaps that stay safe', () => {
    const game = bossArena(), s = game.state, b = s.boss!, h = s.hero;
    Object.assign(b, { form: 2, phase: 3, hp: BOSS_AWAKENED_HP / 2, maxHp: BOSS_AWAKENED_HP, attackCount: 0, timer: 0, x: 1170 });
    h.invincible = 0;
    advance(game, .02);
    expect(b.intent).toBe('eclipse');
    expect(b.mode).toBe('windup');
    const lanes = eclipseLanes(b, s.room.width);
    const safeBetweenLanes = (lanes[1] + lanes[2]) / 2;
    h.x = safeBetweenLanes - h.w / 2;
    const hp = h.hp;
    advance(game, .82);
    const pillars = s.projectiles.filter(p => p.style === 'eclipse');
    expect(pillars.map(p => p.x + ECLIPSE_WIDTH / 2)).toEqual(lanes);
    expect(pillars.every(p => p.delay! > 0)).toBe(true);
    expect(new Set(pillars.map(p => p.delay)).size).toBe(2);
    advance(game, 1.14);
    expect(h.hp).toBe(hp);
  });
});

describe('triggered relic buffs', () => {
  it('gives the first weapon-switch attack 25 extra damage percentage points per stack', () => {
    const ordinary = arena(), upgraded = arena();
    grant(upgraded, 'gildedSwitch');
    grant(upgraded, 'gildedSwitch');
    for (const game of [ordinary, upgraded]) {
      game.equipWeapon('ember');
      game.update(1 / 120, input({ attackPressed: true }));
    }
    expect(upgraded.state.projectiles[0].damage / ordinary.state.projectiles[0].damage).toBeCloseTo(1.8 / 1.3);
    expect(upgraded.state.hero.buffEffects?.map(effect => effect.kind)).toEqual(['gildedSwitch']);
    advance(upgraded, .31);
    upgraded.update(1 / 120, input({ attackPressed: true }));
    expect(upgraded.state.projectiles[1].damage / upgraded.state.projectiles[0].damage).toBeCloseTo(1 / 1.8);
    expect(upgraded.state.hero.buffEffects).toHaveLength(1);
    advance(upgraded, .7);
    expect(upgraded.state.hero.buffEffects).toEqual([]);
  });

  it('charges on the third attack once regardless of projectile count', () => {
    const game = arena('ember');
    grant(game, 'thirdStar');
    grant(game, 'thirdStar');
    const h = game.state.hero;
    h.extraProjectiles = 2;
    for (let n = 0; n < 2; n++) {
      advance(game, .29, { attackPressed: true });
      expect(game.state.resonance).toBe(0);
    }
    game.update(1 / 120, input({ attackPressed: true }));
    expect(game.state.projectiles.filter(p => p.style === 'charged')).toHaveLength(3);
    expect(game.state.resonance).toBe(8);
    expect(h.buffEffects?.map(effect => effect.kind)).toEqual(['thirdStar']);
  });

  function placeHostileBolts(game: GameEngine): void {
    const h = game.state.hero;
    h.invincible = 0;
    game.state.projectiles = [1, 2].map(id => ({ id, kind: 'enemy', x: h.x + 16, y: h.y + 8,
      w: 12, h: 18, vx: 0, vy: 0, life: 1, damage: 1, owner: 'enemy', hitIds: [] }));
  }

  it('refunds dash cooldown once per perfect dodge even with overlapping attacks', () => {
    const ordinary = arena(), upgraded = arena();
    grant(upgraded, 'afterimage');
    grant(upgraded, 'afterimage');
    for (const game of [ordinary, upgraded]) {
      placeHostileBolts(game);
      game.update(1 / 120, input({ dashPressed: true }));
      expect(game.state.resonance).toBe(20);
    }
    expect(ordinary.state.hero.dashCooldown - upgraded.state.hero.dashCooldown).toBeCloseTo(.64);
    expect(upgraded.state.hero.buffEffects?.map(effect => effect.kind)).toEqual(['afterimage']);
  });

  it('keeps each signature perfect-dodge marker visual-only and preserves the original hero ring', () => {
    const classic = arena();
    placeHostileBolts(classic);
    classic.update(1 / 120, input({ dashPressed: true }));
    for (const character of ['traveller', 'blade', 'staff', 'wheel', 'spear', 'monk'] as const) {
      const game = arena();
      game.state.character = character;
      placeHostileBolts(game);
      game.update(1 / 120, input({ dashPressed: true }));
      const { dodgeCue, ...hero } = game.state.hero;
      expect(hero).toEqual(classic.state.hero);
      expect(game.state.resonance).toBe(classic.state.resonance);
      if (character === 'traveller') {
        expect(dodgeCue).toBeUndefined();
        expect(game.state.impacts).toEqual(classic.state.impacts);
        expect(game.state.particles).toEqual(classic.state.particles);
      } else {
        expect(dodgeCue?.life).toBeCloseTo(.38);
        expect(dodgeCue?.facing).toBe(hero.facing);
        expect(game.state.impacts).toHaveLength(0);
      }
      advance(game, .41);
      expect(game.state.hero.dodgeCue).toBeUndefined();
    }
  });

  it('awards bonus resonance once when a directional perfect guard succeeds', () => {
    const game = arena();
    grant(game, 'jadeParry');
    grant(game, 'jadeParry');
    placeHostileBolts(game);
    game.update(1 / 120, input({ guardPressed: true }));
    expect(game.state.resonance).toBe(24);
    expect(game.state.hero.buffEffects?.map(effect => effect.kind)).toEqual(['jadeParry']);
    expect(game.state.hero.hp).toBe(game.state.hero.maxHp);
  });

  it('lets only the traveller with Jade Spring consume a heart at full health', () => {
    const first = arena(), second = arena();
    first.setCoopReplica(0);
    second.setCoopReplica(1);
    grant(second, 'jadeSpring');
    grant(second, 'jadeSpring');
    for (const game of [first, second]) {
      const h = game.state.hero;
      game.state.pickups = [{ id: 99, kind: 'heart', x: h.x + 8, y: h.y + 12, w: 12, h: 12, value: 1, vy: 0, bob: 0, collected: false }];
      game.tickCoop(1 / 120, EMPTY_INPUT);
      expect(h.hp).toBe(h.maxHp);
    }
    expect(first.state.pickups).toHaveLength(1);
    expect(first.state.resonance).toBe(0);
    expect(second.state.pickups).toHaveLength(0);
    expect(second.state.resonance).toBe(10);
    expect(second.state.hero.buffEffects?.map(effect => effect.kind)).toEqual(['jadeSpring']);
  });

  it('damages enemies only on the first platform touch after a double jump', () => {
    const game = arena();
    grant(game, 'landingSeal');
    grant(game, 'landingSeal');
    game.state.hero.critChance = 0;
    game.state.room.platforms.push({ x: 140, y: 410, w: 460, h: 12, kind: 'stone', oneWay: true });
    game.update(1 / 120, input({ jumpPressed: true }));
    advance(game, .13);
    game.update(1 / 120, input({ jumpPressed: true }));
    expect(game.state.hero.jumps).toBe(2);
    const close = enemy(game.state.hero.x + 62, 100);
    const far = { ...enemy(game.state.hero.x + 170, 100), id: 72 };
    game.state.enemies = [close, far];
    for (let n = 0; n < 120 && !game.state.hero.grounded; n++) game.update(1 / 120, EMPTY_INPUT);
    expect(game.state.hero.y + game.state.hero.h).toBe(410);
    expect(close.hp).toBe(94);
    expect(far.hp).toBe(100);
    expect(game.state.hero.buffEffects?.map(effect => effect.kind)).toEqual(['landingSeal']);
    advance(game, .13);
    expect(close.hp).toBe(94);
    expect(game.state.hero.buffEffects).toHaveLength(1);
    advance(game, 1, { jumpPressed: true });
    expect(close.hp).toBe(94);
    expect(game.state.hero.buffEffects).toEqual([]);
  });

  it('drafts the six relics and drops capped relics from normal choices', () => {
    const ids = ['gildedSwitch', 'thirdStar', 'afterimage', 'jadeParry', 'jadeSpring', 'landingSeal'];
    const seen = new Set<string>();
    for (let seed = 1; seed <= 48; seed++) {
      const game = arena();
      game.state.seed = seed;
      game.grantCoopXP(game.state.hero.xpNeeded);
      for (const item of game.state.upgradeChoices) seen.add(item.id);
      game.state.phase = 'playing';
      for (const id of ids) for (let n = 0; n < 3; n++) grant(game, id);
      game.grantCoopXP(game.state.hero.xpNeeded);
      expect(game.state.upgradeChoices.some(item => ids.includes(item.id))).toBe(false);
    }
    expect(ids.every(id => seen.has(id))).toBe(true);
  });
});

describe('starfall overdrive and build synergies', () => {
  it('charges from the first encounter and activates only when the meter is full', () => {
    const game = arena();
    game.update(1 / 120, input({ overdrivePressed: true }));
    expect(game.state.overdrive).toBe(0);
    game.state.enemies = [0, 1, 2, 3].map(n => ({ ...enemy(350 + n, .1), id: n + 1 }));
    advance(game, .1, { attackHeld: true });
    expect(game.state.resonance).toBe(100);
    settleUpgrades(game);
    game.update(1 / 120, input({ overdrivePressed: true }));
    expect(game.state.overdrive).toBe(6);
    expect(game.state.overdriveCount).toBe(1);
    expect(game.state.resonance).toBe(0);
    game.update(1 / 120, input({ overdrivePressed: true }));
    expect(game.state.overdriveCount).toBe(1);
  });

  it('temporarily empowers movement, attacks and dash without changing permanent stats', () => {
    const game = arena();
    const h = game.state.hero;
    const permanent = { damage: h.damage, speed: h.speed, attackSpeed: h.attackSpeed, extraProjectiles: h.extraProjectiles };
    game.state.resonance = 100;
    game.update(1 / 120, input({ overdrivePressed: true }));
    advance(game, .35, { right: true });
    expect(h.vx).toBeGreaterThan(permanent.speed);
    game.update(1 / 120, input({ attackPressed: true, dashPressed: true }));
    expect(game.state.projectiles.filter(p => p.owner === 'hero')).toHaveLength(2);
    expect(h.attackCooldown).toBeLessThan(.2);
    expect(h.dashCooldown).toBeLessThan(.4);
    advance(game, 6.1);
    expect(game.state.overdrive).toBe(0);
    expect({ damage: h.damage, speed: h.speed, attackSpeed: h.attackSpeed, extraProjectiles: h.extraProjectiles }).toEqual(permanent);
    game.state.projectiles = [];
    game.update(1 / 120, input({ attackPressed: true }));
    expect(game.state.projectiles.filter(p => p.owner === 'hero')).toHaveLength(0);
    expect(h.attackCooldown).toBeGreaterThan(.25);
  });

  it.each<WeaponId>(['ember', 'disc'])('overdrive adds two projectiles to the %s volley', weapon => {
    const game = arena(weapon);
    game.state.resonance = 100;
    game.update(1 / 120, input({ overdrivePressed: true, attackPressed: true }));
    expect(game.state.projectiles.filter(p => p.owner === 'hero')).toHaveLength(weapon === 'disc' ? 4 : 3);
    expect(game.state.projectiles[0].damage).toBeGreaterThan(game.state.hero.damage);
  });

  it('overdrive blade reaches a distant target that its ordinary slash cannot hit', () => {
    const normal = arena(); const empowered = arena();
    for (const game of [normal, empowered]) game.state.enemies = [enemy(416, 100)];
    normal.update(1 / 120, input({ attackPressed: true }));
    empowered.state.resonance = 100;
    empowered.update(1 / 120, input({ attackPressed: true, overdrivePressed: true }));
    expect(normal.state.enemies[0].hp).toBe(100);
    expect(empowered.state.enemies[0].hp).toBeLessThan(100);
  });

  it('awakened disc returns faster, larger, and with bonus return damage', () => {
    const game = arena('disc');
    game.state.resonance = 100;
    game.update(1 / 120, input({ attackPressed: true, overdrivePressed: true }));
    const outward = game.state.projectiles[0];
    const damage = outward.damage;
    advance(game, .65);
    expect(outward.returning).toBe(true);
    expect(outward.damage).toBeCloseTo(damage * 1.6);
    expect(outward.w).toBe(34);
    expect(Math.hypot(outward.vx, outward.vy)).toBeCloseTo(900);
  });

  it('activates blazing only with its pair and improves actual damage and attack interval', () => {
    const alone = arena(); const paired = arena();
    for (const game of [alone, paired]) {
      game.state.enemies = [enemy(355, 100)];
      game.state.hero.critChance = 0;
      grant(game, 'edge');
    }
    expect(alone.state.synergies).not.toContain('blazing');
    grant(paired, 'tempo');
    expect(paired.state.synergies).toContain('blazing');
    alone.update(1 / 120, input({ attackPressed: true }));
    paired.update(1 / 120, input({ attackPressed: true }));
    expect(paired.state.enemies[0].hp).toBeLessThan(alone.state.enemies[0].hp);
    expect(paired.state.hero.attackCooldown).toBeLessThan(alone.state.hero.attackCooldown);
  });

  it('fireflies adds a real projectile and attracts coins beyond normal magnet reach', () => {
    const game = arena('ember');
    grant(game, 'multishot'); grant(game, 'magnet');
    expect(game.state.synergies).toContain('fireflies');
    game.state.pickups = [{ id: 991, kind: 'coin', x: 600, y: 420, w: 13, h: 16, value: 1, vy: 0, bob: 0, collected: false }];
    game.update(1 / 120, input({ attackPressed: true }));
    expect(game.state.projectiles.filter(p => p.owner === 'hero')).toHaveLength(3);
    expect(game.state.pickups[0].x).toBeLessThan(600);
  });

  it('guardian grants a shield immediately and another when entering a room', () => {
    const game = arena();
    grant(game, 'vigor'); grant(game, 'shield');
    expect(game.state.synergies).toContain('guardian');
    expect(game.state.hero.shield).toBe(4);
    game.state.hero.shield = 0;
    game.state.enemies = [];
    game.state.hero.x = game.state.room.exit.x;
    game.update(1 / 120, input({ interactPressed: true }));
    expect(game.state.roomIndex).toBe(1);
    expect(game.state.hero.shield).toBe(2);
  });

  it('offers a matching relic once one synergy component has been chosen', () => {
    for (let seed = 1; seed < 25; seed++) {
      const game = arena();
      game.state.seed = seed;
      grant(game, 'edge');
      game.state.hero.xp = 9;
      game.state.pickups = [{ id: 99, kind: 'xp', x: 310, y: 420, w: 11, h: 11, value: 5, vy: 0, bob: 0, collected: false }];
      game.update(1 / 120, input());
      expect(game.state.upgradeChoices.some(choice => choice.id === 'tempo')).toBe(true);
    }
  });
});

describe('input-only playthrough', () => {
  function runInputOnly(config: GameConfig) {
    const game = new GameEngine();
    game.start(config);
    let jumpHeldUntil = 0;
    let lastJump = -1;
    let bossStarted: number | null = null;
    let phaseTwoStarted: number | null = null;
    let phaseThreeStarted: number | null = null;
    let secondFullHealthSeen = false;
    const warnedForms = new Set<number>();
    const bossAttacksSeen = new Set<string>();
    const bossIntentsSeen = new Set<string>();
    const visitedRealms: number[] = [];
    const preference = ['edge', 'multishot', 'tempo', 'vigor', 'shield', 'blood', 'magnet', 'stride', 'thirdStar',
      'jadeSpring', 'afterimage', 'fortune', 'frost', 'bell', 'breeze', 'jadeParry', 'gildedSwitch', 'landingSeal'];
    for (let frame = 0; frame < 60 * 240 && !game.state.result; frame++) {
      const s = game.state;
      if (visitedRealms.length <= s.roomIndex) visitedRealms.push(s.room.theme);
      if (s.phase === 'upgrade') {
        const choice = [...s.upgradeChoices].sort((a, b) => preference.indexOf(a.id) - preference.indexOf(b.id))[0];
        game.chooseUpgrade(choice.id);
        continue;
      }
      const h = s.hero;
      if (s.boss?.active && bossStarted === null) bossStarted = s.time;
      if (s.boss?.phase === 2 && phaseTwoStarted === null) phaseTwoStarted = s.time;
      if (s.boss?.phase === 3 && phaseThreeStarted === null) phaseThreeStarted = s.time;
      if (s.boss?.form === 2 && s.boss.hp === s.boss.maxHp) secondFullHealthSeen = true;
      if (s.boss?.mode === 'windup') warnedForms.add(s.boss.form ?? 1);
      if (s.boss && ['charge', 'jump', 'slam', 'barrage'].includes(s.boss.mode)) bossAttacksSeen.add(s.boss.mode);
      if (s.boss?.mode === 'windup') bossIntentsSeen.add(s.boss.intent);
      if (s.projectiles.some(p => p.style === 'eclipse')) bossAttacksSeen.add('eclipse');
      const targets = s.enemies.filter(e => !e.dead).sort((a, b) => Math.abs(a.x - h.x) - Math.abs(b.x - h.x));
      const target = targets[0] ?? (s.boss && s.boss.mode !== 'dead' ? s.boss : null);
      const keys = input({ attackHeld: !!target, overdrivePressed: s.resonance >= 100 });
      let direction = 0;
      if (target) {
        const distance = target.x - h.x;
        if (Math.abs(distance) > 290) direction = Math.sign(distance);
        else if (Math.abs(distance) < 145) direction = -Math.sign(distance);
        else if (h.facing !== Math.sign(distance)) direction = Math.sign(distance);
      } else direction = 1;
      if (h.grounded && h.y < 400 && (!target || target.y > h.y + 50)) {
        const platform = s.room.platforms.find(p => p.oneWay && h.x + h.w > p.x && h.x < p.x + p.w && Math.abs(h.y + h.h - p.y) < 3);
        if (platform) direction = h.x < platform.x + platform.w / 2 ? -1 : 1;
      }
      if (h.x < 70 && direction < 0) direction = 1;
      keys.left = direction < 0;
      keys.right = direction > 0;
      const ahead = h.x + h.w / 2 + direction * 78;
      const gapAhead = direction !== 0 && !s.room.platforms.some(p => p.kind === 'ground' && ahead >= p.x && ahead <= p.x + p.w);
      const spikesAhead = s.room.hazards.some(hazard => hazard.kind === 'spikes' && ahead > hazard.x - 18 && ahead < hazard.x + hazard.w + 18);
      const incoming = s.projectiles.some(p => p.owner === 'enemy' && Math.abs(p.x - h.x) < 130 && Math.abs(p.y - h.y) < 70 && (p.x - h.x) * p.vx < 0);
      if (incoming && h.dashCooldown <= 0) keys.dashPressed = true;
      const highTarget = !!target && target.y < h.y - 60;
      const bossWindup = s.boss?.active && s.boss.mode === 'windup' && s.boss.timer < .28;
      if (h.grounded && s.time - lastJump > .6 && (gapAhead || spikesAhead || incoming || highTarget || bossWindup)) {
        keys.jumpPressed = true;
        lastJump = s.time;
        jumpHeldUntil = s.time + .28;
      }
      const fallingIntoGap = !h.grounded && h.jumps < 2 && h.vy > 100 && !s.room.platforms.some(p => p.kind === 'ground' && h.x + 14 > p.x && h.x + 14 < p.x + p.w);
      if (fallingIntoGap && s.time - lastJump > .18) {
        keys.jumpPressed = true;
        lastJump = s.time;
        jumpHeldUntil = s.time + .28;
      }
      keys.jumpHeld = s.time < jumpHeldUntil;
      game.update(1 / 60, keys);
    }
    expect(game.state.result, `room=${game.state.roomIndex}, time=${game.state.time}, hp=${game.state.hero.hp}, alive=${game.state.enemies.filter(e => !e.dead).map(e => `${e.kind}@${Math.round(e.x)}`).join(',')}, boss=${game.state.boss?.hp}`).not.toBeNull();
    expect(game.state.result?.won, `seed=${config.seed},mode=${config.modifier},room=${game.state.roomIndex},time=${game.state.time},hp=${game.state.hero.hp},falls=${game.state.deaths},position=${Math.round(game.state.hero.x)},alive=${game.state.enemies.filter(e => !e.dead).map(e => `${e.kind}@${Math.round(e.x)}`).join(',')},boss=${game.state.boss?.hp}`).toBe(true);
    expect(game.state.result?.roomsCleared).toBe(EXPEDITION_ROOM_COUNT);
    expect(game.state.roomIndex).toBe(EXPEDITION_ROOM_COUNT - 1);
    expect(visitedRealms).toEqual(expeditionOrder(config.seed));
    // Both real health bars must be defeated; strong builds may now burst a
    // form quickly, while separate no-attack tests exercise every boss move.
    expect(game.state.time - (bossStarted ?? 0)).toBeGreaterThan(BOSS_TRANSFORM_TIME);
    expect(secondFullHealthSeen).toBe(true);
    expect(game.state.boss!.form).toBe(2);
    expect(phaseTwoStarted).not.toBeNull();
    expect(game.state.time - (phaseTwoStarted ?? 0)).toBeGreaterThan(2);
    expect(phaseThreeStarted).not.toBeNull();
    expect(game.state.time - (phaseThreeStarted ?? 0)).toBeGreaterThanOrEqual(BOSS_ASCENSION_TIME);
    expect(game.state.boss!.attackCount).toBeGreaterThanOrEqual(1);
    // Strong builds can shorten a pattern; focused tests also exercise full releases.
    expect(bossIntentsSeen.size).toBeGreaterThanOrEqual(1);
    expect(warnedForms.size).toBeGreaterThanOrEqual(1);
    console.info(JSON.stringify({ seed: config.seed, modifier: config.modifier, route: visitedRealms, complete: game.state.result?.time,
      bossDuration: Math.round((game.state.time - (bossStarted ?? 0)) * 100) / 100, attacks: game.state.boss!.attackCount,
      hp: game.state.hero.hp, falls: game.state.deaths, attacksReleased: [...bossAttacksSeen], intents: [...bossIntentsSeen], phases: [phaseTwoStarted, phaseThreeStarted] }));
  }

  it('allows a standard run to be completed with movement, jumps and ranged attacks', () => {
    runInputOnly({ ...CONFIG, weapon: 'ember' });
  });

  it.each([
    { seed: 1, modifier: 'standard' as const },
    { seed: 7, modifier: 'moon' as const },
    { seed: 42, modifier: 'haste' as const },
    { seed: 20261116, modifier: 'moon' as const },
    { seed: 987654321, modifier: 'haste' as const },
  ])('completes route $seed in $modifier mode with the same input policy', ({ seed, modifier }) => {
    runInputOnly({ seed, modifier, weapon: 'ember' });
  });
});
