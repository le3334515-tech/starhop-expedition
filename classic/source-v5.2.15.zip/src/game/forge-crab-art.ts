import type { Enemy } from './types';

const METAL = {
  d: '#302b29', // soot in the joints
  b: '#483b34', // bronze shadow
  s: '#4e514a', // gunmetal
  i: '#66675a',
  w: '#8d8a75', // worn steel edge
  c: '#6f5140',
  o: '#8c644a', // tarnished copper
  a: '#a47b56',
  g: '#bca07a', // copper wear and rivets
  r: '#884b3a',
  f: '#be7950', // heat inside the grate
  p: '#e1a970',
} as const;

type PixelRun = readonly [color: string, x: number, y: number, length: number];

function patch(map: string): PixelRun[] {
  return map.trim().split(/\s+/).flatMap((row, y) =>
    [...row.matchAll(/(.)\1*/g)].flatMap(run => {
      const tone = METAL[run[1] as keyof typeof METAL];
      return tone ? [[tone, run.index, y, run[0].length] as const] : [];
    }));
}

const CARAPACE = patch(`
  .......dddd.............
  ......dboobd............
  ......dddbbdd...........
  .....dboaoacbdd.........
  ....dboboogacbbddd......
  ...dooossccobwccdss.....
  ..dooisiswsoobisssdd....
  .dcoossiwsoacosssbdd....
  .dboocissscowgccbbrbd...
  dcoocbsssscbacbrrfobod..
  dboocbbsssdcacdrfrcod...
  dccobdscscbbbrcfrbbcdd..
  dbcccdsoscbbccrfbrcbd...
  .ddccbbssdcobbdbcbdd....
  ..dbccddbbbbcbbbdsd.....
  ...dbbcdsdddbbcddd......
  ....dddsddd..dd.........
`);

const LEG_REAR = patch(`
  ...bds...
  ..dscid..
  ..dcbdd..
  .dcbdd...
  .dobd....
  dcbd.....
  ddbdd....
`);

const LEG_MIDDLE = patch(`
  dcobo..
  dccaab.
  .dcbdd.
  .dbcb..
  .dabc..
  .dbsd..
  ddbdds.
`);

const LEG_FRONT = patch(`
  .ddcbdd.
  dcbcabo.
  .dbcaid.
  ..dcbcd.
  ..dbcsd.
  ..dbicd.
  ..dddssd
`);

const PINCER_GUARD = patch(`
  .......wdd....
  .dd...iaodd...
  .dso.dcaaad...
  ..dbddoagob...
  ..dbboagocbd..
  ...dcaooisbdb.
  ...dbocswsbb..
  ....dcosibbd..
  ..ddboccdcbd..
  .dswcbdbdbd...
  ddbcsdbddd....
  dddbddd.......
`);

const PINCER_BACK = patch(`
  ....dd...
  ...dbid..
  ..dciod..
  .dbssd...
  .dscbd...
  .dbcd....
  ddbd.....
`);

const PINCER_STRIKE = patch(`
  .........dodd..
  ..dd...dcoagd..
  .dso.ddoagcwd..
  dsscdoaogobd...
  .dbccogcbbd....
  ..ddcobbbbdd...
  ...dbcasscbod..
  ....dbbbsidod..
  .....ddbdddd...
`);

const PINCER_FOLDED = patch(`
  ....dd.....
  .dddoob....
  .dbsscod...
  ..dccsabd..
  .dboaabbd..
  ..dcobdds..
  ...dddd....
`);

const HEAT = patch(`
  ..r.f..
  .rfprf.
  rfrrf..
  .rr....
`);

function paint(c: CanvasRenderingContext2D, sprite: PixelRun[], x: number, y: number) {
  for (const [color, dx, dy, length] of sprite) {
    c.fillStyle = color;
    c.fillRect(x + dx, y + dy, length, 1);
  }
}

/** Facing right beside the other co-op sprites, anchored at the ground. */
export function drawForgeCrab(c: CanvasRenderingContext2D, e: Enemy) {
  const strike = e.aiMode === 'attack';
  const brace = e.aiMode === 'windup';
  const exposed = e.aiMode === 'recover';
  const gait = Math.abs(e.vx) > 12 ? Math.floor(e.timer * 10) % 4 : -1;
  const lean = strike ? 2 : brace ? -1 : 0;
  const crouch = brace ? 1 : 0;
  paint(c, LEG_REAR, -14, -7 - Number(gait === 1 || gait === 2));
  paint(c, LEG_MIDDLE, -7, -7 - Number(gait === 0 || gait === 3));
  paint(c, LEG_FRONT, 0, -7 - Number(gait === 1));
  paint(c, PINCER_BACK, -14 + lean, -14 + crouch);
  paint(c, CARAPACE, -13 + lean, -22 + crouch);
  if (brace || exposed) paint(c, HEAT, 1 + lean, -13 + crouch);
  if (brace) paint(c, PINCER_GUARD, 5 + lean, -24);
  else if (strike) paint(c, PINCER_STRIKE, 3 + lean, -13);
  else if (exposed) paint(c, PINCER_FOLDED, 6 + lean, -7);
  else paint(c, PINCER_GUARD, 4 + lean, -16);
}
