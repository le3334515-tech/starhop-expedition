import { artImage } from './art-assets';
import type { Enemy } from './types';

const FRAME_W = 22;
const FRAME_H = 36;
const FRAMES = 6;

export function drawForgeLantern(c: CanvasRenderingContext2D, e: Enemy): boolean {
  const art = artImage('actors/forge-lantern.png');
  if (!art) return false;
  const casting = e.aiMode === 'attack' || e.aiMode === 'windup';
  const frame = Math.floor(e.timer * (casting ? 12 : 7)) % FRAMES;
  const y = Math.round(Math.sin(e.timer * 5)) - 32;
  c.drawImage(art, frame * FRAME_W, casting ? FRAME_H : 0, FRAME_W, FRAME_H, -11, y, FRAME_W, FRAME_H);
  if (casting) {
    c.fillStyle = '#d29060';
    c.fillRect(13, y + 17 - frame, 2, 1);
    c.fillStyle = '#a56450';
    c.fillRect(-13, y + 22 - frame, 1, 1);
    c.fillRect(15, y + 23 + frame, 1, 2);
  }
  return true;
}
