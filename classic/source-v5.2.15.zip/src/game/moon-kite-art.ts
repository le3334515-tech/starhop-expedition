import { artImage } from './art-assets';
import type { Enemy } from './types';

// The original flying-eye wing animation is from LuizMelo's CC0 Monsters
// Creatures Fantasy pack, already credited in docs/素材来源与许可.md.
// Copper bird armour and silk streamers are original project pixel work.
const wings = new Map<number, HTMLCanvasElement>();
const tones = ['#213638', '#2c4341', '#40584d', '#6a7053', '#818667', '#a0a285', '#b7b695'];
const paint: Record<string, string> = {
  d: '#243b3c', j: '#436354', o: '#6c8060', a: '#929a70',
  b: '#8b7756', c: '#ae9565', g: '#cfb06b', l: '#b6b28a',
};
const body = [
  '.........cc......',
  '.......cbbbc.....',
  '......cjbbbbl....',
  '.....cjjbbbbbc...',
  '....djjjbbbgcccc.',
  '...djjjjjbbgc....',
  '..djjjjjjjjbc....',
  '.ddjjjjjoojjbc...',
  '.ddjjjjoaaajjc...',
  '...dddjooaajcc...',
  '.....ddjooac.....',
  '.......djjc......',
] as const;

function pixel(c: CanvasRenderingContext2D, color: string, x: number, y: number, w = 1, h = 1) {
  c.fillStyle = color;c.fillRect(x, y, w, h);
}

function wingFrame(frame: number): HTMLCanvasElement | undefined {
  const cached = wings.get(frame);if(cached)return cached;
  const sprite=artImage('actors/eye-flight.png');if(!sprite)return;
  const canvas=document.createElement('canvas');canvas.width=canvas.height=40;
  const c=canvas.getContext('2d')!;c.imageSmoothingEnabled=false;
  c.drawImage(sprite,frame*150,0,150,150,-29,-30,98,98);
  const pixels=c.getImageData(0,0,40,40);
  for(let i=0;i<pixels.data.length;i+=4) {
    if(!pixels.data[i+3])continue;
    const value=pixels.data[i]*.213+pixels.data[i+1]*.715+pixels.data[i+2]*.072;
    const index=value<30?0:value<55?1:value<80?2:value<110?3:value<145?4:value<190?5:6;
    const tone=tones[index];
    pixels.data[i]=parseInt(tone.slice(1,3),16);pixels.data[i+1]=parseInt(tone.slice(3,5),16);pixels.data[i+2]=parseInt(tone.slice(5,7),16);
  }
  c.putImageData(pixels,0,0);wings.set(frame,canvas);return canvas;
}

/** Native 40 px raster coordinates: origin is CENTER=20, FOOT=36. */
export function drawMoonKite(c: CanvasRenderingContext2D,e: Enemy): void {
  const diving=e.aiMode==='attack',charging=e.aiMode==='windup';
  const frame=charging?0:diving?5:Math.floor(e.timer*10+e.id)%8;
  const wing=wingFrame(frame),lean=diving?2:charging?-1:0,bob=diving?2:charging?-1:0;
  c.save();c.imageSmoothingEnabled=false;
  if(wing)c.drawImage(wing,-20+lean,-36+bob);
  // The small asymmetric beak and breastplate replace the eye's large pale disk.
  for(let y=0;y<body.length;y++)for(let x=0;x<body[y].length;x++) {
    const color=paint[body[y][x]];if(color)pixel(c,color,x-4+lean,y-25+bob);
  }
  pixel(c,'#1e3638',7+lean,-21+bob,2,2);
  pixel(c,charging?'#d2b772':'#b7a16b',8+lean,-21+bob);
  pixel(c,'#90764f',11+lean,-19+bob,3,1);
  // Dark cloth, with one muted copper seam, remains separate from the wing feathers.
  const sway=diving?0:Math.round(Math.sin(e.timer*7));
  for(let step=0;step<8;step++) {
    const x=-4-step+(diving?Math.trunc(-step/3):0),y=-14+step+Math.round(sway*step/8);
    pixel(c,'#353b43',x,y,3,2);if(step%2===0)pixel(c,'#72715b',x+1,y);
  }
  for(let step=0;step<6;step++)pixel(c,'#3e5350',-1-step,-13+step-Math.round(sway*step/6),2,1);
  if(charging){pixel(c,'#a49266',-2,-17,3,1);pixel(c,'#7e8c67',-4,-15,2,2);}
  c.restore();
}
