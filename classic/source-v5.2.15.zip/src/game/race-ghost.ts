import type { RaceGhost } from '../race-types';
import { getCharacterWeapons, isCharacterId, type GameState, type Hero } from './types';
import { drawArtHero } from './actor-art';
import { drawCoopHero } from './coop-hero-art';
import { drawArtSlash } from './effect-art';

// Composite the complete costume once. Applying a live filter and a blur to
// each separate sword, cloth and spell draw is expensive on mobile canvases.
const size = { w: 304, h: 210, x: 152, foot: 148 };
let ghostLayer: CanvasRenderingContext2D | null = null;

/** Opponents are a render layer only. Never add them to collision or combat lists. */
export function drawRaceGhost(c: CanvasRenderingContext2D, state: GameState, remote: RaceGhost, now: number): void {
  if (remote.roomIndex !== state.roomIndex || remote.ageMs > 8000 || !['playing', 'paused', 'upgrade'].includes(remote.phase)) return;
  if (remote.x < state.cameraX - 100 || remote.x > state.cameraX + 1060) return;
  const character = isCharacterId(remote.character) ? remote.character : undefined;
  if (!ghostLayer) {
    const canvas = c.canvas.ownerDocument.createElement('canvas');
    canvas.width = size.w; canvas.height = size.h;
    ghostLayer = canvas.getContext('2d');
  }
  if (!ghostLayer) return;
  const layer = ghostLayer;
  const weapons = getCharacterWeapons(character);
  const weapon = weapons.includes(remote.weapon) ? remote.weapon : weapons[0];
  const hero: Hero = { ...state.hero, x: size.x - state.hero.w/2, y: size.foot - state.hero.h, vx: remote.vx, vy: remote.vy,
    facing: remote.facing, grounded: remote.grounded, weapon, level: remote.level,
    attackTimer: remote.attackTimer, attackStep: remote.attackStep, animation: remote.animation,
    hp: Math.max(1, remote.hp), maxHp: remote.maxHp, shield: 0, upgrades: [], invincible: 0,
    dashTimer: 0, swapBoost: 0, counterTimer: 0, guardTimer: 0 };
  layer.clearRect(0,0,size.w,size.h);
  layer.save();
  layer.imageSmoothingEnabled = false;
  if ((!character || !drawCoopHero(layer, character, hero, now, false)) && drawArtHero(layer, hero, now)) drawArtSlash(layer, hero, now);
  layer.globalCompositeOperation = 'source-atop';
  layer.fillStyle = 'rgba(158,213,202,.32)';
  layer.fillRect(0,0,size.w,size.h);
  layer.restore();
  c.save();
  const freshness = remote.ageMs <= 2000 ? 1 : Math.max(0, 1 - (remote.ageMs - 2000) / 6000);
  c.globalAlpha *= .38 * freshness;
  c.drawImage(layer.canvas,Math.round(remote.x + hero.w/2 - size.x),Math.round(remote.y + hero.h - size.foot));
  c.restore();
  c.save(); c.globalAlpha *= .8 * freshness; c.font = '10px "Microsoft YaHei", sans-serif';
  c.textAlign = 'center'; c.lineWidth = 3; c.strokeStyle = '#102a2e'; c.fillStyle = '#b7e2dc';
  const label = `${remote.name || '对手'} · 影`;
  c.strokeText(label, remote.x + hero.w / 2, remote.y - 23);
  c.fillText(label, remote.x + hero.w / 2, remote.y - 23);
  c.restore();
}
