// Only fixed, color-only filters are reused here. Glow and continuous fades
// stay on their live drawing paths rather than baking them into a sprite.
const LIMIT = 40;
const frames = new Map<string, HTMLCanvasElement>();
const sheetIds = new WeakMap<HTMLImageElement, number>();
let nextSheetId = 0;

export function drawTintedSprite(c: CanvasRenderingContext2D, image: HTMLImageElement, sourceX: number,
  width: number, height: number, x: number, y: number, displayWidth: number, displayHeight: number,
  filter: string, reuse: boolean) {
  if (reuse && filter && sourceX >= 0 && sourceX + width <= image.naturalWidth && height <= image.naturalHeight) {
    let id = sheetIds.get(image);
    if (id === undefined) {
      id = ++nextSheetId;
      sheetIds.set(image, id);
    }
    const key = `${id}/${sourceX}/${width}/${height}/${filter}`;
    let cached = frames.get(key);
    if (!cached) {
      const bitmap = document.createElement('canvas');
      bitmap.width = width;
      bitmap.height = height;
      const brush = bitmap.getContext('2d');
      if (brush) {
        brush.filter = filter;
        brush.drawImage(image, sourceX, 0, width, height, 0, 0, width, height);
        if (frames.size === LIMIT) frames.delete(frames.keys().next().value!);
        frames.set(key, bitmap);
        cached = bitmap;
      }
    }
    if (cached) {
      c.drawImage(cached, x, y, displayWidth, displayHeight);
      return;
    }
  }
  if (filter) c.filter = filter;
  c.drawImage(image, sourceX, 0, width, height, x, y, displayWidth, displayHeight);
  if (filter) c.filter = 'none';
}
