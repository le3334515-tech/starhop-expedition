import type { CharacterImpactSound } from './weapon-audio';

export const EXPEDITION_ROOM_COUNT = 8;
export const AWAKENING_DURATION = 6;
export const CHARACTER_IDS = ['traveller', 'blade', 'staff', 'wheel', 'spear', 'monk'] as const;
export type CharacterId = typeof CHARACTER_IDS[number];
export const isCharacterId = (value: unknown): value is CharacterId =>
  CHARACTER_IDS.some(character => character === value);
export const SOLO_WEAPON_IDS = ['blade', 'ember', 'disc'] as const;
type SoloWeaponId = typeof SOLO_WEAPON_IDS[number];
export type WeaponArchetype = SoloWeaponId | 'spear' | 'fan' | 'sabre' | 'fist';
export const CHARACTER_WEAPONS = {
  blade: ['blade', 'willowSword', 'swallowDart'],
  staff: ['ember', 'frostStaff', 'moonMirror'],
  wheel: ['fan', 'jadeNeedle', 'silkFan'],
  spear: ['spear', 'reedJavelin', 'halberd'],
  traveller: ['blade', 'ember', 'disc'],
  monk: ['fist', 'ironGauntlet', 'prayerBeads'],
} as const satisfies Record<CharacterId, readonly [string, string, string]>;
export type WeaponId = WeaponArchetype | (typeof CHARACTER_WEAPONS)[CharacterId][number];
export function getCharacterWeapons(character?: CharacterId | null): readonly WeaponId[] {
  return character ? CHARACTER_WEAPONS[character] : SOLO_WEAPON_IDS;
}
export function isLoadoutWeapon(character: CharacterId | null | undefined, value: unknown): value is WeaponId {
  return getCharacterWeapons(character).some(id => id === value);
}
export function isWeaponId(value: unknown): value is WeaponId {
  return typeof value === 'string' && Object.hasOwn(WEAPONS, value);
}

export const isSoloWeapon = (id: WeaponId): id is SoloWeaponId =>
  SOLO_WEAPON_IDS.some(weapon => weapon === id);
export type ModifierId = 'standard' | 'moon' | 'haste' | 'iron';
export type Phase = 'menu' | 'playing' | 'paused' | 'upgrade' | 'victory' | 'gameover';
export type SoundName = CharacterImpactSound | 'jump' | 'doubleJump' | 'attack' | 'fire' | 'coin' | 'hurt' | 'kill' | 'upgrade' | 'portal' | 'boss' | 'win' | 'lose' | 'dash' | 'select' | 'awaken' | 'synergy' | 'hit' | 'critical' | 'heavy' | 'guardBreak' | 'perfectDodge';

export interface Rect { x: number; y: number; w: number; h: number }
export interface Vec { x: number; y: number }
export interface Platform extends Rect { kind: 'ground' | 'stone' | 'wood' | 'spring'; oneWay?: boolean }
export interface RealmTrap extends Rect { kind: 'mechanism'; theme: number; offset: number }
export type Hazard = (Rect & { kind: 'spikes' | 'lava' }) | RealmTrap;
export interface Decoration { x: number; y: number; kind: 'tree' | 'ruin' | 'lamp' | 'mushroom' | 'grass' | 'crystal'; scale?: number }
export interface Enemy extends Rect {
  id: number; kind: 'slime' | 'bat' | 'sentry'; vx: number; vy: number; hp: number; maxHp: number;
  facing: number; timer: number; hurt: number; dead: boolean; originX: number; originY: number; attackCooldown: number;
  variant?: string; skin?: string; aiMode?: 'patrol' | 'windup' | 'attack' | 'recover'; aiTimer?: number; aiCount?: number; targetX?: number; targetY?: number;
  attackCue?: { at: number; x: number; y: number; facing: number; angle: number; duration: number };
  burnTime?: number; burnTick?: number; burnDamage?: number;
  emberMark?: number; nextMechanismHit?: number; comboStagger?: number;
}
export interface Boss extends Rect {
  kind?: 'warden';
  hp: number; maxHp: number; phase: number; mode: 'idle' | 'windup' | 'charge' | 'jump' | 'slam' | 'recover' | 'dead' | 'transition' | 'barrage' | 'stagger';
  timer: number; vx: number; vy: number; facing: number; hurt: number; attackCount: number; active: boolean;
  intent: 'charge' | 'leap' | 'slam' | 'barrage' | 'rift' | 'rain' | 'eclipse'; targetX: number; chain: number;
  guard: number; maxGuard: number; exposed: number;
  form?: 1 | 2; burnTime?: number; burnTick?: number; burnDamage?: number;
}
export interface Projectile extends Rect {
  id: number; kind: 'ember' | 'disc' | 'fan' | 'enemy' | 'shockwave' | 'rift'; vx: number; vy: number; life: number;
  weapon?: WeaponId; ownerCharacter?: CharacterId; returnAt?: number;
  enemyVariant?: string; sourceEnemyId?: number;
  damage: number; owner: 'hero' | 'enemy'; hitIds: number[]; returning?: boolean; rotation?: number;
  style?: 'charged' | 'ink' | 'reflected' | 'eclipse' | 'court-quake' | 'court-cleave'; pierce?: number; burn?: number; delay?: number; gravity?: number; color?: string;
  primesEmber?: boolean; finishingThrow?: boolean;
}
export interface Pickup extends Rect { id: number; kind: 'coin' | 'xp' | 'heart'; value: number; vy: number; bob: number; collected: boolean }
export interface Particle { x: number; y: number; vx: number; vy: number; life: number; maxLife: number; size: number; color: string; gravity?: number }
export interface FloatingText { x: number; y: number; text: string; color: string; life: number; maxLife: number }
export interface WeaponContact {
  character: Exclude<CharacterId, 'traveller'>;
  weapon: WeaponId;
  facing: number;
  accent: boolean;
}
export interface Impact { contact?: WeaponContact; enemyVariant?: string; x: number; y: number; life: number; maxLife: number; size: number; angle: number; color: string; kind: 'hit' | 'critical' | 'heavy' | 'break' }
export type BuffEffectKind = 'gildedSwitch' | 'thirdStar' | 'afterimage' | 'jadeParry' | 'jadeSpring' | 'landingSeal';
export interface BuffEffect { kind: BuffEffectKind; x: number; y: number; facing: number; life: number; duration: number }
export interface DodgeCue { x: number; y: number; facing: number; life: number }
export interface Hero extends Rect {
  dodgeCue?: DodgeCue;
  vx: number; vy: number; facing: number; hp: number; maxHp: number; xp: number; xpNeeded: number; level: number;
  grounded: boolean; jumps: number; coyote: number; jumpBuffer: number; invincible: number;
  attackTimer: number; attackCooldown: number; dashTimer: number; dashCooldown: number; weapon: WeaponId;
  damage: number; speed: number; attackSpeed: number; critChance: number; extraProjectiles: number;
  lifesteal: number; magnet: number; shield: number; upgrades: string[]; animation: number;
  attackStep: number; comboWindow: number; swapBoost: number; swapCooldown: number; counterTimer: number; perfectDodgeCooldown: number;
  guardTimer: number; guardCooldown: number;
  buffEffects?: BuffEffect[];
}
export interface Room {
  index: number; name: string; subtitle: string; width: number; height: number; theme: number;
  platforms: Platform[]; hazards: Hazard[]; decorations: Decoration[];
  spawn: Vec; exit: Rect; checkpoint: Vec; isBoss: boolean;
}
export interface Upgrade { id: string; name: string; description: string; icon: string; rarity: 'common' | 'rare' | 'epic'; color: string }
export interface Synergy { id: string; name: string; description: string; requires: string[]; color: string }
export interface GameConfig { seed: number; modifier: ModifierId; weapon: WeaponId; character?: CharacterId; buffSeed?: number }
export interface GameResult extends GameConfig {
  won: boolean; time: number; score: number; coins: number; kills: number; level: number;
  deaths: number; roomsCleared: number; maxCombo: number; upgrades: string[]; overdriveCount: number; synergies: string[];
}
export interface InputState {
  left: boolean; right: boolean; jumpPressed: boolean; jumpHeld: boolean;
  attackPressed: boolean; attackHeld: boolean; dashPressed: boolean; interactPressed: boolean; overdrivePressed: boolean;
  guardPressed?: boolean; dropPressed?: boolean;
}
export interface GameState {
  phase: Phase; seed: number; modifier: ModifierId; roomIndex: number; roomCount: number; room: Room;
  hero: Hero; enemies: Enemy[]; boss: Boss | null; projectiles: Projectile[]; pickups: Pickup[];
  particles: Particle[]; floatingTexts: FloatingText[]; cameraX: number; time: number; visualTime: number;
  coins: number; kills: number; deaths: number; combo: number; maxCombo: number; comboTimer: number;
  roomCleared: boolean; roomsCleared: number; upgradeChoices: Upgrade[];
  shake: number; flash: number; transition: number; announcement: string; announcementTimer: number;
  result: GameResult | null;
  resonance: number; overdrive: number; overdriveCount: number; synergies: string[];
  hitstop: number; impacts: Impact[];
  character?: CharacterId;
  coopPartySize?: number;
}
export interface EngineCallbacks { sound?: (name: SoundName) => void }
export const EMPTY_INPUT: InputState = { left: false, right: false, jumpPressed: false, jumpHeld: false, attackPressed: false, attackHeld: false, dashPressed: false, interactPressed: false, overdrivePressed: false, guardPressed: false, dropPressed: false };

/** Weapons awaken new moves as the current run grows. */
export function weaponTier(hero: Pick<Hero, 'level'>): number { return hero.level >= 7 ? 3 : hero.level >= 4 ? 2 : 1; }

export interface WeaponTuning {
  damage?: number; reach?: number; cooldown?: number; speed?: number;
  shots?: number; spread?: number; pierce?: number;
}
export interface WeaponDefinition {
  name: string; subtitle: string; description: string; color: string; icon: string;
  archetype: WeaponArchetype; tuning?: WeaponTuning;
}
export const WEAPONS: Record<WeaponId, WeaponDefinition> = {
  blade: { archetype: 'blade', name: '星陨短刃', subtitle: '近战 · 迅捷连斩', description: '挥出弧形剑气，近身攻击更强。', color: '#7de7cf', icon: 'blade' },
  ember: { archetype: 'ember', name: '萤火法杖', subtitle: '远程 · 贯穿焰爆', description: '追踪贯穿并引爆灼烧，每第三次施放为蓄能重弹；二阶增加一道星焰，三阶贯穿更多敌人。', color: '#ffb474', icon: 'ember' },
  disc: { archetype: 'disc', name: '回声飞轮', subtitle: '投掷 · 双轮回锋', description: '双轮往返穿透，回程伤害提升45%；二阶三轮齐出，三阶可击碎敌方飞弹。命中回收积攒星能。', color: '#b7afff', icon: 'disc' },
  spear: { archetype: 'spear', name: '金霆长枪', subtitle: '中距 · 贯穿破甲', description: '向前穿刺一列敌人；第三击为破甲重刺。格挡反击时枪锋伸得更远。', color: '#efd68e', icon: 'spear', tuning: { damage: 1.71, cooldown: .88 } },
  fan: { archetype: 'fan', name: '青羽折扇', subtitle: '远程 · 扇锋穿击', description: '向身前挥出飞掠的扇锋；第三扇更宽，能贯穿更多敌人并削减首领护甲。', color: '#a0ddbb', icon: 'fan', tuning: { damage: 1.36, cooldown: .94 } },
  sabre: { archetype: 'sabre', name: '游侠长刀', subtitle: '近战 · 广角重斩', description: '大幅挥斩，覆盖比短刃更广；第三刀横扫一列敌人。', color: '#dc9da7', icon: 'blade' },
  fist: { archetype: 'fist', name: '镇岳拳', subtitle: '贴身 · 快拳震击', description: '两记快拳接一记重拳。第三拳范围更大，并削减首领护甲。', color: '#efad72', icon: 'fist', tuning: { damage: 1.44 } },
  willowSword: { name: '柳叶软剑', subtitle: '近战 · 快刺', description: '剑身细长，比短刃刺得更远，出手更快，单击较轻。', color: '#b9d79d', icon: 'willowSword', archetype: 'blade', tuning: { damage: 1.02, reach: 1.23, cooldown: .82 } },
  swallowDart: { name: '归燕镖', subtitle: '投掷 · 疾返', description: '燕形飞镖掠过敌阵后折返。弹速快，单次伤害较低，适合边移动边消耗。', color: '#daa47a', icon: 'swallowDart', archetype: 'disc', tuning: { damage: .82, speed: 1.25, cooldown: .87 } },
  frostStaff: { name: '霜枝杖', subtitle: '远程 · 霜矢', description: '杖端连发两道霜光，分击前方目标。每道威力较轻。', color: '#a4d8ec', icon: 'frostStaff', archetype: 'ember', tuning: { damage: .66, speed: 1.10, shots: 1, spread: 1.28, cooldown: 1.15 } },
  moonMirror: { name: '照月镜', subtitle: '法器 · 贯阵', description: '举镜照出一束银辉，出手稍缓，能穿过数名敌人。', color: '#dccce7', icon: 'moonMirror', archetype: 'fan', tuning: { damage: 1.69, speed: .90, cooldown: 1.29, pierce: 2 } },
  jadeNeedle: { name: '翠翎针', subtitle: '暗器 · 速射', description: '以袖中翠针点射远敌。针行得快，出手间隔短。', color: '#a5dfcd', icon: 'jadeNeedle', archetype: 'ember', tuning: { damage: .90, speed: 1.30, cooldown: .80 } },
  silkFan: { name: '裁风翎刃', subtitle: '远程 · 双刃', description: '甩出两道错高飞行的青玉翎刃，扫过高低不同的目标。', color: '#a8d8ba', icon: 'wingBlade', archetype: 'fan', tuning: { damage: .84, shots: 1, spread: 1.52, speed: .86, cooldown: 1.21 } },
  reedJavelin: { name: '芦影标枪', subtitle: '投掷 · 贯刺', description: '向前掷出一支细长标枪，穿过前排直取后方。', color: '#b1cfad', icon: 'reedJavelin', archetype: 'fan', tuning: { damage: 1.58, speed: 1.35, pierce: 1, cooldown: 1.10 } },
  halberd: { name: '断岳戟', subtitle: '长柄 · 重击', description: '长戟出招较慢，戟锋探得更远，重击威力更高。', color: '#e5b47a', icon: 'halberd', archetype: 'spear', tuning: { damage: 2.28, reach: 1.22, cooldown: 1.18 } },
  ironGauntlet: { name: '伏虎铁拳', subtitle: '贴身 · 重拳', description: '铁拳套扩大击打距离，牺牲出手速度换取重击。', color: '#dc996c', icon: 'ironGauntlet', archetype: 'fist', tuning: { damage: 2.07, reach: 1.18, cooldown: 1.31 } },
  prayerBeads: { name: '回山佛珠', subtitle: '法器 · 散投', description: '掷出三枚环回的念珠，覆盖身前一片区域，每颗伤害较轻。', color: '#d8ba85', icon: 'prayerBeads', archetype: 'disc', tuning: { damage: .67, shots: 1, speed: .91, spread: 1.35, cooldown: 1.15 } },
};
export const MODIFIERS: Record<ModifierId, { name: string; tag: string; description: string; icon: string }> = {
  standard: { name: '经典远征', tag: 'STANDARD', description: '按标准战斗规则探索八境。', icon: 'star' },
  moon: { name: '月球漫步', tag: 'LOW GRAVITY', description: '重力降低，跳得更高，滞空更久。', icon: 'moon' },
  haste: { name: '极速派对', tag: 'HYPER SPEED', description: '你和敌人都会加速。', icon: 'bolt' },
  iron: { name: '一命之约', tag: 'ONE HEART', description: '开局只有一颗心，生命上限也是一颗心。', icon: 'heart' },
};
