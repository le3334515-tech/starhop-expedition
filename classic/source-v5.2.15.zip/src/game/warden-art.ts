import { artImage } from './art-assets';
import { ascensionProgress, BOSS_ASCENSION_IMPACT, BOSS_ASCENSION_TIME, BOSS_TRANSFORM_TIME, ease, ECLIPSE_WINDUP, openingAscension, openingSeal, sealProgress } from './boss-seal';
import { drawWardenSword } from './warden-vfx';
import type { Boss } from './types';

const CELL_W = 144, CELL_H = 94, PIVOT_X = 54, PIVOT_Y = 89;
const TEMPER_AT = 2.04 / BOSS_TRANSFORM_TIME;
const ASCEND_AT = BOSS_ASCENSION_IMPACT / BOSS_ASCENSION_TIME;
const TAU = Math.PI * 2;
const clamp = (n: number, low = 0, high = 1) => Math.max(low, Math.min(high, n));
const count = { idle: 11, run: 8, jump: 3, fall: 3, strike: 7, cleave: 7, hurt: 4, death: 11 };
type Motion = keyof typeof count;
const deaths = new WeakMap<Boss, number>();

type Cinematic = { progress: number; impact: number };
function cinematic(b: Boss): Cinematic | null {
  if (openingSeal(b)) return { progress: sealProgress(b), impact: TEMPER_AT };
  if (openingAscension(b)) return { progress: ascensionProgress(b), impact: ASCEND_AT };
  return null;
}

function pose(b: Boss, now: number, scene: Cinematic | null): [Motion, number] {
  if (scene) {
    if (scene.progress < scene.impact) return ['strike', 1];
    return ['idle', Math.floor(now * 7) % count.idle];
  }
  if (b.mode === 'dead') {
    if (!deaths.has(b)) deaths.set(b, now);
    return ['death', Math.min(count.death - 1, Math.floor((now - deaths.get(b)!) * 10))];
  }
  deaths.delete(b);
  if (b.mode === 'windup') {
    const duration = b.intent === 'eclipse' ? ECLIPSE_WINDUP : .82 - (b.phase - 1) * .17;
    const close = b.intent === 'leap' || b.intent === 'slam' || b.intent === 'rift';
    return [close ? 'strike' : 'cleave', Math.floor(clamp(1 - b.timer / duration) * 2.9)];
  }
  if (b.mode === 'charge') return ['run', Math.floor(now * 21) % count.run];
  if (b.mode === 'jump') {
    return [b.vy < 0 ? 'jump' : 'fall', Math.min(2, Math.floor(Math.abs(b.vy) / 175))];
  }
  if (b.mode === 'slam') return ['strike', 3 + Math.min(3, Math.floor(clamp(1 - b.timer / .12) * 4))];
  if (b.mode === 'barrage') return ['cleave', 3 + Math.floor(now * 17) % 4];
  if (b.mode === 'stagger' || b.hurt > .065) return ['hurt', b.mode === 'stagger' ? 3 : 2];
  return ['idle', Math.floor(now * (b.mode === 'recover' ? 5 : 8)) % count.idle];
}

function orbit(c: CanvasRenderingContext2D, x: number, y: number, radius: number, depth: number, tone: string) {
  c.strokeStyle = tone; c.lineWidth = 1;
  c.beginPath(); c.ellipse(x, y, radius, depth, 0, 0, TAU); c.stroke();
}

function crown(c: CanvasRenderingContext2D, y: number, glow: number) {
  c.save(); c.translate(0, y);
  c.strokeStyle = '#c29b6a'; c.lineWidth = 1;
  c.globalAlpha = glow * .64;
  c.beginPath(); c.arc(0, 0, 44, Math.PI, TAU); c.stroke();
  c.fillStyle = '#302b2d'; c.globalAlpha = glow;
  c.fillRect(-24,-6,48,9); c.fillRect(-4,-29,8,25);
  for (const side of [-1,1]) {
    c.fillRect(side * 17-3,-21,6,16);
    c.fillRect(side * 25-1,-15,3,12);
  }
  c.fillStyle = '#d6b578';
  c.fillRect(-23,-6,46,2); c.fillRect(-20,0,40,2);
  c.fillRect(-2,-25,4,17); c.fillRect(-1,-30,2,5);
  c.fillRect(-18,-21,2,16); c.fillRect(16,-21,2,16);
  c.fillRect(-24,-14,2,11); c.fillRect(22,-14,2,11);
  c.fillStyle = '#f2deb0'; c.fillRect(-2,-30,4,3);
  c.restore();
}

export function drawWardenBackdrop(c: CanvasRenderingContext2D, b: Boss, now: number, reduce: boolean) {
  const x = Math.round(b.x + b.w / 2), foot = Math.round(b.y + b.h);
  const scene = cinematic(b);
  const final = b.phase === 3;
  const tone = final ? '#d9b678' : b.phase === 2 ? '#bc7a63' : '#a3b99f';
  c.save(); c.translate(x,foot);
  if (scene) {
    const { progress, impact } = scene;
    const rise = ease(.03, impact, progress);
    const release = ease(impact, 1, progress);
    const energy = ease(0,.16,progress);
    const cold = final ? '#a89176' : '#89a697';
    // All six blades move to the core before dispersing into the next form.
    for (let i = 0; i < 6; i++) {
      const direction = i % 2 ? 1 : -1, row = Math.floor(i / 2);
      const startX = direction * (168 - row * 24), startY = -97 - row * 35;
      const px = startX * (1 - rise) + direction * (30 + row * 12) * rise;
      const py = startY * (1 - rise) - (86 + row * 14) * rise;
      const exitX = direction * (66 + row * 27), exitY = -104 - row * 18;
      const sx = px * (1 - release) + exitX * release;
      const sy = py * (1 - release) + exitY * release;
      const angle = Math.atan2(px,-82-py) * (1-release) + direction * (.62 + row*.15) * release;
      const length = (final ? 63 : 54) - row * 7;
      if (!reduce) {
        c.globalAlpha = .28 * energy * (1 - release);
        c.strokeStyle = cold;
        c.setLineDash([5,6]);
        c.beginPath(); c.moveTo(startX,startY);
        c.quadraticCurveTo((startX+sx)*.55,sy-40,sx,sy); c.stroke();
        c.setLineDash([]);
      }
      c.globalAlpha = energy * (reduce ? .70 : .96) * (1 - release * (final ? .22 : .48));
      drawWardenSword(c,sx,sy,length,angle,progress<impact?cold:tone,final);
    }
    for (let i = 0; i < (reduce ? 2 : 3); i++) {
      const radius = 51 + i * 15 + release * (107 + i * 16);
      c.globalAlpha = (.70 - i * .16) * (1 - release) * energy;
      orbit(c,0, -2 - i * 3,radius,radius*.16,tone);
      if (i === 0) for (const side of [-1,1]) {
        c.fillStyle = tone;
        c.fillRect(side * radius * .91-3,-8,6,2);
      }
    }
    if (final && progress >= impact) crown(c,-126,ease(0,.45,release));
    if (!reduce) {
      const strike = 1 - ease(0,.11,Math.abs(progress-impact));
      c.fillStyle = '#dfbb82'; c.globalAlpha = strike * .42;
      c.fillRect(-3,-225,6,220); c.fillRect(-18,-74,36,3);
      for (let i = 0; i < 20; i++) {
        const angle = i * 2.399;
        const range = 24 + i * 3 + release * (65 + i * 2);
        const y = -12 + Math.sin(angle) * range * .57 - release * 58;
        c.globalAlpha = energy * (1 - release) * (i%4===0 ? .78 : .42);
        c.fillStyle = i%3===0 ? '#ead2a3' : tone;
        c.fillRect(Math.round(Math.cos(angle)*range),Math.round(y),i%3===0?3:2,i%2===0?6:3);
      }
    }
    c.restore();
    return;
  }
  if (!b.active || b.mode === 'dead') { c.restore(); return; }
  const raised = b.mode === 'windup' || b.mode === 'barrage' || b.mode === 'slam';
  if (b.phase === 1) {
    if (raised) {
      c.globalAlpha = .44; orbit(c,0,-2,68,11,tone);
      c.fillStyle = tone; c.fillRect(-68,-4,4,4); c.fillRect(64,-4,4,4);
    }
    c.restore();
    return;
  }
  const stagger = b.mode === 'stagger';
  const charging = b.mode === 'charge';
  c.globalAlpha = stagger ? .24 : raised ? .91 : .61;
  for (let i = 0; i < (final ? 6 : 4); i++) {
    const side = i % 2 ? 1 : -1, row = Math.floor(i / 2);
    const sway = reduce ? 0 : Math.round(Math.sin(now * 3 + i) * 4);
    const bladeX = side * (65 + row * 21 + (raised?10:0));
    const bladeY = -102 - row*17 + sway + (stagger?12:0);
    drawWardenSword(c,bladeX,bladeY,(final?53:42)-row*4,
      charging ? (b.facing||1)*-.92 : side*(raised?.54:.74+row*.14),tone,final);
  }
  if (final) {
    crown(c,-126,stagger?.42:.81);
    c.globalAlpha = raised ? .56 : .34;
    orbit(c,0,-3,80,12,tone); orbit(c,0,-4,99,16,'#995f50');
  }
  if (!reduce && !stagger) {
    for (let i = 0; i < (final ? 14 : 8); i++) {
      const elapsed = (now * (.65 + i%3*.14) + i * .17) % 1;
      const side = i%2 ? 1 : -1;
      const radius = (final?57:46) + i*3 + Math.sin(i*2.4)*11;
      const py = -4 - elapsed * (final?86:55);
      c.globalAlpha = (1-elapsed) * (raised?.65:.42);
      c.fillStyle = i%3===0 ? '#ead3a1' : tone;
      c.fillRect(Math.round(side*(radius+elapsed*13)),Math.round(py),2,i%4===0?5:3);
    }
  }
  c.restore();
}

function drawWardenSilhouette(c: CanvasRenderingContext2D, phase: number) {
  const ink = '#191f20';
  const trim = phase === 3 ? '#c8ac6f' : phase === 2 ? '#9b7249' : '#75867e';
  const armor = phase === 3 ? '#514939' : phase === 2 ? '#503733' : '#3b5050';
  const mantle = phase === 3 ? '#673b2d' : phase === 2 ? '#773942' : '#4c403b';
  c.fillStyle = mantle;
  c.beginPath();
  c.moveTo(-8, -40); c.lineTo(-19, -33); c.lineTo(-26, -12); c.lineTo(-30, -8);
  c.lineTo(-21, -6); c.lineTo(-18, -8); c.lineTo(-8, -5); c.lineTo(0, -28); c.closePath(); c.fill();
  c.fillStyle = ink;
  c.fillRect(-9, -19, 9, 15); c.fillRect(-10, -5, 13, 5);
  c.fillRect(4, -20, 9, 17); c.fillRect(4, -5, 15, 5);
  c.beginPath();
  c.moveTo(-8, -42); c.lineTo(5, -42); c.lineTo(12, -34); c.lineTo(12, -19);
  c.lineTo(-10, -21); c.lineTo(-12, -33); c.closePath(); c.fill();
  c.fillStyle = armor;
  c.fillRect(-8, -35, 18, 14);
  c.fillRect(-11, -32, 4, 8); c.fillRect(7, -31, 9, 8);
  c.fillStyle = ink;
  c.beginPath();
  c.moveTo(-10, -42); c.lineTo(-11, -52); c.lineTo(-7, -58); c.lineTo(-2, -57);
  c.lineTo(1, -61); c.lineTo(4, -56); c.lineTo(8, -53); c.lineTo(9, -44);
  c.lineTo(4, -39); c.lineTo(-5, -39); c.closePath(); c.fill();
  c.fillStyle = armor;
  c.fillRect(-8, -50, 15, 8);
  c.fillStyle = trim;
  c.fillRect(-7, -48, 15, 2); c.fillRect(-7, -55, 2, 5); c.fillRect(2, -56, 3, 5);
  c.fillRect(-13, -36, 12, 3); c.fillRect(-6, -24, 15, 2);
  c.fillStyle = ink;
  c.fillRect(15, -30, 10, 5); c.fillRect(22, -34, 4, 12);
  c.fillStyle = trim;
  c.beginPath();
  c.moveTo(25, -30); c.lineTo(44, -28); c.lineTo(56, -18); c.lineTo(46, -18);
  c.lineTo(24, -24); c.closePath(); c.fill();
}

export function drawWardenArt(c: CanvasRenderingContext2D, b: Boss, now: number): boolean {
  const scene = cinematic(b);
  const [motion, frame] = pose(b, now, scene);
  const motionArt = artImage(`actors/warden-${motion}.png`);
  const art = motionArt ?? artImage('actors/warden-idle.png');
  const frameIndex = motionArt ? frame : Math.floor(now * 7) % count.idle;
  const phase = scene && scene.progress < scene.impact ? b.phase - 1 : b.phase;
  const scale = b.h / 52;
  const foot = b.y + b.h - (scene ? Math.round(Math.sin(scene.progress * Math.PI) * 17) : 0);
  const x = b.x + b.w / 2;
  c.save();
  c.translate(Math.round(x), Math.round(foot));
  c.scale((b.facing || -1) * (1 + (phase - 1) * .065), 1);
  c.imageSmoothingEnabled = false;
  if (b.hurt > .085 && b.mode !== 'dead') c.filter = 'brightness(1.42) saturate(.65)';
  if (art) {
    c.drawImage(art, frameIndex * CELL_W, (phase - 1) * CELL_H, CELL_W, CELL_H,
      -Math.round(PIVOT_X * scale), -Math.round(PIVOT_Y * scale),
      Math.round(CELL_W * scale), Math.round(CELL_H * scale));
  } else {
    c.scale(scale, scale);
    drawWardenSilhouette(c, phase);
  }
  c.restore();
  return true;
}
