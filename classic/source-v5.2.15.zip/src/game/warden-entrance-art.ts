import { ease, entranceProgress, WARDEN_LANDING_FRACTION as LAND } from './boss-seal';
import type { Boss } from './types';
import { drawWardenArt } from './warden-art';

const TAU = Math.PI * 2;

function pixelDisk(c: CanvasRenderingContext2D, x: number, y: number, radius: number, color: string) {
  c.fillStyle = color;
  for (let dy = -radius; dy <= radius; dy += 2) {
    const half = Math.floor(Math.sqrt(radius * radius - dy * dy) / 2) * 2;
    c.fillRect(Math.round(x - half), Math.round(y + dy), half * 2, 2);
  }
}

function eclipse(c: CanvasRenderingContext2D, progress: number, quiet: boolean) {
  const rise = quiet ? 1 : ease(.02, .42, progress);
  const y = -198 - Math.round(rise * 17);
  const visible = ease(0, .16, progress) * (1 - ease(.76, 1, progress));
  c.save();
  c.globalAlpha = visible;
  pixelDisk(c, 0, y, 56, '#512731');
  pixelDisk(c, 0, y, 50, '#ad574d');
  pixelDisk(c, 0, y, 47, '#cf7860');
  pixelDisk(c, quiet ? 4 : 22 - rise * 19, y - 3, 45, '#271e2a');
  // Long pixel-thin streaks descend from the rim like ink bleeding through silk.
  c.fillStyle = '#713941';
  for (const [x, dy, length] of [[-38, 34, 31], [-24, 47, 47], [7, 50, 30], [31, 39, 37]]) {
    c.fillRect(x, y + dy, 2, Math.ceil(length * rise));
  }
  c.restore();
}

function chainLink(c: CanvasRenderingContext2D, x: number, y: number, slope: number, edgeOn: boolean) {
  c.save();
  c.translate(Math.round(x), Math.round(y));
  c.rotate(slope);
  const h = edgeOn ? 2 : 5;
  c.fillStyle = '#281b26';
  c.fillRect(-9, -h, 18, h * 2 + 1);
  c.fillStyle = '#825449';
  c.fillRect(-7, -h, 14, 2);
  c.fillRect(-7, h - 1, 14, 2);
  c.fillStyle = '#cc9574';
  c.fillRect(-6, -h, 11, 2);
  c.fillRect(6, 1 - h, 2, h + 2);
  c.fillStyle = '#ad715d';
  c.fillRect(-9, 1 - h, 2, h * 2 - 1);
  c.restore();
}

function sealChains(c: CanvasRenderingContext2D, p: number, quiet: boolean) {
  const opacity = ease(.04, .22, p) * (1 - ease(.72, .86, p));
  const release = ease(LAND - .012, .82, p);
  c.save();
  c.globalAlpha = opacity;
  for (const side of [-1, 1]) {
    for (let k = 0; k < 2; k++) {
      const tilt = k ? -.57 : .14;
      // The outer eight links fly clear at landing while two stay on the cuff.
      for (let i = 0; i < 10; i++) {
        const broken = i >= 2 ? release : 0;
        const x = side * (32 + 14 * i + broken * (quiet ? 14 : 36 + i));
        const y = -72 - k * 17 + tilt * 14 * i + broken * (quiet ? 0 : k ? -24 : 15);
        chainLink(c, x, y, side * (tilt + (quiet ? 0 : broken * (k ? -.18 : .16))), i % 2 !== 0);
      }
      const flare = ease(LAND - .035, LAND, p) * (1 - ease(LAND, LAND + .11, p));
      if (flare > 0) {
        c.save();
        c.translate(side * 55, -72 - k * 17 + tilt * 23);
        c.scale(side, 1);
        c.globalAlpha *= flare;
        c.fillStyle = '#e6a16b';
        for (const [x, y, w] of [[-8,-9,6],[1,-15,3],[7,-5,10],[6,6,6],[-1,11,3]]) c.fillRect(x, y, w, 3);
        c.fillStyle = '#ffddb0';
        c.fillRect(-3, -3, 7, 5);
        c.restore();
      }
    }
  }
  c.restore();
}

function groundSeal(c: CanvasRenderingContext2D, p: number, quiet: boolean) {
  const arrival = ease(.1, .48, p);
  const strike = ease(LAND - .025, LAND + .09, p);
  const release = 1 - ease(.79, 1, p);
  const radius = 42 + (quiet ? 45 : 38 * arrival + 96 * strike);
  c.save();
  c.globalAlpha = arrival * release;
  c.lineWidth = 2;
  for (let i = 0; i < 2; i++) {
    c.strokeStyle = i ? '#c47d60' : '#783b46';
    c.beginPath();
    c.ellipse(0, -3, radius - i * 12, 10 + i * 7, 0, 0, TAU);
    c.stroke();
  }
  c.globalAlpha *= strike;
  for (const side of [-1, 1]) {
    c.fillStyle = '#bd7360';
    for (let j = 0; j < 7; j++) {
      const x = side * Math.round(20 + j * (radius - 14) / 7);
      const y = -2 - [0, 3, 2, 4, 1, 3, 2][j];
      c.fillRect(x, y, 9, 2);
    }
  }
  c.restore();
}

/** World coordinates use only the replicated boss clock, including on reconnect. */
export function drawWardenEntrance(c: CanvasRenderingContext2D, b: Boss, quiet: boolean) {
  const p = entranceProgress(b);
  c.save();
  c.translate(Math.round(b.x + b.w / 2), Math.round(b.y + b.h));
  eclipse(c, p, quiet);
  groundSeal(c, p, quiet);
  sealChains(c, p, quiet);
  c.restore();

  // Start with the selected knight's actual silhouette. The sword and mantle
  // become readable as the seal splits, before the first combat windup begins.
  const reveal = ease(.37, .76, p);
  const drop = quiet ? 0 : 35 * (1 - ease(.48, LAND, p));
  c.save();
  c.translate(0, -Math.round(drop));
  c.globalAlpha = ease(.08, .3, p);
  c.filter = `brightness(${.15 + .85 * reveal})`;
  drawWardenArt(c, b, p * 2);
  c.restore();
}
