import { describe, expect, it } from 'vitest';
import { entranceProgress, isWardenEntrance, WARDEN_ENTRANCE_TIME } from './boss-seal';
import { COOP_WARDEN_ROOM_INDEX } from './coop-levels';
import { GameEngine } from './engine';
import { EMPTY_INPUT } from './types';

const frame = 1 / 120;

describe('Warden arrival in the final court', () => {
  it('starts once when a living teammate crosses the threshold ahead of the host', () => {
    const game = new GameEngine();
    game.startCoop({ seed: 42, modifier: 'standard', weapon: 'blade', character: 'traveller' }, 4);
    game.forceCoopRoom(COOP_WARDEN_ROOM_INDEX);
    const { hero, boss } = game.state;
    const guest = { ...hero, hp: 0, x: 720 };
    game.setCoopTargets(() => [hero, guest]);
    game.update(frame, EMPTY_INPUT);
    expect(boss!.active).toBe(false);
    guest.hp = guest.maxHp;
    guest.x = 500;
    game.update(frame, EMPTY_INPUT);
    expect(boss!.active).toBe(false);
    guest.x = 520;
    game.update(frame, EMPTY_INPUT);
    expect(isWardenEntrance(boss!)).toBe(true);
    expect(entranceProgress(boss!)).toBe(0);
    guest.x = 180;
    for (let i = 0; i < 120; i++) game.update(frame, EMPTY_INPUT);
    expect(entranceProgress(boss!)).toBeCloseTo(1 / WARDEN_ENTRANCE_TIME, 5);
    guest.x = 670;
    game.update(frame, EMPTY_INPUT);
    expect(entranceProgress(boss!)).toBeGreaterThan(.31);
  });

  it('protects an overlapping player until the first warned strike and protects boss health during the reveal', () => {
    const game = new GameEngine();
    game.startCoop({ seed: 42, modifier: 'standard', weapon: 'blade', character: 'traveller' }, 2);
    game.forceCoopRoom(COOP_WARDEN_ROOM_INDEX);
    const state = game.state, b = state.boss!, h = state.hero;
    Object.assign(h, { x: b.x - 2, y: b.y + b.h - h.h, grounded: true, invincible: 0, facing: 1 });
    const heroHp = h.hp;
    game.update(frame, EMPTY_INPUT);
    expect(isWardenEntrance(b)).toBe(true);
    for (let i = 0; i < WARDEN_ENTRANCE_TIME / frame - 1; i++) {
      game.update(frame, { ...EMPTY_INPUT, attackHeld: true, attackPressed: i === 0 });
    }
    expect(b.mode).toBe('transition');
    expect(b.hp).toBe(b.maxHp);
    expect(b.guard).toBe(b.maxGuard);
    expect(h.hp).toBe(heroHp);
    for (let i = 0; i < 160 && b.mode !== 'windup'; i++) game.update(frame, EMPTY_INPUT);
    expect(b.mode).toBe('windup');
    expect(b.attackCount).toBe(1);
    expect(b.timer).toBeGreaterThan(.7);
    expect(state.projectiles.filter(p => p.owner === 'enemy')).toHaveLength(0);
    expect(h.hp).toBe(heroHp);
  });
});
