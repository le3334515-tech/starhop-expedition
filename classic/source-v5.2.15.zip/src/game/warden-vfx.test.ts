import { describe, expect, it } from 'vitest';
import { COOP_WARDEN_ROOM_INDEX } from './coop-levels';
import { GameEngine } from './engine';
import { EMPTY_INPUT, type Boss, type Rect } from './types';
import { drawWardenIntent, drawWardenProjectile } from './warden-vfx';

function canvasSpy() {
  const rects: Rect[] = [];
  const noop = () => {};
  const ctx = { save:noop, restore:noop, translate:noop, rotate:noop, scale:noop,
    fillRect(x:number,y:number,w:number,h:number) { rects.push({x,y,w,h}); } };
  return { ctx:ctx as unknown as CanvasRenderingContext2D, rects };
}

describe('Warden visual lanes', () => {
  it.each([['rift',5],['rain',9],['eclipse',7]] as const)('matches %s to every emitted strike', (intent, count) => {
    const game = new GameEngine();
    game.startCoop({ seed:42,modifier:'standard',weapon:'blade',character:'traveller' }, 4);
    game.forceCoopRoom(COOP_WARDEN_ROOM_INDEX);
    const state = game.state;
    const boss: Boss = state.boss!;
    Object.assign(boss, {phase:3,form:2,mode:'windup',timer:.01,active:true,targetX:95,intent});
    state.hero.invincible = 2;
    const warning = canvasSpy();
    expect(drawWardenIntent(warning.ctx,boss,state.room.width)).toBe(true);
    for (let i=0; i<4; i++) game.update(1/120, EMPTY_INPUT);
    const projectiles = state.projectiles;
    expect(projectiles).toHaveLength(count);
    const expected = projectiles.map(p => ({x:Math.round(p.x),y:444,w:p.w,h:2}));
    expect(warning.rects.filter(rect => rect.y === 444)).toEqual(expected);
    for (const p of projectiles) {
      const pending = canvasSpy();
      expect(drawWardenProjectile(pending.ctx,p,3,1,true)).toBe(true);
      expect(pending.rects).toContainEqual({x:Math.round(p.x),y:444,w:p.w,h:2});
      const active = canvasSpy();
      expect(drawWardenProjectile(active.ctx,{...p,delay:0},3,1,true)).toBe(true);
      if (p.kind === 'rift') {
        expect(active.rects).toContainEqual({x:Math.round(p.x),y:p.y,w:2,h:p.h});
        expect(active.rects).toContainEqual({x:Math.round(p.x+p.w-2),y:p.y,w:2,h:p.h});
      }
    }
  });
});
