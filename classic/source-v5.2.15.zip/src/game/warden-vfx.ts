import { ease, eclipseLanes, ECLIPSE_WIDTH, ECLIPSE_WINDUP } from './boss-seal';
import { wardenRainOrigins, wardenRiftLanes } from './coop-levels';
import type { Boss, Projectile, Rect } from './types';

const FLOOR = 448;
const INK = '#20252a';
const GOLD = '#d5b477';
const PEARL = '#ead6a7';
const CINNABAR = '#b17161';
const JADE = '#86a796';
const cell = (c: CanvasRenderingContext2D, x: number, y: number, w = 2, h = w) =>
  c.fillRect(Math.round(x), Math.round(y), Math.max(0, Math.round(w)), Math.max(0, Math.round(h)));

/** A thin black spine, two amber bevels and deliberately stepped tips. */
export function drawWardenSword(c: CanvasRenderingContext2D, x: number, y: number, length: number,
  angle: number, tone: string, broad = false) {
  c.save(); c.translate(Math.round(x), Math.round(y)); c.rotate(angle);
  const width = broad ? 6 : 4;
  const blade = length - 10;
  c.fillStyle = INK;
  cell(c, -2, -8, 4, 13); cell(c, -width - 4, 2, 2 * width + 8, 4);
  cell(c, -width - 1, 6, 2 * width + 2, blade);
  cell(c, -width, length - 4, 2 * width, 3);
  cell(c, -2, length - 1, 4, 4);
  c.fillStyle = tone;
  cell(c, -7, 2, 14, 2); cell(c, -1, -8, 2, 4);
  cell(c, -width, 8, 2 * width, blade - 3);
  cell(c, -width + 2, length - 5, 2 * width - 4, 4);
  c.fillStyle = PEARL;
  cell(c, 0, 9, 2, blade - 1); cell(c, -2, 4, 4, 2);
  c.restore();
}

function lane(c: CanvasRenderingContext2D, hit: Rect, floor: number, tone: string, urgency: number, glyphs: number) {
  const {x,y,w} = hit;
  c.save();
  c.fillStyle = tone;
  c.globalAlpha *= .26 + urgency * .3;
  for (let step = y + 3; step < floor - 20; step += 24) {
    cell(c, x, step, 1, 7); cell(c, x + w - 1, step, 1, 7);
  }
  c.globalAlpha = .67 + urgency * .26;
  cell(c, x, floor - 4, w, 2);
  cell(c, x, floor - 13, 2, 11); cell(c, x + w - 2, floor - 13, 2, 11);
  for (let i = 0; i < glyphs; i++) {
    const mark = x + w / 2 + (i - (glyphs - 1) / 2) * 10;
    cell(c, mark - 1, floor - 16, 2, 8); cell(c, mark - 3, floor - 13, 6, 2);
  }
  c.restore();
}

/** Exact lanes from the same helpers that create the eventual projectiles. */
export function drawWardenIntent(c: CanvasRenderingContext2D, b: Boss, width: number): boolean {
  const pressure = 1 - ease(0, b.intent === 'eclipse' ? ECLIPSE_WINDUP : .65, b.timer);
  if (b.intent === 'rift') {
    wardenRiftLanes(b, width).forEach((x, i) => lane(c, {x:x - 18,y:270,w:36,h:178}, FLOOR,
      i % 2 ? CINNABAR : GOLD, pressure, i % 2 + 1));
    return true;
  }
  if (b.intent === 'rain') {
    wardenRainOrigins(b, width).forEach((x, i) => lane(c, {x,y:65,w:19,h:26}, FLOOR,
      i % 2 ? CINNABAR : GOLD, pressure, 1));
    return true;
  }
  if (b.intent === 'eclipse') {
    eclipseLanes(b, width).forEach((x, i) => lane(c, {x:x - ECLIPSE_WIDTH / 2,y:156,w:ECLIPSE_WIDTH,h:292}, FLOOR,
      i % 2 ? CINNABAR : GOLD, pressure, i % 2 + 1));
    return true;
  }
  return false;
}

function swordColumn(c: CanvasRenderingContext2D, p: Projectile, phase: number, now: number, reduce: boolean) {
  const {x,y,w,h,life} = p;
  const eclipse = p.style === 'eclipse', foot = y + h;
  const delay = p.delay ?? 0, middle = x + w / 2;
  const tone = eclipse || phase === 3 ? GOLD : CINNABAR;
  if (delay > 0) {
    lane(c, p, foot, tone, 1 - ease(0, eclipse ? .64 : .85, delay), 1);
    return;
  }
  const fresh = 1 - ease(0, .16, (eclipse ? .46 : .66) - life);
  c.save();
  // The illuminated rails always delimit the active collision zone, even as the blade rises.
  c.fillStyle = INK; c.globalAlpha = .16 + fresh * .11; cell(c, x,y,w,h);
  c.fillStyle = tone; c.globalAlpha = .66 + fresh * .20;
  cell(c,x,y,2,h); cell(c,x+w-2,y,2,h);
  const grown = reduce ? 1 : .55 + (1-fresh) * .45;
  const length = Math.round((h - 20) * grown);
  const base = eclipse ? y + 10 : foot - 10;
  drawWardenSword(c, middle, base, length, eclipse ? 0 : Math.PI, tone, eclipse);
  c.globalAlpha = .85;
  c.fillStyle = PEARL;
  cell(c,x+3,foot - 5,w-6,3);
  if (!reduce) {
    c.fillStyle = tone;
    for (let i=0; i<(eclipse ? 6 : 4); i++) {
      const step = (i * .17 + now * 1.5) % 1;
      const side = i % 2 ? 1 : -1;
      cell(c,middle + side * (w * .18 + step * w * .18),foot - 10 - step * (h - 22),2,4);
    }
  }
  c.restore();
}

function fallingBlade(c: CanvasRenderingContext2D, p: Projectile, phase: number, reduce: boolean) {
  const delay = p.delay ?? 0;
  const tone = phase === 3 ? GOLD : CINNABAR;
  const middle = p.x+p.w/2;
  if (delay > 0) {
    lane(c, p, FLOOR, tone, 1 - ease(0, .95, delay), 1);
    return;
  }
  c.save();
  if (!reduce) {
    c.fillStyle = tone; c.globalAlpha = .22;
    cell(c, middle-1,p.y-19,2,18); cell(c,middle-4,p.y-8,2,6); cell(c,middle+3,p.y-12,2,6);
  }
  c.globalAlpha = .96;
  c.fillStyle = tone;
  cell(c,p.x+1,p.y+6,2,p.h-11); cell(c,p.x+p.w-3,p.y+6,2,p.h-11);
  drawWardenSword(c,middle,p.y+9,p.h-12,0,tone);
  c.restore();
}

function surge(c: CanvasRenderingContext2D, p: Projectile, tone: string, reduce: boolean) {
  const direction = p.vx < 0 ? -1 : 1;
  c.save();
  c.translate(Math.round(p.x + (direction < 0 ? p.w : 0)),Math.round(p.y));
  c.scale(direction,1);
  if ((p.delay ?? 0) > 0) {
    c.globalAlpha = .66; c.fillStyle = tone;
    cell(c,0,p.h-3,p.w,2); cell(c,1,p.h-10,2,8); cell(c,p.w-3,p.h-10,2,8);
    c.restore();
    return;
  }
  c.fillStyle=INK; c.globalAlpha=.59; cell(c,0,p.h-8,p.w,7);
  const count = reduce ? 5 : 8;
  for(let i=0;i<count;i++){
    const progress=i/(count-1), x=progress*(p.w-8), height=p.h*(.34+.66*progress);
    c.globalAlpha=.39+progress*.55; c.fillStyle=i%2 ? tone : PEARL;
    cell(c,x,p.h-height,3,height); cell(c,x+3,p.h-height+3,4,height*.6);
  }
  c.restore();
}

export function drawWardenProjectile(c: CanvasRenderingContext2D, p: Projectile, phase: number, now: number, reduce: boolean): boolean {
  if (p.owner !== 'enemy') return false;
  if (p.kind === 'rift') { swordColumn(c,p,phase,now,reduce); return true; }
  if (p.kind === 'shockwave') { surge(c,p,phase === 1 ? JADE : phase === 2 ? CINNABAR : GOLD,reduce); return true; }
  if (p.kind !== 'enemy') return false;
  // Rain shares the enemy projectile kind but only it starts on a timed vertical path.
  if (p.w === 19 && p.h === 26 && p.vx === 0 && p.vy > 0) { fallingBlade(c,p,phase,reduce); return true; }
  c.save(); c.translate(Math.round(p.x+p.w/2),Math.round(p.y+p.h/2));
  const tone = phase === 1 ? JADE : phase === 2 ? CINNABAR : GOLD;
  drawWardenSword(c,-p.w*.27,-p.h*.24,p.w*.9,Math.atan2(p.vy,p.vx)-Math.PI/2,tone);
  c.restore();
  return true;
}
