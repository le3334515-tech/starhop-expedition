import type { Boss, CharacterId, Enemy, WeaponId } from './types';

const MARK_DURATION = 2.4;
type HitPath = 'melee' | 'ember' | 'fan' | 'disc';
type ComboTarget = Enemy | Boss;

interface ComboStrike {
  weapon: WeaponId;
  path: HitPath;
  onReturn?: true;
}

interface WeaponCombo {
  name: string;
  description: string;
  color: string;
  primer: ComboStrike;
  finisher: ComboStrike;
  damageMultiplier?: number;
  resonance?: number;
  stagger?: number;
  heavyEnemy?: true;
  guardDamage?: number;
  dashRecovery?: number;
}

type ComboHit = { combo: WeaponCombo; step: 'setup' | 'finish' };

const COMBOS: Record<Exclude<CharacterId, 'traveller'>, WeaponCombo> = {
  blade: {
    name: '归燕点穴', description: '柳叶软剑命中后，2.4 秒内让归燕镖回程击中同一目标，伤害提高 35%。', color: '#e5bb87',
    primer: { weapon: 'willowSword', path: 'melee' }, finisher: { weapon: 'swallowDart', path: 'disc', onReturn: true },
    damageMultiplier: 1.35,
  },
  staff: {
    name: '霜镜回辉', description: '霜枝杖命中后，2.4 秒内让照月镜击中同一目标，额外获得 4 点星能。', color: '#dcceec',
    primer: { weapon: 'frostStaff', path: 'ember' }, finisher: { weapon: 'moonMirror', path: 'fan' },
    resonance: 4,
  },
  wheel: {
    name: '翎风扰阵', description: '翠翎针命中后，2.4 秒内用裁风翎刃击中同一小怪，使它震停 0.5 秒。', color: '#b8dfc2',
    primer: { weapon: 'jadeNeedle', path: 'ember' }, finisher: { weapon: 'silkFan', path: 'fan' },
    stagger: .5,
  },
  spear: {
    name: '标戟破阵', description: '芦影标枪命中后，2.4 秒内让断岳戟击中同一目标，对小怪造成重击，额外削去首领 6 点护甲。', color: '#e8c896',
    primer: { weapon: 'reedJavelin', path: 'fan' }, finisher: { weapon: 'halberd', path: 'melee' },
    heavyEnemy: true, guardDamage: 6,
  },
  monk: {
    name: '回山退步', description: '伏虎铁拳命中后，2.4 秒内让回山佛珠回程击中同一目标，闪避冷却缩短 0.4 秒。', color: '#e3ad79',
    primer: { weapon: 'ironGauntlet', path: 'melee' }, finisher: { weapon: 'prayerBeads', path: 'disc', onReturn: true },
    dashRecovery: .4,
  },
};

export function getWeaponCombo(character?: CharacterId | null): WeaponCombo | undefined {
  return character && character !== 'traveller' ? COMBOS[character] : undefined;
}

/** Each authoritative player engine owns its marks, including on shared co-op targets. */
export class WeaponComboMarks {
  private readonly marks = new WeakMap<ComboTarget, { expires: number; phase?: number }>();

  hit(character: CharacterId | undefined, target: ComboTarget, weapon: WeaponId | undefined, path: HitPath, now: number, returning = false): ComboHit | undefined {
    const combo = getWeaponCombo(character);
    if (!combo) return;
    const boss = 'phase' in target;
    if (boss && (combo.stagger || !target.active || target.mode === 'transition' || target.mode === 'dead')) return;

    const phase = boss ? target.phase : undefined;
    const mark = this.marks.get(target);
    const live = mark && mark.expires >= now && mark.phase === phase;
    if (weapon === combo.primer.weapon && path === combo.primer.path) {
      this.marks.set(target, { expires: now + MARK_DURATION, phase });
      return live ? undefined : { combo, step: 'setup' };
    }
    const finisher = combo.finisher;
    if (weapon !== finisher.weapon || path !== finisher.path || (finisher.onReturn && !returning)) return;
    this.marks.delete(target);
    if (live) return { combo, step: 'finish' };
  }
}
