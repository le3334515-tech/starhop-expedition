import { WEAPONS, type WeaponId } from './types';

export const MELEE_COMBOS = {
  blade: { active: [.18, .28], recovery: [.28, .43], extraSpread: 70 },
  spear: { active: [.19, .26], recovery: [.37, .52], extraSpread: 50 },
  sabre: { active: [.24, .34], recovery: [.40, .62], extraSpread: 54 },
  fist: { active: [.14, .24], recovery: [.18, .40], extraSpread: 38 },
} as const;

export function weaponAttackDuration(weapon: WeaponId, step: number): number {
  const family = WEAPONS[weapon].archetype;
  if (family === 'fan') return step === 3 ? .28 : .20;
  if (family === 'ember' || family === 'disc') return .20;
  return MELEE_COMBOS[family].active[step === 3 ? 1 : 0];
}

export function attackProgress(weapon: WeaponId, step: number, remaining: number): number {
  return Math.max(0, Math.min(1, 1 - remaining / weaponAttackDuration(weapon, step)));
}

// Strike frames differ by source sheet. Put the authored contact silhouette
// at the first visible beat, hold it briefly, then hand the last beats back to locomotion.
export const SHEET_RELEASE_END = .79;
export function attackSheetFrame(p: number, contact: number, count: number): number {
  if (p < .13) return Math.min(contact, Math.floor((p / .13) * contact));
  if (p <= .29) return contact;
  return Math.min(count - 1, contact + Math.floor((p - .29) / (SHEET_RELEASE_END - .29) * (count - contact)));
}

/** Travel from the drawn-back wrist through contact, recoil, and exactly back to rest. */
export function wristBeat(p: number, ready: number, contact: number, follow: number, rest: number): number {
  const t = p < .16 ? p / .16 : p < .36 ? (p - .16) / .20 : Math.min(1, (p - .36) / .64);
  const a = p < .16 ? ready : p < .36 ? contact : follow;
  const b = p < .16 ? contact : p < .36 ? follow : rest;
  return a + (b - a) * (t * (2 - t));
}
