import { DirectRace } from './race-direct';
import { directRoom, raceKey, RaceRuleError } from './race-host';
import { getCharacterWeapons, type CharacterId, type GameConfig } from './game/types';
import { parseRaceResponse, RACE_RULESET, RACE_RULESET_MISMATCH, sanitizeRaceFrame, type RaceFrame, type RaceGhost, type RaceResponse, type RaceRoom, type RaceSeat, type RaceView } from './race-types';
export type { RaceFrame, RaceGhost, RacePlayer, RaceRoom, RaceView } from './race-types';

export const RACE_ENDPOINT = 'https://starhop-race-relay-20261118.fruitfulmaple8.chatgpt.site/api/race';
interface Options { onChange?: (view: RaceView) => void; onStart?: (config: GameConfig, startAt: number) => void; onError?: (message: string) => void }
interface Credentials { roomId: string; token: string; clientId: string; selfId: RaceSeat }
interface GhostSample { frame: RaceFrame; at: number; receivedAt: number; name: string }
class RaceApiError extends RaceRuleError {}
const storageKey = (room: string) => `starhop.race.room.v1.${room}`;
const uid = () => globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}_${Math.random().toString(36).slice(2)}`;
const friendlyError = (error: unknown) => error instanceof Error && /[\u3400-\u9fff]/.test(error.message) ? error.message : '服务器线路未能响应。可发起好友直连房间。';

/** Independent race transport. Frames are visual ghosts, never simulation inputs. */
export class RaceSession {
  private direct: DirectRace | null = null;
  private room: RaceRoom | null = null;
  private credentials: Credentials | null = null;
  private connection: RaceView['connection'] = 'idle';
  private error: string | null = null;
  private offset = 0;
  private bestRtt = Infinity;
  private latestFrame: RaceFrame | null = null;
  private samples: GhostSample[] = [];
  private ghostDelay = 180;
  private ghostCursor = 0;
  private timer: ReturnType<typeof setTimeout> | undefined;
  private startTimer: ReturnType<typeof setTimeout> | undefined;
  private startDeadline = 0;
  private request: AbortController | null = null;
  private generation = 0;
  private busy = false;
  private startedKey = '';
  private finishFrame: RaceFrame | null = null;
  private lastOpponentSeq = -1;
  private latestSnapshotAt = 0;
  private pollPeriod = 0;
  private choosingCharacter = false;
  private resetting = false;

  constructor(readonly endpoint = RACE_ENDPOINT, private options: Options = {}) {}

  get view(): RaceView {
    const selfId = this.credentials?.selfId ?? null;
    const self = this.room && selfId ? this.room[selfId] : null;
    const opponent = this.room && selfId ? this.room[selfId === 'host' ? 'guest' : 'host'] : null;
    const startAt = this.room?.startAt ?? null;
    return { connection: this.connection, room: this.room, selfId, self, opponent,
      started: startAt !== null && this.estimatedServerNow() >= startAt,
      countdown: startAt !== null && this.estimatedServerNow() < startAt ? Math.max(1, Math.ceil((startAt - this.estimatedServerNow()) / 1000)) : null,
      elapsed: this.elapsed(), error: this.error, choosingCharacter: this.choosingCharacter,
      opponentAgeMs: this.samples.length ? Math.max(0, Date.now() - this.samples[this.samples.length - 1]!.receivedAt) : 0 };
  }
  estimatedServerNow(): number { return Date.now() + this.offset; }
  elapsed(): number {
    const at = this.room?.startAt;
    if (at == null) return 0;
    const self = this.credentials ? this.room?.[this.credentials.selfId] : null;
    const end = self?.finishedAt ?? (this.finishFrame ? at + this.finishFrame.elapsed * 1000 : this.estimatedServerNow());
    return Math.max(0, (end - at) / 1000);
  }
  tick(): void { this.maybeStart(); }

  async create(config: GameConfig, name: string, mode: 'auto' | 'server' = 'auto'): Promise<void> {
    this.disconnect(); const generation = this.generation;
    this.connection = 'connecting'; this.error = null; this.publish();
    const clientId = uid();
    try {
      if (mode === 'auto' && this.endpoint === RACE_ENDPOINT && typeof globalThis.crypto?.getRandomValues === 'function') {
        const direct = new DirectRace('p2_' + raceKey());
        this.direct = direct;
        try { await direct.host(config, name); }
        catch {
          direct.close();
          if (generation !== this.generation) return;
          this.direct = null;
          this.error = '正在连接备用服务器…'; this.publish();
        }
        if (generation !== this.generation) return;
      }
      const { character, ...route } = config;
      const response = await this.post({ action: 'create', config: route, ...(character ? { character } : {}), name, clientId, ruleset: RACE_RULESET });
      if (generation !== this.generation) return;
      if (response.room.ruleset !== RACE_RULESET) throw new RaceRuleError(RACE_RULESET_MISMATCH, 409);
      if (!response.token) throw new Error('房间凭证未能生成，请重新发起。');
      this.credentials = { roomId: response.room.id, token: response.token, selfId: response.selfId, clientId };
      this.saveCredentials(); this.accept(response); this.startPolling();
    } catch (error) { if (generation !== this.generation) return; this.direct?.close(); this.direct = null; this.fail(error); throw error; }
  }
  async join(roomId: string, name: string): Promise<void> {
    if (!/^[a-zA-Z0-9_-]{12,128}$/.test(roomId)) throw new Error('这份在线挑战链接不完整。');
    this.disconnect(); const generation = this.generation;
    this.connection = 'connecting'; this.error = null; this.publish();
    let saved: Credentials | null = null;
    try { const value = JSON.parse(sessionStorage.getItem(storageKey(roomId)) || 'null'); if (value?.roomId === roomId && typeof value.token === 'string' && typeof value.clientId === 'string' && ['host', 'guest'].includes(value.selfId)) saved = value; } catch { /* Optional refresh recovery. */ }
    const clientId = saved?.clientId ?? uid();
    try {
      if (directRoom(roomId)) {
        this.direct = new DirectRace(roomId); await this.direct.guest();
        if (generation !== this.generation) return;
      }
      let response: RaceResponse;
      const join = { action: 'join', roomId, name, clientId, ruleset: RACE_RULESET };
      if (saved) {
        this.credentials = saved;
        try { response = await this.post({ action: 'state', roomId, token: saved.token, clientId }); }
        catch (error) {
          if (!(error instanceof RaceRuleError) || error.status !== 401) throw error;
          this.credentials = null; response = await this.post(join);
        }
      } else response = await this.post(join);
      if (generation !== this.generation) return;
      if (response.room.ruleset !== RACE_RULESET) {
        // An old host can accept a join before it knows about this check. Return only a newly granted seat.
        if (!this.credentials && response.token) {
          try { await this.post({ action: 'leave', roomId, token: response.token, clientId }); }
          catch { /* An old room may already have closed. */ }
          if (generation !== this.generation) return;
        }
        this.credentials = null;
        throw new RaceRuleError(RACE_RULESET_MISMATCH, 409);
      }
      const token = response.token ?? saved?.token;
      if (!token) throw new Error('未能取得同行凭证，请重新打开邀请。');
      this.credentials = { roomId, token, selfId: response.selfId, clientId };
      this.saveCredentials(); this.accept(response); this.startPolling();
    } catch (error) { if (generation !== this.generation) return; this.direct?.close(); this.direct = null; this.fail(error); throw error; }
  }
  async chooseCharacter(character: CharacterId | null): Promise<void> {
    if (!this.room?.characterSelection) throw new Error('这条服务器线路使用经典旅人。');
    if (this.choosingCharacter || this.view.self?.character === character) return;
    const generation = this.generation;
    this.choosingCharacter = true;
    this.publish();
    try { await this.command('character', { character }); }
    finally {
      if (generation === this.generation) {
        this.choosingCharacter = false;
        this.publish();
      }
    }
  }
  async ready(ready = true): Promise<void> {
    if (this.choosingCharacter) throw new Error('正在同步角色，请稍候再准备。');
    await this.command('ready', { ready });
  }
  async reset(): Promise<void> {
    if (this.resetting) return;
    const generation = this.generation;
    this.resetting = true;
    try { await this.command('reset', { epoch: this.room?.epoch ?? 0 }); }
    finally { if (generation === this.generation) this.resetting = false; }
  }
  updateFrame(frame: RaceFrame): void {
    if (!this.credentials || this.finishFrame) return;
    const character = this.room?.[this.credentials.selfId]?.character;
    this.latestFrame = sanitizeRaceFrame({ ...frame, character: character === undefined ? frame.character : character, elapsed: this.elapsed() });
  }
  async finish(won: boolean): Promise<void> {
    if (!this.credentials || this.finishFrame) return;
    this.finishFrame = sanitizeRaceFrame({ ...this.latestFrame, elapsed: this.elapsed(), finished: true, won, phase: won ? 'victory' : 'gameover', seq: (this.latestFrame?.seq ?? 0) + 1 });
    this.latestFrame = this.finishFrame;
    await this.command('state', { frame: this.finishFrame });
    this.startPolling(1000);
  }
  async leave(): Promise<void> {
    const credentials = this.credentials, direct = this.direct;
    this.direct = null;
    this.disconnect(); this.connection = 'closed'; this.publish();
    if (!credentials) { direct?.close(); return; }
    try { sessionStorage.removeItem(storageKey(credentials.roomId)); } catch { /* Optional storage. */ }
    if (direct) {
      try { await direct.request({action:'leave', ...credentials}); } catch { /* Peer may already be gone. */ }
      finally { direct.close(); }
      return;
    }
    const abort = new AbortController(), timeout = setTimeout(() => abort.abort(), 3000);
    try { await fetch(this.endpoint, { method: 'POST', headers: { 'content-type': 'text/plain;charset=UTF-8' }, body: JSON.stringify({ action: 'leave', ...credentials }), signal: abort.signal, keepalive: true }); }
    catch { /* Local departure does not depend on a reply. */ }
    finally { clearTimeout(timeout); }
  }
  opponentFrame(): RaceGhost | null {
    const latest = this.samples[this.samples.length - 1]; if (!latest) return null;
    if (this.credentials && this.room?.[this.credentials.selfId === 'host' ? 'guest' : 'host']?.leftAt != null) return null;
    const now = Date.now();
    const target = this.ghostCursor = Math.min(latest.at + 120, Math.max(this.ghostCursor, now - this.ghostDelay));
    // Retain the enclosing pair even when two packets arrive in a burst.
    const nextIndex = this.samples.findIndex(sample => sample.at >= target);
    const next = nextIndex >= 0 ? this.samples[nextIndex]! : latest;
    const previous = nextIndex > 0 ? this.samples[nextIndex - 1]! : next;
    const frame = { ...next.frame };
    if (previous.at < next.at) {
      const t = Math.min(1, Math.max(0, (target - previous.at) / (next.at - previous.at)));
      frame.x = previous.frame.x + (next.frame.x - previous.frame.x) * t;
      frame.y = previous.frame.y + (next.frame.y - previous.frame.y) * t;
      frame.animation = previous.frame.animation + (next.frame.animation - previous.frame.animation) * t;
      if (frame.phase === 'playing' && previous.frame.weapon === frame.weapon &&
          previous.frame.attackStep === frame.attackStep && previous.frame.attackTimer >= frame.attackTimer) {
        frame.attackTimer = previous.frame.attackTimer + (frame.attackTimer - previous.frame.attackTimer) * t;
      }
    }
    const ageMs = Math.max(0, now - latest.receivedAt);
    if (latest.frame.phase === 'playing' && !latest.frame.finished && target > latest.at) {
      // Once prediction runs out, hold its endpoint until the next packet.
      const dt = Math.min(.12, (target - latest.at) / 1000);
      frame.x += latest.frame.vx * dt;
      if (!latest.frame.grounded) frame.y += latest.frame.vy * dt;
      frame.animation += dt;
      frame.attackTimer = Math.max(0, frame.attackTimer - dt);
    }
    return { ...frame, name: latest.name, ageMs, stale: ageMs > 2000 };
  }

  private recordGhost(frame: RaceFrame, name: string) {
    const receivedAt = Date.now();
    const previous = this.samples.at(-1);
    const gap = previous ? receivedAt - previous.receivedAt : 0;
    const travel = previous ? Math.abs(frame.x - previous.frame.x) : 0;
    // Stage changes, respawns and long outages should appear immediately.
    if (!previous || previous.frame.roomIndex !== frame.roomIndex || previous.frame.phase !== frame.phase ||
        gap > 2400 || travel > 320 + .72 * gap) {
      this.samples = []; this.ghostCursor = 0;
      this.ghostDelay = this.direct?.pollInterval === 1000 ? 900 : 180;
    }
    let at = receivedAt;
    if (previous && this.samples.length) {
      const senderGap = (frame.elapsed - previous.frame.elapsed) * 1000;
      // A bounded sender clock absorbs delivery jitter. Older room frames
      // without elapsed timestamps use their observed arrival intervals.
      if (senderGap >= 12 && senderGap <= 1800 && Math.abs(previous.at + senderGap - receivedAt) < 340)
        at = previous.at + senderGap;
      at = Math.max(previous.at + 1, at);
      const cadence = Math.max(70, Math.min(1400, (at - previous.at) * .9));
      if (gap >= 24) this.ghostDelay = this.samples.length === 1 ? cadence : this.ghostDelay * .65 + cadence * .35;
    }
    this.samples.push({frame,at,receivedAt,name});
    if (this.samples.length > 12) this.samples.shift();
  }

  private saveCredentials() { try { if (this.credentials) sessionStorage.setItem(storageKey(this.credentials.roomId), JSON.stringify(this.credentials)); } catch { /* In-memory networking remains available. */ } }
  private publish() { this.options.onChange?.(this.view); }
  private fail(error: unknown) { this.connection = 'error'; this.error = friendlyError(error); this.publish(); this.options.onError?.(this.error); }
  private disconnect() {
    this.direct?.close(); this.direct = null;
    this.generation++; clearTimeout(this.timer); clearTimeout(this.startTimer); this.timer = undefined; this.startTimer = undefined; this.pollPeriod = 0;
    this.request?.abort(); this.request = null; this.busy = false;
    this.room = null; this.credentials = null; this.latestFrame = null; this.finishFrame = null; this.samples = []; this.lastOpponentSeq = -1; this.latestSnapshotAt = 0; this.startedKey = ''; this.bestRtt = Infinity; this.offset = 0; this.choosingCharacter = false; this.resetting = false;
  }
  private startPolling(period = this.direct?.pollInterval ?? 200) {
    if (this.pollPeriod === period && (this.timer || this.busy)) return;
    clearTimeout(this.timer); this.timer = undefined; this.pollPeriod = period;
    if (!this.busy) this.scheduleExchange(period);
  }
  private scheduleExchange(delay: number) { this.timer = setTimeout(() => { this.timer = undefined; void this.exchange(); }, delay); }
  private async exchange() {
    if (this.busy || !this.credentials) return;
    this.busy = true; const generation = this.generation, sent = Date.now();
    try {
      const response = await this.post({ action: 'state', ...this.credentials, frame: this.finishFrame ?? this.latestFrame ?? undefined });
      if (generation === this.generation) this.accept(response);
    } catch (error) {
      if (generation !== this.generation) return;
      if (error instanceof RaceRuleError && [401, 404, 410].includes(error.status)) { clearTimeout(this.timer); clearTimeout(this.startTimer); this.fail(error); }
      else { this.connection = 'reconnecting'; this.error = '连接暂时中断，正在重连…'; this.publish(); }
    } finally {
      if (generation === this.generation) {
        this.busy = false;
        if (this.credentials && this.connection !== 'error') {
          const active = this.room?.status === 'racing' && this.room.host.finishedAt === null &&
            this.room.guest?.finishedAt === null && this.room.host.leftAt == null && this.room.guest.leftAt == null;
          // Only an open WebRTC channel gets fast gameplay polls. Keep HTTP relay,
          // waiting rooms and completed runs on their existing schedules.
          const normal = this.direct?.pollInterval ?? 0;
          const period = active && this.direct && this.pollPeriod <= normal
            ? this.direct.activePollInterval
            : Math.max(this.pollPeriod, normal);
          this.scheduleExchange(Math.max(30, period - (Date.now() - sent)));
        }
      }
    }
  }
  private async command(action: string, data: Record<string, unknown> = {}) {
    if (!this.credentials) throw new Error('请先进入在线竞速房间。');
    const generation = this.generation;
    try { const response = await this.post({ action, ...this.credentials, ...data }); if (generation === this.generation) this.accept(response); }
    catch (error) { if (generation === this.generation) { this.error = friendlyError(error); this.publish(); } throw error; }
  }
  private async post(body: Record<string, unknown>): Promise<RaceResponse> {
    const generation = this.generation, sent = Date.now(), abort = new AbortController();
    // Capture the round when sending. Old completion frames must not enter a rematch.
    const payload = body.action === 'state' ? { ...body, epoch: this.room?.epoch ?? 0 } : body;
    // A command can run alongside a state exchange; its own timeout always releases.
    const timeout = setTimeout(() => abort.abort(), ['create', 'join'].includes(String(payload.action)) ? 15000 : 6500);
    this.request = abort;
    try {
      let result: RaceResponse;
      if (this.direct) result = await this.direct.request(payload);
      else {
        const response = await fetch(this.endpoint, { method: 'POST', headers: { 'content-type': 'text/plain;charset=UTF-8' }, body: JSON.stringify(payload), signal: abort.signal });
        const raw = await response.json().catch(() => null);
        if (!response.ok || raw?.ok !== true) throw new RaceApiError(typeof raw?.message === 'string' ? raw.message : '服务器线路未能连接，可改用好友直连。', response.status);
        result = parseRaceResponse(raw);
      }
      const received = Date.now(), rtt = received - sent;
      if (generation === this.generation && rtt <= this.bestRtt + 25) {
        const estimate = result.serverNow - (sent + received) / 2;
        this.offset = this.bestRtt === Infinity ? estimate : this.offset * .35 + estimate * .65;
        this.bestRtt = Math.min(this.bestRtt, rtt);
      }
      return result;
    } finally { clearTimeout(timeout); if (this.request === abort) this.request = null; }
  }
  private accept(response: RaceResponse) {
    if (response.serverNow < this.latestSnapshotAt) return;
    if (this.room && (response.room.epoch ?? 0) < (this.room.epoch ?? 0)) return;
    this.latestSnapshotAt = response.serverNow;
    if (this.room && (response.room.epoch !== this.room.epoch || this.room.startAt !== null && response.room.startAt === null && !this.startedKey)) {
      this.finishFrame = null; this.latestFrame = null; this.samples = []; this.lastOpponentSeq = -1; this.startedKey = '';
      this.startPolling();
    }
    this.room = response.room; this.connection = 'online'; this.error = null;
    if (this.credentials) this.credentials.selfId = response.selfId;
    const opponent = response.selfId === 'host' ? response.room.guest : response.room.host;
    if (opponent?.frame && opponent.frame.seq > this.lastOpponentSeq) {
      this.lastOpponentSeq = opponent.frame.seq;
      this.recordGhost(opponent.frame, opponent.name);
    }
    this.maybeStart();
    if (response.room.status === 'finished' || this.credentials && response.room[this.credentials.selfId]?.finishedAt != null) this.startPolling(1000);
    this.publish();
  }
  private maybeStart() {
    const room = this.room, credentials = this.credentials, at = room?.startAt;
    if (at == null || !room || !credentials || this.connection === 'error') return;
    const key = `${room.id}:${at}`;
    if (this.startedKey === key || room[credentials.selfId]?.finishedAt != null) return;
    const remaining = at - this.estimatedServerNow();
    if (remaining > 0) {
      const deadline = at - this.offset;
      if (this.startTimer && Math.abs(this.startDeadline - deadline) < 10) return;
      clearTimeout(this.startTimer); this.startDeadline = deadline;
      this.startTimer = setTimeout(() => { this.startTimer = undefined; this.maybeStart(); }, remaining + 1);
      return;
    }
    clearTimeout(this.startTimer); this.startTimer = undefined;
    const character = room[credentials.selfId]?.character;
    const config = character ? { ...room.config, character, weapon: getCharacterWeapons(character)[0]! } : { ...room.config };
    this.startedKey = key; this.options.onStart?.(config, at);
  }
}

export function raceInviteUrl(roomId: string, pageUrl = location.href): string {
  const url = new URL(pageUrl); url.hash = ''; url.searchParams.set('race', roomId); return url.href;
}
export function raceRoomFromUrl(url: string): string | null {
  try {
    const link = new URL(url.trim());
    const id = link.hash.startsWith('#race=') ? link.hash.slice(6) : link.searchParams.get('race');
    return id && /^[a-zA-Z0-9_-]{12,128}$/.test(id) ? id : null;
  } catch { return null; }
}
