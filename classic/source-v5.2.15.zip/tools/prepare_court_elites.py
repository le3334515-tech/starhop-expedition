"""Prepare the court's two CC0 pixel actors from the original LuizMelo ZIPs."""
from argparse import ArgumentParser
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

from PIL import Image, ImageDraw


OUT = Path(__file__).resolve().parents[1] / "src/assets/art/actors"
CELL = (128, 86)
VANGUARD = {
    (68, 43, 97): "#263b3f", (98, 80, 126): "#425d60", (160, 150, 209): "#9bafa1",
    (129, 112, 154): "#71887e", (121, 57, 10): "#704838", (145, 88, 22): "#987054",
    (138, 11, 65): "#66373b", (206, 32, 56): "#a85744", (206, 175, 71): "#e8ba75",
    (195, 203, 219): "#bac6b0", (252, 252, 252): "#e3dec3",
}


def color(pixel, armored):
    r, g, b, alpha = pixel
    if not alpha:
        return (0, 0, 0, 0)
    if armored:
        replacement = VANGUARD.get((r, g, b))
        if replacement:
            return (*bytes.fromhex(replacement[1:]), alpha)
    else:
        if g > b * 1.25 and abs(r - g) < 30:  # moss trousers to lacquered red
            return (min(210, r + 42), round(g * .65), round(b * .91), alpha)
        if b > r and r > 100:  # lilac blade to pale, warm steel
            return (min(248, r + 12), min(238, g + 11), round(b * .82), alpha)
    return pixel


def shield(frame, x, y):
    face = ImageDraw.Draw(frame)
    pts = [(-7,-13),(0,-16),(7,-13),(9,-8),(8,6),(4,13),(0,16),(-5,13),(-9,7),(-10,-7)]
    face.polygon([(x+dx, y+dy) for dx, dy in pts], fill="#243737", outline="#aa8759")
    face.line([(x-7,y-9),(x,y-12),(x+5,y-10),(x+4,y+7),(x,y+12)], fill="#607b74", width=2)
    face.line([(x-5,y-2),(x,y-7),(x+5,y-2),(x,y+5),(x-5,y-2)], fill="#bc9560")
    face.rectangle((x-1,y-1,x+1,y+1), fill="#dfc693")
    for dx in [-6, 5]:
        face.point((x+dx,y+8),fill="#caa16e")


def build(source, armored):
    prefix = "court-vanguard" if armored else "court-executioner"
    folder = "Hero Knight 2/Sprites" if armored else "Martial Hero 3/Sprite"
    actions = {"idle":"Idle", "run":"Run", "strike":"Attack" if armored else "Attack1", "hurt":"Take Hit"}
    with ZipFile(source) as archive:
        for action, original in actions.items():
            raw = Image.open(BytesIO(archive.read(f"{folder}/{original}.png"))).convert("RGBA")
            count, cell = raw.width // raw.height, raw.height
            sheet = Image.new("RGBA", (CELL[0] * count, CELL[1]))
            for i in range(count):
                frame = raw.crop((i*cell, 0, (i+1)*cell, cell))
                frame.putdata([color(pixel, armored) for pixel in frame.getdata()])
                anchor = (82 if action == "run" else 70, 83) if armored else (63, 82)
                if armored:
                    bob = [0,-2,-1,0,1,-1,0,1][i % 8] if action == "run" else 0
                    swing = [0,-1,-3,-3,8,5][i] if action == "strike" else 0
                    shield(frame, anchor[0] + 10 + swing, 66 + bob)
                crop = frame.crop((anchor[0]-64, anchor[1]-82, anchor[0]+64, anchor[1]+4))
                sheet.paste(crop, (i*CELL[0], 0))
            sheet.save(OUT / f"{prefix}-{action}.png", optimize=True)


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("hero_knight_2_zip", type=Path)
    parser.add_argument("martial_hero_3_zip", type=Path)
    args = parser.parse_args()
    build(args.hero_knight_2_zip, True)
    build(args.martial_hero_3_zip, False)
