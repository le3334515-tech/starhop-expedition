"""Make the forge lantern's dim and charged animation from karsiori's CC0 pack."""

from argparse import ArgumentParser
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
FRAME_W, FRAME_H = 22, 36
MATERIAL = "Pixel Art Lantern Pack/Lanterns - Smaller Versions/Lantern 4/Bronze/Orange Light"
FRAMES = ((3, 5, 8, 16, 21, 26), (10, 12, 14, 28, 32, 34))
METAL = {
    (43, 30, 25): (45, 43, 39),
    (67, 46, 39): (62, 58, 49),
    (102, 70, 58): (94, 72, 56),
    (159, 109, 91): (142, 106, 76),
    (186, 148, 135): (174, 134, 92),
    (217, 196, 189): (201, 163, 115),
}
ROOF = {
    (43, 30, 25): (34, 43, 42),
    (67, 46, 39): (43, 55, 51),
    (102, 70, 58): (59, 72, 60),
    (159, 109, 91): (78, 91, 73),
    (186, 148, 135): (108, 115, 87),
    (217, 196, 189): (152, 138, 103),
}


def paint_frame(image: Image.Image, frame: int, charged: bool) -> Image.Image:
    cell = Image.new("RGBA", (FRAME_W, FRAME_H))
    for y in range(image.height):
        for x in range(image.width):
            r, g, b, a = image.getpixel((x, y))
            if not a:
                continue
            color = (r, g, b)
            if y < 9 and color in ROOF:
                color = ROOF[color]
            elif color in METAL:
                color = METAL[color]
            elif x >= 5 and 10 <= y < 24:
                light = g / 255
                color = (
                    round((145 if charged else 120) + 102 * light),
                    round((62 if charged else 48) + (139 if charged else 100) * light),
                    round((47 if charged else 43) + (84 if charged else 47) * light),
                )
            elif x < 3 and y > 11:
                color = (min(174, r), round(g * .72), max(44, b))
            cell.putpixel((x + 1, y + 2), (*color, a))

    # Narrow silk ties sway on the native pixel grid below the metal base.
    swing = (-1, -1, 0, 1, 1, 0)[frame]
    for anchor, length in ((8, 6), (14, 5)):
        for n in range(length):
            x, y = anchor + (swing if n >= 3 else 0), 28 + n
            cell.putpixel((x, y), (133, 64, 54, 255) if n < 4 else (89, 51, 49, 255))
            if n < 2:
                cell.putpixel((x + 1, y), (181, 105, 70, 255))
    return cell


def main() -> None:
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    args = parser.parse_args()
    sheet = Image.new("RGBA", (FRAME_W * len(FRAMES[0]), FRAME_H * len(FRAMES)))
    with ZipFile(args.source) as archive:
        for row, group in enumerate(FRAMES):
            for frame, index in enumerate(group):
                name = f"{MATERIAL}/Lantern 4 Small - Bronze and Orange_{index:03}.png"
                with Image.open(BytesIO(archive.read(name))) as image:
                    cell = paint_frame(image.convert("RGBA"), frame, charged=row == 1)
                sheet.alpha_composite(cell, (frame * FRAME_W, row * FRAME_H))
    sheet.save(ROOT / "src/assets/art/actors/forge-lantern.png", optimize=True)


if __name__ == "__main__":
    main()
