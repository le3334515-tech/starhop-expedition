import { GameEngine, type CoopMotion } from './game/engine';
import { EMPTY_INPUT, getCharacterWeapons, isLoadoutWeapon, type Boss, type Enemy, type FloatingText, type GameResult, type Hero, type Impact, type InputState,
  type Particle, type Phase, type Pickup, type Projectile, type SoundName, type Upgrade, type WeaponId } from './game/types';
import { getWeaponCombo } from './game/weapon-combos';
import type { CoopCharacterId, CoopPlayer, CoopRoom, CoopSeat, CoopSession } from './coop-transport';

const inputKeys = ['left','right','jumpHeld','attackHeld','jumpPressed','attackPressed','dashPressed','guardPressed','overdrivePressed'] as const;
const heldKeys = inputKeys.slice(0,4);
const edges = inputKeys.slice(4);
const WORLD_INTERVAL = .064;
const PARTY_SCENE_TICKS = 4;
const SCENE_SHOT_LIMIT = 96;
const PARTY_SHOTS_PER_TRAVELLER = 12;
const INPUT_INTERVAL = .048;
const PREDICTION_WINDOW = .95;
const PREDICTION_TICKS = 60;
const MAX_WORLD_LOOKAHEAD = .28;
const MAX_OFFSET = 200;
const wirePixel = (value: number) => Math.round(value * 8) / 8;
const wireSeconds = (value: number) => Math.round(value * 1000) / 1000;
const wireOptionalSeconds = (value: number | undefined) => value === undefined ? undefined : wireSeconds(value);
const clampOffset = (value: number) => Math.max(-MAX_OFFSET, Math.min(MAX_OFFSET,value));

function wirePosition<T extends { x: number; y: number }>(value: T): T {
  return { ...value, x: wirePixel(value.x), y: wirePixel(value.y) };
}
function wireMovement<T extends { x: number; y: number; vx: number; vy: number }>(value: T): T {
  return { ...value, x: wirePixel(value.x), y: wirePixel(value.y), vx: wirePixel(value.vx), vy: wirePixel(value.vy) };
}

// Limit the precision of copies sent to guests. Keep the host's simulation at full precision.
function wireHero(hero: Hero): Hero {
  return {
    ...wireMovement(hero), upgrades: [...hero.upgrades], animation: wireSeconds(hero.animation),
    attackTimer: wireSeconds(hero.attackTimer), attackCooldown: wireSeconds(hero.attackCooldown),
    dashTimer: wireSeconds(hero.dashTimer), dashCooldown: wireSeconds(hero.dashCooldown),
    guardTimer: wireSeconds(hero.guardTimer), guardCooldown: wireSeconds(hero.guardCooldown),
    coyote: wireSeconds(hero.coyote), jumpBuffer: wireSeconds(hero.jumpBuffer),
    invincible: wireSeconds(hero.invincible), counterTimer: wireSeconds(hero.counterTimer),
    comboWindow: wireSeconds(hero.comboWindow), swapCooldown: wireSeconds(hero.swapCooldown),
    perfectDodgeCooldown: wireSeconds(hero.perfectDodgeCooldown),
    dodgeCue: hero.dodgeCue && { ...wirePosition(hero.dodgeCue), life: wireSeconds(hero.dodgeCue.life) },
    buffEffects: hero.buffEffects?.map(effect => ({ ...wirePosition(effect), life: wireSeconds(effect.life) })),
  };
}
function wireEnemy(enemy: Enemy): Enemy {
  const cue = enemy.attackCue;
  return {
    ...wireMovement(enemy), hp: wireSeconds(enemy.hp), timer: wireSeconds(enemy.timer), hurt: wireSeconds(enemy.hurt),
    attackCooldown: wireSeconds(enemy.attackCooldown), aiTimer: wireOptionalSeconds(enemy.aiTimer),
    // The cue and locked target are copied exactly so the telegraph matches the host.
    attackCue: cue && { ...cue },
    burnTime: wireOptionalSeconds(enemy.burnTime), burnTick: wireOptionalSeconds(enemy.burnTick),
    nextMechanismHit: wireOptionalSeconds(enemy.nextMechanismHit), comboStagger: wireOptionalSeconds(enemy.comboStagger),
  };
}
function wireBoss(boss: Boss): Boss {
  return {
    ...wireMovement(boss), hp: wireSeconds(boss.hp), guard: wireSeconds(boss.guard),
    timer: wireSeconds(boss.timer), hurt: wireSeconds(boss.hurt), exposed: wireSeconds(boss.exposed),
    targetX: wirePixel(boss.targetX), burnTime: wireOptionalSeconds(boss.burnTime), burnTick: wireOptionalSeconds(boss.burnTick),
  };
}
function collectProjectiles(shots: readonly Projectile[], limit: number, hostile: Projectile[], allied: Projectile[]) {
  const recent: Projectile[] = [];
  for (const shot of shots) {
    if (shot.life <= 0) continue;
    if (shot.owner === 'enemy') hostile.push(shot);
    else recent.push(shot);
  }
  allied.push(...recent.slice(-limit));
}

function settleOffset(value: number, blend: number, maxStep: number) {
  return value - Math.sign(value) * Math.min(Math.abs(value) * blend, maxStep);
}
const nextInput = (held: InputState, pending: InputState) => {
  const result = { ...held };
  for (const key of edges) { result[key] = pending[key] === true; pending[key] = false; }
  result.dropPressed = pending.dropPressed;
  pending.dropPressed = false;
  return result;
};

const isContactSound = (name: SoundName) => typeof name === 'string' && (name.endsWith('Contact') || name.endsWith('Finisher'));

type UpgradeChoice = { id: string; level: number };
type Command = { kind: 'input'; seq: number; bits: number; upgrade?: UpgradeChoice; weapon?: WeaponId; room: number; drop?: true };
type ViewPose = { animation: number; weapon: WeaponId; attackStep: number; attacking: boolean; attackTimer: number };
type PreviewStep = { seq: number; legacySeq: number; dt: number; input: InputState; weapon?: WeaponId };
interface ContactBeat { tick: number; name: SoundName }
interface Actor {
  engine: GameEngine;
  seq: number;
  appliedSeq: number;
  appliedSteps: number;
  weaponAck: number;
  lastPacket: number;
  held: InputState;
  pending: InputState;
  revived: boolean;
  aid: number;
  sounds: SoundName[];
  lastContact?: ContactBeat & { at: number };
}
export interface PartyTraveller {
  seat: CoopSeat; name: string; color: string; role: CoopCharacterId | null; connected: boolean; hero: Hero;
  phase: Phase; overdrive: number; resonance: number; overdriveCount: number; aid: number;
}
interface PartyStatus {
  choices: Upgrade[]; sounds: SoundName[]; synergies: string[]; coins: number; kills: number; deaths: number; shake: number; flash: number;
  announcement: string; announcementTimer: number; transition: number; cameraX: number;
  maxCombo?: number;
  weaponAck?: number;
  inputAck?: number;
  inputSteps?: number;
  motion?: CoopMotion;
  contactBeat?: ContactBeat;
  comboTexts?: FloatingText[];
}
interface World {
  kind: 'world' | 'motion'; tick: number; room: number; time: number; cleared: boolean;
  enteredAt: number; clearedAt: number | null; motionTime?: number;
  enemies: Enemy[]; boss: Boss | null; shots: Projectile[]; pickups: Pickup[];
  effects: Impact[]; sparks: Particle[]; people: PartyTraveller[];
  status: (PartyStatus | null)[]; result: GameResult | null;
}

function isCommand(data: unknown): data is Command {
  if (!data || typeof data !== 'object') return false;
  const p = data as Partial<Command>;
  return p.kind === 'input' && Number.isSafeInteger(p.seq) && p.seq! > 0 && Number.isSafeInteger(p.bits)
    && p.bits! >= 0 && p.bits! < 512 && Number.isSafeInteger(p.room);
}
function isWorld(data: unknown): data is World {
  if (!data || typeof data !== 'object') return false;
  const s = data as Partial<World>;
  return (s.kind === 'world' || s.kind === 'motion') && Number.isSafeInteger(s.tick) && Number.isSafeInteger(s.room)
    && typeof s.time === 'number' && Number.isFinite(s.time) && Number.isFinite(s.enteredAt)
    && (s.clearedAt === null || Number.isFinite(s.clearedAt))
    && Array.isArray(s.people) && s.people.length <= 4 && s.people.every(p => p && p.hero &&
      Number.isFinite(p.hero.x) && Number.isFinite(p.hero.y) && Number.isFinite(p.hero.hp))
    && Array.isArray(s.status) && s.status.length === 4 && Array.isArray(s.enemies) && s.enemies.length <= 24
    && Array.isArray(s.shots) && s.shots.length <= 96 && Array.isArray(s.pickups) && s.pickups.length <= 84
    && Array.isArray(s.effects) && s.effects.length <= 18 && Array.isArray(s.sparks) && s.sparks.length <= 60;
}

export class CoopPlay {
  private readonly actors = new Map<CoopSeat, Actor>();
  private tickNumber = 0;
  private inputSeq = Date.now() * 1000;
  private clock = 0;
  private lastSend = -1;
  private lastWorld = -1;
  private lastContactTick = -1;
  private enemyDeaths = 0;
  private movePending: InputState = { ...EMPTY_INPUT };
  private lastHeldBits = 0;
  private flushInput = false;
  private lastSnapshotAt = 0;
  private sceneTime = 0;
  private lastSceneAt = 0;
  private sceneRoom = -1;
  private readonly preview?: GameEngine;
  private previewSteps: PreviewStep[] = [];
  private previewReady = false;
  private previewOffset = { x: 0, y: 0 };
  private pendingUpgrade?: UpgradeChoice;
  private pendingWeapon?: { id: WeaponId; firstInput: number };
  private world: World | null = null;
  private chapterIndex = 0;
  private enteredAt = 0;
  private clearedAt: number | null = null;
  private pendingPortal = 0;
  private lastStandAt: number | null = null;
  private closed = false;
  private countdownTime = 0;
  private targetHeroes: Hero[] = [];
  private viewRoom = -1;
  private lastDisplayClock = 0;
  private viewMotionTime = 0;
  private viewCamera = 0;
  private readonly viewHeroes = new Map<CoopSeat, { x:number; y:number }>();
  private readonly viewPoses = new Map<CoopSeat, ViewPose>();
  private readonly viewEnemies = new Map<number, { x:number; y:number }>();

  constructor(private readonly session: CoopSession, private readonly engine: GameEngine, readonly room: CoopRoom, private readonly sound?: (name:SoundName)=>void) {
    const startActor = (game: GameEngine, player: CoopPlayer | undefined) => {
      const character = player?.role ?? undefined;
      const weapon = getCharacterWeapons(character)[0];
      const seat = player?.seat ?? 0;
      const buffSeed = (room.config.seed ^ ((room.startAt ?? 0) >>> 0) ^ Math.imul(seat, 0x9e3779b9)) >>> 0;
      game.startCoop({ ...room.config, weapon, character, buffSeed }, room.players.length);
      game.setCoopReplica(seat);
    };
    startActor(this.engine, room.players.find(player => player.seat === session.view.seat));
    if (!session.view.isHost) {
      this.preview = new GameEngine();
      return;
    }
    for (const p of room.players) {
      const sounds: SoundName[] = [];
      const game = p.seat === 0 ? engine : new GameEngine({ sound: name => { if (sounds.length < 12) sounds.push(name); } });
      if (game !== engine) startActor(game, p);
      this.actors.set(p.seat, { engine: game, seq: 0, appliedSeq:0, appliedSteps:0, weaponAck:0, lastPacket: -2, revived: false, aid: 0, sounds,
        held: { ...EMPTY_INPUT }, pending: { ...EMPTY_INPUT } });
    }
    this.engine.setCoopTargets(() => this.targetHeroes);
    this.countdownTime = .15;
  }

  private activeActors(): { player: CoopPlayer; actor: Actor }[] {
    const players = this.session.view.room?.players ?? [];
    return players.flatMap(player => {
      const actor = this.actors.get(player.seat);
      return actor && player.connected ? [{player, actor}] : [];
    });
  }

  acceptInput(seat: CoopSeat, value: unknown) {
    const actor = this.actors.get(seat);
    if (seat === 0 || !actor || !isCommand(value) || value.seq <= actor.seq) return;
    if (value.room !== this.engine.state.roomIndex) return;
    actor.seq = value.seq;
    const choice = value.upgrade;
    if (choice && typeof choice.id === 'string' && choice.id.length < 32 && choice.level === actor.engine.state.hero.level) {
      actor.engine.chooseUpgrade(choice.id);
    }
    actor.lastPacket = this.clock;
    const target = actor.engine.state;
    if (target.character && target.phase === 'playing' && target.hero.hp > 0 && isLoadoutWeapon(target.character,value.weapon)) {
      if (target.hero.weapon !== value.weapon) actor.engine.equipWeapon(value.weapon);
      if (target.hero.weapon === value.weapon) actor.weaponAck = value.seq;
    }
    inputKeys.forEach((key, index) => {
      const down = (value.bits & (1 << index)) !== 0;
      if (index < heldKeys.length) actor.held[key] = down;
      else if (down) actor.pending[key] = true;
    });
    if (value.drop === true) actor.pending.dropPressed = true;
  }

  acceptWorld(value: unknown) {
    if (this.session.view.isHost || !isWorld(value) || value.tick <= this.lastWorld) return;
    const seat = this.session.view.seat, mine = value.people.find(p => p.seat === seat);
    if (!mine || seat === null || !value.status[seat]) return;
    if (value.room < 0 || value.room >= this.engine.state.roomCount) return;
    if (value.kind === 'motion' && this.sceneRoom !== value.room) return;
    this.lastWorld = value.tick;
    const s = this.engine.state, status = value.status[seat]!, oldPhase = s.phase;
    const discontinuity = s.roomIndex !== value.room || status.deaths !== s.deaths || mine.hero.hp <= 0 || oldPhase !== mine.phase;
    if (s.roomIndex !== value.room) this.engine.forceCoopRoom(value.room);
    s.hero = mine.hero; s.enemies = value.enemies; s.boss = value.boss;
    if (value.kind === 'world') {
      this.sceneTime = Number.isFinite(value.motionTime) ? value.motionTime! : value.tick / 15;
      this.sceneRoom = value.room;
      this.lastSceneAt = this.clock;
      s.projectiles = value.shots; s.pickups = value.pickups; s.impacts = value.effects; s.particles = value.sparks;
    }
    s.floatingTexts = Array.isArray(status.comboTexts) ? status.comboTexts.slice(-6) : [];
    s.time = value.time; s.roomCleared = value.cleared; s.roomIndex = value.room;
    s.roomsCleared = value.result?.roomsCleared ?? value.room + Number(value.cleared);
    s.overdrive = mine.overdrive; s.resonance = mine.resonance; s.overdriveCount = mine.overdriveCount;
    s.phase = value.result ? value.result.won ? 'victory' : 'gameover' : mine.phase;
    s.upgradeChoices = status.choices; s.synergies = status.synergies;
    s.coins = status.coins; s.kills = status.kills; s.deaths = status.deaths;
    s.maxCombo = status.maxCombo ?? 0;
    s.shake = status.shake; s.flash = status.flash; s.cameraX = status.cameraX;
    s.announcement = status.announcement; s.announcementTimer = status.announcementTimer;
    s.transition = status.transition; s.result = value.result;
    const beat = status.contactBeat;
    for (const sound of status.sounds ?? []) {
      if (!beat || !isContactSound(sound)) this.sound?.(sound);
    }
    if (beat && Number.isSafeInteger(beat.tick) && beat.tick > this.lastContactTick && isContactSound(beat.name)) {
      this.lastContactTick = beat.tick;
      this.sound?.(beat.name);
    }
    if (this.pendingUpgrade && (s.phase !== 'upgrade' || s.hero.level !== this.pendingUpgrade.level)) this.pendingUpgrade = undefined;
    if (this.pendingWeapon && (status.weaponAck ?? 0) >= this.pendingWeapon.firstInput && s.hero.weapon === this.pendingWeapon.id) {
      this.pendingWeapon = undefined;
    }
    if (discontinuity || s.phase !== 'playing') this.movePending = { ...EMPTY_INPUT };
    this.lastSnapshotAt = this.clock;
    this.reconcilePreview(status, discontinuity);
    this.world = value;
  }

  private reconcilePreview(status: PartyStatus, discontinuity: boolean) {
    const preview = this.preview, state = this.engine.state;
    const {motion,inputAck} = status;
    if (!preview || !motion || !Number.isSafeInteger(inputAck) || state.phase !== 'playing' || state.hero.hp <= 0 ||
        typeof motion.variableJump !== 'boolean' ||
        ![motion.jumpCutSpeed,motion.attackBuffer,motion.pendingGuard,motion.hitstop].every(Number.isFinite)) {
      this.previewReady = false;
      this.previewSteps = [];
      return;
    }
    if (discontinuity) this.previewSteps = [];
    const replay = this.unappliedSteps(inputAck!, status.inputSteps);
    const oldHero = preview.state.hero;
    const reconcile = this.previewReady && !discontinuity && preview.state.roomIndex === state.roomIndex;
    preview.resetCoopPreview(state, motion);
    for (const step of replay) preview.tickCoopPreview(step.dt, step.input, step.weapon);
    const hero = preview.state.hero;
    const smooth = reconcile && Math.hypot(oldHero.x-hero.x,oldHero.y-hero.y) <= MAX_OFFSET;
    this.previewOffset = smooth ? {
      x:clampOffset(oldHero.x+this.previewOffset.x-hero.x),
      y:clampOffset(oldHero.y+this.previewOffset.y-hero.y),
    } : {x:0,y:0};
    this.previewReady = true;
  }

  private unappliedSteps(ack: number, count: number | undefined): PreviewStep[] {
    const steps = this.previewSteps;
    if (!Number.isSafeInteger(count) || count! < 1) return steps.filter(step => step.legacySeq > ack);

    const first = steps.findIndex(step => step.seq === ack && step.legacySeq === ack);
    if (first < 0) return steps.filter(step => step.seq >= ack);
    const applied = steps[first];
    const end = Math.min(first + count!, steps.length);
    let cursor = first + 1;
    // The host keeps simulating a held command while the next heartbeat is
    // in flight. Only skip steps it could have simulated with that command.
    while (cursor < end) {
      const step = steps[cursor];
      if (step.weapon !== applied.weapon || step.input.dropPressed || edges.some(key => step.input[key]) ||
          heldKeys.some(key => step.input[key] !== applied.input[key])) break;
      cursor++;
    }
    return steps.slice(cursor);
  }

  chooseUpgrade(id: string) {
    if (this.session.view.isHost) this.engine.chooseUpgrade(id);
    else {
      this.pendingUpgrade = { id, level: this.engine.state.hero.level };
      this.flushInput = true;
    }
  }

  equipWeapon(id: WeaponId) {
    const state = this.engine.state;
    if (this.closed || state.phase !== 'playing' || state.hero.hp <= 0 || !state.character || !isLoadoutWeapon(state.character,id)) return;
    if (this.session.view.isHost) this.engine.equipWeapon(id);
    else if (this.pendingWeapon?.id !== id && (this.pendingWeapon || id !== state.hero.weapon)) {
      this.pendingWeapon = { id,firstInput:this.inputSeq+1 };
      this.flushInput = true;
    }
  }

  tick(dt: number, input: InputState): void {
    if (this.closed) return;
    this.clock += dt;
    if (!this.session.view.isHost) {
      const phase = this.engine.state.phase;
      for (const key of edges) this.movePending[key] ||= input[key] === true;
      this.movePending.dropPressed ||= input.dropPressed === true;
      const heldBits = heldKeys.reduce((value,key,index) => value | (input[key] ? 1 << index : 0),0);
      const legacySeq = this.inputSeq + 1;
      if (this.flushInput || heldBits !== this.lastHeldBits || this.movePending.dropPressed || edges.some(key => this.movePending[key]) ||
          this.clock - this.lastSend >= INPUT_INTERVAL) {
        this.flushInput = false;
        this.lastSend = this.clock;
        this.lastHeldBits = heldBits;
        const sampled = nextInput(input, this.movePending);
        const bits = inputKeys.reduce((value,key,index) => value | (sampled[key] ? 1 << index : 0),0);
        this.session.send({kind:'input', seq:++this.inputSeq, bits,
          upgrade:this.pendingUpgrade, weapon:this.pendingWeapon?.id, room:this.engine.state.roomIndex,
          drop:sampled.dropPressed ? true : undefined} satisfies Command);
      }
      if (this.previewReady && this.preview && phase === 'playing' && this.clock-this.lastSnapshotAt < PREDICTION_WINDOW) {
        const step: PreviewStep = { seq:this.inputSeq, legacySeq, dt, input, weapon:this.pendingWeapon?.id };
        this.preview.tickCoopPreview(dt,input,step.weapon);
        this.previewSteps.push(step);
        if (this.previewSteps.length > PREDICTION_TICKS) this.previewSteps.shift();
      }
      return;
    }
    if (this.countdownTime > 0) { this.countdownTime -= dt; return; }
    if (!this.engine.state.result) this.advance(dt, input);
    if (this.clock - this.lastSend >= WORLD_INTERVAL) {
      this.lastSend = this.clock;
      const state = this.engine.state, boss = state.boss, lastBoss = this.world?.boss;
      const split = this.room.players.length === 4 && this.session.splitWorlds;
      const bossChanged = boss?.phase !== lastBoss?.phase || boss?.form !== lastBoss?.form || boss?.active !== lastBoss?.active;
      const full = !split || this.sceneRoom !== state.roomIndex || this.world?.cleared !== state.roomCleared ||
        bossChanged || this.tickNumber % PARTY_SCENE_TICKS === 0 || Boolean(state.result);
      const snapshot = this.snapshot(full, split);
      this.world = snapshot;
      if (full) this.sceneRoom = snapshot.room;
      this.session.broadcast(snapshot, full);
    }
  }

  private advance(dt: number, input: InputState) {
    const host = this.engine.state, originalPhase = host.boss?.phase, originalForm = host.boss?.form;
    const active = this.activeActors();
    this.targetHeroes = active.map(({actor}) => actor.engine.state.hero);
    this.engine.tickCoop(dt, input);
    const enemyShots = host.projectiles.filter(shot => shot.owner === 'enemy' && shot.life > 0);
    const remaining = new Set<number>();
    for (const {player, actor} of active) {
      if (player.seat === 0 || host.result) continue;
      const engine = actor.engine, s = engine.state;
      if (s.roomIndex !== host.roomIndex) engine.forceCoopRoom(host.roomIndex);
      s.enemies = host.enemies; s.boss = host.boss; s.pickups = host.pickups;
      s.time = host.time - dt; s.roomCleared = host.roomCleared;
      // Keep a separate copy per actor: the local tick can spend a bolt while
      // the host still owns its position, delay and remaining flight time.
      for (const shot of enemyShots) {
        if (shot.life > 0) s.projectiles.push({ ...shot, hitIds: [...shot.hitIds] });
      }
      const action = nextInput(this.clock-actor.lastPacket < .9 ? actor.held : EMPTY_INPUT, actor.pending);
      engine.tickCoop(dt, action);
      if (actor.appliedSeq !== actor.seq) actor.appliedSteps = 0;
      actor.appliedSeq = actor.seq;
      actor.appliedSteps = Math.min(PREDICTION_TICKS, actor.appliedSteps + 1);
      host.pickups = s.pickups;
      remaining.clear();
      let ownShots = 0;
      for (const shot of s.projectiles) {
        if (shot.owner === 'hero') s.projectiles[ownShots++] = shot;
        else remaining.add(shot.id);
      }
      s.projectiles.length = ownShots;
      if (originalPhase === host.boss?.phase && originalForm === host.boss?.form) {
        for (const shot of enemyShots) if (!remaining.has(shot.id) && !shot.delay && shot.life > dt) shot.life = 0;
      }
    }
    if (originalPhase !== host.boss?.phase || originalForm !== host.boss?.form)
      host.projectiles = host.projectiles.filter(p => p.owner==='hero');

    this.aidParty(active, dt);
    const hasLivingAlly = active.some(({actor}) => actor.engine.state.hero.hp > 0);
    if (hasLivingAlly) this.lastStandAt = null;
    else {
      const canReconnect = [...this.actors.values()].some(actor => actor.engine.state.hero.hp > 0);
      this.lastStandAt ??= this.clock;
      if (!canReconnect || this.clock - this.lastStandAt >= 12) {
        this.engine.completeCoop(false); return;
      }
    }
    const defeated = host.enemies.filter(e=>e.dead).length;
    if (defeated > this.enemyDeaths) {
      for (const {actor} of active) actor.engine.grantCoopXP(2 * (defeated - this.enemyDeaths));
      this.enemyDeaths = defeated;
    }
    if (host.boss?.mode === 'dead' && host.roomIndex === host.roomCount - 1) {
      host.roomsCleared = host.roomCount; this.engine.completeCoop(true); return;
    }
    const clear = host.room.isBoss ? host.boss?.mode === 'dead' : host.enemies.every(e=>e.dead);
    if (clear && !host.roomCleared) {
      host.roomCleared = true; host.roomsCleared = host.roomIndex+1;
      host.announcement = '全队已清场 · 在星门会合'; host.announcementTimer = 3;
      for (const {actor} of active) actor.engine.grantCoopXP(5);
    }
    if (!clear) return;
    const living = active.filter(({actor}) => actor.engine.state.hero.hp > 0);
    const nearGate = living.filter(({actor}) => {
      const h = actor.engine.state.hero, gate = host.room.exit;
      return Math.abs(h.x+h.w/2-(gate.x+gate.w/2)) < 112 && h.y+h.h >= gate.y - 30;
    });
    this.pendingPortal = nearGate.length > 0 ? this.pendingPortal + dt : 0;
    if (nearGate.length && (nearGate.length === living.length || this.pendingPortal >= 5)) {
      const next = host.roomIndex + 1;
      if (next >= host.roomCount) return;
      for (const actor of this.actors.values()) {
        actor.engine.forceCoopRoom(next); actor.aid = 0; actor.revived = false;
        actor.held = { ...EMPTY_INPUT }; actor.pending = { ...EMPTY_INPUT }; actor.lastPacket = -2;
        const h = actor.engine.state.hero;
        if (h.hp <= 0) { h.hp = 2; h.invincible = 2; }
      }
      this.enemyDeaths = this.pendingPortal = 0;
    }
  }

  private aidParty(active: ReturnType<CoopPlay['activeActors']>, dt: number) {
    for (const {actor} of active) {
      const h = actor.engine.state.hero;
      if (h.hp > 0 || actor.revived) { actor.aid = 0; continue; }
      const helping = active.some(({actor: other}) => {
        const ally = other.engine.state.hero;
        return ally.hp > 0 && Math.abs(ally.x-h.x) < 61 && Math.abs(ally.y-h.y) < 45;
      });
      actor.aid = helping ? Math.min(1.15, actor.aid + dt) : 0;
      if (actor.aid >= 1.15) { actor.revived = true; h.hp = Math.ceil(h.maxHp * .45); h.invincible = 2; actor.aid = 0; }
    }
  }

  private snapshot(full: boolean, split: boolean): World {
    const h = this.engine.state, status: World['status'] = [null,null,null,null];
    if (this.chapterIndex !== h.roomIndex) {
      this.chapterIndex = h.roomIndex;
      this.enteredAt = h.time;
      this.clearedAt = null;
    }
    if (h.roomCleared && this.clearedAt === null) this.clearedAt = h.time;
    const people: PartyTraveller[] = [], hostileShots: Projectile[] = [], alliedShots: Projectile[] = [];
    const alliedLimit = split ? PARTY_SHOTS_PER_TRAVELLER : SCENE_SHOT_LIMIT;
    if (full) collectProjectiles(h.projectiles, alliedLimit, hostileShots, alliedShots);
    const effects = full ? [...h.impacts] : [];
    const four = this.room.players.length === 4;
    const sparks = full ? h.particles.slice(four ? -10 : -18) : [];
    const players = this.session.view.room?.players ?? [];
    for (const player of players) {
      const actor = this.actors.get(player.seat);
      if (!actor) continue;
      const s=actor.engine.state, hero = s.hero;
      people.push({ ...player, hero:wireHero(hero), phase:s.phase, overdrive:wireSeconds(s.overdrive),
        overdriveCount:s.overdriveCount, resonance:wireSeconds(s.resonance), aid:wireSeconds(actor.aid) });
      const combo = getWeaponCombo(s.character);
      const sounds = actor.sounds.splice(0);
      const contact = sounds.find(name => name.endsWith('Finisher')) ?? sounds.find(isContactSound);
      if (contact) actor.lastContact = { tick: this.tickNumber + 1, name: contact, at: this.clock };
      // A polling guest can skip the short snapshot which contained the original hit.
      const beat = actor.lastContact;
      const contactBeat = beat && this.clock - beat.at < .5 ? { tick: beat.tick, name: beat.name } : undefined;
      status[player.seat] = {choices:s.upgradeChoices,sounds,contactBeat,synergies:s.synergies,coins:s.coins,kills:s.kills,deaths:s.deaths,maxCombo:s.maxCombo,
        shake:wireSeconds(s.shake),flash:wireSeconds(s.flash),announcement:s.announcement,announcementTimer:wireSeconds(s.announcementTimer),
        transition:wireSeconds(s.transition),cameraX:wirePixel(s.cameraX),weaponAck:actor.weaponAck,
        inputAck:actor.appliedSeq,inputSteps:actor.appliedSteps,motion:player.seat === 0 ? undefined : actor.engine.captureCoopMotion(),
        comboTexts:player.seat !== 0 && combo ? s.floatingTexts.filter(text => text.text === combo.name).slice(-6)
          .map(text => ({ ...wirePosition(text), life:wireSeconds(text.life) })) : undefined};
      if (full && player.seat !== 0 && player.connected) {
        collectProjectiles(s.projectiles, alliedLimit, hostileShots, alliedShots);
        effects.push(...s.impacts.slice(-4)); sparks.push(...s.particles.slice(four ? -3 : -6));
      }
    }
    // Keep dangerous shots first. Each traveller has a visual budget for busy allied volleys.
    const hostile = hostileShots.slice(-SCENE_SHOT_LIMIT);
    const roomForAllies = SCENE_SHOT_LIMIT - hostile.length;
    const allied = roomForAllies > 0 ? alliedShots.slice(-roomForAllies) : [];
    return {kind:full ? 'world' : 'motion',tick:++this.tickNumber,room:h.roomIndex,time:wireSeconds(h.time),cleared:h.roomCleared,
      enteredAt:wireSeconds(this.enteredAt),clearedAt:this.clearedAt === null ? null : wireSeconds(this.clearedAt),motionTime:wireSeconds(this.clock),
      enemies:h.enemies.map(wireEnemy),boss:h.boss&&wireBoss(h.boss),
      shots:[...hostile, ...allied].map(p=>({...wireMovement(p),hitIds:[],
        life:wireSeconds(p.life),rotation:wireOptionalSeconds(p.rotation),delay:wireOptionalSeconds(p.delay)})),
      pickups:full ? h.pickups.filter(p=>!p.collected).slice(-84).map(p=>({...wirePosition(p),
        vy:wirePixel(p.vy),bob:wireSeconds(p.bob)})) : [],
      effects:effects.slice(-18).map(p=>({...wirePosition(p),size:wirePixel(p.size),angle:wireSeconds(p.angle),
        life:wireSeconds(p.life),maxLife:wireSeconds(p.maxLife)})),
      // Cosmetic sparks share a per-traveller budget so busy fights don't crowd out world updates.
      sparks:sparks.map(p=>({...p,x:wirePixel(p.x),y:wirePixel(p.y),vx:Math.round(p.vx),vy:Math.round(p.vy),
        life:wireSeconds(p.life),maxLife:wireSeconds(p.maxLife)})),
      people,status,result:h.result};
  }

  party(): readonly PartyTraveller[] {
    return this.world?.people ?? [];
  }
  get chapterClock(): Readonly<Pick<World,'room'|'time'|'enteredAt'|'clearedAt'>> | null {
    return this.world;
  }
  display(dt: number) {
    const state = this.engine.state, seat = this.session.view.seat;
    const host = this.session.view.isHost;
    if (state.roomIndex !== this.viewRoom) {
      this.viewRoom = state.roomIndex;
      this.viewHeroes.clear(); this.viewPoses.clear(); this.viewEnemies.clear(); this.viewCamera = state.cameraX;
      this.viewMotionTime = 0;
    }
    const blend = 1 - Math.exp(-dt * 21);
    const age = host ? 0 : Math.max(0, this.clock - this.lastSnapshotAt);
    // A fresh packet can still be behind the movement already drawn.
    // Advance the presentation cursor without rewinding that elapsed time.
    const stamp = this.world?.motionTime;
    const sampleTime = Number.isFinite(stamp) ? stamp! : (this.world?.tick ?? 0) / 15;
    this.viewMotionTime = Math.max(this.viewMotionTime, sampleTime + Math.min(MAX_WORLD_LOOKAHEAD, age));
    const lead = host ? 0 : Math.min(MAX_WORLD_LOOKAHEAD, this.viewMotionTime - sampleTime);
    const shown = this.previewReady && state.phase === 'playing' ? this.preview?.state : undefined;
    const correction = 1 - Math.exp(-dt * 16);
    const advanced = Math.max(0, this.clock - this.lastDisplayClock);
    this.lastDisplayClock = this.clock;
    const hero = shown?.hero;
    // At high refresh rates, several draws can share one physics step.
    // Do not nudge the presentation backwards between two moving steps.
    const vx = hero?.vx ?? 0, vy = hero?.vy ?? 0;
    const limitX = vx && Math.sign(vx) === Math.sign(this.previewOffset.x) ? Math.abs(vx) * .72 * advanced : 540 * dt;
    const limitY = vy && Math.sign(vy) === Math.sign(this.previewOffset.y) ? Math.abs(vy) * .72 * advanced : 720 * dt;
    this.previewOffset.x = settleOffset(this.previewOffset.x, correction, limitX);
    this.previewOffset.y = settleOffset(this.previewOffset.y, correction, limitY);
    const people = this.party().map(person => {
      const target = this.actors.get(person.seat)?.engine.state.hero ?? person.hero;
      if (shown && person.seat === seat) {
        const h = shown.hero;
        const { animation, attackTimer } = this.advancePose(person.seat, h, dt, 0);
        return {...person,hero:{...target,
          x:h.x+this.previewOffset.x,y:h.y+this.previewOffset.y,
          vx:h.vx,vy:h.vy,grounded:h.grounded,facing:h.facing,animation,
          attackTimer,attackStep:h.attackStep,dashTimer:h.dashTimer,guardTimer:h.guardTimer,weapon:h.weapon,
        }};
      }
      const x = Math.max(0,Math.min(state.room.width-target.w,target.x+target.vx*lead));
      let y = target.y+(target.grounded ? 0 : target.vy*lead);
      if (lead > 0 && !target.grounded && target.vy > 0) {
        // Preserve the visual landing on the first platform during packet loss.
        for (const platform of state.room.platforms) {
          if (x < platform.x+platform.w && x+target.w > platform.x &&
              target.y+target.h <= platform.y+4 && y+target.h >= platform.y) {
            y = platform.y-target.h;
          }
        }
      }
      const previous = this.viewHeroes.get(person.seat);
      const snap = !previous || Math.hypot(x-previous.x,y-previous.y)>140 || target.hp<=0;
      const p = snap ? {x,y} : { x:previous.x+(x-previous.x)*blend, y:previous.y+(y-previous.y)*blend };
      this.viewHeroes.set(person.seat,p);
      const { animation, attackTimer } = this.advancePose(person.seat, target, dt, lead);
      return {...person,hero:{...target,...p,animation,
        attackTimer,dashTimer:Math.max(0,target.dashTimer-age),
        guardTimer:Math.max(0,target.guardTimer-age),
      }};
    });
    const self = people.find(person=>person.seat===seat);
    const camera = shown ? shown.cameraX : state.cameraX;
    this.viewCamera += (camera-this.viewCamera)*blend;
    let visual = state;
    if (self && !host) {
      const enemies = state.enemies.map(enemy => {
        if (enemy.dead) return enemy;
        const x = enemy.x+enemy.vx*lead, y = enemy.y+enemy.vy*lead;
        const prior = this.viewEnemies.get(enemy.id);
        const p = prior && Math.hypot(x-prior.x,y-prior.y)<120
          ? {x:prior.x+(x-prior.x)*blend,y:prior.y+(y-prior.y)*blend} : {x,y};
        this.viewEnemies.set(enemy.id,p);
        return {...enemy,...p,timer:enemy.timer+lead,hurt:Math.max(0,enemy.hurt-age)};
      });
      const sceneAge = Math.max(0,this.viewMotionTime-this.sceneTime,this.clock-this.lastSceneAt);
      const bound = Math.min(MAX_WORLD_LOOKAHEAD,sceneAge);
      const projectiles = state.projectiles.filter(p=>p.life>sceneAge).map(p=>{
        const flight = Math.max(0, bound - (p.delay ?? 0));
        return {...p,x:p.x+p.vx*flight,y:p.y+p.vy*flight+.5*(p.gravity ?? 0)*flight*flight,life:p.life-sceneAge,
          delay:p.delay === undefined ? undefined : Math.max(0,p.delay-bound),rotation:p.rotation===undefined ? undefined : p.rotation+flight*16};
      });
      const particles = state.particles.filter(p=>p.life>sceneAge).map(p=>({...p,x:p.x+p.vx*bound,y:p.y+p.vy*bound,life:p.life-sceneAge}));
      const impacts = state.impacts.filter(p=>p.life>sceneAge).map(p=>({...p,life:p.life-sceneAge}));
      const boss = state.boss;
      visual = {...state,hero:self.hero,cameraX:this.viewCamera,enemies,projectiles,particles,impacts,
        boss:boss && {...boss,x:boss.x+boss.vx*lead,y:boss.y+boss.vy*lead,timer:Math.max(0,boss.timer-lead)},
        time:state.time+lead,shake:Math.max(0,state.shake-22*age),flash:Math.max(0,state.flash-2.6*age)};
    }
    if (host) {
      const alliedHits = people.flatMap(person => person.seat !== seat && person.connected
        ? this.actors.get(person.seat)?.engine.state.impacts.filter(effect => effect.contact || effect.enemyVariant).slice(-4) ?? [] : []);
      if (alliedHits.length) visual = { ...state, impacts: [...state.impacts, ...alliedHits] };
    }
    return { state:visual, party:{people,seat,shots:this.partyProjectiles()} };
  }

  private advancePose(seat: CoopSeat, hero: Hero, dt: number, lead: number): ViewPose {
    const previous = this.viewPoses.get(seat);
    const attacking = hero.attackTimer > 0;
    const activeAttack = attacking && previous?.attacking &&
      previous.weapon === hero.weapon && previous.attackStep === hero.attackStep;
    const timer = Math.max(0, hero.attackTimer - lead);
    const pose: ViewPose = {
      animation: (previous?.animation ?? hero.animation) + dt,
      weapon: hero.weapon,
      attackStep: hero.attackStep,
      attacking,
      attackTimer: activeAttack ? Math.min(timer, Math.max(0, previous.attackTimer - dt)) : timer,
    };
    this.viewPoses.set(seat, pose);
    return pose;
  }

  private partyProjectiles(): readonly Projectile[] {
    if (!this.session.view.isHost) return [];
    const state = this.engine.state;
    const allies = this.party().filter(person => person.seat !== 0 && person.connected);
    if (!allies.length) return [];
    const left = state.cameraX - 220, right = state.cameraX + 1180;
    const visible = (shot: Projectile) => shot.life > 0 && shot.x + shot.w >= left && shot.x <= right;
    const available = Math.max(0, 96 - state.projectiles.filter(visible).length);
    const perAlly = Math.floor(available / allies.length);
    if (!perAlly) return [];
    return allies.flatMap(({ seat }) => this.actors.get(seat)?.engine.state.projectiles
      .filter(shot => shot.owner === 'hero' && visible(shot)).slice(-perAlly) ?? []);

  }
  stop() { this.closed = true; this.actors.clear(); this.world = null; }
}
