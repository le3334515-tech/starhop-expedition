import type { Impact, WeaponId } from './types';

type Point = readonly [number, number];
type Stroke = { weapon: WeaponId; travel: number; strong: boolean };
const IVORY = '#fff1ce';

function shape(c: CanvasRenderingContext2D, color: string, points: readonly Point[]) {
  c.fillStyle = color;
  c.beginPath();
  c.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) c.lineTo(points[i][0], points[i][1]);
  c.closePath();
  c.fill();
}

function line(c: CanvasRenderingContext2D, color: string, points: readonly Point[], width = 1) {
  c.strokeStyle = color;
  c.lineWidth = width;
  c.beginPath();
  c.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) c.lineTo(points[i][0], points[i][1]);
  c.stroke();
}

function bladeContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  if (weapon === 'willowSword') {
    // The point exits the target; the little hooked reflection follows it.
    const end = (strong ? 30 : 23) + travel*7;
    shape(c,'#799586',[[-19,3],[-7,-1],[7,-2],[end,0],[7,1],[-6,1]]);
    line(c,'#e4e8cc',[[-17,3],[-5,0],[9,-1],[end,0]],strong ? 1.9 : 1.25);
    line(c,'#b8c8a8',[[6,-4],[11,-6],[17,-5]],1.4);
    if (strong) line(c,'#829e90',[[-6,5],[3,4],[12,2]]);
    return;
  }
  if (weapon === 'swallowDart') {
    const lead=travel*6, split=travel*4;
    shape(c,'#c09a82',[[-10,0],[-1,-3],[7,-4],[18+lead,-10-split],[11,-3],[1,0]]);
    shape(c,'#9d7765',[[-8,3],[1,1],[10,3],[16+lead,6+split],[8,5],[1,3]]);
    line(c,'#ead8b7',[[-7,1],[1,-1],[9,-4],[17+lead,-9-split]],1.5);
    if (strong) line(c,'#dcbaa0',[[9,1],[16,-1],[21+lead,-4]]);
    return;
  }
  const edge = '#eaa59b';
  c.rotate(-.42);
  const flight = 4 * travel;
  shape(c, '#713a47', [[-23,7],[-13,0],[-3,-2],[12,-7],[25+flight,-14],[12,-1],[2,5],[-12,9]]);
  shape(c, edge, [[-20,6],[-10,1],[0,-1],[13,-6],[26+flight,-14],[12,-4],[3,3],[-11,7]]);
  line(c, IVORY, [[-13,4],[-4,1],[9,-3],[22+flight,-12]], strong ? 2 : 1.25);
  if (strong) {
    const y = 8 + travel * 4;
    shape(c, edge, [[-10,y+3],[7,y-3],[18+flight,y-12],[15,y-5],[5,y+2]]);
    shape(c, IVORY, [[-17,0],[-20,1],[-25,3],[-23,0],[-16,-2]]);
  }
}

function staffContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  if (weapon==='frostStaff') {
    const reach=(strong ? 17 : 12)+travel*8;
    for (const angle of [-1.05,-.17,.72]) {
      c.save(); c.rotate(angle);
      shape(c,'#7fa8b6',[[1,1],[7,-2],[reach*.67,-2],[reach+4,-4],[reach-1,0],[5,2]]);
      line(c,'#dce8e1',[[5,0],[reach*.64,-1],[reach+2,-3]],1.3);
      line(c,'#a2bdc1',[[reach*.56,-1],[reach*.64,-5],[reach*.82,-7]]);
      c.restore();
    }
    return;
  }
  if (weapon==='moonMirror') {
    const radius=(strong ? 14 : 10)+travel*7;
    c.rotate(-.23);
    c.strokeStyle='#c7b8d1'; c.lineWidth=1.7;
    c.beginPath(); c.ellipse(1,0,radius*.48,radius,0,-1.43,1.64); c.stroke();
    c.strokeStyle='#e7d7c9'; c.lineWidth=1.15;
    c.beginPath(); c.ellipse(-2,0,radius*.39,radius*.79,0,1.88,4.35); c.stroke();
    shape(c,'#b1a5bb',[[-19,0],[-5,-2],[7,-1],[22+travel*4,0],[3,2],[-6,1]]);
    line(c,'#f2eadd',[[-12,0],[18,0]],1.3);
    return;
  }
  // Moonfire licks upward and leaves a pale crescent around the ember.
  const rise=travel*8;
  shape(c,'#a4809e',[[-9,3],[-10,-3],[-4,-9-rise],[-5,-3],[1,-6],[4,-14-rise],[7,-9],[7,-2],[2,3],[-3,5]]);
  shape(c,'#e1ae8e',[[-5,2],[-1,-2],[1,-6],[1,-2],[4,-2],[2,2],[-2,4]]);
  c.strokeStyle='#ccafc7'; c.lineWidth=strong ? 1.8 : 1.3;
  c.beginPath(); c.ellipse(0,0,11+travel*5,8+travel*5,-.32,-.53,2.65); c.stroke();
  if (strong) line(c,'#edd1ac',[[8,-5],[11,-9],[12,-13-rise]],1.4);
}

function fanContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  if (weapon==='silkFan') {
    const reach = (strong ? 25 : 18) + travel * 9;
    for (const offset of [-5, 5]) {
      c.save();
      c.translate(0, offset * (1 + travel * .35));
      c.rotate(offset < 0 ? -.32 : -.16);
      shape(c, '#43726a', [[-reach*.6,3],[0,-1],[reach,-4],[reach-5,0],[0,3]]);
      line(c, offset < 0 ? '#daead1' : '#a4c6ad', [[-reach*.5,2],[1,0],[reach,-4]], strong ? 2 : 1.35);
      c.restore();
    }
    c.fillStyle = '#dbc493';
    c.fillRect(Math.round(9 + travel * 4), -3, 2, 2);
    return;
  }
  if (weapon==='jadeNeedle') {
    const reach = Math.round(13 + travel * 11);
    c.fillStyle = '#699d88';
    c.fillRect(-12, 0, reach + 12, 1);
    c.fillStyle = '#daead1';
    c.fillRect(3, -1, reach-3, strong ? 2 : 1);
    c.fillStyle = '#dbc493';
    c.fillRect(2, -5, 2, 1);
    if (strong) c.fillRect(5, 4, 3, 1);
    return;
  }
  const count = strong ? 4 : 3;
  for (let i = 0; i < count; i++) {
    const angle = (i / (count - 1) - .5) * 1.72 - .13;
    c.save(); c.rotate(angle); c.translate(6 + travel * (8 + i * 2), 0);
    const edge = '#a5dab4';
    const tail = 15;
    shape(c, '#345e53', [[-2,2],[3,-3],[11,-6],[tail,-3],[11,1],[6,4]]);
    shape(c, edge, [[-2,2],[4,-2],[11,-4],[tail,-3],[10,0],[5,3]]);
    line(c, IVORY, [[0,1],[tail-4,-3]], 1);
    c.restore();
  }
}

function spearContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  if (weapon==='halberd') {
    const drop=travel*9;
    shape(c,'#a68061',[[-14,-17],[-5,-16],[5,-11],[11,-3],[14,5],[14,17+drop],[10,11],[7,1],[1,-7],[-6,-12]]);
    line(c,'#e8c799',[[-10,-16],[-3,-13],[5,-7],[10,1],[13,11+drop]],strong ? 2.3 : 1.6);
    line(c,'#b29b83',[[1,-15],[9,-9],[13,-3]],1.3);
    if (strong) shape(c,'#c6b294',[[9,7],[16,10+drop],[19,15+drop],[13,12+drop]]);
    return;
  }
  if (weapon==='reedJavelin') {
    const tip=25+travel*10;
    shape(c,'#8da49a',[[-15,2],[-5,-1],[12,-2],[tip,0],[13,1],[-4,2]]);
    line(c,'#e1e4cd',[[-9,1],[10,-1],[tip,0]],1.5);
    for (const i of [-1,1]) {
      const y=i*(4+travel*5);
      line(c,'#aab99c',[[1,i*2],[7,y],[13,y+i]],1.2);
    }
    return;
  }
  const tip=(strong ? 30 : 24)+travel*8;
  shape(c,'#b7aa83',[[-18,1],[-4,-2],[12,-2],[tip,0],[12,2],[-5,2]]);
  line(c,'#f0e4bd',[[-10,0],[tip,0]],strong ? 2 : 1.4);
  line(c,'#c9b582',[[2,-3],[8,-8],[6,-4],[15,-6]],1.25);
  if (strong) line(c,'#c9b582',[[4,3],[9,6],[13,5],[19,8]],1.4);
}

function beadContact(c: CanvasRenderingContext2D, travel: number, strong: boolean) {
  const width=(strong ? 15 : 10)+travel*7;
  c.rotate(-.28);
  c.strokeStyle='#c4a675'; c.lineWidth=1.4;
  c.beginPath(); c.ellipse(0,0,width,width*.60,0,.25,2.75); c.stroke();
  for (let i=0;i<3;i++) {
    const a=.40+i*1.08, x=Math.cos(a)*width, y=Math.sin(a)*width*.6;
    shape(c,'#9b7b59',[[x-2,y-1],[x,y-3],[x+3,y-1],[x+2,y+2],[x-1,y+2]]);
    c.fillStyle='#e4c99a'; c.fillRect(Math.round(x),Math.round(y-2),2,1);
  }
  if (strong) line(c,'#e2c38e',[[0,-4],[4,-8],[8,-9]],1.35);
}

function fistContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  const steel = weapon === 'ironGauntlet';
  if (weapon==='prayerBeads') { beadContact(c,travel,strong); return; }
  const face = steel ? '#c6b191' : '#dbab7c';
  const shadow = steel ? '#70675c' : '#8c6952';
  const reach = 10 + travel * 10;
  const count = strong ? 5 : 3;
  if (steel) {
    // Slanted facets burst forward off the striking knuckles.
    shape(c,shadow,[[-7,-7],[1,-8],[7,-6],[10,-1],[6,4],[9,-1],[5,-4],[-2,-5]]);
    line(c,'#ebc79c',[[-4,-7],[2,-7],[8,-3]],1.7);
  } else {
    line(c,face,[[-4,-reach*.52],[2,-reach*.49],[reach*.55,-reach*.30],[reach*.76,0],[reach*.43,reach*.43],[0,reach*.54]],strong ? 2 : 1.4);
    if (strong) line(c,'#b78b67',[[reach*.58,-reach*.6],[reach*.97,-reach*.25],[reach,0]]);
  }
  for (let i = 0; i < count; i++) {
    const angle = (i/(count-1)-.5) * (steel ? 2.6 : 3.1);
    const size = (i % 3 === 1 ? 3.3 : 2.4) * (1 - travel * .44);
    const r = reach * (i % 2 ? 1 : .86);
    c.save(); c.rotate(angle); c.translate(r, 0); c.rotate(i * .4);
    if (steel) {
      shape(c, shadow, [[-size,-size],[size,-size],[size*1.5,0],[size,size],[-size,size]]);
      shape(c, face, [[-size,-size],[size,-size],[size*1.4,-size*.1],[-size*.3,size*.5]]);
    } else {
      shape(c, shadow, [[-size,-size],[size,-size*1.3],[size*1.5,-size*.2],[size,size],[-size*.8,size]]);
      shape(c, face, [[-size,-size],[size,-size*1.3],[size*1.4,-size*.3],[-size*.4,size*.16]]);
    }
    c.restore();
  }
}

/** Uses the confirmed-hit position supplied by the simulation. */
export function drawWeaponContact(c: CanvasRenderingContext2D, effect: Impact): boolean {
  const contact = effect.contact;
  if (!contact) return false;
  const life = Math.max(0, Math.min(1, effect.life / effect.maxLife));
  if (!life) return true;
  const progress = 1 - life;
  const travel = 1 - life * life;
  const strong = effect.kind !== 'hit' || contact.accent;
  const scale = Math.max(.75, Math.min(1.55, effect.size / 22)) * (.75 + travel * .35);
  const stroke = { weapon: contact.weapon, travel, strong };
  c.save();
  c.translate(Math.round(effect.x), Math.round(effect.y));
  c.scale((contact.facing < 0 ? -1 : 1) * scale, scale);
  c.globalAlpha *= Math.min(1, life * 2.3) * (strong ? 1 : .91);
  if (contact.character === 'blade') bladeContact(c, stroke);
  else if (contact.character === 'staff') staffContact(c, stroke);
  else if (contact.character === 'wheel') fanContact(c, stroke);
  else if (contact.character === 'spear') spearContact(c, stroke);
  else fistContact(c, stroke);

  if (progress < .48) {
    c.globalAlpha *= Math.min(1, (.48 - progress) * 4);
    const radius = (strong ? 11 : 6) * (.88 + progress);
    shape(c, IVORY, [[-radius,0],[-2,-2],[0,-radius*.75],[2,-2],[radius,0],[2,2],[0,radius*.75],[-2,2]]);
    if (effect.kind === 'break') {
      c.strokeStyle = effect.color; c.lineWidth = 1;
      c.beginPath(); c.arc(0, 0, radius+6, -.35, 2.83); c.stroke();
    }
  }
  c.restore();
  return true;
}
