import { describe, expect, it } from 'vitest';
import { BOSS_ASCENSION_TIME, BOSS_TRANSFORM_TIME, ECLIPSE_WIDTH, eclipseLanes, WARDEN_ENTRANCE_TIME } from './boss-seal';
import { COOP_ELITE_ROOM_INDEX, COOP_EXTRA_REALMS, COOP_ROOM_COUNT, COOP_WARDEN_ROOM_INDEX, createCoopRoom } from './coop-levels';
import { GameEngine } from './engine';
import { enemyProfile, isCourtElite } from './enemy-catalog';
import { createRoom, expeditionOrder, isSafeFloorPoint } from './levels';
import { EMPTY_INPUT, EXPEDITION_ROOM_COUNT, type Enemy, type GameConfig, type InputState } from './types';

const CONFIG: GameConfig = { seed: 20261116, modifier: 'standard', weapon: 'blade' };

function advance(game: GameEngine, seconds: number, input: Partial<InputState> = {}) {
  const steps = Math.ceil(seconds * 120);
  for (let step = 0; step < steps; step++) {
    game.update(seconds / steps, { ...EMPTY_INPUT, ...input, attackPressed: step === 0 && !!input.attackPressed });
  }
}

function strikeBoss(game: GameEngine) {
  const { hero, boss } = game.state;
  if (!boss) throw new Error('Expected boss room');
  hero.x = boss.x - 35; hero.y = 412; hero.vx = 0; hero.vy = 0;
  hero.hp = hero.maxHp; hero.invincible = 2; hero.facing = 1;
  hero.attackCooldown = 0; hero.attackTimer = 0; hero.damage = 100000;
  advance(game, .15, { attackPressed: true });
}

describe('cooperative realms', () => {
  it('spawns original furnace monsters and moon kites only in their co-op realms', () => {
    const expected = [
      [['skyforge-crab', 'forge-crab', 'guard', 'sentry'], ['skyforge-lantern', 'forge-lantern', 'burst', 'bat']],
      [['moonbridge-kite', 'moon-kite', 'dive', 'bat']],
    ];
    for (let index = 0; index < EXPEDITION_ROOM_COUNT; index++) {
      expect(createRoom(CONFIG.seed, index).enemies.some(enemy => enemyProfile(enemy)?.appearance)).toBe(false);
      expect(createCoopRoom(CONFIG.seed, index, 4).enemies.some(enemy => enemyProfile(enemy)?.appearance)).toBe(false);
    }
    for (const [index, forms] of expected.entries()) {
      const { enemies } = createCoopRoom(CONFIG.seed, EXPEDITION_ROOM_COUNT + index, 1);
      const appearances = enemies.filter(enemy => enemyProfile(enemy)?.appearance);
      expect(new Set(appearances.map(enemy => enemy.variant))).toEqual(new Set(forms.map(([id]) => id)));
      for (const [id, appearance, ability, kind] of forms) {
        const roster = appearances.filter(enemy => enemy.variant === id);
        expect(roster.length).toBeGreaterThan(0);
        expect(roster.every(enemy => enemy.kind === kind)).toBe(true);
        expect(enemyProfile(roster[0])).toMatchObject({ appearance, ability });
      }
    }
  });

  it('places the guardian fifth, the elite guard eleventh and the Warden twelfth', () => {
    const game = new GameEngine();
    game.start(CONFIG);
    game.forceCoopRoom(7);
    expect(game.state.roomCount).toBe(EXPEDITION_ROOM_COUNT);
    expect(game.state.roomIndex).toBe(0);
    game.startCoop(CONFIG, 4);
    expect(game.state.roomCount).toBe(COOP_ROOM_COUNT);
    expect(game.state.room.platforms).toEqual(createRoom(CONFIG.seed, 0).room.platforms);
    for (let i = 0; i < COOP_ROOM_COUNT; i++) {
      game.forceCoopRoom(i);
      expect(game.state.room.index).toBe(i);
      expect(game.state.room.isBoss).toBe(i === 4 || i === COOP_WARDEN_ROOM_INDEX);
      if (i === 4) expect(game.state.room.name).toBe('余烬神殿');
      if (i >= 8) expect(game.state.room.name).toBe(COOP_EXTRA_REALMS[i - 8]);
    }
    expect(game.state.boss?.kind).toBe('warden');
    expect(game.state.roomsCleared).toBe(11);
  });

  it('preserves the seeded order of ordinary realms and uses their actual co-op slots for entity IDs', () => {
    for (const seed of [0, 1, 42, 20261116, 0xffffffff]) {
      const ordinary = expeditionOrder(seed).slice(0, -1);
      for (const size of [1, 2, 3, 4]) {
        const rooms = Array.from({length: 8}, (_, i) => createCoopRoom(seed, i, size));
        expect(rooms.filter(({room}) => !room.isBoss).map(({room}) => room.theme)).toEqual(ordinary);
        for (const [slot, {room, enemies, pickups}] of rooms.entries()) {
          expect(room.index).toBe(slot);
          expect(enemies.every(e => Math.floor(e.id / 100) === slot)).toBe(true);
          expect(pickups.every(p => Math.floor(p.id / 1000) === slot)).toBe(true);
        }
      }
    }
  });

  it.each([1, 2, 3, 4])('doubles all spawns after applying the %i-player scale', size => {
    const game = new GameEngine();
    game.startCoop(CONFIG, size);
    for (let index = 0; index < COOP_ROOM_COUNT; index++) {
      game.forceCoopRoom(index);
      const base = createCoopRoom(CONFIG.seed, index, size);
      expect(game.state.enemies.map(({id, hp, maxHp}) => [id, hp, maxHp]))
        .toEqual(base.enemies.map(({id, hp, maxHp}) => [id, hp * 2, maxHp * 2]));
    }
    expect(game.state.boss?.kind).toBe('warden');
  });

  it.each([8, 9, COOP_ELITE_ROOM_INDEX])('places scaled encounters and aerial mechanisms safely in realm %i', index => {
    const first = createCoopRoom(CONFIG.seed, index, 1);
    const group = createCoopRoom(CONFIG.seed, index, 4);
    expect(group).toEqual(createCoopRoom(CONFIG.seed, index, 4));
    expect(group.room).toEqual(first.room);
    expect(group.enemies.length).toBe(first.enemies.length + 3);
    for (const enemy of group.enemies) {
      if (enemy.kind !== 'bat') expect(isSafeFloorPoint(group.room, enemy.x, enemy.w)).toBe(true);
      const base = first.enemies.find(entry => entry.id === enemy.id);
      if (base) expect(enemy.hp).toBeGreaterThan(base.hp);
    }
    expect(group.room.hazards.some(hazard => hazard.kind === 'mechanism' && hazard.y + hazard.h < 448)).toBe(true);
    expect(group.room.platforms.some(p => p.kind === 'ground' && p.x <= group.room.exit.x &&
      p.x + p.w >= group.room.exit.x + group.room.exit.w)).toBe(true);
  });

  it('fields a tougher elite garrison for every party size in the courtyard only', () => {
    for (let index = 0; index < COOP_ROOM_COUNT; index++) {
      const {enemies} = createCoopRoom(CONFIG.seed, index, 4);
      expect(enemies.some(isCourtElite)).toBe(index === COOP_ELITE_ROOM_INDEX);
    }
    let previousHp = 0;
    for (const size of [1, 2, 3, 4]) {
      const {room, enemies, pickups} = createCoopRoom(CONFIG.seed, COOP_ELITE_ROOM_INDEX, size);
      expect(room).toMatchObject({name:'玄阙校场',isBoss:false});
      expect(enemies).toHaveLength(8 + size);
      expect(enemies.filter(isCourtElite)).toHaveLength(5 + size);
      expect(enemies.find(e => e.variant === 'court-vanguard')).toMatchObject({w:42,h:72});
      expect(enemies.find(e => e.variant === 'court-executioner')).toMatchObject({w:36,h:68});
      const hp = (group: Enemy[]) => group.reduce((sum, e) => sum + e.maxHp, 0);
      const total = hp(enemies);
      expect(total).toBeGreaterThan(hp(createCoopRoom(CONFIG.seed, 9, size).enemies));
      expect(total).toBeGreaterThan(previousHp);
      expect(pickups.length).toBeLessThanOrEqual(84); // Full guest snapshot capacity.
      previousHp = total;
    }
  });

  it.each([
    [1, 132.4, 103.2, 18.4, 22],
    [2, 250, 194.4, 34.8, 41.6],
    [3, 346.4, 269.6, 48.2, 57.8],
    [4, 443.6, 345.2, 61.6, 74],
  ])('doubles both elite variants and keeps the escorts at their usual health for %i players',
    (size, vanguard, executioner, archer, seer) => {
      const game = new GameEngine();
      game.startCoop(CONFIG, size);
      game.forceCoopRoom(COOP_ELITE_ROOM_INDEX);
      const health = new Map([
        ['court-vanguard', vanguard], ['court-executioner', executioner],
        ['astral-archer', archer], ['astral-seer', seer],
      ]);
      for (const enemy of game.state.enemies) {
        const expected = health.get(enemy.variant!);
        expect(expected).toBeDefined();
        expect(enemy.maxHp).toBeCloseTo(expected!);
        expect(enemy.hp).toBeCloseTo(expected!);
      }
    },
  );

  it('raises the work per player after allowing for simultaneous attacks and keeps the yard below both bosses', () => {
    for (const seed of [0, 1, 42, 20261125]) {
      const previous: number[] = [];
      for (const size of [1, 2, 3, 4]) {
        const game = new GameEngine();
        game.startCoop({...CONFIG, seed}, size);
        const burden: number[] = [];
        const bossesAtWeakest: number[] = [];
        for (let i = 0; i < COOP_ROOM_COUNT; i++) {
          game.forceCoopRoom(i);
          const boss = game.state.boss;
          if (boss) {
            const first = boss.maxHp;
            game.state.hero.x = 700;
            advance(game, boss.kind === 'warden' ? WARDEN_ENTRANCE_TIME + .1 : .1);
            strikeBoss(game);
            expect(boss.form).toBe(2);
            burden[i] = (first + boss.maxHp) / size;
            // Best openings amplify damage. Armor is breakable, separate from HP.
            bossesAtWeakest.push((first / 1.6 + boss.maxHp / 1.45) / size);
          } else {
            burden[i] = game.state.enemies.reduce((sum, e) => sum + e.maxHp, 0) / size;
          }
          if (size > 1) {
            expect(burden[i]).toBeGreaterThan(previous[i] * 1.03);
            expect(burden[i]).toBeLessThan(previous[i] * 1.08);
          }
          previous[i] = burden[i];
        }
        const ordinary = Math.max(...burden.filter((_, i) => i !== 4 && i < COOP_ELITE_ROOM_INDEX));
        const yard = burden[COOP_ELITE_ROOM_INDEX];
        expect(yard).toBeGreaterThan(ordinary * 1.3);
        expect(yard).toBeLessThan(bossesAtWeakest[0]);
        expect(bossesAtWeakest[0]).toBeLessThan(bossesAtWeakest[1]);
      }
    }
  });

  it.each([8, 9, COOP_ELITE_ROOM_INDEX])('reaches the exit by jumping across the authored gaps in realm %i', index => {
    const game = new GameEngine();
    game.startCoop(CONFIG, 4);
    game.forceCoopRoom(index);
    const state = game.state, hero = state.hero;
    state.enemies = [];
    hero.hp = hero.maxHp = 99;
    const floor = state.room.platforms.filter(platform => platform.kind === 'ground');
    let keepJumpingUntil = 0, lastJump = -1;
    for (let frame = 0; frame < 60 * 35 && hero.x < state.room.exit.x; frame++) {
      const ahead = hero.x + hero.w / 2 + 72;
      const gap = (x: number) => !floor.some(p => x >= p.x && x <= p.x + p.w);
      const spikesAhead = state.room.hazards.some(h => h.kind === 'spikes' && ahead > h.x - 12 && ahead < h.x + h.w + 12);
      const jump = hero.grounded && state.time - lastJump > .52 && (gap(ahead) || spikesAhead)
        || (!hero.grounded && hero.jumps < 2 && hero.vy > 100 && gap(hero.x + hero.w / 2) && state.time - lastJump > .18);
      if (jump) { lastJump = state.time; keepJumpingUntil = state.time + .27; }
      game.update(1 / 60, { ...EMPTY_INPUT, right: true, jumpPressed: jump, jumpHeld: state.time < keepJumpingUntil });
    }
    expect(hero.x).toBeGreaterThanOrEqual(state.room.exit.x);
    expect(state.deaths).toBe(0);
  });

  it('requires the final boss and caps each phase before the next transformation', () => {
    const game = new GameEngine();
    game.startCoop(CONFIG, 4);
    game.forceCoopRoom(4);
    const old = game.state.boss!;
    const oldPhaseOne = old.maxHp;
    expect(old).toMatchObject({ hp: 5564, maxHp: 5564 });
    strikeBoss(game);
    expect(old).toMatchObject({ phase: 2, mode: 'transition' });
    advance(game, BOSS_TRANSFORM_TIME);
    strikeBoss(game);
    expect(old).toMatchObject({ phase: 3, mode: 'transition' });
    advance(game, BOSS_ASCENSION_TIME);
    strikeBoss(game);
    expect(game.state.roomCleared).toBe(true);
    expect(game.state.roomsCleared).toBe(5);
    expect(game.state.result).toBeNull();
    expect(game.state.phase).toBe('playing');
    game.forceCoopRoom(COOP_WARDEN_ROOM_INDEX);
    const warden = game.state.boss!;
    expect(warden.maxHp).toBeGreaterThan(oldPhaseOne);
    expect(warden).toMatchObject({ hp: 7957, maxHp: 7957 });
    expect(warden.guard).toBeGreaterThan(50);
    game.state.hero.x = 700;
    advance(game, WARDEN_ENTRANCE_TIME + .1);
    strikeBoss(game);
    expect(warden.phase).toBe(2);
    expect(warden.hp).toBe(warden.maxHp);
    expect(warden.maxHp).toBeGreaterThan(old.maxHp);
    advance(game, BOSS_TRANSFORM_TIME);
    strikeBoss(game);
    expect(warden).toMatchObject({ phase: 3, mode: 'transition', hp: warden.maxHp / 2 });
    advance(game, BOSS_ASCENSION_TIME);
    strikeBoss(game);
    expect(game.state.result).toMatchObject({ won: true, roomsCleared: COOP_ROOM_COUNT });
  });

  it.each([[4, 4637], [COOP_WARDEN_ROOM_INDEX, 6826]])(
    'caps a same-frame volley at each transformation in room %i', (roomIndex, secondBar) => {
      const game = new GameEngine();
      game.startCoop(CONFIG, 4);
      game.forceCoopRoom(roomIndex);
      const { boss, hero } = game.state;
      if (!boss) throw new Error('Expected boss room');
      hero.x = 700;
      advance(game, WARDEN_ENTRANCE_TIME + .1);
      const volley = () => {
        game.state.projectiles = Array.from({length: 8}, (_, index) => ({
          id: 800 + index, kind: 'fan', owner: 'hero', x: boss.x + boss.w / 2, y: boss.y + boss.h / 2,
          w: 16, h: 16, vx: 0, vy: 0, life: 1, damage: 100000, hitIds: [], pierce: 1,
        }));
        game.update(1 / 120, EMPTY_INPUT);
      };

      volley();
      expect(boss).toMatchObject({ phase: 2, mode: 'transition', hp: secondBar, maxHp: secondBar });
      volley();
      expect(boss.hp).toBe(secondBar);
      advance(game, BOSS_TRANSFORM_TIME);
      volley();
      expect(boss).toMatchObject({ phase: 3, mode: 'transition', hp: secondBar / 2 });
      volley();
      expect(boss.hp).toBe(secondBar / 2);
      expect(game.state.roomCleared).toBe(false);
    },
  );

  it('locks scaled boss health, telegraph tempo and seven safe lanes to the party at the start', () => {
    const games = [1, 2, 3, 4].map(size => {
      const game = new GameEngine();
      game.startCoop(CONFIG, size);
      game.forceCoopRoom(COOP_WARDEN_ROOM_INDEX);
      game.state.hero.x = 700;
      advance(game, WARDEN_ENTRANCE_TIME + .1);
      const boss = game.state.boss!;
      boss.phase = 3; boss.form = 2; boss.timer = 0;
      advance(game, .01);
      return game;
    });
    for (let i = 1; i < games.length; i++) {
      expect(games[i].state.boss!.maxHp).toBeGreaterThan(games[i - 1].state.boss!.maxHp);
      expect(games[i].state.boss!.timer).toBeLessThan(games[i - 1].state.boss!.timer);
    }
    const last = games[3], boss = last.state.boss!;
    expect(boss).toMatchObject({ intent: 'eclipse', mode: 'windup' });
    const lanes = eclipseLanes(boss, last.state.room.width);
    expect(lanes).toHaveLength(7);
    for (let i = 1; i < lanes.length; i++) expect(lanes[i] - lanes[i - 1] - ECLIPSE_WIDTH).toBeGreaterThan(last.state.hero.w);
    advance(last, .75);
    const blades = last.state.projectiles.filter(shot => shot.style === 'eclipse');
    expect(blades).toHaveLength(7);
    expect(blades.every(shot => shot.damage === 2 && shot.delay! > 0)).toBe(true);
  });
});

describe('cooperative long spear', () => {
  it('pierces enemies along the thrust while fixed to its own cooperative role', () => {
    const game = new GameEngine();
    game.startCoop({ ...CONFIG, weapon: 'spear' }, 4);
    game.equipWeapon('blade');
    expect(game.state.hero.weapon).toBe('spear');
    const state = game.state;
    const spawn = (id: number, x: number, y: number): Enemy => ({
      id, x, y, w: 20, h: 20, kind: 'sentry', originX: x, originY: y, hp: 20, maxHp: 20,
      vx: 0, vy: 0, facing: 1, timer: 0, hurt: 0, dead: false, attackCooldown: 99,
    });
    state.hero.x = 110; state.hero.y = 412; state.hero.critChance = 0;
    state.enemies = [spawn(1, 222, 428), spawn(2, 246, 428), spawn(3, 222, 360), spawn(4, 73, 428)];
    advance(game, .11, { attackPressed: true });
    expect(state.hero.attackStep).toBe(1);
    expect(state.enemies.map(enemy => enemy.hp)).toEqual([17.3324, 17.3324, 20, 20]);
    game.start({ ...CONFIG, weapon: 'spear' });
    expect(game.state.hero.weapon).toBe('blade');
  });
});
