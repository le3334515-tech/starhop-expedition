import { describe, expect, it } from 'vitest';
import { GameEngine } from './engine';
import { CHARACTER_IDS, EMPTY_INPUT, getCharacterWeapons, type CharacterId, type Enemy, type WeaponId } from './types';

function fixture(character: CharacterId = 'traveller', weapon: WeaponId = getCharacterWeapons(character)[0]) {
  const engine = new GameEngine();
  engine.startCoop({seed:42,modifier:'standard',weapon,character},4);
  engine.setCoopReplica(1);
  const state = engine.state;
  state.enemies = [];
  state.pickups = [];
  state.room.hazards = [];
  state.room.platforms = [
    {kind:'wood',x:80,y:220,w:180,h:20,oneWay:true},
    {kind:'stone',x:90,y:300,w:160,h:20,oneWay:true},
    {kind:'ground',x:0,y:448,w:state.room.width,h:120},
  ];
  const hero = state.hero;
  Object.assign(hero,{x:110,y:220-hero.h,grounded:true,invincible:0});
  return {engine,state,hero};
}

describe('drop through and awakening in co-op', () => {
  it('drops through one ledge per press and still lands on solid ground', () => {
    const {engine,hero}=fixture();
    const press = () => {
      engine.tickCoop(1/60,{...EMPTY_INPUT,dropPressed:true});
      for(let i=0;i<60;i++)engine.tickCoop(1/60,EMPTY_INPUT);
    };
    press();
    expect(hero.y+hero.h).toBe(300);
    press();
    expect(hero.y+hero.h).toBe(448);
    press();
    expect(hero.y+hero.h).toBe(448);
  });

  // Damage to this target from one awakened attack in v5.2.15, in weapon-slot order.
  const previousAwakenedHits: Record<CharacterId, readonly number[]> = {
    traveller: [6.80915, 9.3, 7.44],
    blade: [6.9347, 6.56115, 6.1008],
    staff: [9.3, 8.184, 10.84473],
    wheel: [8.72712, 8.37, 7.18704],
    spear: [11.55618, 10.13886, 15.40824],
    monk: [8.5932, 12.352725, 6.231],
  };

  it.each(CHARACTER_IDS)('%s deals 20%% less awakening damage than before with all three weapons', character => {
    for (const [slot, weapon] of getCharacterWeapons(character).entries()) {
      const {engine, state, hero} = fixture(character, weapon);
      hero.critChance = 0;
      const enemy: Enemy = {
        id: 205, kind: 'sentry', x: hero.x + 37, y: 220 - 47, w: 60, h: 47,
        hp: 1000, maxHp: 1000, vx: 0, vy: 0, facing: -1, timer: 0, hurt: 0,
        dead: false, originX: hero.x + 37, originY: 220 - 47, attackCooldown: 99,
      };
      state.enemies = [enemy];
      state.resonance = 100;
      for (let frame = 0; frame < 75 && enemy.hp === enemy.maxHp; frame++) {
        engine.tickCoop(1 / 120, { ...EMPTY_INPUT, attackPressed: frame === 0, overdrivePressed: frame === 0 });
      }
      expect(enemy.maxHp - enemy.hp, weapon).toBeCloseTo(previousAwakenedHits[character][slot] * .8, 7);
    }
  });

  it.each(CHARACTER_IDS)('%s is immune near the end of awakening and takes damage afterwards', character => {
    const {engine,state,hero}=fixture(character);
    const health = hero.hp;
    hero.shield = 1;
    state.resonance = 100;
    engine.tickCoop(1/60,{...EMPTY_INPUT,overdrivePressed:true});
    expect(state.overdrive).toBeGreaterThan(5.9);
    for(let i=0;i<340;i++)engine.tickCoop(1/60,EMPTY_INPUT);
    expect(state.overdrive).toBeGreaterThan(0);
    state.projectiles.push({
      kind:'enemy',id:200,x:hero.x+3,y:hero.y+8,w:10,h:10,owner:'enemy',
      vx:0,vy:0,life:1,damage:2,hitIds:[],
    });
    engine.tickCoop(1/60,EMPTY_INPUT);
    expect(hero.hp).toBe(health);
    expect(hero.shield).toBe(1);
    hero.y = 610; hero.grounded = false;
    engine.tickCoop(1/60,EMPTY_INPUT);
    expect(hero.hp).toBe(health);
    expect(hero.y).toBeLessThan(590);
    expect(hero.shield).toBe(1);
    for(let i=0;i<26;i++)engine.tickCoop(1/60,EMPTY_INPUT);
    expect(state.overdrive).toBe(0);
    hero.shield = 0;
    hero.y = 610; hero.grounded = false;
    engine.tickCoop(1/60,EMPTY_INPUT);
    expect(hero.hp).toBe(health-1);
  });
});
