import { REGIONAL_ENEMIES, regionalEnemyId } from './enemy-catalog';
import { createRoom, isSafeFloorPoint, seededRandom, type RoomContents } from './levels';
import { TRAP_DESIGNS } from './realm-traps';
import { EXPEDITION_ROOM_COUNT, type Boss, type Decoration, type Enemy, type Hazard, type Platform, type RealmTrap, type Room } from './types';

export const COOP_ROOM_COUNT = 11;
export const COOP_WARDEN_NAME = '玄阙镇星王';
export const COOP_EXTRA_REALMS = ['赤铸悬城', '断月星桥', '玄阙王庭'] as const;
const FLOOR = 448;
type Ledge = [x: number, y: number, width: number];
type EnemySlot = [id: string, x: number, height?: number];
type TrapSlot = [theme: number, x: number, surface: number, offset: number];
type Span = [start: number, end: number];

interface RealmPlan {
  theme: number;
  width: number;
  subtitle: string;
  ledges: Ledge[];
  gaps: Span[];
  spikes: Span[];
  traps: TrapSlot[];
  enemies: EnemySlot[];
  reinforcement: EnemySlot[];
  hearts: Array<[x: number, surface: number]>;
}

const REALMS: readonly RealmPlan[] = [
  {
    // The lower route crosses three small furnace breaches. The alternate
    // gantries bypass the floor jets, but one exposed bridge has its own vent.
    theme: 5, width: 3260, subtitle: 'CINNABAR SKYFORGE · 多层炉道',
    ledges: [[310,352,205],[555,279,163],[690,349,225],[944,300,196],[1180,348,246],
      [1460,274,170],[1556,350,246],[1864,304,190],[2200,349,184],[2378,348,235],[2670,280,210],[2940,351,171]],
    gaps: [[740,840],[1600,1708],[2440,2548]],
    spikes: [[1040,1094],[2130,2190],[2840,2890]],
    traps: [[5,620,FLOOR,.4],[5,1266,348,1.7],[5,2020,FLOOR,3.65],[5,2744,280,2.85]],
    enemies: [['forge-bulwark',443],['forge-cinder',809,264],['forge-bomber',958],['forge-smith',1310],
      ['astral-duelist',1850],['forge-cinder',2130,265],['forge-bulwark',2320],['forge-bomber',2700],['forge-smith',3040]],
    reinforcement: [['forge-cinder',1100,242],['forge-bomber',1920],['forge-cinder',2830,247]],
    hearts: [[1010,300],[2035,304],[3060,FLOOR]],
  }, {
    // Start with isolated timing beams, then alternate wind pockets and upper
    // crossing. The last telegraphed beam protects the high route's midpoint.
    theme: 6, width: 3540, subtitle: 'SEVERED MOON BRIDGE · 逆风星闸',
    ledges: [[310,350,195],[553,282,192],[744,332,230],[1050,300,210],[1280,230,164],
      [1450,345,277],[1800,276,188],[2015,350,268],[2310,292,212],[2520,351,260],
      [2830,276,196],[3100,348,239],[3330,286,152]],
    gaps: [[836,950],[1536,1644],[2124,2236],[2600,2710]],
    spikes: [[588,646],[1330,1388],[2356,2412],[3020,3076]],
    traps: [[2,490,FLOOR,.45],[6,1100,300,2.15],[3,1850,FLOOR,3.2],[6,2092,350,4.25],[6,3165,348,1.12]],
    enemies: [['gale-duelist',414],['astral-seer',736],['tide-sprite',990,249],['astral-archer',1140],
      ['crypt-keeper',1472],['tide-sprite',1660,272],['astral-duelist',2040],['astral-seer',2310],
      ['gale-duelist',2500],['tide-sprite',2920,241],['astral-archer',3230],['astral-duelist',3340]],
    reinforcement: [['gale-wing',1180,236],['crypt-wraith',2268],['tide-sprite',3040,236]],
    hearts: [[1370,230],[1850,276],[3450,FLOOR]],
  }, {
    theme: 7, width: 1940, subtitle: 'OBSIDIAN THRONE · 玄阙镇星王',
    ledges: [[442,333,164],[732,290,166],[1070,343,174],[1370,285,185],[1610,339,169]],
    gaps: [], spikes: [], traps: [], enemies: [], reinforcement: [], hearts: [[316,FLOOR]],
  },
];

export function normalizePartySize(size: number): number {
  return Number.isFinite(size) ? Math.max(1, Math.min(4, Math.round(size))) : 1;
}

export function cooperativeDifficulty(size: number) {
  const allies = normalizePartySize(size) - 1;
  return {
    enemyHealth: 1.27 + .67 * allies,
    bossHealth: 1.12 + .68 * allies,
    armor: 1.12 + .45 * allies,
    attackRate: 1.10 + .11 * allies,
    bossTempo: 1 - .05 * allies,
    reinforcements: allies,
  };
}

function mechanism([theme, x, surface, offset]: TrapSlot): RealmTrap {
  const { w, h } = TRAP_DESIGNS[theme];
  return {kind:'mechanism', theme, x, y:surface - h, w, h, offset};
}

function realmPlatforms(plan: RealmPlan): Platform[] {
  const platforms: Platform[] = [];
  let start = 0;
  for (const [left, right] of plan.gaps) {
    platforms.push({x:start, y:FLOOR, w:left - start, h:120, kind:'ground'});
    start = right;
  }
  platforms.push({x:start, y:FLOOR, w:plan.width - start, h:120, kind:'ground'});
  plan.ledges.forEach(([x,y,w], index) => {
    platforms.push({x,y,w,h:24,kind:index % 3 ? 'stone' : 'wood',oneWay:true});
  });
  return platforms;
}

function authoredEnemy(index: number, number: number, slot: EnemySlot, room: Room, health: number, random: () => number): Enemy {
  const [variant, desired, airborneY] = slot, profile = REGIONAL_ENEMIES[variant];
  const kind = airborneY !== undefined ? 'bat' : profile.skin === 'goblin' ? 'slime' : 'sentry';
  const candidates = [0,-36,36,-72,72,-108,108,-144,144,-180,180];
  const x = airborneY !== undefined ? desired : (candidates.map(dx => desired+dx).find(p => isSafeFloorPoint(room,p,32)) ?? desired);
  const y = airborneY ?? FLOOR-profile.height;
  const encounterWeight = index >= 9 ? 1.82 : index === 8 ? 1.65 : 1;
  const hp = Math.round(profile.hp * health * encounterWeight * 10) / 10;
  return {id:index*100+number, kind, variant, skin:profile.skin, x, y, w:kind==='bat'?30:32, h:profile.height,
    hp, maxHp:hp, vx:0, vy:0, originX:x, originY:y, facing:-1, timer:random()*1.5, hurt:0, dead:false,
    attackCooldown:.6+random(), aiMode:'patrol', aiTimer:0, aiCount:0};
}

function scaleClassic(contents: RoomContents, index: number, partySize: number, seed: number): RoomContents {
  const {enemyHealth, reinforcements} = cooperativeDifficulty(partySize);
  for (const enemy of contents.enemies) {
    enemy.hp = enemy.maxHp = Math.round(enemy.maxHp*enemyHealth*10)/10;
  }
  if (contents.room.isBoss || !reinforcements) return contents;
  const room = contents.room;
  const random = seededRandom(seed ^ Math.imul(index+1,0x77cf329));
  const slots = [.38,.56,.75,.47,.66,.84].map(fraction=>Math.round(room.width*fraction));
  const maxEnemies = contents.enemies.length + reinforcements;
  for(const x of slots) {
    if (contents.enemies.length >= maxEnemies) break;
    if (contents.enemies.some(enemy=>Math.abs(enemy.x-x)<120) || !isSafeFloorPoint(room,x,32)) continue;
    const enemy = authoredEnemy(index,contents.enemies.length+1,[regionalEnemyId(room.theme,'sentry'),x],room,enemyHealth,random);
    contents.enemies.push(enemy);
  }
  return contents;
}

export function createCoopRoom(seed: number, index: number, partySize: number): RoomContents {
  if (!Number.isInteger(index) || index<0 || index>=COOP_ROOM_COUNT) throw new RangeError('Unknown cooperative realm');
  if (index<EXPEDITION_ROOM_COUNT) return scaleClassic(createRoom(seed,index),index,partySize,seed);
  const plan = REALMS[index-EXPEDITION_ROOM_COUNT], {enemyHealth, reinforcements} = cooperativeDifficulty(partySize);
  const {width,theme} = plan, isBoss = index===COOP_ROOM_COUNT-1;
  const random = seededRandom(seed ^ Math.imul(index+1,0x409c1a8d));
  const room: Room = {
    index, theme, width, height:640, isBoss, name:COOP_EXTRA_REALMS[index-EXPEDITION_ROOM_COUNT], subtitle:plan.subtitle,
    platforms:realmPlatforms(plan), spawn:{x:100,y:410}, checkpoint:{x:100,y:410}, exit:{x:width-116,y:352,w:64,h:96},
    hazards: [
      ...plan.gaps.map(([x,right]): Hazard=>({kind:'lava',x,y:520,w:right-x,h:50})),
      ...plan.spikes.map(([x,right]): Hazard=>({kind:'spikes',x,y:430,w:right-x,h:18})),
      ...plan.traps.map(mechanism),
    ],
    decorations: [],
  };
  const landmarks: Decoration['kind'][] = theme===5?['lamp','ruin','crystal']:['ruin','crystal','lamp'];
  for(let x=145;x<width-100;x+=184+Math.round(random()*80)) {
    if(!plan.gaps.some(([left,right])=>x>=left-12&&x<=right+12)) {
      room.decorations.push({x,y:FLOOR,kind:landmarks[Math.floor(random()*landmarks.length)],scale:.75+random()*.57});
    }
  }
  const enemies = [...plan.enemies,...plan.reinforcement.slice(0,reinforcements)]
    .map((slot,number)=>authoredEnemy(index,number+1,slot,room,enemyHealth,random));
  const pickups: RoomContents['pickups'] = [];
  const addPickup = (x:number, y:number, kind:'coin'|'heart')=>{
    pickups.push({id:index*1000+pickups.length+1,x,y,w:kind==='heart'?18:13,h:16,kind,value:1,vy:0,bob:random()*6.28,collected:false});
  };
  if(!isBoss)for(const platform of room.platforms) {
    for(let x=platform.x+28;x<platform.x+platform.w-20;x+=platform.oneWay?48:110) {
      const y = platform.y - 36;
      if(x<260 || x>width-150 || room.hazards.some(h=>x<h.x+h.w+8 && x+13>h.x-8 &&
        ((y<h.y+h.h&&y+16>h.y) || (h.kind==='spikes'&&h.y===platform.y-18)))) continue;
      addPickup(x,y,'coin');
    }
  }
  for(const [x,surface] of plan.hearts) addPickup(x,surface-28,'heart');
  return {room,enemies,pickups};
}

const WARDEN_HEALTH = [0, 858, 1325] as const;
const WARDEN_GUARD = [0, 58, 88, 116] as const;
const WARDEN_INTENTS: readonly (readonly Boss['intent'][])[] = [
  ['leap','slam','charge','barrage'],
  ['rift','charge','slam','barrage','rain','leap'],
  ['eclipse','slam','charge','barrage','rain','rift','leap'],
];

export function wardenIntents(phase:number): readonly Boss['intent'][] {
  return WARDEN_INTENTS[Math.max(0,Math.min(2,phase-1))];
}
export function wardenRiftLanes(boss: Boss, roomWidth: number): number[] {
  const center = Math.min(roomWidth - 290, Math.max(620, boss.targetX + boss.w / 2));
  return [-180, -90, 0, 90, 180].map(offset => center + offset);
}

export function wardenRainOrigins(boss: Boss, roomWidth: number): number[] {
  const count = boss.phase === 3 ? 9 : 7;
  const spacing = 74, halfSpread = (count - 1) * spacing / 2;
  const center = Math.min(roomWidth - 90 - halfSpread, Math.max(420 + halfSpread, boss.targetX + boss.w / 2));
  return Array.from({ length: count }, (_, index) => center - halfSpread + index * spacing);
}

export function wardenHealth(form:1|2) { return WARDEN_HEALTH[form]; }
export function wardenGuard(phase:1|2|3) { return WARDEN_GUARD[phase]; }
