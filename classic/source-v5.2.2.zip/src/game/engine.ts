import { awakeningName, COOP_CHARACTERS } from '../coop-characters';
import { sampleTrap, TRAP_DESIGNS } from './realm-traps';
import {
  AWAKENING_DURATION, EMPTY_INPUT, EXPEDITION_ROOM_COUNT, WEAPONS, getCharacterWeapons, type Boss, type EngineCallbacks, type Enemy, type GameConfig,
  type BuffEffectKind, type GameResult, type GameState, type Hero, type InputState, type Projectile,
  type Rect, type SoundName, type WeaponContact, type Synergy, type Upgrade, type WeaponArchetype, type WeaponId, isCharacterId, isSoloWeapon, weaponTier,
} from './types';
import { createRoom, seededRandom, isSafeFloorPoint } from './levels';
import { COOP_ROOM_COUNT, COOP_WARDEN_NAME, cooperativeDifficulty, createCoopRoom, normalizePartySize, wardenGuard, wardenHealth, wardenIntents, wardenRainOrigins, wardenRiftLanes } from './coop-levels';
import { updateEnemyVariant, enemyDamageMultiplier } from './enemy-variants';
import { WeaponComboMarks } from './weapon-combos';

// Seconds of contact freeze for a normal beat and a finisher, per selectable named weapon.
const WEAPON_IMPACT_TIMING = {
  blade: [.028,.059], willowSword: [.017,.050], swallowDart: [.015,.048],
  ember: [.019,.052], frostStaff: [.025,.056], moonMirror: [.019,.047],
  fan: [.016,.046], jadeNeedle: [.014,.039], silkFan: [.022,.048],
  spear: [.032,.065], reedJavelin: [.023,.053], halberd: [.041,.077],
  fist: [.022,.063], ironGauntlet: [.039,.079], prayerBeads: [.018,.050],
  disc: [.018,.048], sabre: [.030,.063],
} satisfies Record<WeaponId, [number, number]>;

const GRAVITY = 1260;
// Hero reach is tuned to the authored 88–184px ledges. Keep enemy/Boss
// gravity separate so a higher jump does not slow combat telegraphs.
const HERO_RISE_GRAVITY = 2200;
const HERO_FALL_GRAVITY = 3000;
const HERO_JUMP_SPEED = 950;
const HERO_AIR_JUMP_SPEED = 580;
const HERO_TAP_SPEED = 800;
const HERO_AIR_TAP_SPEED = 440;
const VIEW_WIDTH = 960;
// Three distinct patterns, breakable guard and punish windows make survival and timing matter.
export const BOSS_MAX_HP = 600;
export const BOSS_AWAKENED_HP = 900;
const BOSS_GUARD = [0, 36, 56, 68] as const;
const STAFF_BOSS_HEALTH_SCALE = .91;
const MELEE_COMBOS = {
  blade: { active: [.18, .28], recovery: [.28, .43], extraSpread: 70 },
  spear: { active: [.19, .26], recovery: [.37, .52], extraSpread: 50 },
  sabre: { active: [.24, .34], recovery: [.40, .62], extraSpread: 54 },
  fist: { active: [.14, .24], recovery: [.18, .40], extraSpread: 38 },
} as const;
const isMelee = (weapon: WeaponArchetype): weapon is keyof typeof MELEE_COMBOS =>
  Object.prototype.hasOwnProperty.call(MELEE_COMBOS, weapon);
export { BOSS_TRANSFORM_TIME } from './boss-seal';
import { BOSS_TRANSFORM_TIME, BOSS_ASCENSION_TIME, BOSS_ASCENSION_IMPACT, ECLIPSE_WIDTH, ECLIPSE_WINDUP, eclipseLanes, sealProgress, openingSeal, openingAscension } from './boss-seal';
const UPGRADES: Upgrade[] = [
  { id: 'edge', name: '星刃淬火', description: '武器伤害 +65%基础值，刀光延伸，斩击附带朱金余焰。', icon: 'blade', rarity: 'common', color: '#e8b674' },
  { id: 'tempo', name: '疾风节拍', description: '攻击速度提高35%，连斩带出疾风残影。', icon: 'bolt', rarity: 'common', color: '#a8e3c4' },
  { id: 'vigor', name: '不灭星心', description: '生命上限 +2，立即回满生命，气血暖辉常驻。', icon: 'heart', rarity: 'rare', color: '#e59a83' },
  { id: 'stride', name: '追风旅靴', description: '移动速度 +18%，闪避冷却缩短，冲刺自带伤敌风刃。', icon: 'wind', rarity: 'common', color: '#c2cf95' },
  { id: 'multishot', name: '双星共鸣', description: '远程多一枚飞弹；近战附带星光弹。', icon: 'star', rarity: 'epic', color: '#ffcf83' },
  { id: 'shield', name: '月光守护', description: '获得3层月盾，每层挡一次伤害；进入新关补1层。', icon: 'shield', rarity: 'rare', color: '#c3d7bc' },
  { id: 'blood', name: '生命余烬', description: '击杀必定回复1颗心，红色星火沿符文回流。', icon: 'spark', rarity: 'rare', color: '#d88976' },
  { id: 'magnet', name: '星尘引力', description: '吸取范围 +220，远处经验与星币自动汇入引力阵。', icon: 'orbit', rarity: 'common', color: '#9fc9c2' },
  { id: 'frost', name: '踏雪生梅', description: '二段跳在脚下绽开霜梅，对周围88像素内的敌人造成每层2点基础伤害。', icon: 'spark', rarity: 'rare', color: '#b9d9d4' },
  { id: 'bell', name: '金钟回响', description: '完美格挡震出一道金色钟波，对周围140像素内的敌人造成每层3点基础伤害。', icon: 'shield', rarity: 'epic', color: '#d8bf80' },
  { id: 'breeze', name: '拾玉还风', description: '吸收经验时，每层立即缩短0.35秒闪避冷却；青玉风纹随身回流。', icon: 'wind', rarity: 'common', color: '#a1cbb4' },
  { id: 'fortune', name: '闪耀口袋', description: '每次拾取星币额外 +2金币，并获得3点觉醒星能。', icon: 'coin', rarity: 'common', color: '#e4c282' },
  { id: 'gildedSwitch', name: '错金换锋', description: '换武追击的第一招，每层额外增加25%基础伤害。', icon: 'blade', rarity: 'rare', color: '#e8b674' },
  { id: 'thirdStar', name: '三星照命', description: '每轮连招第三次出手，每层获得4点星能。', icon: 'star', rarity: 'common', color: '#c2b3f3' },
  { id: 'afterimage', name: '惊鸿留影', description: '完美闪避时，每层缩短0.32秒闪避冷却。', icon: 'wind', rarity: 'rare', color: '#9ae9e3' },
  { id: 'jadeParry', name: '玉关照胆', description: '完美格挡成功时，每层额外获得4点星能。', icon: 'shield', rarity: 'rare', color: '#b6e7cc' },
  { id: 'jadeSpring', name: '碎玉鸣泉', description: '每拾取一颗回血心，每层获得5点星能。满血也可拾取。', icon: 'heart', rarity: 'common', color: '#eba899' },
  { id: 'landingSeal', name: '穿云落印', description: '二段跳后首次落地震击96像素内的敌人，每层造成3点基础伤害。', icon: 'spark', rarity: 'epic', color: '#e6c58d' },
];

const BUFF_EFFECT_DURATION: Record<BuffEffectKind, number> = {
  gildedSwitch: .65, thirdStar: .70, afterimage: .56, jadeParry: .63, jadeSpring: .70, landingSeal: .66,
};
const MAX_BUFF_STACKS = 3;
const isBuffEffectKind = (id: string): id is BuffEffectKind => Object.prototype.hasOwnProperty.call(BUFF_EFFECT_DURATION, id);

const SYNERGIES: Synergy[] = [
  { id: 'blazing', name: '烈星连斩', description: '淬火 × 节拍：伤害额外 +20%，攻击速度额外 +10%。', requires: ['edge', 'tempo'], color: '#ffad78' },
  { id: 'fireflies', name: '流萤星群', description: '共鸣 × 引力：所有武器多一枚星弹，拾取范围额外 +120。', requires: ['multishot', 'magnet'], color: '#a4e8cb' },
  { id: 'guardian', name: '不灭月华', description: '星心 × 余烬或守护：激活时及进入新房间，获得 1 层护盾。', requires: ['vigor', 'blood|shield'], color: '#c3b5ff' },
];

const overlap = (a: Rect, b: Rect) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
const clamp = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n));
const approach = (value: number, target: number, amount: number) => value < target ? Math.min(value + amount, target) : Math.max(value - amount, target);

function makeHero(config: GameConfig): Hero {
  const hp = config.modifier === 'iron' ? 1 : 5;
  return {
    x: 100, y: 410, w: 28, h: 36, vx: 0, vy: 0, facing: 1, hp, maxHp: hp,
    xp: 0, xpNeeded: 10, level: 1, grounded: false, jumps: 0, coyote: 0, jumpBuffer: 0,
    invincible: 0, attackTimer: 0, attackCooldown: 0, dashTimer: 0, dashCooldown: 0,
    weapon: config.weapon, damage: 1, speed: 260, attackSpeed: 1, critChance: .08,
    extraProjectiles: 0, lifesteal: 0, magnet: 80, shield: 0, upgrades: [], animation: 0,
    attackStep: 0, comboWindow: 0, swapBoost: 0, swapCooldown: 0, counterTimer: 0, perfectDodgeCooldown: 0,
    guardTimer: 0, guardCooldown: 0,
  };
}

function createEncounter(seed: number, index: number, partySize?: number) {
  const content = partySize === undefined ? createRoom(seed, index) : createCoopRoom(seed, index, partySize);
  for (const enemy of content.enemies) {
    enemy.hp *= 2;
    enemy.maxHp *= 2;
  }
  return content;
}

function initialState(config: GameConfig, coopPartySize?: number): GameState {
  const content = createEncounter(config.seed, 0, coopPartySize);
  return {
    phase: 'menu', seed: config.seed >>> 0, modifier: config.modifier, roomIndex: 0,
    ...(config.character ? { character: config.character } : {}),
    roomCount: coopPartySize === undefined ? EXPEDITION_ROOM_COUNT : COOP_ROOM_COUNT, coopPartySize,
    ...content, hero: makeHero(config), boss: null, projectiles: [], particles: [], floatingTexts: [],
    cameraX: 0, time: 0, visualTime: 0, coins: 0, kills: 0, deaths: 0, combo: 0, maxCombo: 0,
    comboTimer: 0, roomCleared: false, roomsCleared: 0, upgradeChoices: [], shake: 0, flash: 0,
    transition: 0, announcement: '', announcementTimer: 0, result: null,
    resonance: 0, overdrive: 0, overdriveCount: 0, synergies: [], hitstop: 0, impacts: [],
  };
}

/** Pure simulation: no DOM, canvas, clocks, timers, or network dependencies. */
export class GameEngine {
  state: GameState;
  private callbacks: EngineCallbacks;
  private random = seededRandom(1);
  private visualRandom = seededRandom(17);
  private projectileId = 10000;
  private pickupId = 50000;
  private meleeHits = new Set<number>();
  private weaponComboMarks = new WeaponComboMarks();
  private classicMarks = new WeakMap<Enemy, number>();
  private dashHits = new Set<number>();
  private awakenedDiscs = new Set<number>();
  private previousHeroBottom = 0;
  private weaponAtStart: WeaponId = 'blade';
  private variableJump = false;
  private landingSealArmed = false;
  private jumpCutSpeed = HERO_TAP_SPEED;
  private attackPower = 1;
  private spearRiposte = false;
  private criticalHit = false;
  private nextImpactBeat = 0;
  private bufferedEdges: Partial<InputState> = {};
  private attackBuffer = 0;
  private bossGuardRecovery = 0;
  private pendingGuard = 0;
  private partyActor = false;
  private partyReplica = false;
  private partyTargets: (() => readonly Hero[]) | null = null;

  setCoopReplica(seat: number): void {
    this.partyActor = true; this.partyReplica = seat !== 0;
    this.projectileId = 10000 + seat * 1000000;
    this.pickupId = 50000 + seat * 1000000;
  }

  setCoopTargets(targets: () => readonly Hero[]): void { this.partyTargets = targets; }

  private partyTarget(x: number, y: number): Hero {
    let target = this.state.hero, distance = Infinity;
    for (const hero of this.partyTargets?.() ?? []) {
      if (hero.hp <= 0) continue;
      const next = Math.abs(hero.x - x) + Math.abs(hero.y - y) * .38;
      if (next < distance) { target = hero; distance = next; }
    }
    return target;
  }

  /** A personal upgrade panel stops this traveller's inputs, not the room. */
  tickCoop(dt: number, input: InputState): void {
    const state = this.state, phase = state.phase;
    if (phase === 'paused' || phase === 'upgrade') {
      state.phase = 'playing';
      this.update(dt, EMPTY_INPUT);
      if (state.phase === 'playing') state.phase = phase;
      return;
    }
    this.update(dt, input);
  }

  completeCoop(won: boolean): void { this.finish(won); }
  grantCoopXP(amount: number): void { if (this.state.hero.hp > 0) this.gainXp(amount); }


  constructor(callbacks: EngineCallbacks = {}) {
    this.callbacks = callbacks;
    this.state = initialState({ seed: 20261116, modifier: 'standard', weapon: 'blade' });
  }

  startCoop(config: GameConfig, partySize: number): void {
    this.start(config, normalizePartySize(partySize));
    this.partyActor = true;
  }

  start(config: GameConfig, coopPartySize?: number): void {
    this.partyActor = this.partyReplica = false; this.partyTargets = null;
    const character = isCharacterId(config.character) ? config.character : undefined;
    const allowedWeapons = getCharacterWeapons(character);
    const weapon = coopPartySize !== undefined && !character
      ? config.weapon
      : allowedWeapons.includes(config.weapon) ? config.weapon : allowedWeapons[0];
    const safeConfig = { seed: config.seed >>> 0, modifier: config.modifier, weapon, character };
    this.random = seededRandom(safeConfig.seed ^ 0xab10c377);
    this.visualRandom = seededRandom(safeConfig.seed ^ 0x781ab29);
    this.projectileId = 10000;
    this.pickupId = 50000;
    this.weaponAtStart = safeConfig.weapon;
    this.nextImpactBeat = 0;
    this.attackPower = 1; this.bufferedEdges = {}; this.attackBuffer = 0; this.bossGuardRecovery = 0; this.pendingGuard = 0;
    this.variableJump = false;
    this.landingSealArmed = false;
    this.spearRiposte = false;
    this.jumpCutSpeed = HERO_TAP_SPEED;
    this.meleeHits.clear();
    this.weaponComboMarks = new WeaponComboMarks();
    this.classicMarks = new WeakMap();
    this.dashHits.clear();
    this.awakenedDiscs.clear();
    this.state = initialState(safeConfig, coopPartySize);
    this.state.phase = 'playing';
    this.state.announcement = this.state.room.name;
    this.state.announcementTimer = 2.5;
    this.state.transition = 1;
  }

  pause(): void { if (this.state.phase === 'playing') { this.state.phase = 'paused'; this.bufferedEdges = {}; this.pendingGuard = 0; } }
  resume(): void { if (this.state.phase === 'paused') this.state.phase = 'playing'; }

  /** Called directly by key/pointer down, even while impact hitstop is active. */
  requestGuard(): boolean {
    const s = this.state, h = s.hero;
    if (s.phase !== 'playing' || h.hp <= 0) return false;
    if (h.guardCooldown > 0) {
      if (h.guardCooldown <= .12) this.pendingGuard = .14;
      return false;
    }
    this.pendingGuard = 0;
    delete this.bufferedEdges.dashPressed;
    h.guardTimer = .24; h.guardCooldown = .36;
    h.dashTimer = 0;
    h.attackTimer = 0;
    this.attackBuffer = 0;
    this.sound('select');
    this.burst(h.x + 14 + h.facing * 20, h.y + 16, '#c9eee1', 5, 55);
    return true;
  }

  equipWeapon(id: WeaponId): void {
    const character = this.state.character;
    if (!(character ? getCharacterWeapons(character).includes(id) : !this.partyActor && isSoloWeapon(id))) return;
    const h = this.state.hero;
    if (h.weapon !== id) {
      h.attackStep = 0; h.comboWindow = 0;
      if (character && character !== 'traveller') {
        h.attackTimer = 0;
        this.attackBuffer = 0;
        this.spearRiposte = false;
      }
      if (this.state.phase === 'playing' && h.swapCooldown <= 0) {
        h.swapBoost = 1.2; h.swapCooldown = 2;
        this.gainResonance(6);
        this.label(h.x + 14, h.y - 25, '换武 · 下一击强化', '#a9dfff');
      }
    }
    h.weapon = id;
    if (this.state.phase === 'playing') this.sound('select');
  }

  chooseUpgrade(id: string): void {
    const state = this.state;
    if (state.phase !== 'upgrade' || !state.upgradeChoices.some(item => item.id === id)) return;
    if (isBuffEffectKind(id) && this.buffStacks(id) >= MAX_BUFF_STACKS) return;
    const hero = state.hero;
    hero.upgrades.push(id);
    switch (id) {
      case 'edge': hero.damage += .65; break;
      case 'tempo': hero.attackSpeed = Math.min(2.8, hero.attackSpeed * 1.35); break;
      case 'vigor': hero.maxHp += 2; hero.hp = hero.maxHp; break;
      case 'stride': hero.speed = Math.min(460, hero.speed * 1.18); break;
      case 'multishot': hero.extraProjectiles = Math.min(3, hero.extraProjectiles + 1); break;
      case 'shield': hero.shield += 3; break;
      case 'blood': hero.lifesteal = 1; break;
      case 'magnet': hero.magnet += 220; break;
      case 'fortune': break;
    }
    this.refreshSynergies();
    // Every level is a small recovery opportunity, whichever upgrade is chosen.
    if (id !== 'vigor' && hero.hp < hero.maxHp) {
      hero.hp = Math.min(hero.maxHp, hero.hp + 1);
      this.label(hero.x + 14, hero.y - 36, '升阶回春 +1 ♥', '#ffa5ac');
    }
    state.upgradeChoices = [];
    state.phase = 'playing'; state.hitstop = 0; this.bufferedEdges = {};
    this.sound('upgrade');
    const acquired = UPGRADES.find(item => item.id === id)!;
    this.burst(hero.x + 14, hero.y + 15, acquired.color, 34, 210);
    this.impact(hero.x + 14, hero.y + 18, 'break', acquired.color);
    this.label(hero.x + 14, hero.y - 15, acquired.name, acquired.color);
    if (!(state.announcement.startsWith('羁绊觉醒') && state.announcementTimer > 0)) {
      state.announcement = `星纹入牒 · ${acquired.name}`;
      state.announcementTimer = 2.2;
    }
    if (hero.xp >= hero.xpNeeded) this.offerUpgrade();
  }

  update(dt: number, input: InputState = EMPTY_INPUT): void {
    if (!Number.isFinite(dt) || dt <= 0) return;
    dt = Math.min(dt, .05);
    const state = this.state;
    state.visualTime += dt;
    this.updateEffects(dt);
    if (state.phase !== 'playing') return;
    // Defensive input is accepted before freeze/physics, rather than waiting
    // behind a hit reaction or the end of a dash.
    if (input.guardPressed) this.requestGuard();
    // The stopwatch counts the complete active run, including impact pauses.
    state.time += dt;
    const edgeKeys = ['jumpPressed','attackPressed','dashPressed','interactPressed','overdrivePressed','guardPressed'] as const;
    for (const key of edgeKeys) if (input[key]) this.bufferedEdges[key] = true;
    const frozen = Math.min(dt, state.hitstop);
    state.hitstop = Math.max(0, state.hitstop - dt);
    dt -= frozen;
    if (dt <= 0) return;
    input = { ...input };
    for (const key of edgeKeys) input[key] ||= !!this.bufferedEdges[key];
    this.bufferedEdges = {};
    // Small physics steps prevent a fast dash crossing an enemy or a narrow platform.
    const steps = Math.ceil(dt / (1 / 120));
    const step = dt / steps;
    for (let i = 0; i < steps && state.phase === 'playing'; i++) {
      const frameInput = i === 0 ? input : { ...input, jumpPressed: false, attackPressed: false, dashPressed: false, interactPressed: false, overdrivePressed: false, guardPressed: false };
      this.step(step, frameInput);
      if (state.hitstop > 0) break;
    }
  }

  private step(dt: number, input: InputState): void {
    const s = this.state;
    const h = s.hero;
    s.overdrive = Math.max(0, s.overdrive - dt);
    if (h.hp > 0 && input.overdrivePressed && s.resonance >= 100 && s.overdrive <= 0) {
      s.resonance = 0;
      s.overdrive = AWAKENING_DURATION;
      s.overdriveCount += 1;
      s.announcement = `${awakeningName(s.character)} · 全武器超载`;
      s.announcementTimer = 2.2;
      s.shake = 6;
      h.invincible = Math.max(h.invincible, .8);
      h.dashCooldown = 0;
      this.burst(h.x + 14, h.y + 18, '#ffe4a2', 23, 205);
      this.burst(h.x + 14, h.y + 24, '#93e4cd', 19, 163);
      this.sound('awaken');
    }
    s.comboTimer = Math.max(0, s.comboTimer - dt);
    if (s.comboTimer === 0) s.combo = 0;
    s.announcementTimer = Math.max(0, s.announcementTimer - dt);
    s.transition = Math.max(0, s.transition - dt * 1.8);
    if (h.hp > 0 || !this.partyActor) this.updateHero(dt, input);
    if (s.phase !== 'playing') return;
    if (!this.partyReplica) { this.updateEnemies(dt); this.updateBoss(dt); }
    this.updateAttacks(dt, h.hp > 0 || !this.partyActor);
    if (s.phase !== 'playing') return;
    if (h.hp > 0 || !this.partyActor) this.enemyContact();
    if (s.phase !== 'playing') return;
    if (h.hp > 0 || !this.partyActor) this.updatePickups(dt);
    if (s.phase !== 'playing') return;

    if (!this.partyActor && !s.room.isBoss && !s.roomCleared && s.enemies.every(enemy => enemy.dead)) {
      s.roomCleared = true;
      s.roomsCleared = s.roomIndex + 1;
      s.announcement = '房间净化 · 星门已开启';
      s.announcementTimer = 2.8;
      if (s.roomIndex < 4) h.hp = Math.min(h.maxHp, h.hp + 1);
      this.sound('portal');
      this.gainXp(5);
    }
    const exitArea = { ...s.room.exit, x: s.room.exit.x - 28, w: s.room.exit.w + 56 };
    if (!this.partyActor && s.phase === 'playing' && s.roomCleared && !s.room.isBoss && overlap(h, exitArea)) {
      // Walking through the open gate is enough on touch; E also works from its edge.
      if (input.interactPressed || h.x > s.room.exit.x - 12) this.nextRoom();
    }
    const cameraTarget = clamp(h.x - 340, 0, s.room.width - VIEW_WIDTH);
    s.cameraX = approach(s.cameraX, cameraTarget, Math.max(200, Math.abs(cameraTarget - s.cameraX) * 9) * dt);
  }

  private updateHero(dt: number, input: InputState): void {
    const s = this.state;
    const h = s.hero;
    const speedFactor = (s.modifier === 'haste' ? 1.16 : 1) * (s.overdrive > 0 ? 1.25 : 1);
    const moonGravity = s.modifier === 'moon' ? .62 : 1;
    const jumpScale = s.modifier === 'moon' ? .82 : 1;
    h.animation += dt;
    h.comboWindow = Math.max(0, h.comboWindow - dt);
    h.swapBoost = Math.max(0, h.swapBoost - dt);
    h.swapCooldown = Math.max(0, h.swapCooldown - dt);
    h.counterTimer = Math.max(0, h.counterTimer - dt);
    h.perfectDodgeCooldown = Math.max(0, h.perfectDodgeCooldown - dt);
    h.guardTimer = Math.max(0, h.guardTimer - dt);
    h.guardCooldown = Math.max(0, h.guardCooldown - dt);
    this.pendingGuard = Math.max(0, this.pendingGuard - dt);
    if (this.pendingGuard > 0 && h.guardCooldown <= 0) this.requestGuard();
    if (h.comboWindow === 0) h.attackStep = 0;
    h.invincible = Math.max(0, h.invincible - dt);
    h.attackTimer = Math.max(0, h.attackTimer - dt);
    h.attackCooldown = Math.max(0, h.attackCooldown - dt);
    this.attackBuffer = input.attackPressed ? .16 : Math.max(0, this.attackBuffer - dt);
    h.dashCooldown = Math.max(0, h.dashCooldown - dt);
    h.dashTimer = Math.max(0, h.dashTimer - dt);
    const dashColor = s.character && s.character !== 'traveller' ? COOP_CHARACTERS[s.character].color : undefined;
    if (h.dodgeCue) {
      h.dodgeCue.life -= dt;
      if (h.dodgeCue.life <= 0) delete h.dodgeCue;
    }
    h.coyote = h.grounded ? .12 : Math.max(0, h.coyote - dt);
    h.jumpBuffer = input.jumpPressed ? .14 : Math.max(0, h.jumpBuffer - dt);

    const move = Number(input.right) - Number(input.left);
    if (move) h.facing = move;
    if (input.dashPressed && h.dashCooldown <= 0 && h.guardTimer <= 0) {
      this.dashHits.clear();
      h.guardTimer = 0;
      h.dashTimer = .18;
      h.attackCooldown = Math.min(h.attackCooldown, .12);
      h.dashCooldown = s.overdrive > 0 ? .38 : Math.max(.7, 1.35 - h.upgrades.filter(item => item === 'stride').length * .15);
      h.invincible = Math.max(h.invincible, .24);
      this.variableJump = false;
      this.sound('dash');
      this.burst(h.x + 14, h.y + 20, dashColor ?? '#8ee9de', 9, 110);
    }

    if (h.jumpBuffer > 0 && (h.grounded || h.coyote > 0 || h.jumps < 2)) {
      if (!h.grounded && h.coyote <= 0 && h.jumps === 0) h.jumps = 1;
      const isDouble = h.jumps >= 1 && !h.grounded && h.coyote <= 0;
      h.dashTimer = 0;
      const launchSpeed = (isDouble ? HERO_AIR_JUMP_SPEED : HERO_JUMP_SPEED) * jumpScale;
      // The air jump adds a small correction. Pressing it early must not
      // chop the stronger upward momentum of the first jump.
      const preserveAscent = isDouble && h.vy < -launchSpeed;
      if (!preserveAscent) h.vy = -launchSpeed;
      this.jumpCutSpeed = (isDouble && !preserveAscent ? HERO_AIR_TAP_SPEED : HERO_TAP_SPEED) * jumpScale;
      h.jumps = isDouble ? 2 : 1;
      h.grounded = false;
      h.coyote = 0;
      h.jumpBuffer = 0;
      this.variableJump = true;
      if (isDouble) {
        this.landingSealArmed = this.buffStacks('landingSeal') > 0;
        this.sealPulse('frost');
      }
      this.sound(isDouble ? 'doubleJump' : 'jump');
      this.burst(h.x + 14, h.y + h.h, isDouble ? '#a9dfff' : '#c9edda', isDouble ? 12 : 6, 75);
    }
    if (!input.jumpHeld && !input.jumpPressed && h.vy < -this.jumpCutSpeed && this.variableJump) {
      h.vy = -this.jumpCutSpeed;
      this.variableJump = false;
    }
    if ((this.attackBuffer > 0 || input.attackHeld) && h.attackCooldown <= 0) {
      this.attackBuffer = 0;
      this.attack();
    }

    this.previousHeroBottom = h.y + h.h;
    if (h.dashTimer > 0) {
      h.vx = h.facing * 520;
      h.vy = 0;
      if (Math.floor(s.visualTime * 70) % 2 === 0) this.burst(h.x + 14, h.y + 20, dashColor ?? '#7cddcf', 1, 20);
    } else {
      h.vx = approach(h.vx, move * h.speed * speedFactor, (h.grounded ? 2400 : 1650) * dt);
      const jumpGravity = h.vy > 0 ? HERO_FALL_GRAVITY : HERO_RISE_GRAVITY * (input.jumpHeld && Math.abs(h.vy) < 90 ? .72 : 1);
      h.vy = Math.min(800, h.vy + jumpGravity * moonGravity * dt);
    }
    h.x += h.vx * dt;
    h.x = clamp(h.x, 0, s.room.width - h.w);
    for (const p of s.room.platforms) {
      if (p.oneWay || p.kind === 'spring' || !overlap(h, p)) continue;
      if (h.y + h.h > p.y + 5 && h.y < p.y + p.h - 3) {
        if (h.vx > 0) h.x = p.x - h.w;
        else if (h.vx < 0) h.x = p.x + p.w;
        h.vx = 0;
      }
    }
    const oldY = h.y;
    h.y += h.vy * dt;
    h.grounded = false;
    for (const p of s.room.platforms) {
      if (h.x + h.w <= p.x || h.x >= p.x + p.w) continue;
      if (h.vy >= 0 && oldY + h.h <= p.y + 4 && h.y + h.h >= p.y) {
        h.y = p.y - h.h;
        h.vy = 0;
        h.grounded = true;
        h.jumps = 0;
        this.variableJump = false;
        if (this.landingSealArmed) {
          this.landingSealArmed = false;
          this.sealPulse('landingSeal');
        }
        if (p.kind === 'spring') {
          h.vy = -960 * jumpScale;
          h.grounded = false;
          h.jumps = 1;
          this.sound('doubleJump');
          this.burst(h.x + 14, h.y + h.h, '#b9edb0', 14, 120);
        } else if (p.kind === 'ground' && h.x > s.room.checkpoint.x + 180 && h.x > p.x + 32 && h.x < p.x + p.w - 50) {
          if (isSafeFloorPoint(s.room, h.x, h.w)) s.room.checkpoint = { x: h.x, y: p.y - h.h };
        }
      } else if (!p.oneWay && h.vy < 0 && oldY >= p.y + p.h - 3 && h.y <= p.y + p.h) {
        h.y = p.y + p.h;
        h.vy = 0;
      }
    }
    for (const hazard of s.room.hazards) if (overlap(h, hazard)) {
      if (hazard.kind === 'mechanism') {
        const { hit } = sampleTrap(hazard, s.time);
        if (!hit || !overlap(h, hit)) continue;
        const kind = TRAP_DESIGNS[hazard.theme].kind;
        if (kind === 'gust') { h.x -= (h.grounded ? 85 : 140) * dt; continue; }
        if (kind === 'tide') {
          if (h.grounded || h.vy >= 0) {
            h.vy = -690; h.grounded = false; h.jumps = 1; h.coyote = 0; this.variableJump = false;
            this.burst(h.x + 14, h.y + h.h, '#99d8cb', 14, 115);
          }
          continue;
        }
        this.hurtHero(1, hit.x + hit.w / 2, false, false);
      } else this.hurtHero(1, hazard.x + hazard.w / 2, false, false);
      if (s.phase !== 'playing') return;
      if (hazard.kind === 'lava') this.respawnFromFall();
    }
    if (h.y > 590) {
      this.hurtHero(1, h.x, true);
      if (s.phase === 'playing') this.respawnFromFall();
    }
  }

  private respawnFromFall(): void {
    const s = this.state;
    const h = s.hero;
    h.x = s.room.checkpoint.x;
    h.y = s.room.checkpoint.y - 4;
    h.vx = h.vy = 0;
    h.jumps = 0;
    h.dashTimer = 0;
    h.guardTimer = 0;
    h.invincible = 1.5;
    this.variableJump = false;
    this.landingSealArmed = false;
    s.deaths += 1;
    this.label(h.x, h.y - 10, '小心脚下！', '#ffb59c');
  }

  private attack(): void {
    const s = this.state;
    const h = s.hero;
    const { archetype, tuning } = WEAPONS[h.weapon];
    const recovery = tuning?.cooldown ?? 1;
    const spread = tuning?.spread ?? 1;
    const gildedSwitch = h.swapBoost > 0 ? this.buffStacks('gildedSwitch') : 0;
    this.attackPower = (h.swapBoost > 0 ? 1.3 + gildedSwitch * .25 : 1) * (h.counterTimer > 0 ? 1.5 : 1);
    if (gildedSwitch) this.fireBuff('gildedSwitch');
    h.attackTimer = .2;
    this.meleeHits.clear();
    const attackSpeed = h.attackSpeed * (s.overdrive > 0 ? 1.65 : 1) * (s.synergies.includes('blazing') ? 1.1 : 1);
    const extraShots = h.extraProjectiles + Number(s.synergies.includes('fireflies')) +
      (s.overdrive > 0 ? 2 : 0) + (tuning?.shots ?? 0);
    const tier = weaponTier(h);
    if (isMelee(archetype)) {
      h.attackStep = h.comboWindow > 0 ? h.attackStep % 3 + 1 : 1;
      h.comboWindow = 1.05;
      const combo = MELEE_COMBOS[archetype];
      const variant = h.attackStep === 3 ? 1 : 0;
      this.spearRiposte = archetype === 'spear' && h.counterTimer > 0;
      h.attackTimer = combo.active[variant];
      h.attackCooldown = combo.recovery[variant] * recovery / attackSpeed;
      this.sound('attack');
      for (let i = 0; i < extraShots; i++) this.heroProjectile('ember', (i - (extraShots - 1) / 2) * combo.extraSpread * spread, .7);
    } else if (archetype === 'fan') {
      h.attackStep = h.comboWindow > 0 ? h.attackStep % 3 + 1 : 1;
      h.comboWindow = 1.15;
      const charged = h.attackStep === 3;
      h.attackTimer = charged ? .28 : .20;
      h.attackCooldown = (charged ? .56 : .40) * recovery / attackSpeed;
      const shots = Math.max(1, 1 + extraShots);
      for (let i = 0; i < shots; i++) this.fanWave((i - (shots - 1) / 2) * 66 * spread, charged, tier);
      this.sound('fire');
    } else if (archetype === 'ember') {
      h.attackStep = h.attackStep % 3 + 1;
      h.comboWindow = 1.3;
      h.attackCooldown = .28 * recovery / attackSpeed;
      const shots = Math.max(1, 1 + extraShots + Number(tier >= 2));
      for (let i = 0; i < shots; i++) this.heroProjectile('ember', (i - (shots - 1) / 2) * 74 * spread, 1, h.attackStep === 3);
      this.sound('fire');
    } else {
      h.attackStep = h.attackStep % 3 + 1;
      h.comboWindow = 1.3;
      h.attackCooldown = .48 * recovery / attackSpeed;
      const shots = Math.max(1, 2 + extraShots + Number(tier >= 2));
      for (let i = 0; i < shots; i++) this.heroProjectile('disc', (i - (shots - 1) / 2) * 64 * spread);
      this.sound('attack');
    }
    if (h.attackStep === 3) this.gainBuffResonance('thirdStar', 4);
    h.swapBoost = 0; h.counterTimer = 0;
  }

  private fanWave(verticalSpeed: number, charged: boolean, tier: number): void {
    const { hero: h, character } = this.state;
    const { tuning } = WEAPONS[h.weapon];
    const w = charged ? 44 : 28;
    const height = charged ? 54 : 36;
    this.state.projectiles.push({
      id: ++this.projectileId, kind: 'fan', weapon: h.weapon, ownerCharacter: character,
      x: h.x + h.w / 2 + h.facing * 27 - w / 2,
      y: h.y + h.h / 2 - height / 2 - (charged ? 13 : 4),
      w, h: height, vx: h.facing * (charged ? 690 : 645) * (tuning?.speed ?? 1), vy: verticalSpeed,
      life: (charged ? .75 : .64) * (tuning?.reach ?? 1),
      damage: this.effectiveDamage() * (charged ? 2.95 : 1.38) * (1 + (tier - 1) * .10) * (tuning?.damage ?? 1),
      owner: 'hero', hitIds: [], style: charged ? 'charged' : undefined,
      pierce: Math.max(1, tier + (charged ? 2 : 0) + (tuning?.pierce ?? 0)),
    });
  }

  private heroProjectile(kind: 'ember' | 'disc', verticalSpeed: number, multiplier = 1, charged = false): void {
    const { hero: h, character } = this.state;
    const { tuning } = WEAPONS[h.weapon];
    const id = ++this.projectileId;
    if (kind === 'disc' && this.state.overdrive > 0) this.awakenedDiscs.add(id);
    const tier = weaponTier(h);
    const reach = tuning?.reach ?? 1;
    const burns = kind === 'ember' && h.weapon !== 'frostStaff' && h.weapon !== 'jadeNeedle';
    this.state.projectiles.push({ id, kind, weapon: h.weapon, ownerCharacter: character === 'traveller' ? undefined : character,
      x: h.x + h.w / 2 + h.facing * 16 - 10,
      y: h.y + (kind === 'disc' ? 8 : charged ? -5 : 2), w: kind === 'disc' ? 26 : charged ? 30 : 20, h: kind === 'disc' ? 26 : charged ? 26 : 16,
      vx: h.facing * (kind === 'disc' ? 560 : 720) * (tuning?.speed ?? 1), vy: verticalSpeed,
      life: (kind === 'disc' ? 1.7 : 1.5) * reach,
      returnAt: kind === 'disc' ? 1.3 * reach : undefined,
      ...(kind === 'disc' && character && character !== 'traveller' && h.attackStep === 3 && { finishingThrow: true }),
      damage: this.effectiveDamage() * multiplier * (kind === 'disc' ? 1.2 : charged ? 3.1 : 2) * (tuning?.damage ?? 1),
      owner: 'hero', hitIds: [], returning: false, rotation: 0,
      style: charged ? 'charged' : undefined,
      pierce: kind === 'ember' ? Math.max(1, (charged ? 5 : 2 + tier) + (tuning?.pierce ?? 0)) : undefined,
      burn: burns ? 1.6 : undefined, primesEmber: burns && h.weapon === 'ember' });
  }

  private updateEnemies(dt: number): void {
    const s = this.state;
    const partyRate = s.coopPartySize === undefined ? 1 : cooperativeDifficulty(s.coopPartySize).attackRate;
    const factor = (s.modifier === 'haste' ? 1.28 : 1) * (1 + Math.min(6, s.roomIndex) * .045) * partyRate;
    for (const e of s.enemies) {
      if (e.dead) continue;
      const h = this.partyTarget(e.x, e.y);
      if ((e.emberMark ?? 0) > 0) e.emberMark = Math.max(0, e.emberMark! - dt);
      if ((e.burnTime ?? 0) > 0) {
        e.burnTime = Math.max(0, e.burnTime! - dt);
        e.burnTick = (e.burnTick ?? .35) - dt;
        if (e.burnTick <= 0) { e.burnTick = .4; this.hitEnemy(e, e.burnDamage ?? .25, false, true); }
        if (e.dead) continue;
      }
      e.timer += dt;
      e.hurt = Math.max(0, e.hurt - dt);
      e.attackCooldown = Math.max(0, e.attackCooldown - dt * factor);
      this.checkEnemyMechanisms(e);
      if ((e.comboStagger ?? 0) > 0) {
        e.comboStagger = Math.max(0, e.comboStagger! - dt);
        continue;
      }
      if (updateEnemyVariant(e, h === s.hero ? s : { ...s, hero: h }, dt, {
        nextProjectileId: () => ++this.projectileId,
        hitEnemy: (enemy, damage) => this.hitEnemy(enemy, damage),
        burst: (x, y, color, count, speed) => this.burst(x, y, color, count, speed),
        sound: name => this.sound(name),
      })) continue;
      const distance = h.x - e.x;
      if (e.kind === 'bat') {
        const engaged = Math.abs(distance) < 440;
        const targetX = engaged ? h.x + (Math.sin(e.timer * 1.6) * 80) : e.originX + Math.sin(e.timer) * 65;
        const targetY = engaged ? h.y + 4 + Math.sin(e.timer * 2.4) * 56 : e.originY + Math.sin(e.timer * 2.5) * 24;
        e.vx = approach(e.vx, clamp((targetX - e.x) * 1.7, -135, 135) * factor, 420 * dt);
        e.vy = approach(e.vy, clamp((targetY - e.y) * 1.6, -100, 100) * factor, 280 * dt);
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        e.facing = e.vx >= 0 ? 1 : -1;
      } else {
        if (e.kind === 'slime') {
          if (Math.abs(distance) < 400) e.facing = distance >= 0 ? 1 : -1;
          else if (Math.abs(e.x - e.originX) > 92) e.facing = e.x > e.originX ? -1 : 1;
          const nextX = e.x + e.facing * 23 + e.w / 2;
          const hasGround = s.room.platforms.some(p => nextX >= p.x && nextX <= p.x + p.w && p.kind === 'ground');
          if (!hasGround) e.facing *= -1;
          if (e.hurt <= 0) e.vx = e.facing * 58 * factor;
          if (e.attackCooldown <= 0 && Math.abs(distance) < 350 && e.y + e.h >= 447) {
            e.vy = -205;
            e.attackCooldown = 1.7;
          }
        } else {
          e.vx = e.hurt > 0 ? e.vx : 0;
          e.facing = distance >= 0 ? 1 : -1;
          if (e.attackCooldown <= 0 && Math.abs(distance) < 720) {
            const dx = h.x + 14 - e.x - 16;
            const dy = h.y + 18 - e.y - 20;
            const len = Math.hypot(dx, dy) || 1;
            s.projectiles.push({ id: ++this.projectileId, kind: 'enemy', x: e.x + 10, y: e.y + 12,
              w: 12, h: 12, vx: dx / len * 190 * factor, vy: dy / len * 190 * factor,
              life: 4, damage: 1, owner: 'enemy', hitIds: [] });
            e.attackCooldown = 2.45;
            this.burst(e.x + 16, e.y + 16, '#ff9a86', 5, 50);
          }
        }
        e.x += e.vx * dt;
        const oldBottom = e.y + e.h;
        e.vy = Math.min(650, e.vy + GRAVITY * dt);
        e.y += e.vy * dt;
        for (const p of s.room.platforms) {
          if (e.x + e.w > p.x && e.x < p.x + p.w && e.vy >= 0 && oldBottom <= p.y + 4 && e.y + e.h >= p.y) {
            e.y = p.y - e.h;
            e.vy = 0;
          }
        }
        if (e.y > 600) this.hitEnemy(e, 100);
      }
    }
  }

  private checkEnemyMechanisms(enemy: Enemy): void {
    const s = this.state;
    if (enemy.kind === 'bat' || !enemy.variant || (enemy.nextMechanismHit ?? 0) > s.time) return;
    for (const trap of s.room.hazards) {
      if (trap.kind !== 'mechanism' || !overlap(enemy, trap)) continue;
      const design = TRAP_DESIGNS[trap.theme];
      const forgeGuard = design.kind === 'kiln' && enemy.variant === 'forge-bulwark';
      if (!forgeGuard && design.kind !== 'bell') continue;
      const hit = sampleTrap(trap, s.time).hit;
      if (!hit || !overlap(enemy, hit)) continue;
      enemy.nextMechanismHit = s.time + design.active;
      this.staggerRegionalEnemy(enemy, forgeGuard ? 1.1 : .75);
      enemy.hurt = .16;
      enemy.vx = 0;
      const x = enemy.x + enemy.w / 2, y = enemy.y + enemy.h / 2;
      this.impact(x, y, 'break', design.color);
      this.burst(x, y, design.color, forgeGuard ? 18 : 12, 170);
      this.label(x, enemy.y - 11, forgeGuard ? '炉火破甲' : '钟鸣震停', '#f2d39a');
      this.sound(forgeGuard ? 'guardBreak' : 'heavy');
      break;
    }
  }

  private staggerRegionalEnemy(enemy: Enemy, duration: number): void {
    if (!enemy.variant) return;
    enemy.aiTimer = Math.max(enemy.aiMode === 'recover' ? (enemy.aiTimer ?? 0) : 0, duration);
    enemy.aiMode = 'recover';
    enemy.attackCooldown = Math.max(enemy.attackCooldown, duration + .22);
  }

  private updateBoss(dt: number): void {
    const s = this.state, b = s.boss;
    if (!b || b.mode === 'dead') return;
    const h = this.partyTarget(b.x + b.w / 2, b.y + b.h / 2);
    const warden = b.kind === 'warden';
    this.bossGuardRecovery = Math.max(0, this.bossGuardRecovery - dt);
    b.hurt = Math.max(0, b.hurt - dt);
    b.exposed = Math.max(0, b.exposed - dt);
    if (!b.active && h.x > 510) {
      b.active = true;
      s.announcement = warden ? `${COOP_WARDEN_NAME} · 刃落前必有预兆` : '余烬守卫 · 观察预警，抓住破绽';
      s.announcementTimer = 2.8;
      this.sound('boss'); s.shake = 5;
    }
    if (!b.active) return;
    if (b.form === 2 && b.phase === 2 && b.hp <= b.maxHp / 2 && b.mode !== 'transition') this.ascendBoss(b);
    const previousTimer = b.timer;
    b.timer -= dt;
    if (b.mode === 'transition') {
      if (openingSeal(b) && previousTimer > BOSS_TRANSFORM_TIME - 2.04 && sealProgress(b) >= 2.04 / BOSS_TRANSFORM_TIME) {
        s.shake = warden ? 11 : 8;
        this.burst(b.x + b.w / 2, b.y + b.h - 2, warden ? '#ffc884' : '#dba26e', warden ? 40 : 28, 170);
      }
      const ascensionImpact = BOSS_ASCENSION_TIME - BOSS_ASCENSION_IMPACT;
      if (openingAscension(b) && previousTimer > ascensionImpact && b.timer <= ascensionImpact) {
        s.shake = warden ? 15 : 11;
        this.impact(b.x + b.w / 2, b.y + b.h - 12, 'heavy', '#ffd39a');
        this.burst(b.x + b.w / 2, b.y + b.h - 6, '#ffc887', warden ? 64 : 48, 260);
        this.sound('boss');
      }
      if (b.timer <= 0) { b.mode = 'idle'; b.timer = b.phase === 3 ? 0 : .3; this.bossGuardRecovery = 1.4; }
      return;
    }
    if (b.mode === 'stagger') {
      b.vx = b.vy = 0;
      if (b.timer <= 0) { b.mode = 'idle'; b.timer = .3; b.guard = b.maxGuard; this.bossGuardRecovery = 1.4; }
      return;
    }
    if (b.mode === 'idle' || b.mode === 'recover') {
      b.vx = approach(b.vx, 0, 1000 * dt);
      if (b.timer <= 0) {
        const patterns: readonly Boss['intent'][] = warden ? wardenIntents(b.phase) : b.phase === 1
          ? ['charge','leap','slam'] : b.phase === 2 ? ['rift','charge','barrage','rain','leap'] : ['eclipse','charge','rain','slam','barrage'];
        b.intent = patterns[b.attackCount % patterns.length];
        b.attackCount += 1;
        b.chain = b.intent === 'charge' ? b.phase - 1 : 0;
        this.bossWindup(b, b.intent === 'eclipse' ? ECLIPSE_WINDUP : .82 - (b.phase - 1) * .17);
      }
    } else if (b.mode === 'windup' && b.timer <= 0) {
      if (b.intent === 'charge') {
        b.mode = 'charge'; b.timer = warden ? .58 : .55;
        const speed = warden ? 500 + (b.phase - 1) * 92 : b.phase === 3 ? 625 : 420 + (b.phase - 1) * 90;
        b.vx = b.facing * speed;
      } else if (b.intent === 'leap') {
        b.mode = 'jump'; b.vy = warden ? -616 - (b.phase - 1) * 24 : -540;
        const airTime = 2 * Math.abs(b.vy) / GRAVITY;
        b.vx = clamp((b.targetX - b.x) / airTime, warden ? -510 : -450, warden ? 510 : 450);
      } else if (b.intent === 'rift') {
        if (warden) {
          wardenRiftLanes(b, s.room.width).forEach((center, index) => this.bossChargeSeal(center, .52 + (index % 2) * .28));
        } else {
          for (const offset of [-120, 0, 120]) {
            s.projectiles.push({ id: ++this.projectileId, kind: 'rift', x: clamp(b.targetX + offset, 430, s.room.width - 100), y: 270,
              w: 40, h: 178, vx: 0, vy: 0, life: 1.35, delay: .55, damage: 1, owner: 'enemy', hitIds: [], style: 'ink' });
          }
        }
        this.sound('boss'); this.bossRecover(b, 1.1);
      } else if (b.intent === 'eclipse') {
        this.bossEclipse(b);
      } else if (b.intent === 'rain') {
        const origins = warden ? wardenRainOrigins(b, s.room.width) : Array.from({ length: b.phase === 3 ? 7 : 5 },
          (_, index) => clamp(b.targetX - 210 + index * 75, 420, s.room.width - 90));
        origins.forEach((x, index) => {
          s.projectiles.push({ id: ++this.projectileId, kind: 'enemy', x, y: 65,
            w: 19, h: 26, vx: 0, vy: warden ? 410 : 330, life: 2.6, delay: .3 + index * .08, damage: 1, owner: 'enemy', hitIds: [], style: 'ink' });
        });
        this.sound('fire'); this.bossRecover(b, 1.2);
      } else if (b.intent === 'barrage') {
        b.mode = 'barrage'; b.timer = .08; b.chain = (b.phase === 3 ? 3 : 2) + (warden && b.phase >= 2 ? 1 : 0);
      } else { b.mode = 'slam'; b.timer = .12; }
    } else if (b.mode === 'charge') {
      this.burst(b.x + b.w / 2, 446, '#eb945e', 1, 40);
      const atWall = b.vx < 0 && b.x <= 420 || b.vx > 0 && b.x + b.w >= s.room.width - 90;
      if (b.timer <= 0 || atWall) {
        b.vx = 0;
        if (b.chain > 0) {
          if (b.phase === 3) this.bossChargeSeal(b.targetX + b.w / 2, .58);
          b.chain -= 1;
          this.bossWindup(b, .44);
        }
        else { this.bossShockwaves(b); this.bossRecover(b, 1.05 - (b.phase - 1) * .12); }
      }
    } else if (b.mode === 'slam' && b.timer <= 0) {
      this.bossShockwaves(b); this.bossRecover(b, 1.15 - (b.phase - 1) * .12);
    } else if (b.mode === 'barrage' && b.timer <= 0) {
      this.bossVolley(b, (b.phase === 3 ? 5 : 3) + (warden ? 2 : 0));
      b.chain -= 1;
      if (b.chain > 0) b.timer = warden ? .34 : .38;
      else this.bossRecover(b, 1.1);
    }
    b.x = clamp(b.x + b.vx * dt, 410, s.room.width - b.w - 80);
    if (b.mode === 'jump') {
      b.vy += GRAVITY * dt; b.y += b.vy * dt;
      if (b.y + b.h >= 448 && b.vy > 0) {
        b.y = 448 - b.h; b.vy = b.vx = 0;
        this.bossShockwaves(b); this.bossRecover(b, 1.15 - (b.phase - 1) * .1);
      }
    }
  }

  private bossWindup(b: Boss, duration: number): void {
    const h = this.partyTarget(b.x + b.w / 2, b.y + b.h / 2);
    const warden = b.kind === 'warden';
    const size = this.state.coopPartySize;
    const tempo = size === undefined ? 1 : cooperativeDifficulty(size).bossTempo;
    b.mode = 'windup'; b.timer = duration * tempo; b.vx = 0;
    b.targetX = clamp(h.x + h.w / 2 - b.w / 2, 420, this.state.room.width - b.w - 90);
    if (b.intent === 'leap') {
      const reach = warden ? 490 : 380;
      b.targetX = clamp(b.targetX, b.x - reach, b.x + reach);
    }
    b.facing = h.x + h.w / 2 < b.x + b.w / 2 ? -1 : 1;
  }

  private bossRecover(b: Boss, duration: number): void {
    const recovery = duration * (b.phase === 3 ? .82 : b.phase === 2 ? .88 : .94) * (b.kind === 'warden' ? .91 : 1);
    b.mode = 'recover'; b.timer = recovery; b.exposed = recovery; b.vx = 0;
  }

  private ascendBoss(b: Boss): void {
    const s = this.state;
    b.phase = 3; b.mode = 'transition'; b.timer = BOSS_ASCENSION_TIME;
    b.vx = b.vy = 0; b.y = 448 - b.h; b.exposed = 0; b.hurt = 0;
    b.maxGuard = this.bossArmor(b.kind === 'warden', 3); b.guard = b.maxGuard; b.attackCount = 0; b.chain = 0;
    b.burnTime = b.burnTick = b.burnDamage = 0;
    s.projectiles = []; this.awakenedDiscs.clear();
    s.hitstop = 0; s.shake = 4;
    s.hero.invincible = Math.max(s.hero.invincible, BOSS_ASCENSION_TIME + .35);
    s.announcement = b.kind === 'warden' ? '玄阙镇星王 · 王刃裁天' : '玄烬魔君 · 天烬降临';
    s.announcementTimer = BOSS_ASCENSION_TIME + .35;
  }

  private bossEclipse(b: Boss): void {
    const s = this.state;
    const warden = b.kind === 'warden';
    eclipseLanes(b, s.room.width).forEach((center, index) => {
      const delay = index % 2 === 0 ? .28 : .64;
      s.projectiles.push({
        id: ++this.projectileId, kind: 'rift', x: center - ECLIPSE_WIDTH / 2, y: 156,
        w: ECLIPSE_WIDTH, h: 292, vx: 0, vy: 0, life: delay + .46, delay,
        damage: warden ? 2 : 1, owner: 'enemy', hitIds: [], style: 'eclipse',
      });
    });
    this.sound('boss');
    this.bossRecover(b, 1.28);
  }

  private bossVolley(b: Boss, count: number): void {
    const s = this.state, h = this.partyTarget(b.x + b.w / 2, b.y + b.h / 2);
    const warden = b.kind === 'warden';
    const speed = 210 + b.phase * 25 + (warden ? 45 : 0);
    const angle = Math.atan2(h.y + 18 - b.y - 30, h.x + 14 - b.x - b.w / 2);
    for (let i = 0; i < count; i++) {
      const offset = (i - (count - 1) / 2) * .24;
      s.projectiles.push({ id: ++this.projectileId, kind: 'enemy', x: b.x + b.w / 2, y: b.y + 30,
        w: b.form === 2 ? 19 : 14, h: b.form === 2 ? 19 : 14, vx: Math.cos(angle + offset) * speed, vy: Math.sin(angle + offset) * speed,
        life: 4, damage: 1, owner: 'enemy', hitIds: [], style: b.form === 2 ? 'ink' : undefined });
    }
    this.burst(b.x + b.w / 2, b.y + 30, '#ff956a', 10, 100);
    this.sound('fire');
  }

  private bossShockwaves(b: Boss): void {
    const s = this.state;
    const warden = b.kind === 'warden', center = b.x + b.w / 2;
    s.shake = warden ? 10 : 7; this.sound('boss');
    this.impact(center, 442, 'heavy', '#ffb474');
    this.burst(center, 445, '#ffb474', warden ? 36 : 28, 210);
    for (const direction of [-1, 1]) {
      const speed = 230 + (b.phase - 1) * 45 + (warden ? 44 : 0);
      s.projectiles.push({ id: ++this.projectileId, kind: 'shockwave', x: center, y: 424,
        w: warden ? 56 : 36, h: 24, vx: direction * speed, vy: 0, life: 4, damage: 1,
        owner: 'enemy', hitIds: [], style: b.form === 2 ? 'ink' : undefined });
      if (warden && b.phase >= 2 && b.intent !== 'charge') {
        s.projectiles.push({ id: ++this.projectileId, kind: 'shockwave', x: center, y: 414,
          w: 44, h: 34, vx: direction * speed * 1.15, vy: 0, life: 3.5, delay: .32, damage: 1,
          owner: 'enemy', hitIds: [], style: 'ink' });
      }
    }
    const h = this.partyTarget(center, b.y + b.h / 2);
    if (b.form === 2 && b.intent === 'charge') this.bossChargeSeal(h.x + h.w / 2, .85);
    if (b.form === 2 && b.intent === 'slam') this.bossVolley(b, b.phase === 3 ? 5 : 3);
  }

  private bossChargeSeal(targetCenter: number, delay: number): void {
    const center = clamp(targetCenter, 430, this.state.room.width - 100);
    this.state.projectiles.push({
      id: ++this.projectileId, kind: 'rift', x: center - 18, y: 270, w: 36, h: 178,
      vx: 0, vy: 0, life: delay + .66, delay, damage: 1, owner: 'enemy', hitIds: [], style: 'ink',
    });
  }

  private updateMelee(h: Hero): void {
    const s = this.state, empowered = s.overdrive > 0, heavy = h.attackStep === 3;
    const { archetype, tuning } = WEAPONS[h.weapon];
    const tier = weaponTier(h);
    const extraReach = Math.min(3, h.upgrades.filter(id => id === 'edge').length) * 12 + (tier - 1) * 10;
    const spear = archetype === 'spear';
    const reach = (heavy ? 160 : 121) + (empowered ? 24 : 0) + (this.spearRiposte ? 24 : 0);
    const center = h.x + h.w / 2;
    const attackRect = spear
      ? { x: h.facing === 1 ? center + 5 : center - 5 - reach, y: h.y + (heavy ? 1 : 7), w: reach, h: heavy ? 34 : 25 }
      : empowered || heavy
        ? { x: h.facing === 1 ? h.x + 4 : h.x - 114, y: h.y - 28, w: 140, h: 96 }
        : { x: h.facing === 1 ? h.x + 12 : h.x - 70, y: h.y - 13, w: 88, h: 67 };
    let strength = spear ? heavy ? 3.05 : 1.56 : heavy ? 2.8 : h.attackStep === 2 ? 1.55 : 1.35;
    if (archetype === 'sabre') {
      attackRect.w = (heavy || empowered ? 166 : 114);
      attackRect.x = h.facing > 0 ? center - 13 : center + 13 - attackRect.w;
      strength = heavy ? 3.8 : 1.78;
    } else if (archetype === 'fist') {
      attackRect.w = heavy ? 80 : 53;
      attackRect.h = heavy ? 57 : 41;
      attackRect.x = h.facing > 0 ? center - 4 : center + 4 - attackRect.w;
      attackRect.y = h.y - (heavy ? 7 : 0);
      strength = heavy ? 2.75 : h.attackStep === 2 ? 1.20 : 1.05;
    }
    const damage = this.effectiveDamage() * (1 + (tier - 1) * .12) * strength * (tuning?.damage ?? 1);
    const changedReach = extraReach + attackRect.w * ((tuning?.reach ?? 1) - 1);
    attackRect.w += changedReach;
    if (h.facing < 0) attackRect.x -= changedReach;
    for (const enemy of s.enemies) if (!enemy.dead && !this.meleeHits.has(enemy.id) && overlap(attackRect, enemy)) {
      this.meleeHits.add(enemy.id);
      this.hitWithWeapon(enemy, damage, heavy);
    }
    if (s.boss?.active && !this.meleeHits.has(-1) && overlap(attackRect, s.boss)) {
      this.meleeHits.add(-1);
      this.hitWithWeapon(s.boss, damage, heavy);
    }
  }

  private updateAttacks(dt: number, canAttack = true): void {
    const s = this.state;
    const h = s.hero;
    if (canAttack && h.dashTimer > 0 && h.upgrades.includes('stride')) {
      const gust = { x: h.x - 12, y: h.y - 6, w: h.w + 24, h: h.h + 12 };
      for (const enemy of s.enemies) if (!enemy.dead && !this.dashHits.has(enemy.id) && overlap(gust, enemy)) {
        this.dashHits.add(enemy.id);
        this.hitEnemy(enemy, this.effectiveDamage() * .8);
        this.label(enemy.x + enemy.w / 2, enemy.y - 12, '追风刃', '#c2cf95');
      }
      if (s.boss?.active && !this.dashHits.has(-1) && overlap(gust, s.boss)) {
        this.dashHits.add(-1);
        this.hitBoss(this.effectiveDamage() * .8);
      }
    }
    if (canAttack && h.attackTimer > 0 && isMelee(WEAPONS[h.weapon].archetype)) {
      this.updateMelee(h);
    }
    for (const p of s.projectiles) {
      if (p.life <= 0) continue;
      p.life -= dt;
      if ((p.delay ?? 0) > 0) { p.delay = Math.max(0, p.delay! - dt); continue; }
      p.rotation = (p.rotation || 0) + dt * 16;
      if (p.kind === 'disc') {
        if (p.life < (p.returnAt ?? 1.3) && !p.returning) {
          p.returning = true; p.hitIds = [];
          if (this.awakenedDiscs.has(p.id)) {
            p.damage *= 1.6;
            p.w = p.h = 34;
            this.burst(p.x + 10, p.y + 10, '#c9baff', 6, 90);
          } else p.damage *= 1.45;
        }
        if (p.returning) {
          const dx = h.x + 14 - p.x;
          const dy = h.y + 18 - p.y;
          const len = Math.hypot(dx, dy) || 1;
          const returnSpeed = this.awakenedDiscs.has(p.id) ? 900 : 780;
          p.vx = dx / len * returnSpeed; p.vy = dy / len * returnSpeed;
          if (len < 22) {
            p.life = 0;
            if (p.hitIds.length) {
              this.gainResonance(5);
              this.burst(h.x + 14, h.y + 18, '#c9baff', 5, 70);
            }
          }
        }
        if (weaponTier(h) >= 3) {
          for (const enemyShot of s.projectiles) if (enemyShot.owner === 'enemy' && enemyShot.kind !== 'rift' && enemyShot.life > 0 && overlap(p, enemyShot)) {
            enemyShot.life = 0;
            this.gainResonance(3);
            this.impact(enemyShot.x, enemyShot.y, 'break', '#c2e5d6');
            this.sound('perfectDodge');
          }
        }
      }
      if (p.kind === 'ember' && p.owner === 'hero') {
        // A shallow aim assist helps ranged attacks meet airborne enemies, while
        // retaining forward flight and the need to face the target.
        const targets: Rect[] = s.enemies.filter(e => !e.dead && !p.hitIds.includes(e.id));
        if (s.boss?.active && s.boss.mode !== 'dead' && !p.hitIds.includes(-1)) targets.push(s.boss);
        const centerX = p.x + p.w / 2, centerY = p.y + p.h / 2;
        const target = targets.filter(e => (e.x + e.w / 2 - centerX) * Math.sign(p.vx) > 0 && Math.abs(e.x - centerX) < 480 && Math.abs(e.y + e.h / 2 - centerY) < 190)
          .sort((a, b) => Math.hypot(a.x - centerX, a.y - centerY) - Math.hypot(b.x - centerX, b.y - centerY))[0];
        if (target) p.vy = approach(p.vy, clamp((target.y + target.h / 2 - centerY) * 5, -330, 330), 1400 * dt);
      }
      p.vy += (p.gravity ?? 0) * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.x < -60 || p.x > s.room.width + 60 || p.y < -100 || p.y > 600) p.life = 0;
      if (p.life <= 0) continue;
      if (p.owner === 'hero') {
        for (const e of s.enemies) {
          if (!e.dead && !p.hitIds.includes(e.id) && overlap(p, e)) {
            p.hitIds.push(e.id);
            const detonate = p.kind === 'disc' && p.returning && !p.ownerCharacter &&
              (p.weapon === undefined || p.weapon === 'disc') && (this.classicMarks.get(e) ?? 0) > s.time;
            if (detonate) {
              this.classicMarks.delete(e);
              e.emberMark = e.burnTime = e.burnDamage = 0;
              e.burnTick = .35;
              this.staggerRegionalEnemy(e, .6);
              const x = e.x + e.w / 2, y = e.y + e.h / 2;
              this.impact(x, y, 'break', '#f2ac89');
              this.burst(x, y, '#e7ac91', 22, 205);
              this.burst(x, y, '#c9baff', 9, 145);
              this.label(x, e.y - 18, '回锋引烬', '#f3c498');
              this.sound('synergy');
            }
            this.hitWithWeapon(e, p.damage * (detonate ? 1.5 : 1), p.style === 'charged', p);
            if (p.kind === 'ember') {
              this.markWithEmber(e, p);
              this.emberBurst(p);
            }
            if (p.kind === 'ember' || p.kind === 'fan') {
              p.pierce = (p.pierce ?? 1) - 1;
              if (p.pierce <= 0) { p.life = 0; break; }
            }
          }
        }
        if (p.life > 0 && s.boss && s.boss.active && s.boss.mode !== 'dead' && !p.hitIds.includes(-1) && overlap(p, s.boss)) {
          p.hitIds.push(-1);
          // Staff fire keeps its cast-time tag even after switching weapons.
          this.hitWithWeapon(s.boss, p.damage, p.kind === 'fan' && p.style === 'charged', p);
          if (p.kind !== 'disc') { this.emberBurst(p); p.life = 0; }
        }
      } else if (canAttack && overlap(p, h)) {
        this.hurtHero(p.damage, p.x);
        if (p.kind !== 'shockwave' && p.kind !== 'rift') p.life = 0;
      }
      if (p.kind === 'ember' || p.kind === 'fan') {
        for (const platform of s.room.platforms) if (p.life > 0 && !platform.oneWay && overlap(p, platform)) { this.emberBurst(p); p.life = 0; break; }
      }
    }
    s.projectiles = s.projectiles.filter(p => {
      if (p.life <= 0) this.awakenedDiscs.delete(p.id);
      return p.life > 0;
    });
  }

  private emberBurst(projectile: Projectile): void {
    if (projectile.kind !== 'ember') return;
    const s = this.state;
    const center = { x: projectile.x + projectile.w / 2, y: projectile.y + projectile.h / 2 };
    const moonfire = projectile.ownerCharacter === 'staff' && projectile.weapon === 'ember';
    const tint = projectile.weapon && projectile.ownerCharacter && projectile.weapon !== 'ember' ? WEAPONS[projectile.weapon].color : null;
    this.impact(center.x, center.y, 'heavy', moonfire ? '#e5d7fb' : tint ?? '#ffd49a');
    this.burst(center.x, center.y, moonfire ? '#b48ccf' : tint ?? '#ffb474', projectile.style === 'charged' ? 30 : 18, projectile.style === 'charged' ? 250 : 180);
    if (moonfire) this.burst(center.x, center.y, '#edb995', 8, 94);
    for (const enemy of s.enemies) {
      if (enemy.dead || projectile.hitIds.includes(enemy.id)) continue;
      if (Math.hypot(enemy.x + enemy.w / 2 - center.x, enemy.y + enemy.h / 2 - center.y) < (projectile.style === 'charged' ? 124 : 92)) {
        projectile.hitIds.push(enemy.id);
        this.hitEnemy(enemy, projectile.damage * .75);
        this.markWithEmber(enemy, projectile);
      }
    }
    const boss = s.boss;
    if (boss?.active && !projectile.hitIds.includes(-1) && Math.hypot(boss.x + boss.w / 2 - center.x, boss.y + boss.h / 2 - center.y) < 100) {
      projectile.hitIds.push(-1);
      this.hitBoss(projectile.damage * .75, false, projectile.primesEmber ? STAFF_BOSS_HEALTH_SCALE : 1);
    }
  }

  private markWithEmber(enemy: Enemy, projectile: Projectile): void {
    if (enemy.dead || !projectile.burn) return;
    if (projectile.primesEmber && !projectile.ownerCharacter) {
      enemy.emberMark = 2.75;
      this.classicMarks.set(enemy, this.state.time + 2.75);
    }
    enemy.burnTime = projectile.burn;
    enemy.burnDamage = projectile.damage * .15;
    enemy.burnTick ??= .35;
  }

  private enemyContact(): void {
    const s = this.state;
    const h = s.hero;
    for (const e of s.enemies) if (!e.dead && overlap(h, e)) {
      if (h.vy > 80 && this.previousHeroBottom <= e.y + 18) {
        this.hitEnemy(e, this.effectiveDamage() * 2);
        h.vy = -365;
        h.jumps = 1;
        this.variableJump = false;
        this.sound('jump');
        this.burst(e.x + e.w / 2, e.y, '#fff0b5', 12, 110);
      } else if (!(e.comboStagger && e.comboStagger > 0)) this.hurtHero(1, e.x + e.w / 2);
    }
    const b = s.boss;
    if (b && b.active && !['dead','transition','recover','stagger'].includes(b.mode) && overlap(h, b)) {
      if (h.vy > 80 && this.previousHeroBottom <= b.y + 18) {
        this.hitBoss(this.effectiveDamage() * 2);
        h.vy = -430; h.jumps = 1; h.invincible = Math.max(h.invincible, .25);
        this.variableJump = false;
        this.sound('jump');
      } else {
        const crushing = b.kind === 'warden' && b.phase === 3 && (b.mode === 'charge' || b.mode === 'jump');
        this.hurtHero(crushing ? 2 : 1, b.x + b.w / 2);
      }
    }
  }

  private damageAmount(base: number): number {
    const critical = this.random() < this.state.hero.critChance;
    this.criticalHit = critical;
    return base * (critical ? 1.75 : 1);
  }

  private effectiveDamage(): number {
    const s = this.state;
    return s.hero.damage * (s.overdrive > 0 ? 1.55 : 1) * (s.synergies.includes('blazing') ? 1.2 : 1) * (s.hero.attackTimer > 0 ? this.attackPower : 1);
  }

  private gainResonance(amount: number): void {
    const s = this.state;
    if (s.overdrive > 0) return;
    const previous = s.resonance;
    s.resonance = Math.min(100, s.resonance + amount);
    if (previous < 100 && s.resonance >= 100) {
      s.announcement = '星能充盈 · 按 Q 觉醒';
      s.announcementTimer = 3;
      this.sound('upgrade');
      this.burst(s.hero.x + 14, s.hero.y + 18, '#ffe29b', 22, 150);
    }
  }

  private buffStacks(kind: BuffEffectKind): number {
    return Math.min(MAX_BUFF_STACKS, this.state.hero.upgrades.filter(id => id === kind).length);
  }

  private fireBuff(kind: BuffEffectKind): void {
    const h = this.state.hero;
    const duration = BUFF_EFFECT_DURATION[kind];
    (h.buffEffects ??= []).push({ kind, x: h.x + h.w / 2, y: h.y + h.h, facing: h.facing, life: duration, duration });
  }

  private gainBuffResonance(kind: 'thirdStar' | 'jadeParry' | 'jadeSpring', perStack: number): void {
    const stacks = this.buffStacks(kind);
    if (stacks === 0) return;
    this.gainResonance(stacks * perStack);
    this.fireBuff(kind);
  }

  private refreshSynergies(): void {
    const s = this.state;
    const active = SYNERGIES.filter(synergy => synergy.requires.every(requirement => requirement.split('|').some(id => s.hero.upgrades.includes(id)))).map(item => item.id);
    for (const id of active) if (!s.synergies.includes(id)) {
      const synergy = SYNERGIES.find(item => item.id === id)!;
      if (id === 'guardian') s.hero.shield += 1;
      this.label(s.hero.x + 14, s.hero.y - 36, `羁绊 · ${synergy.name}`, synergy.color);
      this.burst(s.hero.x + 14, s.hero.y + 18, synergy.color, 36, 220);
      this.sound('synergy');
      s.announcement = `羁绊觉醒 · ${synergy.name}`;
      s.announcementTimer = 3;
    }
    s.synergies = active;
  }

  private hitWithWeapon(target: Enemy | Boss, damage: number, heavy: boolean, projectile?: Projectile): void {
    const s = this.state;
    const path = projectile?.kind ?? 'melee';
    const own = !projectile || projectile.ownerCharacter === s.character;
    const link = own && (path === 'melee' || path === 'ember' || path === 'fan' || path === 'disc')
      ? this.weaponComboMarks.hit(s.character, target, projectile ? projectile.weapon : s.hero.weapon, path, s.time, projectile?.returning)
      : undefined;
    const combo = link?.step === 'finish' ? link.combo : undefined;
    const amount = damage * (combo?.damageMultiplier ?? 1);
    const weapon = projectile ? projectile.weapon : s.hero.weapon;
    const contact: WeaponContact | undefined = own && s.character && s.character !== 'traveller' && weapon
      ? { character: s.character, weapon, facing: Math.sign(projectile?.vx ?? 0) || s.hero.facing,
          accent: !!combo || !!projectile?.returning || !!projectile?.finishingThrow || projectile?.style === 'charged' }
      : undefined;
    if ('phase' in target) {
      this.hitBoss(amount, heavy, projectile?.primesEmber ? STAFF_BOSS_HEALTH_SCALE : 1, combo?.guardDamage, contact);
    } else {
      this.hitEnemy(target, amount, heavy || !!combo?.heavyEnemy, false, contact);
      if (!target.dead && combo?.stagger) {
        target.comboStagger = combo.stagger;
        target.vx = target.vy = 0;
        this.staggerRegionalEnemy(target, 0);
      }
    }
    if (!link) return;
    const x = target.x + target.w / 2;
    const y = target.y + target.h / 2;
    if (!combo) {
      this.burst(x, y - 12, link.combo.color, 4, 70);
      return;
    }
    if (combo.resonance) this.gainResonance(combo.resonance);
    if (combo.dashRecovery) s.hero.dashCooldown = Math.max(0, s.hero.dashCooldown - combo.dashRecovery);
    this.label(x, target.y - 23, combo.name, combo.color);
    this.impact(x, y, 'break', combo.color);
    this.burst(x, y, combo.color, 7, 128);
    this.sound('synergy');
  }

  private weaponImpact(target: Enemy | Boss, heavy: boolean, critical: boolean, color: string, contact?: WeaponContact): void {
    const s = this.state;
    const kind = heavy ? 'heavy' : critical ? 'critical' : 'hit';
    const x = target.x + target.w / 2, y = target.y + target.h / 2;
    if (!contact) {
      const boss = 'phase' in target;
      const stop = boss ? (heavy ? .065 : critical ? .045 : .025) : (heavy ? .07 : critical ? .055 : .035);
      const shake = boss ? (heavy ? 5 : critical ? 4 : 3) : (heavy ? 5.5 : critical ? 4.2 : 2.8);
      s.shake = Math.max(s.shake, shake);
      s.hitstop = Math.max(s.hitstop, stop);
      this.impact(x, y, kind, color);
      this.sound(kind);
      return;
    }

    const accent = contact.accent || heavy || critical;
    const { weapon, character } = contact;
    const weight = WEAPON_IMPACT_TIMING[weapon];
    // Hits on the same swing all draw contact marks. Crowds share a single pause and sound.
    if (s.time >= this.nextImpactBeat) {
      this.nextImpactBeat = s.time + (accent ? .09 : .06);
      const stop = weight[accent ? 1 : 0];
      s.shake = Math.max(s.shake, Math.min(6, stop * 75));
      s.hitstop = Math.max(s.hitstop, stop);
      this.sound(`${character}${accent ? 'Finisher' : 'Contact'}`);
    }
    this.impact(x, y, accent ? 'heavy' : 'hit', WEAPONS[weapon].color, { ...contact, accent });
  }

  private hitEnemy(e: Enemy, base: number, heavy = false, burn = false, contact?: WeaponContact): void {
    if (e.dead) return;
    const amount = burn ? base : this.damageAmount(base * enemyDamageMultiplier(e, this.state.hero)), critical = !burn && this.criticalHit;
    e.hp -= amount;
    if (!burn) {
    this.gainResonance(8 + (heavy ? 5 : 0));
    e.hurt = heavy ? .25 : .17;
    e.vx = (contact?.facing ?? this.state.hero.facing) * (heavy ? 310 : critical ? 220 : 155);
    if (heavy && e.kind !== 'bat') e.vy = -150;
    this.weaponImpact(e, heavy, critical, critical ? '#ffd779' : '#c8fff0', contact);
    this.burst(e.x + e.w / 2, e.y + e.h / 2, critical ? '#ffd779' : '#dcfff1', heavy ? 17 : 10, heavy ? 210 : 140);
    this.label(e.x + e.w / 2, e.y - 2, `${critical ? '暴击 ' : heavy ? '终结 ' : ''}${Math.round(amount * 10) / 10}`, critical ? '#ffd779' : heavy ? '#aaffea' : '#fff0ce');
    } else {
      this.label(e.x + e.w / 2, e.y - 2, `灼烧 ${Math.round(amount * 10) / 10}`, '#efb374');
      this.burst(e.x + e.w / 2, e.y + e.h - 8, '#e99559', 3, 45);
    }
    if (e.hp > 0) return;
    const s = this.state;
    const h = s.hero;
    e.dead = true;
    this.gainResonance(18);
    s.kills += 1;
    s.combo += 1;
    s.maxCombo = Math.max(s.maxCombo, s.combo);
    s.comboTimer = 4;
    this.sound('kill');
    this.burst(e.x + e.w / 2, e.y + e.h / 2, e.kind === 'bat' ? '#b7afff' : '#8cdec0', 18, 150);
    const loot = seededRandom(s.seed ^ Math.imul(e.id + 1, 0x85ebca6b));
    this.drop('xp', e.x + 7, e.y, 5);
    for (let i = 0; i < 2 + Number(loot() > .5); i++) this.drop('coin', e.x - 4 + i * 13, e.y + 12, 1);
    const heartChance = h.hp <= Math.ceil(h.maxHp / 2) ? .4 : .25;
    if (loot() < heartChance && h.hp < h.maxHp) this.drop('heart', e.x + 13, e.y - 12, 1);
    if (h.hp < h.maxHp && h.lifesteal > 0 && loot() < h.lifesteal) {
      h.hp = Math.min(h.maxHp, h.hp + 1);
      this.label(h.x, h.y - 18, '汲取 +1 ♥', '#d88976');
      this.burst(h.x + 14, h.y + 18, '#d88976', 12, 95);
    }
  }

  private hitBoss(base: number, heavy = false, healthScale = 1, bonusGuardDamage = 0, contact?: WeaponContact): void {
    const s = this.state, b = s.boss;
    if (!b || b.mode === 'dead' || b.mode === 'transition' || !b.active) return;
    const weakness = b.mode === 'stagger' ? (b.form === 2 ? 1.35 : 1.6) : b.exposed > 0 ? 1.45 : 1;
    const rawAmount = this.damageAmount(base) * weakness, critical = this.criticalHit;
    const darkArmor = b.form === 2 && b.guard > 0 && b.exposed <= 0 && b.mode !== 'stagger';
    const floor = b.form === 2 && b.phase === 2 ? b.maxHp / 2 : 0;
    const amount = Math.min(Math.max(0, b.hp - floor), rawAmount * (darkArmor ? .35 : 1) * healthScale);
    b.hp -= amount;
    this.gainResonance(5 + (heavy ? 3 : 0));
    b.hurt = .15;
    this.weaponImpact(b, heavy, critical, weakness > 1 ? '#b6fff0' : '#ffbe7d', contact);
    this.burst(b.x + b.w / 2, b.y + b.h / 2, weakness > 1 ? '#b6fff0' : '#ffbe7d', heavy ? 18 : 10, 170);
    this.label(b.x + b.w / 2, b.y, `${weakness > 1 ? '破绽 ' : critical ? '暴击 ' : ''}${Math.round(amount * 10) / 10}`, weakness > 1 ? '#b6fff0' : '#ffe1b0');
    if (floor > 0 && b.hp <= floor) {
      this.ascendBoss(b);
      return;
    }
    // Recover armor long enough to release one warned move. Powerful builds
    // keep their full health damage, but cannot lock every attack in stagger.
    if (b.mode !== 'stagger' && this.bossGuardRecovery <= 0) {
      b.guard = Math.max(0, b.guard - rawAmount * (heavy ? 1.8 : .8) - bonusGuardDamage);
      if (b.guard <= 0 && b.hp > 0) {
        b.mode = 'stagger'; b.timer = b.form === 2 ? .7 : 1.6; b.exposed = b.timer; b.vx = b.vy = 0; b.y = 448 - b.h;
        s.hitstop = .09; s.shake = 7;
        this.impact(b.x + b.w / 2, b.y + b.h / 2, 'break', '#adfff0');
        this.label(b.x + b.w / 2, b.y - 24, '护甲击破 · 全力输出！', '#adfff0');
        this.sound('guardBreak');
      }
    }
    if (b.hp <= 0) {
      if (b.form !== 2) {
        b.form = 2; b.phase = 2;
        b.maxHp = this.bossHealth(b.kind === 'warden', 2); b.hp = b.maxHp;
        b.mode = 'transition'; b.timer = BOSS_TRANSFORM_TIME;
        b.vx = b.vy = 0; b.y = 448 - b.h; b.exposed = 0;
        b.maxGuard = this.bossArmor(b.kind === 'warden', 2); b.guard = b.maxGuard; b.attackCount = 0; b.chain = 0;
        b.burnTime = b.burnTick = b.burnDamage = 0;
        s.projectiles = []; s.hitstop = 0; s.shake = 9; s.flash = .18;
        s.hero.invincible = Math.max(s.hero.invincible, BOSS_TRANSFORM_TIME + .4);
        s.announcement = b.kind === 'warden' ? '玄阙镇星王 · 王刃出鞘' : '封印崩解 · 玄烬魔君';
        s.announcementTimer = 1.15;
        this.impact(b.x + b.w / 2, b.y + b.h / 2, 'break', '#aa4260');
        this.burst(b.x + b.w / 2, b.y + b.h / 2, '#623247', 28, 140);
        this.sound('guardBreak');
        return;
      }
      b.mode = 'dead'; b.vx = b.vy = 0;
      s.kills += 1; s.roomCleared = true; s.roomsCleared = s.roomIndex + 1;
      this.burst(b.x + b.w / 2, b.y + b.h / 2, '#ffca78', 90, 300);
      s.shake = 12; s.flash = .8;
      if (s.coopPartySize !== undefined && s.roomsCleared < s.roomCount) {
        s.projectiles = s.projectiles.filter(projectile => projectile.owner !== 'enemy');
        s.announcement = '余烬已平 · 星门开启'; s.announcementTimer = 2.6;
        this.sound('portal');
      } else {
        s.roomsCleared = s.roomCount;
        this.finish(true);
      }
    }
  }

  private hurtHero(amount: number, sourceX: number, force = false, parryable = true): void {
    const s = this.state;
    const h = s.hero;
    if (s.phase !== 'playing') return;
    if (!force && parryable && h.guardTimer > 0 && (sourceX - h.x - h.w / 2) * h.facing >= -4) {
      h.guardTimer = 0;
      h.invincible = Math.max(h.invincible, .2);
      h.counterTimer = 1.6;
      this.gainResonance(16);
      this.gainBuffResonance('jadeParry', 4);
      this.sealPulse('bell');
      this.impact(h.x + 14 + h.facing * 22, h.y + 18, 'break', '#c1ffed');
      this.burst(h.x + 14, h.y + 18, '#c1ffed', 24, 200);
      this.label(h.x + 14, h.y - 28, '完美格挡 · 反击！', '#c1ffed');
      s.hitstop = Math.max(s.hitstop, .065);
      s.shake = 4;
      this.sound('guardBreak');
      const boss = s.boss;
      if (boss?.active && !['dead', 'transition', 'stagger'].includes(boss.mode)) {
        boss.guard = Math.max(0, boss.guard - 10);
        if (boss.guard === 0) {
          boss.mode = 'stagger'; boss.timer = boss.form === 2 ? .7 : 1.6; boss.exposed = boss.timer;
          boss.vx = boss.vy = 0; boss.y = 448 - boss.h;
          this.label(boss.x + boss.w / 2, boss.y - 20, '弹反破甲', '#c1ffed');
        } else if (boss.mode === 'charge') this.bossRecover(boss, .9);
      }
      return;
    }
    if (!force && h.invincible > 0) {
      if (h.dashTimer > .1 && h.perfectDodgeCooldown <= 0) {
        h.perfectDodgeCooldown = 1; h.counterTimer = 1.4;
        this.gainResonance(20);
        const afterimage = this.buffStacks('afterimage');
        if (afterimage) {
          h.dashCooldown = Math.max(0, h.dashCooldown - afterimage * .32);
          this.fireBuff('afterimage');
        }
        const signature = s.character && s.character !== 'traveller' ? COOP_CHARACTERS[s.character] : undefined;
        if (signature) h.dodgeCue = { x: h.x + 14, y: h.y + 18, facing: h.facing, life: .38 };
        else this.impact(h.x + 14, h.y + 18, 'break', '#9cefff');
        this.label(h.x + 14, h.y - 30, '完美闪避 · 下一击反击', signature?.color ?? '#9cefff');
        this.sound('perfectDodge');
      }
      return;
    }
    if (h.shield > 0) {
      h.shield -= 1;
      h.invincible = 1;
      this.burst(h.x + 14, h.y + 18, '#b7afff', 18, 160);
      this.label(h.x, h.y - 12, '月光守护', '#c2bdff');
      this.sound('hurt');
      return;
    }
    h.hp = Math.max(0, h.hp - amount);
    if (h.hp === 0) this.landingSealArmed = false;
    h.invincible = 1.3;
    h.vx = (h.x + 14 >= sourceX ? 1 : -1) * 230;
    h.vy = -230;
    h.dashTimer = 0;
    h.guardTimer = 0;
    this.variableJump = false;
    s.combo = 0; s.comboTimer = 0;
    s.shake = 7; s.flash = .3; s.hitstop = Math.max(s.hitstop, .055);
    this.sound('hurt');
    this.burst(h.x + 14, h.y + 20, '#ff9a93', 18, 160);
    if (h.hp <= 0) {
      if (!this.partyActor) this.finish(false);
      else {
        h.vx = h.vy = 0;
        h.attackTimer = h.dashTimer = 0;
        if (h.y + h.h > 470) { h.x = s.room.checkpoint.x; h.y = s.room.checkpoint.y; }
        this.label(h.x + 14, h.y - 18, '倒地 · 等候队友救援', '#f3bd9a');
      }
    }
  }

  private drop(kind: 'coin' | 'xp' | 'heart', x: number, y: number, value: number): void {
    this.state.pickups.push({ id: ++this.pickupId, kind, x, y, w: kind === 'xp' ? 11 : 14, h: kind === 'xp' ? 11 : 16,
      value, vy: -130, bob: this.visualRandom() * Math.PI * 2, collected: false });
  }

  private updatePickups(dt: number): void {
    const s = this.state;
    const h = s.hero;
    const jadeSpring = this.buffStacks('jadeSpring');
    for (const p of s.pickups) {
      if (p.collected) continue;
      if (!this.partyReplica) p.bob += dt * 2.5;
      if (!this.partyReplica && p.vy !== 0) {
        p.vy += 430 * dt;
        p.y += p.vy * dt;
        for (const platform of s.room.platforms) if (p.x + p.w > platform.x && p.x < platform.x + platform.w && p.y + p.h >= platform.y && p.y < platform.y + 14 && p.vy > 0) {
          p.y = platform.y - p.h - 5; p.vy = 0;
        }
        if (p.y > 550) { p.collected = true; continue; }
      }
      const dx = h.x + h.w / 2 - p.x - p.w / 2;
      const dy = h.y + h.h / 2 - p.y - p.h / 2;
      const distance = Math.hypot(dx, dy);
      const magnetRange = h.magnet + (s.synergies.includes('fireflies') ? 120 : 0);
      const radius = p.kind === 'xp' ? Math.max(150, magnetRange) : magnetRange;
      const canCollect = p.kind !== 'heart' || h.hp < h.maxHp || jadeSpring > 0;
      if (distance < radius && canCollect) {
        const speed = p.kind === 'xp' ? 400 : 320;
        p.x += dx / (distance || 1) * speed * dt;
        p.y += dy / (distance || 1) * speed * dt;
        p.vy = 0;
      }
      if (canCollect && (distance < 22 || overlap(p, h))) {
        p.collected = true;
        if (p.kind === 'coin') {
          const fortune = h.upgrades.filter(item => item === 'fortune').length;
          s.coins += p.value + fortune * 2;
          if (fortune > 0) this.gainResonance(fortune * 3);
          this.sound('coin');
          this.burst(p.x + 6, p.y + 6, '#ffdb80', 4, 65);
        } else if (p.kind === 'xp') {
          const breeze = h.upgrades.filter(id => id === 'breeze').length;
          if (breeze && h.dashCooldown > 0) {
            h.dashCooldown = Math.max(0, h.dashCooldown - .35 * breeze);
            this.burst(h.x + h.w / 2, h.y + h.h - 4, '#a1cbb4', 7, 80);
          }
          this.gainResonance(4);
          this.gainXp(p.value);
          this.burst(p.x + 6, p.y + 6, '#80e5d1', 4, 65);
        } else {
          if (h.hp < h.maxHp) {
            h.hp = Math.min(h.maxHp, h.hp + p.value);
            this.label(h.x, h.y - 15, '+1 ♥', '#ffb3bb');
          }
          this.gainBuffResonance('jadeSpring', 5);
          this.sound('coin');
        }
      }
    }
    s.pickups = s.pickups.filter(p => !p.collected);
  }

  private gainXp(amount: number): void {
    const h = this.state.hero;
    h.xp += amount;
    if (h.xp >= h.xpNeeded && this.state.phase === 'playing' && this.state.upgradeChoices.length === 0) this.offerUpgrade();
  }

  private offerUpgrade(): void {
    const s = this.state;
    const h = s.hero;
    h.xp -= h.xpNeeded;
    h.level += 1;
    h.xpNeeded += 5;
    const pool = UPGRADES.filter(item => !(s.modifier === 'iron' && item.id === 'vigor')
      && !(h.extraProjectiles >= 3 && item.id === 'multishot')
      && !(h.attackSpeed >= 2.8 && item.id === 'tempo')
      && !(h.speed >= 460 && item.id === 'stride')
      && !(h.lifesteal >= 1 && item.id === 'blood')
      && (!isBuffEffectKind(item.id) || this.buffStacks(item.id) < MAX_BUFF_STACKS));
    const random = seededRandom(s.seed ^ Math.imul(h.level, 0x45d9f3b));
    const choices: Upgrade[] = [];
    while (choices.length < 3 && pool.length) {
      const index = Math.floor(random() * pool.length);
      choices.push(pool.splice(index, 1)[0]);
    }
    // Once a player has a component, offer a matching component in later drafts.
    const complements: string[] = [];
    if (h.upgrades.includes('edge') && !h.upgrades.includes('tempo')) complements.push('tempo');
    if (h.upgrades.includes('tempo') && !h.upgrades.includes('edge')) complements.push('edge');
    if (h.upgrades.includes('multishot') && !h.upgrades.includes('magnet')) complements.push('magnet');
    if (h.upgrades.includes('magnet') && !h.upgrades.includes('multishot')) complements.push('multishot');
    if (h.upgrades.includes('vigor') && !h.upgrades.some(id => id === 'blood' || id === 'shield')) complements.push('shield');
    if (s.modifier !== 'iron' && h.upgrades.some(id => id === 'blood' || id === 'shield') && !h.upgrades.includes('vigor')) complements.push('vigor');
    if (complements.length && !choices.some(choice => complements.includes(choice.id))) {
      const matching = UPGRADES.find(item => item.id === complements[Math.floor(random() * complements.length)]);
      if (matching) choices[choices.length - 1] = matching;
    }
    s.upgradeChoices = choices;
    s.phase = 'upgrade';
    this.pendingGuard = 0;
    this.sound('upgrade');
  }

  private nextRoom(): void {
    const nextIndex = this.state.roomIndex + 1;
    if (nextIndex < this.state.roomCount) this.loadRoom(nextIndex);
  }

  forceCoopRoom(index: number): void {
    const s = this.state;
    if (s.coopPartySize === undefined || !Number.isInteger(index) || index <= s.roomIndex || index >= s.roomCount) return;
    s.roomsCleared = Math.max(s.roomsCleared, index);
    this.loadRoom(index);
  }

  private loadRoom(nextIndex: number): void {
    const s = this.state;
    const content = createEncounter(s.seed, nextIndex, s.coopPartySize);
    s.roomIndex = nextIndex;
    s.room = content.room;
    s.enemies = content.enemies;
    s.pickups = content.pickups;
    s.projectiles = []; s.hitstop = 0; s.impacts = [];
    this.awakenedDiscs.clear();
    this.dashHits.clear();
    this.bossGuardRecovery = 0;
    this.pendingGuard = 0;
    s.particles = [];
    s.floatingTexts = [];
    s.hero.x = s.room.spawn.x; s.hero.y = s.room.spawn.y;
    s.hero.vx = 0; s.hero.vy = 0; s.hero.jumps = 0;
    s.hero.grounded = false; s.hero.dashTimer = 0; s.hero.invincible = 1.2;
    delete s.hero.dodgeCue;
    s.hero.guardTimer = s.hero.guardCooldown = 0;
    s.hero.buffEffects = undefined;
    this.variableJump = false;
    this.landingSealArmed = false;
    if (s.synergies.includes('guardian')) s.hero.shield += 1;
    if (s.hero.upgrades.includes('shield')) s.hero.shield += 1;
    s.cameraX = 0; s.roomCleared = false;
    s.announcement = s.room.name; s.announcementTimer = 2.6; s.transition = 1;
    s.boss = null;
    if (s.room.isBoss) {
      const warden = nextIndex === COOP_ROOM_COUNT - 1;
      const hp = this.bossHealth(warden, 1);
      const guard = this.bossArmor(warden, 1);
      const w = warden ? 124 : 104, h = warden ? 122 : 118;
      s.boss = { kind: warden ? 'warden' : undefined, x: 1210, y: 448 - h, w, h, hp, maxHp: hp, phase: 1,
        mode: 'idle', timer: 1.1, vx: 0, vy: 0, facing: -1, hurt: 0, attackCount: 0, active: false,
        intent: 'charge', targetX: 700, chain: 0, guard, maxGuard: guard, exposed: 0, form: 1 };
    }
    this.sound('portal');
  }

  private bossHealth(warden: boolean, form: 1 | 2): number {
    const base = warden ? wardenHealth(form) : form === 1 ? BOSS_MAX_HP : BOSS_AWAKENED_HP;
    const size = this.state.coopPartySize;
    return size === undefined ? base : Math.round(base * cooperativeDifficulty(size).bossHealth);
  }

  private bossArmor(warden: boolean, phase: 1 | 2 | 3): number {
    const base = warden ? wardenGuard(phase) : BOSS_GUARD[phase];
    const size = this.state.coopPartySize;
    return size === undefined ? base : Math.round(base * cooperativeDifficulty(size).armor);
  }

  private finish(won: boolean): void {
    const s = this.state;
    if (s.result) return;
    s.phase = won ? 'victory' : 'gameover';
    const result: GameResult = {
      seed: s.seed, modifier: s.modifier, weapon: this.weaponAtStart, won,
      ...(s.character ? { character: s.character } : {}),
      time: Math.round(s.time * 100) / 100,
      score: Math.max(0, Math.round(s.roomsCleared * 1200 + s.kills * 200 + s.coins * 25 + (won ? 5000 : 0) - s.time * 8 - s.deaths * 200)),
      coins: s.coins, kills: s.kills, level: s.hero.level, deaths: s.deaths,
      roomsCleared: s.roomsCleared, maxCombo: s.maxCombo, upgrades: [...s.hero.upgrades],
      overdriveCount: s.overdriveCount, synergies: [...s.synergies],
    };
    s.result = result;
    this.sound(won ? 'win' : 'lose');
  }

  private updateEffects(dt: number): void {
    const s = this.state;
    s.shake = Math.max(0, s.shake - dt * 20);
    s.flash = Math.max(0, s.flash - dt * 2.5);
    for (const impact of s.impacts) impact.life -= dt;
    s.impacts = s.impacts.filter(impact => impact.life > 0);
    if (s.hero.buffEffects?.length) {
      for (const effect of s.hero.buffEffects) effect.life -= dt;
      s.hero.buffEffects = s.hero.buffEffects.filter(effect => effect.life > 0);
    }
    for (const p of s.particles) {
      p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt;
      p.vy += (p.gravity ?? 220) * dt;
    }
    s.particles = s.particles.filter(p => p.life > 0);
    for (const text of s.floatingTexts) { text.life -= dt; text.y -= dt * 30; }
    s.floatingTexts = s.floatingTexts.filter(text => text.life > 0);
  }

  private sealPulse(id: 'frost' | 'bell' | 'landingSeal'): void {
    const { hero, enemies, boss, particles } = this.state;
    const stacks = id === 'landingSeal' ? this.buffStacks(id) : hero.upgrades.filter(seal => seal === id).length;
    if (!stacks) return;
    const frost = id === 'frost', radius = id === 'landingSeal' ? 96 : frost ? 88 : 140;
    const x = hero.x + hero.w / 2, y = hero.y + (id === 'bell' ? hero.h / 2 : hero.h);
    const reaches = (r: Rect) => Math.hypot(clamp(x, r.x, r.x + r.w) - x, clamp(y, r.y, r.y + r.h) - y) <= radius;
    const damage = (frost ? 2 : 3) * stacks;
    for (const enemy of enemies) if (!enemy.dead && reaches(enemy)) this.hitEnemy(enemy, damage);
    if (boss?.active && reaches(boss)) this.hitBoss(damage);
    if (id === 'landingSeal') {
      this.fireBuff(id);
      return;
    }
    const color = frost ? '#b9d9d4' : '#d8bf80', life = frost ? .33 : .42;
    for (let i = 0; i < 36; i++) {
      const theta = Math.PI * 2 * i / 36;
      const speed = radius / life * (frost ? .6 + .4 * Math.cos(theta * 3) ** 2 : 1);
      particles.push({ x, y, vx: Math.cos(theta) * speed, vy: Math.sin(theta) * speed, gravity: 0,
        life, maxLife: life, color: i % 3 ? color : '#f0e8c6', size: i % 3 ? 2 : 3 });
    }
    this.label(x, y - 19, frost ? '踏雪生梅' : '金钟回响', color);
  }

  private impact(x: number, y: number, kind: 'hit' | 'critical' | 'heavy' | 'break', color: string, contact?: WeaponContact): void {
    const life = kind === 'break' ? .42 : kind === 'heavy' ? .3 : .22;
    this.state.impacts.push({ x, y, ...(contact && {contact}), kind, color, life, maxLife: life, size: kind === 'break' ? 84 : kind === 'heavy' ? 52 : kind === 'critical' ? 38 : 25, angle: this.state.hero.facing < 0 ? Math.PI : 0 });
    if (this.state.impacts.length > 28) this.state.impacts.shift();
  }

  private burst(x: number, y: number, color: string, count: number, speed: number): void {
    const particles = this.state.particles;
    for (let i = 0; i < count; i++) {
      const angle = this.visualRandom() * Math.PI * 2;
      const velocity = speed * (.25 + this.visualRandom() * .75);
      const life = .25 + this.visualRandom() * .45;
      particles.push({ x, y, vx: Math.cos(angle) * velocity, vy: Math.sin(angle) * velocity,
        life, maxLife: life, size: 2 + Math.floor(this.visualRandom() * 3), color, gravity: 170 });
    }
    if (particles.length > 350) particles.splice(0, particles.length - 350);
  }

  private label(x: number, y: number, text: string, color: string): void {
    this.state.floatingTexts.push({ x, y, text, color, life: .95, maxLife: .95 });
  }

  private sound(name: SoundName): void { this.callbacks.sound?.(name); }
}

export { UPGRADES, SYNERGIES };
