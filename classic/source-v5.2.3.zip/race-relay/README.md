# 星跃远征双人竞速服务

独立的 Cloudflare Worker + D1 HTTPS 房间服务。游戏仍由现有 GitHub Pages 提供；此服务负责两名玩家、同图配置、统一服务端倒计时、最新幽灵快照和本场完成时间。无需局域网、浏览器 WebRTC 或本机常驻隧道。

`POST /api/race` 接受 create / join / ready / state / leave / reset。房间邀请只携带随机 roomId；每个座位使用独立 token。客户端每 200–250ms 上传自己的快照并读取对方快照，以服务器时间校正倒计时，绘制层插值。最多两人，旧 seq 不覆盖新快照，Boss 完成标记必须来自第八关。本服务不写游戏共享排行榜。

双方 ready 后在同一 D1 事务派生唯一 startAt；取消就绪会撤回尚未开始的倒计时。房主可在结束后 reset 再赛。房间两小时过期，断线可用本机 clientId 重连。代码和本地 SQLite 测试一起保留。

每个 state POST 还需携带当前 `epoch`。重赛时服务器增加 epoch；旧 epoch 的迟到状态只取得最新房间快照，不写入新轮，避免旧完成帧阻塞重赛同步。同 epoch 的开赛前完成帧仍会被拒绝。

构建：`npm run build`。检查：`npm test`。数据库迁移随 Sites 发布。
