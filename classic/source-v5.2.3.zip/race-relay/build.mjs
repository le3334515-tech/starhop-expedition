import { mkdir, copyFile, readFile } from 'node:fs/promises';
await mkdir('dist/server',{recursive:true}); await mkdir('dist/.openai',{recursive:true});
await copyFile('worker/index.js','dist/server/index.js');
await copyFile('.openai/hosting.json','dist/.openai/hosting.json');
JSON.parse(await readFile('.openai/hosting.json','utf8'));
console.log('Race Worker ESM built.');
