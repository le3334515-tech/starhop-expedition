CREATE TABLE race_rooms (
 id TEXT PRIMARY KEY NOT NULL,
 config TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 expires_at INTEGER NOT NULL,
 start_at INTEGER,
 closed_at INTEGER,
 epoch INTEGER NOT NULL DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE race_players (
 room_id TEXT NOT NULL REFERENCES race_rooms(id) ON DELETE CASCADE,
 id TEXT NOT NULL,
 client_id TEXT NOT NULL,
 token TEXT NOT NULL,
 name TEXT NOT NULL,
 ready_at INTEGER,
 last_seen INTEGER NOT NULL,
 frame TEXT,
 last_seq INTEGER NOT NULL DEFAULT -1,
 finished_at INTEGER,
 left_at INTEGER,
 PRIMARY KEY (room_id,id),
 UNIQUE (room_id,client_id)
);
--> statement-breakpoint
CREATE INDEX race_expiration ON race_rooms(expires_at);
