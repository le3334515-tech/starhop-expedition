import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import worker from '../worker/index.js';

function database(beforeWrite,beforeBatch){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(readFileSync(new URL('../drizzle/0000_race_rooms.sql',import.meta.url),'utf8').replaceAll('--> statement-breakpoint',''));
 const prepare=sql=>({values:[],bind(...values){this.values=values;return this;},async run(){await beforeWrite?.(sql);const result=sqlite.prepare(sql).run(...this.values);return{success:true,meta:result};},async all(){return{success:true,results:sqlite.prepare(sql).all(...this.values)};},sql});
 return{prepare,async batch(statements){await beforeBatch?.(statements.map(statement=>statement.sql));sqlite.exec('BEGIN');try{const out=[];for(const s of statements){if(/^\s*SELECT/i.test(s.sql))out.push(await s.all());else{await s.run();out.push({success:true,results:[]});}}sqlite.exec('COMMIT');return out;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
}
test('two public clients exchange snapshots and use one server-clock countdown; tokens, race order and reset are enforced',async()=>{
 const DB=database();const realNow=Date.now;let now=100000;Date.now=()=>now;
 const call=async body=>{const response=await worker.fetch(new Request('https://race.example/api/race',{method:'POST',body:JSON.stringify(body)}),{DB});return{status:response.status,...await response.json()};};
 try{
  const created=await call({action:'create',clientId:'host-client-1',name:'房主',config:{seed:42,modifier:'standard',weapon:'ember'}});
  assert.equal(created.status,200);assert.equal(created.selfId,'host');assert.equal(created.room.status,'waiting');
  assert.equal(created.room.host.character,'traveller');
  const roomId=created.room.id,host=created.token;
  const joined=await call({action:'join',roomId,clientId:'guest-client-1',name:'好友'});assert.equal(joined.status,200);const guest=joined.token;
  assert.equal((await call({action:'join',roomId,clientId:'third-client-1'})).status,409);
  assert.equal((await call({action:'join',roomId,clientId:'host-client-1'})).token,host);
  assert.equal((await call({action:'state',roomId,token:'wrong'})).status,401);
  assert.equal((await call({action:'ready',roomId,token:host})).room.startAt,null);
  now+=400;const ready=await call({action:'ready',roomId,token:guest});assert.equal(ready.room.startAt,now+5000);assert.equal(ready.room.status,'countdown');
  assert.equal((await call({action:'state',roomId,token:host})).room.startAt,ready.room.startAt);
  const cancelled=await call({action:'ready',roomId,token:guest,ready:false});assert.equal(cancelled.room.startAt,null);
  const again=await call({action:'ready',roomId,token:guest});const start=again.room.startAt;
  assert.equal((await call({action:'state',roomId,token:host,frame:{seq:1,roomIndex:7,finished:true,won:true}})).status,409);
  now=start+30;
  assert.equal((await call({action:'ready',roomId,token:host})).status,409);
  let frame={seq:2,roomIndex:0,x:310,y:412,phase:'playing',animation:.4,weapon:'ember'};
  await call({action:'state',roomId,token:host,frame});
  const other=await call({action:'state',roomId,token:guest,frame:{...frame,seq:1,x:420,weapon:'disc'}});
  assert.equal(other.room.host.frame.x,310);assert.equal(other.room.host.frame.phase,'playing');assert.equal(other.room.guest.frame.x,420);
  const stale=await call({action:'state',roomId,token:host,frame:{...frame,seq:1,x:1}});assert.equal(stale.room.host.frame.x,310);
  assert.equal((await call({action:'reset',roomId,token:host})).status,409);
  assert.equal((await call({action:'state',roomId,token:host,frame:{...frame,seq:3,roomIndex:1}})).status,200);
  assert.equal((await call({action:'state',roomId,token:host,frame:{...frame,seq:4,roomIndex:0}})).status,409);
  now+=20000;await call({action:'state',roomId,token:host,frame:{...frame,seq:5,roomIndex:7,finished:true,won:true}});
  now+=200;const finished=await call({action:'state',roomId,token:guest,frame:{...frame,seq:5,roomIndex:7,finished:true,won:true}});
  assert.equal(finished.room.status,'finished');assert.equal(finished.room.guest.finishedAt-finished.room.host.finishedAt,200);
  const reset=await call({action:'reset',roomId,token:host});assert.equal(reset.room.startAt,null);assert.equal(reset.room.epoch,1);assert.equal(reset.room.host.frame,null);
  const lateFinish=await call({action:'state',roomId,token:guest,epoch:0,frame:{...frame,seq:99,roomIndex:7,finished:true,won:true}});
  assert.equal(lateFinish.status,200);assert.equal(lateFinish.room.epoch,1);
  assert.equal(lateFinish.room.guest.frame,null);assert.equal(lateFinish.room.guest.finishedAt,null);
  assert.equal(lateFinish.room.startAt,null);
  assert.equal((await call({action:'state',roomId,token:guest,epoch:1,frame:{...frame,seq:1,roomIndex:7,finished:true,won:true}})).status,409);
  await call({action:'ready',roomId,token:host});
  const nextReady=await call({action:'ready',roomId,token:guest});now=nextReady.room.startAt+20;
  const newRun=await call({action:'state',roomId,token:guest,epoch:1,frame:{...frame,seq:1,roomIndex:0,x:140}});
  assert.equal(newRun.status,200);assert.equal(newRun.room.guest.frame.x,140);assert.equal(newRun.room.guest.frame.roomIndex,0);
  const oldRun=await call({action:'state',roomId,token:guest,epoch:0,frame:{...frame,seq:100,roomIndex:7,finished:true,won:true}});
  assert.equal(oldRun.room.guest.frame.x,140);assert.equal(oldRun.room.guest.finishedAt,null);
  await call({action:'leave',roomId,token:guest});await call({action:'leave',roomId,token:host});
  const freshRound=await call({action:'reset',roomId,token:host});assert.equal(freshRound.room.epoch,2);
  const left=await call({action:'leave',roomId,token:guest});assert.equal(left.room.guest,null);assert.equal(left.room.host.readyAt,null);
  const replacement=await call({action:'join',roomId,clientId:'new-guest-client'});assert.equal(replacement.status,200);
  now+=7200001;assert.equal((await call({action:'state',roomId,token:host})).status,410);
 }finally{Date.now=realNow;}
});

test('stores a seat character in an existing-schema room and validates all its weapons',async()=>{
 const DB=database(), realNow=Date.now;let now=200000;Date.now=()=>now;
 const call=async body=>{
  const response=await worker.fetch(new Request('https://race.example/api/race',{method:'POST',body:JSON.stringify(body)}),{DB});
  return {status:response.status,...await response.json()};
 };
 try{
  const config={seed:42,modifier:'standard',weapon:'disc'};
  const create=await call({action:'create',clientId:'host-client-1',config,character:'wheel'});
  const roomId=create.room.id,host=create.token;
  assert.equal(create.room.characterSelection,true);
  assert.deepEqual(create.room.config,config);
  assert.equal(create.room.host.character,'wheel');
  const join=await call({action:'join',roomId,clientId:'guest-client-1'});
  assert.equal(join.room.guest.character,'traveller');
  const guest=join.token;
  assert.equal((await call({action:'character',roomId,token:guest,character:'unknown'})).status,400);
  assert.equal((await call({action:'character',roomId,token:guest,character:'wheel'})).room.guest.character,'wheel');
  assert.equal((await call({action:'leave',roomId,token:guest})).room.guest,null);
  const replacement=await call({action:'join',roomId,clientId:'guest-client-2'});
  assert.equal(replacement.room.guest.character,'traveller');
  assert.equal((await call({action:'character',roomId,token:replacement.token,character:'spear'})).room.guest.character,'spear');
  await call({action:'ready',roomId,token:host});
  assert.equal((await call({action:'character',roomId,token:host,character:null})).status,409);
  now+=400;
  const ready=await call({action:'ready',roomId,token:replacement.token});
  assert.equal(ready.room.startAt,now+5000);
  now=ready.room.startAt+10;
  assert.equal((await call({action:'character',roomId,token:replacement.token,character:'wheel'})).status,409);
  const frame={seq:1,roomIndex:0,weapon:'jadeNeedle',character:'monk'};
  const playing=await call({action:'state',roomId,token:host,frame});
  assert.equal(playing.room.host.frame.character,'wheel');
  assert.equal(playing.room.host.frame.weapon,'jadeNeedle');
  const swapped=await call({action:'state',roomId,token:host,frame:{...frame,seq:2,weapon:'silkFan'}});
  assert.equal(swapped.room.host.frame.weapon,'silkFan');
  const wrong=await call({action:'state',roomId,token:host,frame:{...frame,seq:3,weapon:'halberd'}});
  assert.equal(wrong.room.host.frame.weapon,'fan');
  const spear=await call({action:'state',roomId,token:replacement.token,frame:{...frame,weapon:'halberd'}});
  assert.equal(spear.room.guest.frame.character,'spear');
  assert.equal(spear.room.guest.frame.weapon,'halberd');
 }finally{Date.now=realNow;}
});

test('verifies rules before assigning a seat and still accepts two legacy peers', async () => {
 const DB = database();
 const call = async body => {
  const response = await worker.fetch(new Request('https://race.example/api/race', {method:'POST',body:JSON.stringify(body)}), {DB});
  return {status:response.status,...await response.json()};
 };
 const config = {seed:42,modifier:'standard',weapon:'blade'};
 const ruleset = 'guardians-v2';
 const fresh = await call({action:'create',clientId:'new-host-client',config,ruleset});
 assert.equal(fresh.room.ruleset,ruleset);
 assert.deepEqual(fresh.room.config,config);
 const join = {action:'join',roomId:fresh.room.id,clientId:'guest-client'};
 const absent = await call(join);
 assert.equal(absent.status,409); assert.equal(absent.error,'ruleset-mismatch');
 assert.equal((await call({...join,ruleset:'guardians-v3'})).status,409);
 assert.equal((await call({...join,ruleset})).room.guest.id,'guest');
 const old = await call({action:'create',clientId:'old-host-client',config});
 assert.equal(old.room.ruleset,undefined);
 assert.equal((await call({...join,roomId:old.room.id,ruleset})).error,'ruleset-mismatch');
 assert.equal((await call({...join,roomId:old.room.id})).status,200);
});

test('an in-flight duplicate of the final frame cannot write a finished result into a rematch', async () => {
 let pauseNextWrite = false;
 let markPaused;
 const paused = new Promise(resolve => { markPaused = resolve; });
 let releaseWrite;
 const continueWrite = new Promise(resolve => { releaseWrite = resolve; });
 const DB = database(async sql => {
  if (pauseNextWrite && sql.startsWith('UPDATE race_players SET frame=')) {
   pauseNextWrite = false;
   markPaused();
   await continueWrite;
  }
 });
 const realNow = Date.now;
 let now = 200000;
 Date.now = () => now;
 const call = async body => {
  const response = await worker.fetch(new Request('https://race.example/api/race', {method:'POST',body:JSON.stringify(body)}), {DB});
  const payload = await response.json();
  assert.equal(response.status,200,JSON.stringify(payload));
  return payload;
 };
 try {
  const created = await call({action:'create',clientId:'host-client',config:{seed:42,modifier:'standard',weapon:'blade'}});
  const roomId = created.room.id;
  const guest = await call({action:'join',roomId,clientId:'guest-client'});
  await call({action:'ready',roomId,token:created.token});
  const ready = await call({action:'ready',roomId,token:guest.token});
  now = ready.room.startAt+200;
  const frame = {seq:21,roomIndex:7,finished:true,won:true,weapon:'disc'};
  const finish = token => call({action:'state',roomId,token,epoch:0,frame});
  await finish(created.token);
  pauseNextWrite = true;
  const oldWrite = finish(guest.token);
  await paused;
  assert.equal((await finish(guest.token)).room.status,'finished');
  assert.equal((await call({action:'reset',roomId,token:created.token})).room.epoch,1);
  releaseWrite();
  const delayed = await oldWrite;
  assert.equal(delayed.room.epoch,1);
  assert.equal(delayed.room.guest.frame,null);
  assert.equal(delayed.room.guest.finishedAt,null);
 } finally {
  releaseWrite();
  Date.now = realNow;
 }
});

test('a delayed duplicate reset does not erase the next round countdown or readiness', async () => {
 let pauseNextReset = false, markPaused, releaseReset;
 const paused = new Promise(resolve => { markPaused = resolve; });
 const resume = new Promise(resolve => { releaseReset = resolve; });
 const DB = database(undefined, async queries => {
  if (pauseNextReset && queries.some(sql => sql.includes('epoch=epoch+1'))) {
   pauseNextReset = false;
   markPaused();
   await resume;
  }
 });
 const realNow = Date.now;
 let now = 200000;
 Date.now = () => now;
 const call = async body => {
  const response = await worker.fetch(new Request('https://race.example/api/race', {method:'POST',body:JSON.stringify(body)}), {DB});
  const payload = await response.json();
  assert.equal(response.status,200,JSON.stringify(payload));
  return payload;
 };
 try {
  const host = await call({action:'create',clientId:'host-client',config:{seed:42,modifier:'standard',weapon:'blade'}});
  const roomId = host.room.id;
  const guest = await call({action:'join',roomId,clientId:'guest-client'});
  const ready = token => call({action:'ready',roomId,token});
  await ready(host.token);
  now = (await ready(guest.token)).room.startAt + 20;
  const frame = {seq:5,roomIndex:7,finished:true,won:true,weapon:'blade'};
  await call({action:'state',roomId,token:host.token,epoch:0,frame});
  await call({action:'state',roomId,token:guest.token,epoch:0,frame});
  const reset = () => call({action:'reset',roomId,token:host.token,epoch:0});
  pauseNextReset = true;
  const delayedReset = reset();
  await paused;
  assert.equal((await reset()).room.epoch,1);
  await ready(host.token);
  const next = (await ready(guest.token)).room;
  assert.ok(next.startAt);
  releaseReset();
  const unchanged = (await delayedReset).room;
  assert.equal(unchanged.epoch,1);
  assert.equal(unchanged.startAt,next.startAt);
  assert.equal(unchanged.host.readyAt,next.host.readyAt);
  assert.equal(unchanged.guest.readyAt,next.guest.readyAt);
  assert.equal((await reset()).room.startAt,next.startAt);
 } finally {
  releaseReset();
  Date.now = realNow;
 }
});
