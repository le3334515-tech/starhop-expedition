const TTL=2*60*60*1000;
const MODES=new Set(['standard','moon','haste','iron']);
const WEAPONS=new Set(['blade','ember','disc']);
const CHARACTER_WEAPONS=new Map([
 ['blade',['blade','willowSword','swallowDart']],
 ['staff',['ember','frostStaff','moonMirror']],
 ['wheel',['fan','jadeNeedle','silkFan']],
 ['spear',['spear','reedJavelin','halberd']],
 ['traveller',['blade','ember','disc']],
 ['monk',['fist','ironGauntlet','prayerBeads']],
]);
const PHASES=new Set(['menu','playing','paused','upgrade','victory','gameover']);
const cors={ 'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type','Access-Control-Max-Age':'86400','Cache-Control':'no-store' };
class ApiError extends Error { constructor(status,error,message){super(message);this.status=status;this.code=error;} }
const fail=(status,error,message)=>{throw new ApiError(status,error,message);};
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{...cors,'Content-Type':'application/json; charset=utf-8'}});
const random=bytes=>{const a=new Uint8Array(bytes);crypto.getRandomValues(a);return btoa(String.fromCharCode(...a)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');};
const cleanName=value=>Array.from(String(value??'星际旅人').replace(/[\u0000-\u001f\u007f<>]/g,'').trim()).slice(0,16).join('')||'星际旅人';
const finite=(value,min,max)=>typeof value==='number'&&Number.isFinite(value)&&value>=min&&value<=max;
function configOf(config){
 if(!config||!Number.isInteger(config.seed)||!finite(config.seed,0,0xffffffff)||!MODES.has(config.modifier)||!WEAPONS.has(config.weapon))fail(400,'invalid-config','远征配置无效。');
 return{seed:config.seed,modifier:config.modifier,weapon:config.weapon};
}
function characterOf(value){
 if(value==null)return null;
 if(CHARACTER_WEAPONS.has(value))return value;
 fail(400,'invalid-character','竞速角色无效。');
}
export function frameOf(frame,character=null){
 if(!frame||!Number.isInteger(frame.seq)||!finite(frame.seq,0,1e10)||!Number.isInteger(frame.roomIndex)||!finite(frame.roomIndex,0,7))fail(400,'invalid-frame','竞速进度无效。');
 const out={seq:frame.seq,roomIndex:frame.roomIndex};
 for(const [key,min,max]of[['x',-300,20000],['y',-2000,2000],['vx',-3000,3000],['vy',-3000,3000],['attackTimer',0,3],['animation',0,1e9],['hp',0,1000],['maxHp',1,1000],['level',1,10000],['progress',0,1],['elapsed',0,7200]]){
  if(frame[key]!==undefined){if(!finite(frame[key],min,max))fail(400,'invalid-frame',`角色${key}无效。`);out[key]=frame[key];}
 }
 out.facing=frame.facing===-1?-1:1;out.grounded=Boolean(frame.grounded);
 const loadout=CHARACTER_WEAPONS.get(character);
 if(loadout){out.character=character;out.weapon=loadout.includes(frame.weapon)?frame.weapon:loadout[0];}
 else out.weapon=WEAPONS.has(frame.weapon)?frame.weapon:'blade';
 out.attackStep=[1,2,3].includes(frame.attackStep)?frame.attackStep:0;
 out.phase=PHASES.has(frame.phase)?frame.phase:'playing';out.finished=frame.finished===true;out.won=frame.won===true;
 if(out.won&&(!out.finished||out.roomIndex!==7))fail(400,'invalid-finish','须完成最终关卡才可登记通关。');
 return out;
}
function playerView(p,character){return p?{id:p.id,name:p.name,character:CHARACTER_WEAPONS.has(character)?character:null,readyAt:p.ready_at,lastSeen:p.last_seen,frame:p.frame?JSON.parse(p.frame):null,finishedAt:p.finished_at,leftAt:p.left_at}:null;}
async function roomState(db,id){
 const results=await db.batch([db.prepare('SELECT * FROM race_rooms WHERE id=?').bind(id),db.prepare('SELECT * FROM race_players WHERE room_id=?').bind(id)]);
 const room=results[0].results[0]; if(!room)fail(404,'room-not-found','这个竞速房间不存在或已过期。');
 const now=Date.now();if(room.expires_at<now||room.closed_at)fail(410,'room-expired','房间已关闭，请重新发起竞速。');
 const players=results[1].results; const host=players.find(p=>p.id==='host'),guest=players.find(p=>p.id==='guest');
 let status=!room.start_at?'waiting':now<room.start_at?'countdown':'racing';
 if(room.start_at&&host?.finished_at&&guest?.finished_at)status='finished';
 const {characters,ruleset,...config}=JSON.parse(room.config);
 return{raw:room,players,view:{id,config,...(ruleset?{ruleset}:{}),characterSelection:true,createdAt:room.created_at,expiresAt:room.expires_at,epoch:room.epoch,startAt:room.start_at,status,host:playerView(host,characters?.host),guest:playerView(guest,characters?.guest)}};
}
function rulesetOf(value){
 if(value===undefined)return undefined;
 if(typeof value!=='string'||!/^[a-z0-9-]{1,32}$/.test(value))fail(400,'invalid-ruleset','竞速规则版本无效。');
 return value;
}
function clientIdOf(id){if(typeof id!=='string'||!/^[a-zA-Z0-9_-]{8,100}$/.test(id))fail(400,'invalid-client','请刷新页面后重新加入。');return id;}
function authOf(state,token){const p=state.players.find(p=>p.token===token);if(!p)fail(401,'invalid-token','房间凭证失效，请重新加入。');return p;}
async function operate(db,body){
 const now=Date.now(),action=body.action;
 if(action==='create'){
  const id=random(12),token=random(24),clientId=clientIdOf(body.clientId),config=configOf(body.config);
  const character=characterOf(body.character)??'traveller';
  const ruleset=rulesetOf(body.ruleset);
  const storedConfig={...config,...(ruleset?{ruleset}:{}),characters:{host:character}};
  await db.batch([
   db.prepare('DELETE FROM race_players WHERE room_id IN (SELECT id FROM race_rooms WHERE expires_at<?)').bind(now),
   db.prepare('DELETE FROM race_rooms WHERE expires_at<?').bind(now),
   db.prepare('INSERT INTO race_rooms (id,config,created_at,expires_at) VALUES (?,?,?,?)').bind(id,JSON.stringify(storedConfig),now,now+TTL),
   db.prepare('INSERT INTO race_players (room_id,id,client_id,token,name,last_seen) VALUES (?,\'host\',?,?,?,?)').bind(id,clientId,token,cleanName(body.name),now)
  ]);
  return{ok:true,serverNow:Date.now(),selfId:'host',token,room:(await roomState(db,id)).view};
 }
 const id=String(body.roomId??''); if(!/^[A-Za-z0-9_-]{16}$/.test(id))fail(400,'invalid-room','房间编号不完整。');
 let state=await roomState(db,id);
 if(action==='join'){
  if(rulesetOf(body.ruleset)!==state.view.ruleset)fail(409,'ruleset-mismatch','这份邀请使用不同版本的竞速规则。请双方刷新到同一版本，再由房主重新发起。');
  const clientId=clientIdOf(body.clientId);
  const existing=state.players.find(p=>p.client_id===clientId);
  if(existing){await db.prepare('UPDATE race_players SET last_seen=?,left_at=NULL WHERE room_id=? AND id=?').bind(now,id,existing.id).run();return{ok:true,serverNow:Date.now(),selfId:existing.id,token:existing.token,room:(await roomState(db,id)).view};}
  if(state.raw.start_at)fail(409,'race-started','这场竞速已经开始。');
  if(state.players.some(p=>p.id==='guest'))fail(409,'room-full','房间已有两名旅人。');
  const token=random(24);
  // The primary key is the final arbiter when two invitees join concurrently.
  try{await db.batch([
   db.prepare('INSERT INTO race_players (room_id,id,client_id,token,name,last_seen) VALUES (?,\'guest\',?,?,?,?)').bind(id,clientId,token,cleanName(body.name),now),
   db.prepare("UPDATE race_rooms SET config=json_set(config,'$.characters.guest','traveller') WHERE id=?").bind(id)
  ]);}
  catch{fail(409,'room-full','房间已有两名旅人。');}
  return{ok:true,serverNow:Date.now(),selfId:'guest',token,room:(await roomState(db,id)).view};
 }
 const p=authOf(state,body.token);
 // A rematch resets seq/progress. Delayed frames from the prior run must be
 // read-only, including finished frames, so the peer can learn the new epoch
 // instead of getting trapped behind a race-not-started response forever.
 if(action==='state'&&(Number.isInteger(body.epoch)?body.epoch:0)!==state.raw.epoch){
  return{ok:true,serverNow:Date.now(),selfId:p.id,room:state.view};
 }
 if(action==='character'){
  if(!Object.hasOwn(body,'character'))fail(400,'invalid-character','竞速角色无效。');
  const character=characterOf(body.character);
  // Existing room rows can gain per-seat selections without a schema migration.
  const update=await db.prepare(`UPDATE race_rooms SET config=json_set(config, ?, ?) WHERE id=? AND start_at IS NULL
   AND EXISTS (SELECT 1 FROM race_players WHERE room_id=? AND id=? AND ready_at IS NULL)`)
   .bind('$.characters.'+p.id,character,id,id,p.id).run();
  if(!update.meta.changes)fail(409,'character-locked','请取消准备后再更换角色。');
 }else if(action==='ready'){
  if(state.raw.start_at&&now>=state.raw.start_at)fail(409,'race-started','竞速已经开始。');
  if(body.ready===false){await db.batch([db.prepare('UPDATE race_players SET ready_at=NULL,last_seen=? WHERE room_id=? AND id=?').bind(now,id,p.id),db.prepare('UPDATE race_rooms SET start_at=NULL WHERE id=?').bind(id)]);}
  else{
   await db.batch([
    db.prepare('UPDATE race_players SET ready_at=COALESCE(ready_at,?),last_seen=?,left_at=NULL WHERE room_id=? AND id=?').bind(now,now,id,p.id),
    db.prepare(`UPDATE race_rooms SET start_at=(SELECT MAX(ready_at)+5000 FROM race_players WHERE room_id=?) WHERE id=? AND start_at IS NULL AND (SELECT COUNT(*) FROM race_players WHERE room_id=? AND ready_at IS NOT NULL AND left_at IS NULL)=2`).bind(id,id,id)
   ]);
  }
 }else if(action==='state'){
  // A reset may commit after roomState() above. Guard the actual write as well.
  const sameEpoch=' AND EXISTS (SELECT 1 FROM race_rooms WHERE race_rooms.id=race_players.room_id AND race_rooms.epoch=?)';
  const keepAlive=()=>db.prepare('UPDATE race_players SET last_seen=?,left_at=NULL WHERE room_id=? AND id=?'+sameEpoch).bind(now,id,p.id,state.raw.epoch).run();
  if(body.frame){
   const frame=frameOf(body.frame,state.view[p.id]?.character);
   if(frame.seq>p.last_seq){
    const prior=p.frame?JSON.parse(p.frame):null;
    if(prior&&frame.roomIndex<prior.roomIndex)fail(409,'stale-progress','关卡进度不能倒退。');
    if(frame.finished&&(!state.raw.start_at||now<state.raw.start_at))fail(409,'race-not-started','竞速尚未开始。');
    await db.prepare('UPDATE race_players SET frame=?,last_seq=?,last_seen=?,left_at=NULL,finished_at=CASE WHEN ? THEN COALESCE(finished_at,?) ELSE finished_at END WHERE room_id=? AND id=? AND last_seq<?'+sameEpoch).bind(JSON.stringify(frame),frame.seq,now,frame.finished?1:0,now,id,p.id,frame.seq,state.raw.epoch).run();
   }else await keepAlive();
  }else await keepAlive();
 }else if(action==='leave'){
  if(!state.raw.start_at||now<state.raw.start_at){
   if(p.id==='host')await db.prepare('UPDATE race_rooms SET closed_at=? WHERE id=?').bind(now,id).run();
   else await db.batch([db.prepare('DELETE FROM race_players WHERE room_id=? AND id=\'guest\'').bind(id),db.prepare('UPDATE race_players SET ready_at=NULL WHERE room_id=?').bind(id),db.prepare("UPDATE race_rooms SET start_at=NULL,config=json_remove(config,'$.characters.guest') WHERE id=?").bind(id)]);
   if(p.id==='host')return{ok:true,serverNow:Date.now(),selfId:p.id,room:{...state.view,status:'closed'}};
  }else await db.prepare('UPDATE race_players SET left_at=? WHERE room_id=? AND id=?').bind(now,id,p.id).run();
 }else if(action==='reset'){
  if(p.id!=='host')fail(403,'host-only','由房主发起下一场竞速。');
  const epoch=Number.isInteger(body.epoch)?body.epoch:state.raw.epoch;
  if(epoch!==state.raw.epoch||state.raw.start_at===null||now<state.raw.start_at){
   return{ok:true,serverNow:Date.now(),selfId:p.id,room:state.view};
  }
  if(state.players.some(player=>!player.finished_at&&!player.left_at&&now-player.last_seen<15000))fail(409,'race-running','请等双方完成或离场后再开始下一场。');
  // Compare the round again inside the write, and clear player data only if
  // that update won. The two statements share one D1 batch transaction.
  await db.batch([
   db.prepare('UPDATE race_rooms SET start_at=NULL,epoch=epoch+1,expires_at=? WHERE id=? AND epoch=?').bind(now+TTL,id,epoch),
   db.prepare('UPDATE race_players SET ready_at=NULL,frame=NULL,last_seq=-1,finished_at=NULL,left_at=NULL WHERE room_id=? AND changes()=1').bind(id)
  ]);
 }else fail(400,'invalid-action','未知竞速操作。');
 state=await roomState(db,id);
 return{ok:true,serverNow:Date.now(),selfId:p.id,room:state.view};
}

export default{async fetch(request,env){
 const path=new URL(request.url).pathname;
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
 if(path==='/api/health')return json({ok:true,service:'starhop-race',version:'1.1.0',serverNow:Date.now(),storage:env.DB?'d1':'missing'});
 if(path!=='/api/race')return new Response('<!doctype html><meta charset="UTF-8"><title>星跃远征 · 双人竞速服务</title><style>body{background:#142925;color:#e9dbb8;font:18px sans-serif;max-width:600px;margin:12vh auto;padding:24px}a{color:#b2dac3}</style><h1>星跃远征 · 双人竞速</h1><p>同步倒计时与旅人幽灵状态服务。</p><p><a href="https://le3334515-tech.github.io/starhop-expedition/classic/?v=4.5">进入八境远征</a></p>',{headers:{...cors,'Content-Type':'text/html;charset=utf-8'}});
 if(request.method!=='POST')return json({ok:false,error:'method-not-allowed',message:'请使用POST。'},405);
 try{
  if(!env.DB)fail(503,'storage-unavailable','竞速服务暂未就绪。');
  const text=await request.text();if(text.length>8000)fail(413,'payload-too-large','状态内容过大。');
  let body;try{body=JSON.parse(text);}catch{fail(400,'invalid-json','请求格式无效。');}
  return json(await operate(env.DB,body));
 }catch(error){return json({ok:false,error:error instanceof ApiError?error.code:'server-error',message:error instanceof ApiError?error.message:'竞速服务暂时繁忙，请稍后重试。'},error instanceof ApiError?error.status:500);}
}};
