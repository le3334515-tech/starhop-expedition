import { ACHIEVEMENTS, heroAchievementCount, type Achievement } from './achievements';
import { CHARACTER_IDS } from './game/types';
import { icon } from './icons';

export function achievementBook(unlocked: ReadonlySet<string>): string {
  const groups = Array.from(new Set(ACHIEVEMENTS.map(badge => badge.group)));
  const count = unlocked.size, total = ACHIEVEMENTS.length;
  return `<div class="achievement-progress">
    <div><span>成就解锁</span><strong>${count} <small>/ ${total}</small></strong>
      <progress max="${total}" value="${count}" aria-label="成就解锁进度"></progress></div>
    <div><span>英雄通关</span><strong>${heroAchievementCount(unlocked)} <small>/ ${CHARACTER_IDS.length}</small></strong>
      <progress max="${CHARACTER_IDS.length}" value="${heroAchievementCount(unlocked)}" aria-label="英雄通关进度"></progress></div>
  </div>
  ${groups.map(group => `<section class="achievement-group">
    <h3>${group}</h3>
    <ul>${ACHIEVEMENTS.filter(badge => badge.group === group).map(badge => {
      const earned = unlocked.has(badge.id);
      return `<li data-achievement="${badge.id}" class="${earned ? 'earned' : ''}">
        <span class="achievement-icon">${icon(badge.icon)}</span>
        <div><strong>${badge.name}</strong><p>${badge.detail}</p></div>
        <small>${earned ? '已解锁' : '待解锁'}</small>
      </li>`;
    }).join('')}</ul>
  </section>`).join('')}`;
}

export function achievementFeedback(badges: readonly Achievement[]): string {
  const names = badges.slice(0, 3).map(badge => badge.name).join(' · ');
  return `<div class="achievement-feedback">
    <div role="status">${icon('trophy')}<div><strong>解锁 ${badges.length} 项成就</strong><span>${names}${badges.length > 3 ? ' 等' : ''}</span></div></div>
    <button class="text-button" data-action="achievements">查看成就 ${icon('arrow')}</button>
  </div>`;
}
