import { describe, expect, it } from 'vitest';
import { ACHIEVEMENTS, ExpeditionAchievements, heroAchievementCount } from './achievements';
import { CHARACTER_IDS, type GameResult } from './game/types';
import type { RunRecord } from './social';

const win = (patch: Partial<GameResult> = {}): GameResult => ({
  seed:1, modifier:'standard', weapon:'blade', won:true, time:481, score:25000,
  coins:20, kills:31, level:8, deaths:1, roomsCleared:8, maxCombo:7,
  upgrades:[], overdriveCount:2, synergies:[], ...patch,
});
function store() {
  const data = new Map<string, string>();
  return { data, getItem: (key: string) => data.get(key) ?? null, setItem: (key: string, value: string) => { data.set(key, value); } };
}
const record = (result: GameResult): RunRecord => ({ id:'old', createdAt:'2026-11-18T00:00:00Z', name:'星际旅人', result });

describe('expedition achievements', () => {
  it('requires a genuine completed route and unlocks nested time goals at exact thresholds', () => {
    const book = new ExpeditionAchievements([], null);
    expect(book.complete(win({won:false, time:180}), {kind:'solo'})).toEqual([]);
    expect(book.complete(win({roomsCleared:7, time:180}), {kind:'solo'})).toEqual([]);
    expect(book.complete(win({time:Infinity}), {kind:'solo'})).toEqual([]);
    const awarded = book.complete(win({time:300}), {kind:'solo'}).map(badge => badge.id);
    expect(awarded).toEqual(expect.arrayContaining(['solo-win', 'speed-8', 'speed-5']));
    expect(awarded).not.toContain('speed-3');
    expect(book.complete(win({time:180}), {kind:'solo'}).map(badge => badge.id)).toEqual(['speed-3']);
    expect(book.complete(win({time:180}), {kind:'solo'})).toHaveLength(0);
  });

  it('keeps online race, solo and sufficiently large teams distinct', () => {
    const book = new ExpeditionAchievements([], null);
    book.complete(win({time:179}), {kind:'race'});
    expect(book.unlocked.has('race-win')).toBe(true);
    expect(book.unlocked.has('solo-win')).toBe(false);
    expect(book.unlocked.has('speed-3')).toBe(false);
    book.complete(win({roomsCleared:11, character:'spear'}), {kind:'coop', players:1});
    expect(book.unlocked.has('hero-spear')).toBe(true);
    expect(book.unlocked.has('coop-win')).toBe(false);
    book.complete(win({roomsCleared:11, character:'monk', deaths:0, maxCombo:8, overdriveCount:3}), {kind:'coop',players:2});
    expect([...book.unlocked]).toEqual(expect.arrayContaining(['coop-win', 'hero-monk', 'no-fall', 'combo-8', 'awaken-3']));
    expect(book.unlocked.has('four-win')).toBe(false);
    expect(book.complete(win({roomsCleared:11}), {kind:'coop', players:4}).map(badge=>badge.id)).toEqual(['four-win']);
  });

  it('unlocks the aggregate hero and rule badges, with a stable 22-badge catalogue', () => {
    const book = new ExpeditionAchievements([], null);
    const rules = ['standard','moon','haste','iron'] as const;
    for (const [index, character] of CHARACTER_IDS.entries()) book.complete(win({character,modifier:rules[index % rules.length]}), {kind:'solo'});
    expect(heroAchievementCount(book.unlocked)).toBe(6);
    expect([...book.unlocked]).toEqual(expect.arrayContaining(['all-heroes','all-rules']));
    expect(ACHIEVEMENTS).toHaveLength(22);
    expect(new Set(ACHIEVEMENTS.map(badge=>badge.id)).size).toBe(22);
  });

  it('migrates validated old local completions once and preserves their badges without the record history', () => {
    const storage = store();
    const previous = win({time:299, character:'wheel', maxCombo:8, overdriveCount:3});
    const book = new ExpeditionAchievements([record(previous)], storage);
    expect([...book.unlocked]).toEqual(expect.arrayContaining(['speed-5','hero-wheel','combo-8','awaken-3']));
    expect(book.unlocked.has('solo-win')).toBe(false);
    expect(new ExpeditionAchievements([], storage).unlocked).toEqual(book.unlocked);

    const race = win({time:179, character:'staff'});
    book.complete(race, {kind:'race'});
    const reload = new ExpeditionAchievements([record(race)], storage);
    expect(reload.unlocked.has('race-win')).toBe(true);
    expect(reload.unlocked.has('speed-3')).toBe(false);
  });

  it('keeps in-session awards available when storage throws', () => {
    const inaccessible = { getItem: () => { throw new Error('storage blocked'); }, setItem: () => { throw new Error('storage blocked'); } };
    const book = new ExpeditionAchievements([], inaccessible);
    book.complete(win(), {kind:'solo'});
    expect(book.unlocked.has('solo-win')).toBe(true);
  });
});
