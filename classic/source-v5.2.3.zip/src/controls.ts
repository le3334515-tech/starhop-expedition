export const CONTROL_ACTIONS = ['left', 'right', 'jump', 'attack', 'dash', 'guard', 'interact', 'overdrive', 'weapon1', 'weapon2', 'weapon3', 'pause'] as const;
export type ControlAction = typeof CONTROL_ACTIONS[number];
export type KeyBindings = Record<ControlAction, string[]>;
export const CONTROL_NAMES: Record<ControlAction, string> = { left: '向左移动', right: '向右移动', jump: '跳跃 / 二段跳', attack: '攻击', dash: '无敌闪避', guard: '精准格挡', interact: '进入星门', overdrive: '星陨觉醒', weapon1: '星陨短刃', weapon2: '萤火法杖', weapon3: '回声飞轮', pause: '暂停 / 继续' };
export const KEY_STORAGE = 'starhop.keyboard.v1';
export function defaultBindings(): KeyBindings {
  return { left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'], jump: ['Space', 'KeyK', 'KeyW', 'ArrowUp', 'KeyZ'], attack: ['KeyJ', 'KeyX'], dash: ['ShiftLeft', 'ShiftRight', 'KeyL'], guard: ['KeyF'], interact: ['KeyE'], overdrive: ['KeyQ'], weapon1: ['Digit1'], weapon2: ['Digit2'], weapon3: ['Digit3'], pause: ['KeyP'] };
}
export function bindableKey(code: string): boolean {
  return /^(Key[A-Z]|Digit[0-9]|Arrow(Left|Right|Up|Down)|Space|Shift(Left|Right)|Control(Left|Right)|Alt(Left|Right)|Enter|Tab|Backspace|Bracket(Left|Right)|Semicolon|Quote|Comma|Period|Slash|Backslash|Minus|Equal|Numpad[0-9])$/.test(code);
}
export function parseBindings(raw: unknown): KeyBindings {
  const defaults = defaultBindings();
  if (!raw || typeof raw !== 'object' || (raw as {v?: unknown}).v !== 1) return defaults;
  const bindings = (raw as {bindings?: unknown}).bindings;
  if (!bindings || typeof bindings !== 'object') return defaults;
  const candidate = bindings as Record<string, unknown>;
  const used = new Set<string>();
  const result = {} as KeyBindings;
  // A damaged or conflicting profile resets as a whole, so every action stays reachable.
  for (const action of CONTROL_ACTIONS) {
    const keys = candidate[action];
    if (!Array.isArray(keys) || keys.length < 1 || keys.length > 6) return defaults;
    result[action] = [];
    for (const code of keys) {
      if (typeof code !== 'string' || !bindableKey(code) || used.has(code)) return defaults;
      used.add(code); result[action].push(code);
    }
  }
  return result;
}
export function bindingConflict(bindings: KeyBindings, action: ControlAction, code: string): ControlAction | null {
  return CONTROL_ACTIONS.find(other => other !== action && bindings[other].includes(code)) || null;
}
export function keyLabel(code: string): string {
  const labels: Record<string, string> = { Space: '空格', ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', ShiftLeft: 'Shift', ShiftRight: '右 Shift', ControlLeft: 'Ctrl', ControlRight: '右 Ctrl', AltLeft: 'Alt', AltRight: '右 Alt', Enter: 'Enter', Backspace: '退格', Tab: 'Tab', BracketLeft: '[', BracketRight: ']', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/', Backslash: '\\', Minus: '-', Equal: '=' };
  return labels[code] || code.replace(/^(Key|Digit)/, '').replace('Numpad', '小键盘 ');
}
export interface StickVector { x: number; y: number }
/** Convert screen motion to stage motion, including the portrait 90° fallback. */
export function stickVector(dx: number, dy: number, radius: number, rotated = false, deadzone = .18): StickVector {
  if (!(radius > 0) || !Number.isFinite(dx) || !Number.isFinite(dy)) return { x: 0, y: 0 };
  const x = (rotated ? dy : dx) / radius;
  const y = (rotated ? -dx : dy) / radius;
  const length = Math.hypot(x, y);
  if (length <= deadzone) return { x: 0, y: 0 };
  const magnitude = Math.min(1, (length - deadzone) / (1 - deadzone));
  return { x: x / length * magnitude, y: y / length * magnitude };
}
