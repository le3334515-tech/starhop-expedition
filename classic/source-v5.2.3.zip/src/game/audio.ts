import { ExpeditionScore, ElementScore, type ScoreCue } from './score';
import type { SoundName } from './types';
import { characterImpactVoice } from './weapon-audio';

type Bus = 'music' | 'effects';
type Source = OscillatorNode | AudioBufferSourceNode;

/** Original sample-based score and synthesized combat effects share one master. */
export class GameAudio {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private effectsBus: GainNode | null = null;
  private sources = new Map<Source, Bus>();
  private noiseBuffer: AudioBuffer | null = null;
  private score: ExpeditionScore | ElementScore | null = null;
  private musicWanted: ScoreCue | null = null;
  private cueOffset: number | undefined;
  private _muted = false;
  private disposed = false;
  private lastEffectAt = new Map<SoundName, number>();

  constructor() {
    try { this._muted = localStorage.getItem('starhop.audioMuted.v1') === '1'; } catch { /* Optional preference. */ }
  }

  get muted(): boolean { return this._muted; }

  async unlock(): Promise<void> {
    if (this.disposed) return;
    try {
      if (!this.context) {
        const AudioContextClass = globalThis.AudioContext || (globalThis as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AudioContextClass) {
          if (typeof Audio === 'undefined') return;
          this.score ??= new ElementScore(this._muted);
          if(this.score instanceof ElementScore) this.score.unlock();
          this.score.select(this.musicWanted,this.cueOffset);
          return;
        }
        this.context = new AudioContextClass();
        this.master = this.context.createGain();
        this.master.gain.value = this._muted ? 0 : 0.65;
        const compressor = this.context.createDynamicsCompressor();
        compressor.threshold.value = -15;
        compressor.knee.value = 16;
        compressor.ratio.value = 5;
        this.master.connect(compressor);
        compressor.connect(this.context.destination);
        this.musicBus = this.context.createGain();
        this.musicBus.gain.value = .86;
        this.score = new ExpeditionScore(this.context, this.musicBus);
        this.effectsBus = this.context.createGain();
        this.effectsBus.gain.value = 0.65;
        this.musicBus.connect(this.master);
        this.effectsBus.connect(this.master);
        this.noiseBuffer = this.context.createBuffer(1, Math.ceil(this.context.sampleRate * 0.5), this.context.sampleRate);
        const samples = this.noiseBuffer.getChannelData(0);
        for (let i = 0; i < samples.length; i++) samples[i] = Math.random() * 2 - 1;
      }
      if (this.context.state === 'suspended') await this.context.resume();
      if (this.context.state === 'running') this.score?.select(this.musicWanted, this.cueOffset);
    } catch { /* Audio is decorative: browsers without it can still play. */ }
  }

  setMuted(value: boolean): void {
    this._muted = value;
    if (this.score instanceof ElementScore) this.score.setMuted(value);
    try { localStorage.setItem('starhop.audioMuted.v1', value ? '1' : '0'); } catch { /* Optional preference. */ }
    if (this.context && this.master) this.master.gain.setTargetAtTime(value ? 0 : 0.65, this.context.currentTime, 0.015);
  }

  setMusic(active: ScoreCue | boolean | null, offset?: number): void {
    this.musicWanted = active === true ? 'mist' : active || null;
    this.cueOffset = offset;
    if (this.score instanceof ElementScore || this.context?.state === 'running') this.score?.select(this.musicWanted,offset);
  }
  warmGuardian() { this.score?.warm('guardian'); }
  resetScore() { this.musicWanted = null; this.score?.reset(); }

  play(name: SoundName): void {
    const ctx = this.context;
    if (!ctx || ctx.state !== 'running' || this._muted || this.disposed) return;
    const t = ctx.currentTime;
    const characterVoice = characterImpactVoice(name);
    const contactInterval = characterVoice?.cooldown ?? (name === 'hit' ? .026 : name === 'critical' ? .045 : name === 'heavy' ? .055 : name === 'guardBreak' ? .12 : 0);
    if (contactInterval && t - (this.lastEffectAt.get(name) ?? -10) < contactInterval) return;
    this.lastEffectAt.set(name, t);
    try {
      if (characterVoice) {
        for (const voice of characterVoice.tones)
          this.tone(voice.frequency, t + voice.at, voice.duration, voice.type, voice.volume, 'effects', voice.endFrequency);
        for (const voice of characterVoice.noise)
          this.noise(t + voice.at, voice.duration, voice.volume, 'effects', voice.frequency);
        return;
      }
      switch (name) {
        case 'jump': this.tone(300, t, 0.13, 'square', 0.11, 'effects', 650); break;
        case 'doubleJump': this.tone(520, t, 0.12, 'triangle', 0.2, 'effects', 980); this.tone(780, t + 0.05, 0.1, 'sine', 0.1, 'effects', 1300); break;
        case 'attack': this.noise(t, 0.045, 0.075, 'effects', 2900); this.tone(250, t, 0.055, 'triangle', 0.07, 'effects', 105); break;
        case 'fire': this.tone(850, t, 0.12, 'sawtooth', 0.055, 'effects', 220); break;
        case 'coin': this.tone(988, t, 0.07, 'square', 0.09, 'effects'); this.tone(1319, t + 0.065, 0.1, 'square', 0.075, 'effects'); break;
        case 'hurt': this.tone(140, t, 0.22, 'sawtooth', 0.14, 'effects', 45); this.noise(t, 0.1, 0.15, 'effects', 900); break;
        case 'hit':
          this.noise(t, .035, .24, 'effects', 2700);
          this.tone(175, t, .085, 'sine', .23, 'effects', 52);
          this.tone(470, t, .045, 'triangle', .11, 'effects', 150);
          break;
        case 'critical':
          this.noise(t, .055, .25, 'effects', 3800);
          this.tone(150, t, .12, 'sine', .28, 'effects', 42);
          this.tone(1280, t, .095, 'triangle', .15, 'effects', 540);
          this.tone(1920, t + .018, .12, 'sine', .09, 'effects', 960);
          break;
        case 'heavy':
          this.noise(t, .1, .28, 'effects', 1600);
          this.tone(135, t, .18, 'sine', .34, 'effects', 36);
          this.tone(310, t, .09, 'triangle', .18, 'effects', 70);
          this.noise(t + .045, .055, .1, 'effects', 4700);
          break;
        case 'guardBreak':
          this.noise(t, .17, .26, 'effects', 1900);
          this.noise(t + .075, .08, .16, 'effects', 4200);
          this.tone(195, t, .25, 'sawtooth', .15, 'effects', 47);
          this.tone(92, t, .3, 'sine', .28, 'effects', 29);
          this.tone(1480, t + .03, .19, 'triangle', .12, 'effects', 370);
          break;
        case 'perfectDodge':
          this.noise(t, .085, .13, 'effects', 5200);
          this.tone(880, t, .1, 'sine', .15, 'effects', 1760);
          this.tone(1320, t + .04, .16, 'triangle', .1, 'effects');
          break;
        case 'kill':
          this.tone(170, t, .14, 'sine', .23, 'effects', 48);
          this.noise(t, .07, .14, 'effects', 2300);
          this.tone(660, t + .025, .12, 'triangle', .15, 'effects', 330);
          this.tone(990, t + .06, .095, 'triangle', .08, 'effects');
          break;
        case 'upgrade': this.arpeggio([72, 76, 79, 84], t, 0.085, 0.16); break;
        case 'portal': this.arpeggio([60, 67, 72, 79, 84], t, 0.065, 0.12); break;
        case 'boss': this.tone(66, t, 0.42, 'sawtooth', 0.13, 'effects', 35); this.tone(92, t, .45, 'sine', .25, 'effects', 28); this.noise(t, 0.3, 0.18, 'effects', 600); break;
        case 'win': this.arpeggio([72, 76, 79, 84, 79, 84, 88], t, 0.12, 0.16); this.tone(this.note(48), t, 1.1, 'triangle', 0.15, 'effects'); break;
        case 'lose': this.arpeggio([72, 69, 65, 60, 48], t, 0.14, 0.14); break;
        case 'dash': this.noise(t, 0.11, 0.15, 'effects', 3600); this.tone(210, t, 0.1, 'sine', 0.12, 'effects', 90); break;
        case 'select': this.tone(880, t, 0.055, 'triangle', 0.14, 'effects'); break;
        case 'awaken':
          this.tone(196, t, .52, 'sine', .15, 'effects', 164);
          this.noise(t, .28, .08, 'effects', 1100);
          this.arpeggio([50, 62, 69, 74, 77, 81], t + .026, .044, .11);
          // Match the jade blade's release at 0.36 seconds.
          this.tone(102, t + .36, .42, 'sine', .27, 'effects', 39);
          this.tone(463, t + .36, .5, 'sine', .16, 'effects', 412);
          this.tone(1389, t + .363, .29, 'sine', .09, 'effects', 1236);
          this.noise(t + .36, .1, .16, 'effects', 2450);
          this.tone(this.note(74), t + .407, .43, 'triangle', .11, 'effects');
          this.tone(this.note(81), t + .407, .43, 'triangle', .08, 'effects');
          break;
        case 'synergy':
          this.arpeggio([76, 79, 84, 88], t, 0.09, 0.13);
          this.tone(this.note(72), t + 0.27, 0.48, 'sine', 0.12, 'effects');
          this.tone(this.note(79), t + 0.27, 0.48, 'triangle', 0.08, 'effects');
          break;
      }
    } catch { /* A suspended or closed audio device never interrupts a run. */ }
  }

  private note(midi: number): number { return 440 * 2 ** ((midi - 69) / 12); }

  private arpeggio(notes: number[], time: number, interval: number, volume: number): void {
    notes.forEach((note, index) => this.tone(this.note(note), time + index * interval, 0.23, 'triangle', volume, 'effects'));
  }

  private tone(frequency: number, time: number, duration: number, type: OscillatorType, volume: number, bus: Bus, endFrequency?: number): void {
    const ctx = this.context;
    const destination = bus === 'music' ? this.musicBus : this.effectsBus;
    if (!ctx || !destination) return;
    const oscillator = ctx.createOscillator();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, time);
    if (endFrequency) oscillator.frequency.exponentialRampToValueAtTime(endFrequency, time + duration);
    const envelope = ctx.createGain();
    envelope.gain.setValueAtTime(0.0001, time);
    envelope.gain.exponentialRampToValueAtTime(Math.max(0.001, volume), time + 0.006);
    envelope.gain.exponentialRampToValueAtTime(0.0001, time + duration);
    oscillator.connect(envelope);
    envelope.connect(destination);
    this.sources.set(oscillator, bus);
    oscillator.onended = () => { this.sources.delete(oscillator); oscillator.disconnect(); envelope.disconnect(); };
    oscillator.start(time);
    oscillator.stop(time + duration + 0.02);
  }

  private noise(time: number, duration: number, volume: number, bus: Bus, frequency: number): void {
    const ctx = this.context;
    const destination = bus === 'music' ? this.musicBus : this.effectsBus;
    if (!ctx || !this.noiseBuffer || !destination) return;
    const source = ctx.createBufferSource();
    source.buffer = this.noiseBuffer;
    const filter = ctx.createBiquadFilter();
    filter.type = frequency > 2000 ? 'highpass' : 'bandpass';
    filter.frequency.value = frequency;
    const envelope = ctx.createGain();
    envelope.gain.setValueAtTime(volume, time);
    envelope.gain.exponentialRampToValueAtTime(0.0001, time + duration);
    source.connect(filter);
    filter.connect(envelope);
    envelope.connect(destination);
    this.sources.set(source, bus);
    source.onended = () => { this.sources.delete(source); source.disconnect(); filter.disconnect(); envelope.disconnect(); };
    source.start(time);
    source.stop(time + duration + 0.01);
  }

  dispose(): void {
    this.disposed = true;
    this.musicWanted = null;
    this.score?.dispose();
    for (const source of this.sources.keys()) { try { source.stop(); } catch { /* Already stopped. */ } }
    this.sources.clear();
    this.lastEffectAt.clear();
    void this.context?.close().catch(() => {});
    this.context = null;
  }
}
