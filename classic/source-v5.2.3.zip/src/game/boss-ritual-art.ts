import { ascensionProgress, BOSS_ASCENSION_IMPACT, BOSS_ASCENSION_TIME, ease, openingAscension } from './boss-seal';
import type { Boss } from './types';

const TAU = 2 * Math.PI;
const IMPACT = BOSS_ASCENSION_IMPACT / BOSS_ASCENSION_TIME;
const COAL = '#110e17';
const WINE = '#492534';
const BRONZE = '#ae6648';
const GOLD = '#e6aa65';
const WHITE_GOLD = '#ffe2a6';

function block(c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  c.fillRect(Math.round(x), Math.round(y), Math.max(1, Math.round(w)), Math.max(1, Math.round(h)));
}

function ring(c: CanvasRenderingContext2D, cx: number, cy: number, radius: number, count: number, facing: number, scaleY = 1) {
  c.beginPath();
  for (let i = 0; i <= count; i++) {
    const angle = facing + i * TAU / count;
    const x = Math.round(cx + Math.cos(angle) * radius);
    const y = Math.round(cy + Math.sin(angle) * radius * scaleY);
    if (i === 0) c.moveTo(x, y);
    else c.lineTo(x, y);
  }
  c.closePath();
}

function plaque(c: CanvasRenderingContext2D, x: number, y: number, tilt: number, active: boolean) {
  c.save();
  c.translate(Math.round(x), Math.round(y));
  c.rotate(tilt);
  c.fillStyle = COAL;
  c.fillRect(-7, -13, 14, 26);
  c.fillStyle = active ? GOLD : BRONZE;
  c.fillRect(-6, -13, 12, 2);
  c.fillRect(-6, 10, 12, 2);
  c.fillRect(-6, -9, 1, 17);
  c.fillRect(5, -9, 1, 17);
  c.fillRect(-3, -6, 6, 2);
  c.fillRect(-1, -7, 2, 14);
  c.fillRect(-3, 0, 6, 2);
  c.fillRect(-3, 4, 2, 2);
  c.fillRect(2, 5, 2, 2);
  c.restore();
}

/** Eight seals and the rotating bronze calendar sit behind the actor silhouette. */
export function drawBossRitualBack(c: CanvasRenderingContext2D, b: Boss, now: number, reduce: boolean) {
  if (b.form !== 2 || b.phase !== 3 || b.mode === 'dead') return;
  const ascending = openingAscension(b);
  const p = ascending ? ascensionProgress(b) : 1;
  const pull = ascending ? ease(.08, .56, p) * (1 - ease(IMPACT, .85, p)) : 0;
  const born = ease(IMPACT - .035, .86, p);
  const x = b.x + b.w / 2;
  const foot = b.y + b.h;
  const y = foot - 183 + pull * 54;
  const radius = 108 - pull * 69 + born * 22;
  const spin = reduce ? Math.PI / 16 : now * .105 + p * .7;
  const opacity = b.mode === 'stagger' ? .27 : ascending ? .84 : b.mode === 'windup' ? .56 : .40;

  c.save();
  c.globalAlpha *= opacity;
  c.fillStyle = COAL;
  ring(c, x, y, radius, 32, spin);
  c.fill();
  c.strokeStyle = WINE;
  c.lineWidth = 7;
  c.stroke();
  c.strokeStyle = BRONZE;
  c.lineWidth = 1.7;
  ring(c, x, y, radius + 6, 24, spin);
  c.stroke();
  c.strokeStyle = born > .8 ? GOLD : BRONZE;
  c.lineWidth = 1;
  ring(c, x, y, radius - 11, 24, -spin);
  c.stroke();

  // Wide octagonal corners make the halo read as an inlaid astrolabe even on a phone.
  for (let i = 0; i < 24; i++) {
    const angle = spin + i * TAU / 24;
    const distance = radius - 5;
    const px = x + Math.cos(angle) * distance;
    const py = y + Math.sin(angle) * distance;
    c.save();
    c.translate(Math.round(px), Math.round(py));
    c.rotate(angle);
    c.fillStyle = i % 3 === 0 ? WHITE_GOLD : BRONZE;
    c.fillRect(-2, -1, i % 3 === 0 ? 9 : 4, 2);
    c.restore();
  }

  const windup = b.mode === 'windup';
  for (let i = 0; i < 8; i++) {
    const angle = -1.15 + i * TAU / 8 - spin * .82;
    const gathering = ascending ? 40 * (1 - ease(.08, .49, p)) : 0;
    const orbit = radius + 14 + gathering;
    const bob = reduce ? 0 : Math.sin(now * 3 + i) * 3;
    const px = x + Math.cos(angle) * (orbit + bob);
    const py = y + Math.sin(angle) * orbit * .88;
    if (ascending && p < IMPACT) {
      c.strokeStyle = i % 2 ? WINE : BRONZE;
      c.beginPath();
      c.moveTo(Math.round(px), Math.round(py));
      c.lineTo(Math.round(x), Math.round(y));
      c.stroke();
    }
    plaque(c, px, py, angle + Math.PI / 2, ascending || windup);
  }

  if (ascending && p > IMPACT && p < .96) {
    const wave = ease(IMPACT, .96, p);
    c.globalAlpha *= 1 - wave;
    c.strokeStyle = GOLD;
    c.lineWidth = 2;
    ring(c, x, foot - 5, 30 + 266 * wave, 24, 0, .12);
    c.stroke();
    c.strokeStyle = BRONZE;
    ring(c, x, foot - 8, 18 + 224 * wave, 24, 0, .10);
    c.stroke();
    for (let i = 0; i < 16; i++) {
      const side = i % 2 === 0 ? 1 : -1;
      const px = x + side * (18 + wave * (57 + i * 12));
      const py = foot - 8 - Math.sin(Math.PI * wave) * (20 + i % 5 * 8);
      c.fillStyle = i % 3 ? GOLD : WHITE_GOLD;
      block(c, px, py, 4 + i % 3 * 2, 2);
    }
  }
  c.restore();
}

/** A single cut at the gong, then embers scattered by the staff strike. */
export function drawBossRitualStrike(c: CanvasRenderingContext2D, b: Boss, reduce: boolean) {
  if (!openingAscension(b)) return;
  const p = ascensionProgress(b);
  const x = b.x + b.w / 2;
  const foot = b.y + b.h;
  const spark = ease(IMPACT - .04, IMPACT, p) * (1 - ease(IMPACT, .79, p));
  if (spark > .015) {
    const breadth = reduce ? 88 : 205;
    const open = ease(IMPACT - .04, IMPACT + .05, p);
    c.save();
    c.translate(Math.round(x), Math.round(foot - 108));
    c.scale(b.facing || 1, 1);
    c.globalAlpha *= spark;
    c.fillStyle = WINE;
    c.beginPath();
    c.moveTo(-breadth * .56 * open, 57);
    c.lineTo(-28, -9);
    c.lineTo(breadth * open, -87);
    c.lineTo(24, 20);
    c.closePath();
    c.fill();
    c.fillStyle = GOLD;
    c.beginPath();
    c.moveTo(-breadth * .58 * open, 64);
    c.lineTo(-24, 1);
    c.lineTo(breadth * open, -91);
    c.lineTo(15, 16);
    c.closePath();
    c.fill();
    c.fillStyle = WHITE_GOLD;
    c.beginPath();
    c.moveTo(-breadth * .38 * open, 34);
    c.lineTo(0, -2);
    c.lineTo(breadth * .84 * open, -76);
    c.lineTo(19, 4);
    c.closePath();
    c.fill();
    c.restore();
  }

  if (!reduce && p >= IMPACT && p < .95) {
    const fallout = ease(IMPACT, .95, p);
    c.save();
    c.globalAlpha *= (1 - fallout) * .77;
    for (let i = 0; i < 21; i++) {
      const angle = i * 2.39996;
      const distance = 28 + fallout * (99 + i * 5);
      const px = x + Math.cos(angle) * distance;
      const py = foot - 103 + Math.sin(angle) * distance * .58 + fallout * fallout * 57;
      c.fillStyle = i % 3 ? GOLD : WHITE_GOLD;
      block(c, px, py, 2 + i % 4, 2);
    }
    c.restore();
  }
}

export function drawBossRushWake(c: CanvasRenderingContext2D, b: Boss, reduce: boolean) {
  if (b.form !== 2 || b.phase !== 3 || b.mode !== 'charge' || reduce) return;
  const center = b.x + b.w / 2;
  const foot = b.y + b.h;
  const direction = b.facing || 1;
  const drag = ease(0, .14, .55 - b.timer);
  if (drag <= .01) return;
  c.save();
  c.translate(Math.round(center), Math.round(foot));
  c.scale(direction, 1);
  c.globalAlpha *= .57 * drag;
  for (let layer = 0; layer < 3; layer++) {
    const length = 136 - layer * 26;
    const height = -86 + layer * 21;
    c.fillStyle = layer === 1 ? WINE : COAL;
    c.beginPath();
    c.moveTo(-length * drag, height + 6);
    c.lineTo(-43, height - 5);
    c.lineTo(-14, height - 17);
    c.lineTo(-26, height + 10);
    c.closePath();
    c.fill();
    c.fillStyle = layer === 1 ? GOLD : BRONZE;
    block(c, -length * drag, height + 4, length * .34 * drag, 2);
  }
  c.restore();
}
