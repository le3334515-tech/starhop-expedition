import type { Impact, WeaponId } from './types';

type Point = readonly [number, number];
type Stroke = { weapon: WeaponId; travel: number; strong: boolean };
const IVORY = '#fff1ce';

function shape(c: CanvasRenderingContext2D, color: string, points: readonly Point[]) {
  c.fillStyle = color;
  c.beginPath();
  c.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) c.lineTo(points[i][0], points[i][1]);
  c.closePath();
  c.fill();
}

function line(c: CanvasRenderingContext2D, color: string, points: readonly Point[], width = 1) {
  c.strokeStyle = color;
  c.lineWidth = width;
  c.beginPath();
  c.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) c.lineTo(points[i][0], points[i][1]);
  c.stroke();
}

function bladeContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  const isDart = weapon === 'swallowDart';
  const willow = weapon === 'willowSword';
  const edge = willow ? '#b6dabc' : '#eaa59b';
  if (isDart) c.rotate(.43);
  if (willow) c.scale(1.08, .84);
  c.rotate(-.42);
  const flight = 4 * travel;
  shape(c, '#713a47', [[-23,7],[-13,0],[-3,-2],[12,-7],[25+flight,-14],[12,-1],[2,5],[-12,9]]);
  shape(c, edge, [[-20,6],[-10,1],[0,-1],[13,-6],[26+flight,-14],[12,-4],[3,3],[-11,7]]);
  line(c, IVORY, [[-13,4],[-4,1],[9,-3],[22+flight,-12]], strong ? 2 : 1.25);
  if (isDart || strong) {
    const y = 8 + travel * 4;
    shape(c, edge, [[-10,y+3],[7,y-3],[18+flight,y-12],[15,y-5],[5,y+2]]);
    shape(c, IVORY, [[-17,0],[-20,1],[-25,3],[-23,0],[-16,-2]]);
  }
}

function staffContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  const mirror = weapon === 'moonMirror';
  const frost = weapon === 'frostStaff';
  const rim = mirror ? '#c6a0e4' : frost ? '#96d6e9' : '#d08163';
  const gem = mirror ? '#e2c4ff' : frost ? '#d1f1f1' : '#ffd296';
  const n = strong ? 6 : 4;
  const reach = (mirror ? 14 : 11) + travel * 9;
  c.save();
  c.rotate(frost ? -.56 : -.26);
  c.strokeStyle = rim;
  c.lineWidth = 1.3;
  c.beginPath(); c.ellipse(0, 0, 12 + travel * 7, (mirror ? 10 : 8) + travel * 4, 0, -.6, Math.PI * 1.48); c.stroke();
  if (mirror || strong) {
    c.beginPath(); c.ellipse(0, 0, 16 + travel * 7, 11 + travel * 4, 0, .84, 4.72); c.stroke();
  }
  for (let i = 0; i < n; i++) {
    const angle = i * Math.PI * 2 / n + (i % 2) * .24;
    c.save(); c.rotate(angle); c.translate(reach + (i % 3) * 2, 0);
    shape(c, rim, [[-4,1],[-1,-4],[7,0],[1,3]]);
    shape(c, gem, [[-2,0],[0,-2],[6,0],[0,1]]);
    c.restore();
  }
  c.restore();
}

function fanContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  const needle = weapon === 'jadeNeedle';
  const silk = weapon === 'silkFan';
  const count = strong ? 5 : 3;
  for (let i = 0; i < count; i++) {
    const angle = (i / (count - 1) - .5) * (needle ? 1.02 : silk ? 2.2 : 1.92) - .13;
    c.save(); c.rotate(angle); c.translate(6 + travel * (8 + i * 2), 0);
    const edge = silk ? '#dcdeac' : '#a5dab4';
    const tail = needle ? 21 : 15;
    shape(c, '#345e53', [[-2,2],[3,-3],[11,-6],[tail,-3],[11,1],[6,4]]);
    shape(c, edge, [[-2,2],[4,-2],[11,-4],[tail,-3],[10,0],[5,3]]);
    line(c, IVORY, [[0,1],[tail-4,-3]], needle ? 1.5 : 1);
    c.restore();
  }
}

function spearContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  const long = weapon === 'reedJavelin';
  const heavy = weapon === 'halberd';
  const tip = (long ? 34 : 24) + travel * 9;
  c.rotate(heavy ? -.25 : -.1);
  shape(c, '#457889', [[-29,0],[-4,-3],[tip-9,-3],[tip,-1],[tip-7,3],[-3,4]]);
  shape(c, '#a8d9e3', [[-24,0],[-6,-1],[tip-7,-2],[tip,-1],[tip-8,1],[-2,2]]);
  line(c, '#eef6e9', [[-18,0],[tip-6,-1]], strong ? 2 : 1.2);
  for (const i of strong ? [-1, 1] : [1]) {
    const y = i * (5 + travel * 5);
    line(c, '#88bcc6', [[-12,y],[-2,y*.75],[tip*.62,y*.36]]);
    shape(c, '#c5eeed', [[tip*.68,y*.72],[tip*.35,y],[tip*.5,y*.54]]);
  }
  if (heavy) {
    shape(c, '#c3dfdb', [[-7,-14],[9,-14],[19,-8],[22,1],[13,-4],[8,-7],[-3,-9]]);
    line(c, IVORY, [[-2,-13],[9,-13],[17,-8]]);
  }
}

function fistContact(c: CanvasRenderingContext2D, { weapon, travel, strong }: Stroke) {
  const steel = weapon === 'ironGauntlet';
  const beads = weapon === 'prayerBeads';
  const face = beads ? '#e8ba71' : steel ? '#b4bdb9' : '#cd9065';
  const shadow = steel ? '#566972' : '#684637';
  const reach = 12 + travel * 13;
  const count = strong ? 7 : 5;
  c.save(); c.scale(1, .78);
  line(c, face, [[-reach,-4],[-reach*.65,-reach*.7],[0,-reach],[reach*.64,-reach*.68],[reach,-2],[reach*.76,7]]);
  if (strong) line(c, shadow, [[-reach*1.17,3],[-reach*.72,reach*.75],[0,reach],[reach*.55,reach*.7],[reach*.85,4]], 1.5);
  c.restore();
  for (let i = 0; i < count; i++) {
    const angle = i * Math.PI * 2 / count + .4;
    const size = (i % 3 === 1 ? 3.8 : 2.4) * (1 - travel * .44);
    const r = reach * (i % 2 ? 1 : .74);
    c.save(); c.rotate(angle); c.translate(r, 0); c.rotate(i * .4);
    if (beads) {
      c.fillStyle = shadow; c.fillRect(-size,-size,size*2,size*2);
      c.fillStyle = face; c.fillRect(-size,-size,size*2,size);
    } else if (steel) {
      shape(c, shadow, [[-size,-size],[size,-size],[size*1.5,0],[size,size],[-size,size]]);
      shape(c, face, [[-size,-size],[size,-size],[size*1.4,-size*.1],[-size*.3,size*.5]]);
    } else {
      shape(c, shadow, [[-size,-size],[size,-size*1.3],[size*1.5,-size*.2],[size,size],[-size*.8,size]]);
      shape(c, face, [[-size,-size],[size,-size*1.3],[size*1.4,-size*.3],[-size*.4,size*.16]]);
    }
    c.restore();
  }
}

/** Uses the confirmed-hit position supplied by the simulation. */
export function drawWeaponContact(c: CanvasRenderingContext2D, effect: Impact): boolean {
  const contact = effect.contact;
  if (!contact) return false;
  const life = Math.max(0, Math.min(1, effect.life / effect.maxLife));
  if (!life) return true;
  const progress = 1 - life;
  const travel = 1 - life * life;
  const strong = effect.kind !== 'hit' || contact.accent;
  const scale = Math.max(.75, Math.min(1.55, effect.size / 22)) * (.75 + travel * .35);
  const stroke = { weapon: contact.weapon, travel, strong };
  c.save();
  c.translate(Math.round(effect.x), Math.round(effect.y));
  c.scale((contact.facing < 0 ? -1 : 1) * scale, scale);
  c.globalAlpha *= Math.min(1, life * 2.3) * (strong ? 1 : .91);
  if (contact.character === 'blade') bladeContact(c, stroke);
  else if (contact.character === 'staff') staffContact(c, stroke);
  else if (contact.character === 'wheel') fanContact(c, stroke);
  else if (contact.character === 'spear') spearContact(c, stroke);
  else fistContact(c, stroke);

  if (progress < .48) {
    c.globalAlpha *= Math.min(1, (.48 - progress) * 4);
    const radius = (strong ? 11 : 6) * (.88 + progress);
    shape(c, IVORY, [[-radius,0],[-2,-2],[0,-radius*.75],[2,-2],[radius,0],[2,2],[0,radius*.75],[-2,2]]);
    if (effect.kind === 'break') {
      c.strokeStyle = effect.color; c.lineWidth = 1;
      c.beginPath(); c.arc(0, 0, radius+6, -.35, 2.83); c.stroke();
    }
  }
  c.restore();
  return true;
}
