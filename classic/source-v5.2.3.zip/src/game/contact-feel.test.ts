import { describe, expect, it, vi } from 'vitest';
import { drawWeaponContact } from './contact-art';
import { GameEngine } from './engine';
import {
  CHARACTER_IDS, EMPTY_INPUT, WEAPONS, getCharacterWeapons,
  type CharacterId, type Enemy, type Impact, type SoundName, type WeaponId,
} from './types';
import { characterImpactVoice } from './weapon-audio';

const DT = 1 / 120;
const HP = 150;
const contactSound = (sounds: SoundName[]) => sounds.filter(sound => /(?:Contact|Finisher)$/.test(sound));
const ranged = (weapon: WeaponId) => ['ember', 'disc', 'fan'].includes(WEAPONS[weapon].archetype);

function target(x: number, id = 1): Enemy {
  return {
    id, kind: 'sentry', x, y: 406, w: 32, h: 42, hp: HP, maxHp: HP,
    vx: 0, vy: 0, facing: -1, timer: 0, hurt: 0, dead: false,
    originX: x, originY: 406, attackCooldown: 99,
  };
}

function arena(character: CharacterId | undefined, weapon: WeaponId, enemies: Enemy[]) {
  const sounds: SoundName[] = [];
  const game = new GameEngine({ sound: sound => sounds.push(sound) });
  game.start({ seed: 42, modifier: 'standard', weapon, character });
  const { state } = game;
  state.room.platforms = [{ x: 0, y: 448, w: state.room.width, h: 130, kind: 'ground' }];
  state.room.hazards = []; state.pickups = []; state.enemies = enemies;
  state.cameraX = 0; state.shake = 0;
  Object.assign(state.hero, { x: 300, y: 412, grounded: true, facing: 1, invincible: 0, critChance: 0 });
  return { game, state, sounds };
}

function attack(game: GameEngine) {
  game.update(DT, { ...EMPTY_INPUT, attackPressed: true });
  for (let frame = 0; frame < 240 && game.state.enemies.every(enemy => enemy.hp === HP); frame++) {
    game.update(DT, EMPTY_INPUT);
  }
}

function expectContactDrawing(effect: Impact) {
  const translate = vi.fn(), fill = vi.fn();
  const context = {
    globalAlpha: 1, translate, fill, fillRect: vi.fn(), stroke: vi.fn(),
    save: vi.fn(), restore: vi.fn(), scale: vi.fn(), rotate: vi.fn(),
    beginPath: vi.fn(), moveTo: vi.fn(), lineTo: vi.fn(), closePath: vi.fn(), ellipse: vi.fn(),
  };
  expect(drawWeaponContact(context as unknown as CanvasRenderingContext2D, effect)).toBe(true);
  expect(translate).toHaveBeenCalledWith(Math.round(effect.x), Math.round(effect.y));
  expect(fill).toHaveBeenCalled();
  expect(context.save.mock.calls.length).toBe(context.restore.mock.calls.length);
}

const namedWeapons = CHARACTER_IDS
  .filter(character => character !== 'traveller')
  .flatMap(character => getCharacterWeapons(character).map(weapon => [character, weapon] as const));

describe('weapon contact is driven by the real hit test', () => {
  it.each(namedWeapons)('%s / %s paints, plays and pauses only on actual contact', (character, weapon) => {
    const enemy = target(ranged(weapon) ? 420 : 350);
    const run = arena(character, weapon, [enemy]);
    attack(run.game);

    expect(enemy.hp).toBeLessThan(HP);
    const effect = run.state.impacts.find(impact => impact.contact);
    expect(effect).toBeDefined();
    expect(effect?.contact).toEqual({ character, weapon, facing: 1, accent: false });
    expect(effect?.x).toBeCloseTo(enemy.x + enemy.w / 2);
    expect(effect?.y).toBeCloseTo(enemy.y + enemy.h / 2);
    expectContactDrawing(effect!);
    expect(run.state.hitstop).toBeGreaterThan(0);
    expect(run.state.shake).toBeGreaterThan(0);
    const voice = `${character}Contact`;
    expect(contactSound(run.sounds)).toEqual([voice]);
    expect(characterImpactVoice(voice)?.tones.length).toBeGreaterThan(0);

    const distant = target(1950);
    const miss = arena(character, weapon, [distant]);
    attack(miss.game);
    expect(distant.hp).toBe(HP);
    expect(miss.state.impacts.some(impact => impact.contact)).toBe(false);
    expect(miss.state.hitstop).toBe(0);
    expect(contactSound(miss.sounds)).toEqual([]);
  });

  it.each([
    ['blade', 'blade'], ['staff', 'frostStaff'], ['wheel', 'fan'],
    ['spear', 'halberd'], ['monk', 'ironGauntlet'],
  ] as const)('%s uses a distinct longer beat and finisher voice on an accented %s hit', (character, weapon) => {
    const x = ranged(weapon) ? 420 : 350;
    const light = arena(character, weapon, [target(x)]);
    const heavy = arena(character, weapon, [target(x)]);
    attack(light.game);
    // The next standard attack input will now release the third stroke.
    Object.assign(heavy.state.hero, { attackStep: 2, comboWindow: 1 });
    attack(heavy.game);

    const effect = heavy.state.impacts.find(impact => impact.contact);
    expect(effect?.contact).toMatchObject({ character, weapon, accent: true });
    expectContactDrawing(effect!);
    expect(heavy.state.hitstop).toBeGreaterThan(light.state.hitstop);
    const voice = `${character}Finisher`;
    expect(contactSound(heavy.sounds)).toEqual([voice]);
    expect(characterImpactVoice(voice)?.noise.length).toBeGreaterThan(0);
  });

  it('keeps a single finite pause and voice when three enemies are caught in one slash', () => {
    const targets = [target(350, 1), target(366, 2), target(383, 3)];
    const solo = arena('blade', 'blade', [target(350)]);
    const group = arena('blade', 'blade', targets);
    attack(solo.game);
    attack(group.game);

    expect(targets.filter(enemy => enemy.hp < HP)).toHaveLength(3);
    expect(group.state.impacts.filter(effect => effect.contact)).toHaveLength(3);
    expect(contactSound(group.sounds)).toEqual(['bladeContact']);
    expect(group.state.hitstop).toBe(solo.state.hitstop);
    for (let frame = 0; frame < 24; frame++) group.game.update(DT, EMPTY_INPUT);
    expect(group.state.hitstop).toBe(0);
    expect(contactSound(group.sounds)).toEqual(['bladeContact']);
  });

  it.each(['blade', 'ember', 'disc'] as const)('leaves original red-hat contact untouched for %s and legacy runs', weapon => {
    for (const character of ['traveller', undefined] as const) {
      const run = arena(character, weapon, [target(ranged(weapon) ? 420 : 350)]);
      attack(run.game);
      expect(run.state.enemies[0].hp).toBeLessThan(HP);
      expect(run.state.impacts.some(impact => impact.contact)).toBe(false);
      expect(run.state.impacts.some(impact => impact.kind === 'hit')).toBe(true);
      expect(run.sounds).toContain('hit');
      expect(contactSound(run.sounds)).toEqual([]);
      expect(run.state.hitstop).toBe(.035);
    }
  });
});
