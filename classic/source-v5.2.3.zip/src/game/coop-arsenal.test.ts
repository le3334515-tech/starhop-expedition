import { describe, expect, it } from 'vitest';
import { GameEngine } from './engine';
import { EMPTY_INPUT, type Enemy, type WeaponId } from './types';

const target = (id: number, x: number): Enemy => ({
  id, x, y: 406, w: 30, h: 42, kind: 'sentry', hp: 100, maxHp: 100, vx: 0, vy: 0,
  facing: -1, timer: 0, hurt: 0, dead: false, originX: x, originY: 406, attackCooldown: 99,
});

function arena(weapon: WeaponId, enemies: Enemy[]) {
  const game = new GameEngine();
  game.startCoop({ seed: 42, modifier: 'standard', weapon }, 2);
  const state = game.state;
  Object.assign(state.hero, { x: 300, y: 448 - state.hero.h, facing: 1, grounded: true, critChance: 0 });
  state.room.platforms = [{ x: 0, y: 448, w: state.room.width, h: 120, kind: 'ground' }];
  state.room.hazards = [];
  state.enemies = enemies;
  state.pickups = [];
  return game;
}

function strike(game: GameEngine, step = 1) {
  Object.assign(game.state.hero, { attackStep: step - 1, comboWindow: 1 });
  game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
}

describe('co-op character arsenal', () => {
  it.each(['fan', 'sabre', 'fist'] as const)('restricts %s to co-op', weapon => {
    const game = new GameEngine();
    game.start({ seed: 42, modifier: 'standard', weapon });
    expect(game.state.hero.weapon).toBe('blade');
    game.equipWeapon(weapon);
    expect(game.state.hero.weapon).toBe('blade');
    game.startCoop({ seed: 42, modifier: 'standard', weapon }, 2);
    game.equipWeapon('disc');
    expect(game.state.hero.weapon).toBe(weapon);
  });

  it('gives the long sabre wider coverage and recovery than the short blade', () => {
    const bladeTarget = target(901, 406), sabreTarget = target(902, 406);
    const blade = arena('blade', [bladeTarget]), sabre = arena('sabre', [sabreTarget]);
    strike(blade); strike(sabre);
    expect(bladeTarget.hp).toBe(100);
    expect(sabreTarget.hp).toBeLessThan(100);
    expect(sabre.state.hero.attackCooldown).toBeGreaterThan(blade.state.hero.attackCooldown);
  });

  it('keeps quick fists close and gives the third strike wider heavy impact', () => {
    const near = target(903, 350), outer = target(904, 378);
    const quick = arena('fist', [near, outer]);
    const heavyTarget = target(905, 378);
    const heavy = arena('fist', [heavyTarget]);
    strike(quick); strike(heavy, 3);
    expect(near.hp).toBeLessThan(100);
    expect(outer.hp).toBe(100);
    expect(heavyTarget.hp).toBeLessThan(near.hp);
    expect(heavy.state.impacts.some(impact => impact.kind === 'heavy')).toBe(true);
  });

  it('casts one-way fan waves with a wider piercing third cast', () => {
    const firstTargets = [target(906, 388), target(907, 449)];
    const thirdTargets = [target(908, 388), target(909, 449)];
    const normal = arena('fan', firstTargets), heavy = arena('fan', thirdTargets);
    strike(normal); strike(heavy, 3);
    expect(normal.state.projectiles[0]).toMatchObject({ kind: 'fan', pierce: 1 });
    expect(heavy.state.projectiles[0]).toMatchObject({ kind: 'fan', style: 'charged', pierce: 3 });
    expect(heavy.state.projectiles[0].h).toBeGreaterThan(normal.state.projectiles[0].h);
    for (let i = 0; i < 48; i++) {
      normal.update(1 / 120, EMPTY_INPUT);
      heavy.update(1 / 120, EMPTY_INPUT);
    }
    expect(firstTargets[0].hp).toBeLessThan(100);
    expect(firstTargets[1].hp).toBe(100);
    expect(thirdTargets.every(enemy => enemy.hp < 100 && !enemy.burnTime)).toBe(true);
    expect(heavy.state.projectiles.every(wave => !wave.returning && wave.vx > 0)).toBe(true);
  });
});
