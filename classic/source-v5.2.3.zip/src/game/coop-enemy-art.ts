import type { CoopEnemyAppearance } from './enemy-catalog';
import type { Enemy } from './types';

const SIZE = 40;
const CENTER = 20;
const FOOT = 36;
const INK = '#171824';
const BRONZE = '#94615a';
const OCHRE = '#c78554';
const GOLD = '#ecb776';
const CREAM = '#ffe5ab';
const JADE = '#6b9d89';
const DARK_JADE = '#345c59';
const PAPER = '#cbdfce';
const PAPER_SHADE = '#789f9d';

type Point = readonly [x: number, y: number];

function bar(c: CanvasRenderingContext2D, color: string, x: number, y: number, w: number, h: number) {
  c.fillStyle = color;
  c.fillRect(x, y, w, h);
}

function facet(c: CanvasRenderingContext2D, color: string, points: readonly Point[]) {
  c.fillStyle = color;
  c.beginPath();
  c.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) c.lineTo(points[i][0], points[i][1]);
  c.closePath();
  c.fill();
}

function forgeCrab(c: CanvasRenderingContext2D, e: Enemy) {
  const walking = Math.abs(e.vx) > 12;
  const stride = walking ? Math.floor(e.timer * 11) % 2 : -1;
  const guard = e.aiMode !== 'attack' && e.aiMode !== 'recover';
  const forward = e.aiMode === 'attack' ? 3 : e.aiMode === 'windup' ? -2 : 0;
  // Squat feet keep the bronze furnace above the floor.
  for (let i = 0; i < 3; i++) {
    const x = -10 + i * 8;
    const y = stride === i % 2 ? -2 : 0;
    facet(c, INK, [[x - 2,-9],[x + 3,-9],[x + 4,-4],[x + 2,y],[x - 4,y],[x - 4,y - 2],[x - 1,-4]]);
    bar(c, BRONZE, x - 2, y - 3, 4, 2);
    bar(c, OCHRE, x - 1, y - 3, 3, 1);
  }
  c.save();
  c.translate(forward, e.aiMode === 'windup' ? 1 : 0);
  facet(c, INK, [[-12,-9],[-13,-13],[-10,-19],[-5,-21],[7,-21],[11,-17],[13,-10],[10,-6],[-9,-6]]);
  facet(c, BRONZE, [[-11,-12],[-8,-18],[-4,-20],[7,-20],[10,-16],[11,-11],[7,-8],[-8,-8]]);
  facet(c, DARK_JADE, [[-10,-13],[-7,-18],[-3,-19],[5,-19],[8,-16],[1,-14],[-6,-11]]);
  bar(c, JADE, -6, -18, 8, 2);
  bar(c, GOLD, -7, -19, 11, 1);
  // The coal grate gives the shell a bright center and leaves the claw easy to read.
  bar(c, INK, -2, -14, 10, 6);
  bar(c, OCHRE, -1, -12, 8, 3);
  bar(c, CREAM, 1, -11, e.aiMode === 'windup' ? 6 : 3, 1);
  bar(c, BRONZE, 2, -13, 1, 5);
  bar(c, BRONZE, 5, -13, 1, 5);
  const claw = guard ? -2 : 2;
  facet(c, INK, [[7,-10],[10,-14],[16,-14 + claw],[17,-10 + claw],[15,-8 + claw],[17,-5],[13,-4],[9,-6]]);
  facet(c, OCHRE, [[9,-10],[12,-13],[15,-13 + claw],[16,-11 + claw],[13,-9 + claw],[15,-6],[13,-5]]);
  bar(c, GOLD, 12, -10, 3, 1);
  c.restore();
}

function forgeLantern(c: CanvasRenderingContext2D, e: Enemy) {
  const sway = Math.round(Math.sin(e.timer * (e.aiMode === 'windup' ? 9 : 4)));
  const open = e.aiMode === 'windup' || e.aiMode === 'attack';
  // A little pavilion roof caps the hollow lamp cage and its silk tassel.
  facet(c, INK, [[-13,-23],[-9,-25],[-5,-31],[-1,-32],[-1,-35],[2,-35],[2,-31],[6,-30],[10,-25],[13,-23],[12,-21],[-13,-21]]);
  facet(c, DARK_JADE, [[-11,-23],[-7,-25],[-4,-29],[5,-29],[8,-25],[11,-23]]);
  bar(c, JADE, -5, -29, 10, 1);
  bar(c, GOLD, -11, -23, 22, 2);
  bar(c, OCHRE, 0, -34, 1, 5);
  facet(c, INK, [[-9,-23],[9,-23],[10,-18],[7,-10],[4,-8],[-5,-8],[-8,-12],[-10,-18]]);
  facet(c, open ? OCHRE : BRONZE, [[-7,-21],[7,-21],[8,-17],[6,-11],[3,-9],[-4,-9],[-6,-11],[-8,-17]]);
  facet(c, open ? CREAM : GOLD, [[0,-21],[5,-19],[5,-13],[0,-10],[-5,-13],[-5,-19]]);
  facet(c, '#a74e4d', [[0,-20],[3,-17],[0,-13],[-3,-17]]);
  bar(c, CREAM, -1, -18, 2, 2);
  bar(c, INK, -7, -21, 2, 11);
  bar(c, INK, 6, -21, 2, 11);
  bar(c, GOLD, -6, -10, 12, 1);
  bar(c, BRONZE, -2, -8, 4, 2);
  facet(c, '#a85d59', [[-2,-7],[2,-7],[3 + sway,-3],[2 + sway,0],[-3 + sway,-1]]);
  bar(c, GOLD, sway - 1, -4, 3, 1);
  if (open) {
    for (const side of [-1, 1]) {
      bar(c, GOLD, side * 12 - 1, -17, 3, 2);
      bar(c, OCHRE, side * 15 - 1, -14, 2, 2);
    }
  }
}

function moonKite(c: CanvasRenderingContext2D, e: Enemy) {
  const flap = [-4, -1, 3, 0][Math.floor(e.timer * 12) % 4];
  const dive = e.aiMode === 'attack';
  const tuck = e.aiMode === 'windup' ? 2 : 0;
  const wing = dive ? -3 : flap + tuck;
  const nose = dive ? -12 : -17;
  // Paper facets and a patinated brass frame read separately at night.
  facet(c, INK, [[-19,-11 + flap],[-15,-15],[-16,-21 + wing],[-9,-29 + wing],[0,-19],[6,-22],[12,-21],[18,nose],[13,nose + 3],[7,-12],[2,-9],[-8,-11],[-13,-8],[-19,-9]]);
  facet(c, DARK_JADE, [[-16,-11 + flap],[-12,-14],[-8,-13],[-13,-9],[-19,-10 + flap]]);
  facet(c, PAPER_SHADE, [[-13,-19 + wing],[-9,-27 + wing],[-1,-18],[0,-13],[-7,-14]]);
  facet(c, PAPER, [[-10,-25 + wing],[-8,-26 + wing],[-1,-18],[-1,-15],[-7,-18]]);
  facet(c, JADE, [[-8,-15],[-1,-17],[6,-20],[11,-19],[15,nose],[8,-14],[2,-11],[-5,-12]]);
  facet(c, PAPER, [[0,-17],[6,-20],[11,-18],[12,nose + 1],[7,-15],[2,-13]]);
  bar(c, GOLD, 7, -19, 5, 1);
  bar(c, CREAM, 9, -18, 2, 1);
  bar(c, OCHRE, -4, -16, 4, 1);
  // The two short streamers stay readable when the wing folds.
  const trail = Math.round(Math.sin(e.timer * 7) * 2);
  facet(c, BRONZE, [[-8,-12],[-11,-9],[-16,-7 + trail],[-19,-4 + trail],[-14,-5 + trail],[-9,-7],[-5,-11]]);
  facet(c, '#a6c7bd', [[-3,-11],[-5,-7],[-9,-4 - trail],[-11,-3 - trail],[-9,-6 - trail],[-7,-7],[-5,-11]]);
  if (dive) bar(c, GOLD, 15, nose + 1, 3, 1);
}

let raster: CanvasRenderingContext2D | null = null;
const PAINTERS: Record<CoopEnemyAppearance, (c: CanvasRenderingContext2D, e: Enemy) => void> = {
  'forge-crab': forgeCrab,
  'forge-lantern': forgeLantern,
  'moon-kite': moonKite,
};

/** Original co-op sprites are drawn at native pixel size and scaled without interpolation. */
export function drawCoopEnemy(c: CanvasRenderingContext2D, e: Enemy, appearance: CoopEnemyAppearance): boolean {
  if (!raster) {
    const surface = c.canvas.ownerDocument.createElement('canvas');
    surface.width = surface.height = SIZE;
    raster = surface.getContext('2d');
  }
  if (!raster) return false;
  raster.clearRect(0, 0, SIZE, SIZE);
  raster.save();
  raster.translate(CENTER, FOOT);
  PAINTERS[appearance](raster, e);
  if (e.hurt > .085) {
    raster.globalCompositeOperation = 'source-atop';
    bar(raster, '#ffd99b66', -CENTER, -FOOT, SIZE, SIZE);
  }
  raster.restore();

  const x = Math.round(e.x + e.w / 2), foot = Math.round(e.y + e.h);
  const airborne = e.kind === 'bat';
  const scale = airborne ? 1.5 : 2;
  c.save();
  c.translate(x, foot);
  if (!airborne) bar(c, '#15181966', -18, -1, 34, 3);
  c.scale(e.facing || 1, 1);
  c.imageSmoothingEnabled = false;
  // Center the bright body on its hitbox. Tassels and roof trim can extend past it.
  c.drawImage(raster.canvas, -CENTER * scale, -FOOT * scale + (airborne ? 8 : 0), SIZE * scale, SIZE * scale);
  c.restore();
  return true;
}
