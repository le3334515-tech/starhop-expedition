import { describe, expect, it } from 'vitest';
import { BOSS_ASCENSION_TIME, BOSS_TRANSFORM_TIME, ECLIPSE_WIDTH, eclipseLanes } from './boss-seal';
import { COOP_EXTRA_REALMS, COOP_ROOM_COUNT, createCoopRoom } from './coop-levels';
import { GameEngine } from './engine';
import { enemyProfile } from './enemy-catalog';
import { createRoom, isSafeFloorPoint } from './levels';
import { EMPTY_INPUT, EXPEDITION_ROOM_COUNT, type Enemy, type GameConfig, type InputState } from './types';

const CONFIG: GameConfig = { seed: 20261116, modifier: 'standard', weapon: 'blade' };

function advance(game: GameEngine, seconds: number, input: Partial<InputState> = {}) {
  const steps = Math.ceil(seconds * 120);
  for (let step = 0; step < steps; step++) {
    game.update(seconds / steps, { ...EMPTY_INPUT, ...input, attackPressed: step === 0 && !!input.attackPressed });
  }
}

function strikeBoss(game: GameEngine) {
  const { hero, boss } = game.state;
  if (!boss) throw new Error('Expected boss room');
  hero.x = boss.x - 35; hero.y = 412; hero.vx = 0; hero.vy = 0;
  hero.hp = hero.maxHp; hero.invincible = 2; hero.facing = 1;
  hero.attackCooldown = 0; hero.attackTimer = 0; hero.damage = 100000;
  advance(game, .15, { attackPressed: true });
}

describe('cooperative realms', () => {
  it('spawns original furnace monsters and moon kites only in their co-op realms', () => {
    const expected = [
      [['skyforge-crab', 'forge-crab', 'guard', 'sentry'], ['skyforge-lantern', 'forge-lantern', 'burst', 'bat']],
      [['moonbridge-kite', 'moon-kite', 'dive', 'bat']],
    ];
    for (let index = 0; index < EXPEDITION_ROOM_COUNT; index++) {
      expect(createRoom(CONFIG.seed, index).enemies.some(enemy => enemyProfile(enemy)?.appearance)).toBe(false);
      expect(createCoopRoom(CONFIG.seed, index, 4).enemies.some(enemy => enemyProfile(enemy)?.appearance)).toBe(false);
    }
    for (const [index, forms] of expected.entries()) {
      const { enemies } = createCoopRoom(CONFIG.seed, EXPEDITION_ROOM_COUNT + index, 1);
      const appearances = enemies.filter(enemy => enemyProfile(enemy)?.appearance);
      expect(new Set(appearances.map(enemy => enemy.variant))).toEqual(new Set(forms.map(([id]) => id)));
      for (const [id, appearance, ability, kind] of forms) {
        const roster = appearances.filter(enemy => enemy.variant === id);
        expect(roster.length).toBeGreaterThan(0);
        expect(roster.every(enemy => enemy.kind === kind)).toBe(true);
        expect(enemyProfile(roster[0])).toMatchObject({ appearance, ability });
      }
    }
  });

  it('opens three authored realms after the classic eight and preserves both bosses', () => {
    const game = new GameEngine();
    game.start(CONFIG);
    game.forceCoopRoom(7);
    expect(game.state.roomCount).toBe(EXPEDITION_ROOM_COUNT);
    expect(game.state.roomIndex).toBe(0);
    game.startCoop(CONFIG, 4);
    expect(game.state.roomCount).toBe(COOP_ROOM_COUNT);
    expect(game.state.room.platforms).toEqual(createRoom(CONFIG.seed, 0).room.platforms);
    for (let i = 7; i < COOP_ROOM_COUNT; i++) {
      game.forceCoopRoom(i);
      expect(game.state.room.index).toBe(i);
      expect(game.state.room.isBoss).toBe(i === 7 || i === 10);
      if (i >= 8) expect(game.state.room.name).toBe(COOP_EXTRA_REALMS[i - 8]);
    }
    expect(game.state.boss?.kind).toBe('warden');
    expect(game.state.roomsCleared).toBe(10);
  });

  it.each([1, 2, 3, 4])('doubles all spawns after applying the %i-player scale', size => {
    const game = new GameEngine();
    game.startCoop(CONFIG, size);
    for (let index = 0; index < COOP_ROOM_COUNT; index++) {
      game.forceCoopRoom(index);
      const base = createCoopRoom(CONFIG.seed, index, size);
      expect(game.state.enemies.map(({id, hp, maxHp}) => [id, hp, maxHp]))
        .toEqual(base.enemies.map(({id, hp, maxHp}) => [id, hp * 2, maxHp * 2]));
    }
    expect(game.state.boss?.kind).toBe('warden');
  });

  it.each([8, 9])('places scaled encounters and aerial mechanisms safely in realm %i', index => {
    const first = createCoopRoom(CONFIG.seed, index, 1);
    const group = createCoopRoom(CONFIG.seed, index, 4);
    expect(group).toEqual(createCoopRoom(CONFIG.seed, index, 4));
    expect(group.room).toEqual(first.room);
    expect(group.enemies.length).toBe(first.enemies.length + 3);
    for (const enemy of group.enemies) {
      if (enemy.kind !== 'bat') expect(isSafeFloorPoint(group.room, enemy.x, enemy.w)).toBe(true);
      const base = first.enemies.find(entry => entry.id === enemy.id);
      if (base) expect(enemy.hp).toBeGreaterThan(base.hp);
    }
    expect(group.room.hazards.some(hazard => hazard.kind === 'mechanism' && hazard.y + hazard.h < 448)).toBe(true);
    expect(group.room.platforms.some(p => p.kind === 'ground' && p.x <= group.room.exit.x &&
      p.x + p.w >= group.room.exit.x + group.room.exit.w)).toBe(true);
  });

  it.each([8, 9])('reaches the exit by jumping across the authored gaps in realm %i', index => {
    const game = new GameEngine();
    game.startCoop(CONFIG, 4);
    game.forceCoopRoom(index);
    const state = game.state, hero = state.hero;
    state.enemies = [];
    hero.hp = hero.maxHp = 99;
    const floor = state.room.platforms.filter(platform => platform.kind === 'ground');
    let keepJumpingUntil = 0, lastJump = -1;
    for (let frame = 0; frame < 60 * 35 && hero.x < state.room.exit.x; frame++) {
      const ahead = hero.x + hero.w / 2 + 72;
      const gap = (x: number) => !floor.some(p => x >= p.x && x <= p.x + p.w);
      const spikesAhead = state.room.hazards.some(h => h.kind === 'spikes' && ahead > h.x - 12 && ahead < h.x + h.w + 12);
      const jump = hero.grounded && state.time - lastJump > .52 && (gap(ahead) || spikesAhead)
        || (!hero.grounded && hero.jumps < 2 && hero.vy > 100 && gap(hero.x + hero.w / 2) && state.time - lastJump > .18);
      if (jump) { lastJump = state.time; keepJumpingUntil = state.time + .27; }
      game.update(1 / 60, { ...EMPTY_INPUT, right: true, jumpPressed: jump, jumpHeld: state.time < keepJumpingUntil });
    }
    expect(hero.x).toBeGreaterThanOrEqual(state.room.exit.x);
    expect(state.deaths).toBe(0);
  });

  it('requires the final boss and caps each phase before the next transformation', () => {
    const game = new GameEngine();
    game.startCoop(CONFIG, 4);
    game.forceCoopRoom(7);
    const old = game.state.boss!;
    const oldPhaseOne = old.maxHp;
    strikeBoss(game);
    expect(old).toMatchObject({ phase: 2, mode: 'transition' });
    advance(game, BOSS_TRANSFORM_TIME);
    strikeBoss(game);
    expect(old).toMatchObject({ phase: 3, mode: 'transition' });
    advance(game, BOSS_ASCENSION_TIME);
    strikeBoss(game);
    expect(game.state.roomCleared).toBe(true);
    expect(game.state.roomsCleared).toBe(8);
    expect(game.state.result).toBeNull();
    expect(game.state.phase).toBe('playing');
    game.forceCoopRoom(10);
    const warden = game.state.boss!;
    expect(warden.maxHp).toBeGreaterThan(oldPhaseOne);
    expect(warden.guard).toBeGreaterThan(50);
    strikeBoss(game);
    expect(warden.phase).toBe(2);
    expect(warden.hp).toBe(warden.maxHp);
    expect(warden.maxHp).toBeGreaterThan(old.maxHp);
    advance(game, BOSS_TRANSFORM_TIME);
    strikeBoss(game);
    expect(warden).toMatchObject({ phase: 3, mode: 'transition', hp: warden.maxHp / 2 });
    advance(game, BOSS_ASCENSION_TIME);
    strikeBoss(game);
    expect(game.state.result).toMatchObject({ won: true, roomsCleared: COOP_ROOM_COUNT });
  });

  it('locks scaled boss health, telegraph tempo and seven safe lanes to the party at the start', () => {
    const games = [1, 2, 3, 4].map(size => {
      const game = new GameEngine();
      game.startCoop(CONFIG, size);
      game.forceCoopRoom(10);
      game.state.hero.x = 700;
      const boss = game.state.boss!;
      boss.phase = 3; boss.form = 2; boss.timer = 0;
      advance(game, .01);
      return game;
    });
    for (let i = 1; i < games.length; i++) {
      expect(games[i].state.boss!.maxHp).toBeGreaterThan(games[i - 1].state.boss!.maxHp);
      expect(games[i].state.boss!.timer).toBeLessThan(games[i - 1].state.boss!.timer);
    }
    const last = games[3], boss = last.state.boss!;
    expect(boss).toMatchObject({ intent: 'eclipse', mode: 'windup' });
    const lanes = eclipseLanes(boss, last.state.room.width);
    expect(lanes).toHaveLength(7);
    for (let i = 1; i < lanes.length; i++) expect(lanes[i] - lanes[i - 1] - ECLIPSE_WIDTH).toBeGreaterThan(last.state.hero.w);
    advance(last, .75);
    const blades = last.state.projectiles.filter(shot => shot.style === 'eclipse');
    expect(blades).toHaveLength(7);
    expect(blades.every(shot => shot.damage === 2 && shot.delay! > 0)).toBe(true);
  });
});

describe('cooperative long spear', () => {
  it('pierces enemies along the thrust while fixed to its own cooperative role', () => {
    const game = new GameEngine();
    game.startCoop({ ...CONFIG, weapon: 'spear' }, 4);
    game.equipWeapon('blade');
    expect(game.state.hero.weapon).toBe('spear');
    const state = game.state;
    const spawn = (id: number, x: number, y: number): Enemy => ({
      id, x, y, w: 20, h: 20, kind: 'sentry', originX: x, originY: y, hp: 20, maxHp: 20,
      vx: 0, vy: 0, facing: 1, timer: 0, hurt: 0, dead: false, attackCooldown: 99,
    });
    state.hero.x = 110; state.hero.y = 412; state.hero.critChance = 0;
    state.enemies = [spawn(1, 222, 428), spawn(2, 246, 428), spawn(3, 222, 360), spawn(4, 73, 428)];
    advance(game, .11, { attackPressed: true });
    expect(state.hero.attackStep).toBe(1);
    expect(state.enemies.map(enemy => enemy.hp)).toEqual([17.3324, 17.3324, 20, 20]);
    game.start({ ...CONFIG, weapon: 'spear' });
    expect(game.state.hero.weapon).toBe('blade');
  });
});
