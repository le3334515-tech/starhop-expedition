import type { CharacterId, Hero } from './types';

type Traveller = Exclude<CharacterId, 'traveller'>;
type Trace = (ctx: CanvasRenderingContext2D, reach: number, quiet: boolean) => void;

const palette: Record<Traveller, { light: string; shadow: string }> = {
  blade: { light: '#d3e4ca', shadow: '#6dafa5' },
  staff: { light: '#edddf2', shadow: '#a498ca' },
  wheel: { light: '#eff2c9', shadow: '#78cdb1' },
  spear: { light: '#eff0db', shadow: '#82a8d3' },
  monk: { light: '#f0d396', shadow: '#b77c54' },
};

function stroke(c: CanvasRenderingContext2D, points: number[], width: number) {
  c.lineWidth = width;
  c.beginPath();
  c.moveTo(points[0], points[1]);
  for (let i = 2; i < points.length; i += 2) c.lineTo(points[i], points[i + 1]);
  c.stroke();
}

function crescent(c: CanvasRenderingContext2D, x: number, y: number, r: number) {
  c.beginPath(); c.moveTo(x + r * .68, y - r);
  c.quadraticCurveTo(x - r * 1.32, y - r * .45, x - r * .63, y + r * .53);
  c.quadraticCurveTo(x - r * .18, y + r * 1.02, x + r * .99, y + r * .57);
  c.quadraticCurveTo(x - r * .15, y + r * .47, x - r * .32, y - r * .16);
  c.quadraticCurveTo(x - r * .28, y - r * .69, x + r * .68, y - r);
  c.fill();
}

function feather(c: CanvasRenderingContext2D, tail: number, tip: number, height: number, angle: number) {
  c.save();
  c.translate(tip, height);
  c.rotate(angle);
  c.beginPath(); c.moveTo(-tail, 0);
  c.quadraticCurveTo(-tail * .55, -11, 0, -1);
  c.quadraticCurveTo(-tail * .37, 7, -tail, 0);
  c.fill();
  stroke(c, [-tail + 4, 0, -tail / 3, -2, -3, -1], .8);
  c.restore();
}

function octagon(c: CanvasRenderingContext2D, x: number, y: number, radius: number) {
  const half = radius * .53;
  stroke(c, [x-radius,y, x-half,y-4, x+half,y-4, x+radius,y, x+half,y+4, x-half,y+4, x-radius,y], 1.3);
}

const traces: Record<Traveller, Trace> = {
  blade(c, reach, quiet) {
    c.strokeStyle = palette.blade.shadow;
    stroke(c, [-reach,-12, -reach * .66,-24, -reach * .36,-19, -6,-29], 3.4);
    c.strokeStyle = palette.blade.light;
    stroke(c, [-reach + 8,-13, -reach * .66,-23, -reach * .36,-18, -6,-29], 1.35);
    if (!quiet) {
      stroke(c, [-reach * .90,-29, -reach * .77,-36, -reach * .57,-33], 1.15);
      c.fillStyle = '#ccb98d'; c.fillRect(-reach * .77, -37, 3, 2);
    }
  },
  staff(c, reach, quiet) {
    c.fillStyle = palette.staff.shadow; crescent(c, -reach * .69, -21, 14);
    c.fillStyle = palette.staff.light; crescent(c, -reach * .29, -28, 16);
    if (!quiet) {
      c.fillRect(-reach * .54, -40, 2, 2);
      c.fillRect(-reach * .84, -17, 3, 2);
      c.fillRect(-reach * .91, -31, 2, 2);
    }
  },
  wheel(c, reach, quiet) {
    c.fillStyle = palette.wheel.shadow;
    c.strokeStyle = palette.wheel.light;
    feather(c, reach * .68, -8, -22, -.18);
    feather(c, reach * .47, -16, -37, .31);
    if (!quiet) feather(c, reach * .44, -10, -12, -.45);
  },
  spear(c, reach, quiet) {
    c.strokeStyle = palette.spear.shadow;
    stroke(c, [-reach,-18, -7,-18], 2.9);
    stroke(c, [-reach*.87,-29, -17,-29], 1.8);
    c.strokeStyle = palette.spear.light;
    stroke(c, [-reach*.72,-18, -7,-18, -15,-22], 1);
    if (!quiet) stroke(c, [-reach*.75,-8, -19,-8], 1);
  },
  monk(c, reach, quiet) {
    c.strokeStyle = palette.monk.light; octagon(c, -reach*.28, -2, 16);
    if (!quiet) {
      c.strokeStyle = palette.monk.shadow; octagon(c, -reach*.71, 2, 12);
      stroke(c, [-reach*.54,-3, -reach*.43,-10, -reach*.37,-6], 1.2);
      c.fillStyle = '#aa7556'; c.fillRect(-reach*.86,-7,4,3); c.fillRect(-reach*.53,-14,3,3);
    }
  },
};

function perfect(c: CanvasRenderingContext2D, role: Traveller, size: number) {
  switch (role) {
    case 'blade':
      stroke(c, [-size,10, -6,-3, -16,-5, size,-16], 2);
      stroke(c, [-size*.63,-13, -12,-7, -21,-6], 1);
      break;
    case 'staff':
      crescent(c, -4, -1, size);
      c.fillRect(size*.6, -size*.51, 3, 3);
      break;
    case 'wheel':
      feather(c, size*1.6, size*.65, 0, .52);
      feather(c, size*1.6, size*.65, 1, -.56);
      break;
    case 'spear':
      for (let y = -9; y <= 9; y += 9) stroke(c, [-size,y, size,y, size-6,y-3], y ? 1 : 2);
      break;
    case 'monk':
      octagon(c, -2, 13, size);
      stroke(c, [-size,14, -size*.56,4, -5,9, 3,0, 12,6, size,3], 2);
      break;
  }
}

export function drawCharacterDodge(c: CanvasRenderingContext2D, character: CharacterId | undefined | null, hero: Hero, quiet: boolean) {
  if (!character || character === 'traveller' || hero.hp <= 0) return;
  if (hero.dashTimer > 0) {
    const phase = Math.max(0, 1 - hero.dashTimer / .18);
    c.save();
    c.translate(Math.round(hero.x + hero.w / 2), Math.round(hero.y + hero.h));
    c.scale(hero.facing || 1, 1);
    c.globalAlpha *= Math.sin(Math.PI * (.24 + .76 * phase)) * (quiet ? .53 : .93);
    traces[character](c, 29 + 53 * phase, quiet);
    c.restore();
  }
  const cue = hero.dodgeCue;
  if (cue && cue.life > 0) {
    const remaining = Math.min(1, cue.life / .38);
    c.save();
    c.translate(Math.round(cue.x), Math.round(cue.y));
    c.scale(cue.facing || 1, 1);
    c.globalAlpha *= remaining * (quiet ? .56 : .9);
    c.strokeStyle = c.fillStyle = palette[character].light;
    perfect(c, character, quiet ? 17 : 17 + (1 - remaining) * 20);
    c.restore();
  }
}
