import { artImage } from './art-assets';
import type { Hero, Impact } from './types';

const clamp01 = (value: number) => Math.max(0, Math.min(1, value));

/** Pimen's four-frame contact animations, kept small so enemy poses stay readable. */
export function drawArtImpact(ctx: CanvasRenderingContext2D, effect: Impact): boolean {
  const progress = 1 - clamp01(effect.life / effect.maxLife);
  const strong = effect.kind !== 'hit';
  const breaking = effect.kind === 'break';
  const file = breaking ? 'impact-ring' : effect.kind === 'heavy' ? 'impact-star' : effect.kind === 'critical' ? 'impact-shard' : 'impact-spark';
  const sprite = artImage(`effects/${file}.png`);
  if (!sprite) return false;
  const frameWidth = sprite.naturalWidth / 4;
  const frame = Math.min(3, Math.floor(progress * 4));
  const scale = breaking ? 2.3 : effect.kind === 'heavy' ? 2 : strong ? 1.9 : 1.45;
  const w = frameWidth * scale;
  const h = sprite.naturalHeight * scale;
  ctx.save();
  ctx.translate(Math.round(effect.x), Math.round(effect.y));
  ctx.rotate(effect.angle + (effect.kind === 'critical' ? -.3 : 0));
  ctx.imageSmoothingEnabled = false;
  ctx.globalAlpha *= Math.min(1, (1 - progress) * 3.6);
  ctx.drawImage(sprite, frame * frameWidth, 0, frameWidth, sprite.naturalHeight, -w / 2, -h / 2, w, h);
  if (breaking) {
    // A second oblique ring makes a guard break distinct without an opaque flash.
    ctx.rotate(Math.PI / 2);
    ctx.globalAlpha *= .64;
    ctx.drawImage(sprite, frame * frameWidth, 0, frameWidth, sprite.naturalHeight, -w * .42, -h * .42, w * .84, h * .84);
  }
  ctx.restore();
  return true;
}

/** Seven hand animated frames; alternating direction and palette follow the combo. */
export function drawArtSlash(ctx: CanvasRenderingContext2D, hero: Hero, _now: number): boolean {
  if (hero.weapon !== 'blade' || hero.attackTimer <= 0) return false;
  const step = Math.max(1, Math.min(3, hero.attackStep));
  const heavy = step === 3;
  const duration = heavy ? .28 : .18;
  const progress = 1 - clamp01(hero.attackTimer / duration);
  const sprite = artImage(`effects/slash-${heavy ? 'cinnabar' : step === 2 ? 'jade' : 'ivory'}.png`);
  if (!sprite) return false;
  const frame = Math.min(6, Math.floor(progress * 7));
  const size = heavy ? 108 : 84;
  ctx.save();
  ctx.translate(Math.round(hero.x + hero.w / 2), Math.round(hero.y + hero.h * .46));
  ctx.scale(hero.facing || 1, step === 2 ? -1 : 1);
  ctx.rotate(heavy ? .28 : step === 2 ? -.18 : -.36);
  ctx.imageSmoothingEnabled = false;
  ctx.globalAlpha *= heavy ? .98 : .9;
  // The transparent center remains close to the sword hand; the arc sweeps outward.
  ctx.drawImage(sprite, frame * 64, 0, 64, 64, -size * .12, -size * .55, size, size);
  if (heavy && progress < .62) {
    ctx.globalAlpha *= .32;
    ctx.rotate(-.19);
    const echo = Math.max(0, frame - 1);
    ctx.drawImage(sprite, echo * 64, 0, 64, 64, -size * .1, -size * .6, size * 1.07, size * 1.07);
  }
  ctx.restore();
  return true;
}
