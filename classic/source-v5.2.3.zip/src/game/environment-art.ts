import { artImage } from './art-assets';
import type { Decoration, Platform } from './types';

const W = 960, H = 540;
const image = (name: string) => artImage(`environment/${name}`);
const mod = (n: number, divisor: number) => ((n % divisor) + divisor) % divisor;
const panels = new Map<string, HTMLCanvasElement>();

/** Environment art uses authored pixel sprites; effects only light and frame those sprites. */
function stamp(c: CanvasRenderingContext2D, name: string, x: number, y: number, width: number, height?: number, alpha = 1) {
  const sprite = image(name);
  if (!sprite) return false;
  c.save(); c.globalAlpha *= alpha;
  c.drawImage(sprite, Math.round(x), Math.round(y), Math.round(width), Math.round(height ?? width * sprite.height / sprite.width));
  c.restore(); return true;
}

function slice(c: CanvasRenderingContext2D, name: string, sx: number, sy: number, sw: number, sh: number, x: number, y: number, w: number, h: number) {
  const sprite = image(name);
  if (sprite) c.drawImage(sprite, sx, sy, sw, sh, Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

function layer(c: CanvasRenderingContext2D, name: string, camera: number, speed: number, y: number, height: number, alpha = 1) {
  const sprite = image(name);
  if (!sprite) return;
  const width = Math.round(sprite.width * height / sprite.height);
  const start = -Math.round(mod(camera * speed, width));
  for (let x = start; x < W; x += width) stamp(c, name, x, y, width, height, alpha);
}

function glow(c: CanvasRenderingContext2D, x: number, y: number, radius: number, color: string, alpha = 1) {
  const light = c.createRadialGradient(x, y, 0, x, y, radius);
  light.addColorStop(0, color); light.addColorStop(1, color.slice(0, 7) + '00');
  c.save(); c.globalAlpha *= alpha; c.fillStyle = light;
  c.fillRect(x-radius, y-radius, radius*2, radius*2); c.restore();
}

function lantern(c: CanvasRenderingContext2D, x: number, y: number, now: number, scale = 1) {
  const s = scale, bob = Math.sin(now * 1.3 + x * .03) * 2;
  x = Math.round(x); y = Math.round(y + bob);
  glow(c, x, y+14*s, 54*s, '#f29c6460', .6);
  c.fillStyle = '#8d7350'; c.fillRect(x-s, y-25*s, 2*s, 25*s);
  c.fillStyle = '#713c3a'; c.fillRect(x-9*s, y+1*s, 18*s, 24*s);
  c.fillStyle = '#c85e49'; c.fillRect(x-7*s, y+3*s, 14*s, 20*s);
  c.fillStyle = '#edb97a'; c.fillRect(x-2*s,y+4*s,4*s,18*s);
  c.fillStyle = '#b9a06b'; c.fillRect(x-10*s,y,20*s,3*s); c.fillRect(x-10*s,y+24*s,20*s,3*s);
  c.fillStyle = '#b35845'; c.fillRect(x-s,y+27*s,2*s,10*s);
}

function sky(c: CanvasRenderingContext2D, name: string, shade: string) {
  stamp(c, name, 0, 0, W, H);
  c.fillStyle = shade; c.fillRect(0,0,W,H);
}

function trees(c: CanvasRenderingContext2D, camera: number, color: 'green' | 'gold' | 'red', y = 455, alpha = .68, spacing = 270) {
  const offset = Math.round(mod(camera * .28, spacing));
  for (let i=-1;i<5;i++) {
    const height = 254 + (i % 2 ? 76 : 0), width = height * 112/368;
    stamp(c, `pine-${color}.png`, i*spacing-offset+70, y-height, width, height, alpha);
  }
}

function town(c: CanvasRenderingContext2D, camera: number, now: number, ember = false) {
  sky(c, 'town-sky.png', ember ? '#32161955' : '#14212724');
  layer(c, 'town-near.png', camera, .11, 20, 432, .75);
  const spacing = 422, offset = Math.round(mod(camera*.26, spacing));
  for(let i=-1;i<4;i++) {
    const x=i*spacing-offset;
    stamp(c, `town-house-${i%2===0?'a':'c'}.png`, x+22, 212, 186, 202, .59);
    stamp(c,'town-house-b.png',x+214,160,190,250,.45);
    lantern(c,x+190,250,now,.8);
  }
  c.fillStyle = ember ? '#210d194a' : '#172b2c3a'; c.fillRect(0,330,W,120);
}

/** Build stone architecture once, then scroll the finished panel instead of filtering large images each frame. */
function hallPanel(theme: number): HTMLCanvasElement | undefined {
  const key=`hall-${theme}`;
  const cached=panels.get(key); if(cached) return cached;
  const atlas=image('castle-tiles.png'); if(!atlas) return;
  const panel=document.createElement('canvas'); panel.width=480; panel.height=448;
  const c=panel.getContext('2d')!; c.imageSmoothingEnabled=false;
  if(theme===6) {
    // The celestial hall is outdoors. The window-wall atlas patch at
    // (1088,240,64,128) includes an opaque rectangular wall, so use the authored
    // transparent arch cap and complete column sprites instead of a wall matte.
    for(const x of [40,264]) {
      c.drawImage(atlas,448,272,32,32,x,92,128,128);
      c.drawImage(atlas,816,112,32,176,x,160,22,234);
      c.drawImage(atlas,816,112,32,176,x+106,160,22,234);
      glow(c,x+64,238,62,'#a2d4bb30',.45);
    }
    // Only the distant architecture fades. The foreground collision platforms
    // keep their existing crisp two-pixel landing edge.
    c.globalCompositeOperation='destination-in';
    const horizontal=c.createLinearGradient(0,0,480,0);
    horizontal.addColorStop(0,'#ffffff00');horizontal.addColorStop(.15,'#ffffffff');
    horizontal.addColorStop(.85,'#ffffffff');horizontal.addColorStop(1,'#ffffff00');
    c.fillStyle=horizontal;c.fillRect(0,0,480,448);
    const vertical=c.createLinearGradient(0,0,0,448);
    vertical.addColorStop(0,'#ffffff00');vertical.addColorStop(.16,'#ffffffff');
    vertical.addColorStop(.77,'#ffffffff');vertical.addColorStop(1,'#ffffff00');
    c.fillStyle=vertical;c.fillRect(0,0,480,448);
    c.globalCompositeOperation='source-over';
    panels.set(key,panel);return panel;
  }
  c.fillStyle=theme===5?'#342c2a':theme===7?'#33252b':'#1a3036'; c.fillRect(0,0,480,448);
  for(let y=0;y<448;y+=48) for(let x=0;x<480;x+=48) {
    c.globalAlpha=.42;
    c.drawImage(atlas,1184,96,32,32,x,y,48,48);
  }
  c.globalAlpha=1;
  // Authored arch windows and pillars frame the playable space without covering it.
  for(const x of [68,292]) {
    glow(c,x+36,205,88,theme===5?'#ec9a6359':'#a2d4bb45');
    c.fillStyle=theme===5?'#744b37':'#40685f'; c.fillRect(x+10,128,52,162);
    c.drawImage(atlas,1088,240,64,128,x,112,80,192);
    c.globalAlpha=.55;
    c.drawImage(atlas,816,112,32,176,x-44,42,40,352);
    c.drawImage(atlas,816,112,32,176,x+90,42,40,352);
    c.globalAlpha=1;
  }
  for(let x=0;x<480;x+=48) {
    c.drawImage(atlas,240,64,48,16,x,22,48,20);
    c.drawImage(atlas,240,64,48,16,x,390,48,24);
  }
  c.fillStyle='#07191b6b'; c.fillRect(0,320,480,128);
  if(theme===5) {
    c.strokeStyle='#947454'; c.lineWidth=9;
    c.beginPath(); c.moveTo(18,0);c.lineTo(18,330);c.lineTo(150,330);c.lineTo(150,448);c.stroke();
    c.strokeStyle='#3b4542';c.lineWidth=4;c.stroke();
    c.fillStyle='#ba674542'; c.fillRect(0,316,480,2);
  }
  panels.set(key,panel); return panel;
}

function hall(c: CanvasRenderingContext2D, camera: number, theme: number, now: number) {
  const panel=hallPanel(theme); if(!panel) return;
  const offset=Math.round(mod(camera*.18,480));
  for(let x=-offset;x<W;x+=480)c.drawImage(panel,x,0);
  for(let i=-1;i<5;i++) {
    const x=i*270-Math.round(mod(camera*.24,270));
    if(theme===5 || theme===7) lantern(c,x+190,82,now,.85);
    else {
      stamp(c,`crystal-${Math.floor(now*5)%4+1}.png`,x+100,252,24,72,.72);
      glow(c,x+112,284,68,'#8bcdb844',.8);
    }
  }
  if(theme===3) {
    // A slow suspended ritual bell gives the crypt a unique silhouette.
    const x=735-camera*.035;
    c.strokeStyle='#b69b69'; c.lineWidth=2;c.beginPath();c.moveTo(x,0);c.lineTo(x,108);c.stroke();
    c.fillStyle='#314c48';c.beginPath();c.moveTo(x-37,129);c.quadraticCurveTo(x,77,x+37,129);c.lineTo(x+47,192);c.lineTo(x-47,192);c.closePath();c.fill();
    c.strokeStyle='#b39f70';c.lineWidth=2;c.stroke();c.fillStyle='#b7a277';c.fillRect(x-50,190,100,6);
    c.fillStyle='#162c2f';c.fillRect(x-2,198,4,34);
  }
}

function water(c: CanvasRenderingContext2D, now: number, y: number, camera: number) {
  layer(c,'cliff-sea.png',camera,.17,y,H-y,.68);
  c.save();c.globalAlpha=.26;c.strokeStyle='#b0d1b4';c.lineWidth=1;
  for(let i=0;i<15;i++) {
    const x=mod(i*113-camera*.12+Math.sin(now*.5+i)*22,W+180)-80;
    c.beginPath();c.moveTo(x,y+9+i*7);c.lineTo(x+28+(i%4)*19,y+9+i*7);c.stroke();
  }
  c.restore();
}

function celestialWater(c: CanvasRenderingContext2D, camera: number) {
  const sprite=image('cliff-sea.png');if(!sprite)return;
  const height=149,width=Math.round(sprite.width*height/sprite.height),key=`celestial-water-${width}`;
  let panel=panels.get(key);
  if(!panel) {
    panel=document.createElement('canvas');panel.width=width;panel.height=height;
    const context=panel.getContext('2d')!;context.imageSmoothingEnabled=false;
    context.drawImage(sprite,0,0,width,height);
    context.globalCompositeOperation='destination-in';
    const fade=context.createLinearGradient(0,0,0,height);
    fade.addColorStop(0,'#ffffff00');fade.addColorStop(.4,'#ffffff20');
    fade.addColorStop(.8,'#ffffff38');fade.addColorStop(1,'#ffffff00');
    context.fillStyle=fade;context.fillRect(0,0,width,height);
    panels.set(key,panel);
  }
  const start=-Math.round(mod(camera*.17,width));
  for(let x=start;x<W;x+=width)c.drawImage(panel,x,391);
}

export function drawArtBackground(c: CanvasRenderingContext2D, camera: number, theme: number, now: number): boolean {
  if(!image('forest-sky.png') || !image('castle-tiles.png') || !image('town-sky.png')) return false;
  c.save(); c.imageSmoothingEnabled=false;
  const t=Math.max(0,Math.min(7,theme));
  if(t===1 || t===7) {
    town(c,camera,now,t===7);
    if(t===7) {
      c.fillStyle='#211e2ba8';c.fillRect(0,0,W,H);
      c.save();c.globalAlpha=.8;hall(c,camera,7,now);c.restore();
      glow(c,640-camera*.025,160,108,'#da9a6655');
      c.strokeStyle='#d1b37b80';c.lineWidth=2;c.beginPath();c.arc(640-camera*.025,160,75,0,Math.PI*2);c.stroke();
      c.strokeStyle='#d1b37b40';c.beginPath();c.arc(640-camera*.025,160,92,0,Math.PI*2);c.stroke();
    }
  } else if(t===3 || t===5) {
    sky(c,'forest-sky.png',t===5?'#312220bd':'#0c1c2cab');
    hall(c,camera,t,now);
  } else if(t===2 || t===4 || t===6) {
    sky(c,'cliff-sky.png',t===6?'#1023325e':'#1a353128');
    layer(c,'cliff-clouds.png',camera,.045,8,302,t===6?.42:.75);
    layer(c,'castle-layer-2.png',camera,.075,26,426,t===6?.45:.22);
    layer(c,'cliff-island.png',camera,.105,t===4?276:294,160,t===6?.4:.7);
    if(t===6)celestialWater(c,camera);
    else water(c,now,t===4?344:391,camera);
    if(t===4) {
      layer(c,'forest-far.png',camera,.16,140,308,.3);
      trees(c,camera,'green',447,.38,410);
    }
    if(t===6) {
      c.save();c.globalAlpha=.4;
      const panel=hallPanel(6);if(panel)c.drawImage(panel,520-camera*.07,24,480,448);
      c.restore();
      const x=580-camera*.025, y=198;
      c.save();c.translate(x,y);c.rotate(now*.025);c.strokeStyle='#d9bc7b88';c.lineWidth=2;
      for(const r of [61,91,117]) {c.beginPath();c.ellipse(0,0,r,r*.73,Math.PI*.15,0,Math.PI*2);c.stroke();}
      for(let i=0;i<12;i++){c.rotate(Math.PI/6);c.fillStyle='#d9bc7b';c.fillRect(104,-2,8,3);}
      c.restore();glow(c,x,y,48,'#cbe3c34c');
    }
  } else {
    sky(c,'forest-sky.png','#0d252b26');
    layer(c,'forest-far.png',camera,.065,52,400,.53);
    layer(c,'forest-near.png',camera,.13,108,342,.55);
    trees(c,camera,'green',459,.74,256);
    // Warm votive lights punctuate the cool forest and distinguish the combat plane.
    const offset=mod(camera*.2,510);
    for(let i=-1;i<3;i++)lantern(c,i*510-offset+350,239,now,.65);
  }
  // A low mist band separates sprite layers; it never obscures enemies or platforms.
  const mist=c.createLinearGradient(0,300,0,454);
  mist.addColorStop(0,'#a8c9ae00');mist.addColorStop(.78,t===1||t===7?'#d3a88a12':'#b2d9c416');mist.addColorStop(1,t===6?'#10272900':'#10272926');
  c.fillStyle=mist;c.fillRect(0,300,W,154);
  // Small drifting motes are deliberately kept out of the immediate combat foreground.
  for(let i=0;i<12;i++) {
    const x=mod(i*97.3+now*(3+i%3)-camera*.04,W), y=60+mod(i*43+Math.sin(now*.4+i)*18,290);
    c.fillStyle=t===5||t===7?'#e9ad725f':'#d6e7c44a';c.fillRect(Math.round(x),Math.round(y),i%3===0?2:1,1);
  }
  c.restore();return true;
}

function textured(c: CanvasRenderingContext2D, atlas: HTMLImageElement, sx: number, sy: number, sw: number, sh: number, x: number, y: number, w: number, h: number, unit=32) {
  for(let ty=0;ty<h;ty+=unit) for(let tx=0;tx<w;tx+=unit) {
    const dw=Math.min(unit,w-tx),dh=Math.min(unit,h-ty);
    c.drawImage(atlas,sx,sy,sw*dw/unit,sh*dh/unit,x+tx,y+ty,dw,dh);
  }
}

/** World-space rendering. The visible top is precisely the collision rectangle's y coordinate. */
export function drawArtPlatform(c: CanvasRenderingContext2D,p: Platform,theme: number,camera: number): boolean {
  const atlas=image('castle-tiles.png'), forest=image('forest-tiles.png'),cliff=image('cliff-tiles.png');
  if(!atlas || !forest || !cliff)return false;
  const x=Math.round(p.x),y=Math.round(p.y),w=Math.round(p.w),h=Math.round(p.h);
  const left=Math.max(x,Math.floor((camera-x-48)/32)*32+x), right=Math.min(x+w,camera+W+48);
  c.save();c.imageSmoothingEnabled=false;c.beginPath();c.rect(x,y,w,h);c.clip();
  c.fillStyle=theme===1||theme===5||theme===7?'#302e2a':'#1c3637';c.fillRect(x,y,w,h);
  const green=theme===0||theme===2||theme===4;
  if(p.kind==='wood') {
    textured(c,atlas,1888,176,32,16,left,y,right-left,h,32);
    c.fillStyle='#c3ad78';c.fillRect(x,y,w,2);
  } else if(p.kind==='spring') {
    textured(c,atlas,240,272,32,16,left,y,right-left,h,24);
    c.fillStyle='#c9b176';c.fillRect(x,y,w,3);
    c.fillStyle='#b9674f';c.fillRect(x+3,y+3,w-6,4);
    c.strokeStyle='#d3c394';c.lineWidth=2;c.beginPath();c.moveTo(x+13,y+9);c.lineTo(x+34,y+12);c.lineTo(x+13,y+16);c.lineTo(x+34,y+20);c.stroke();
  } else if(green) {
    if(p.kind==='ground') {
      textured(c,forest,16,32,32,32,left,y+12,right-left,Math.max(0,h-12),32);
      // Original moss and rock tiles retain all their small authored details.
      for(let tx=left;tx<right;tx+=32)c.drawImage(forest,16,0,32,16,tx,y,32,24);
    } else {
      textured(c,cliff,384,184,32,16,left,y,right-left,h,32);
    }
  } else {
    textured(c,atlas,1184,96,32,32,left,y,right-left,h,32);
    for(let tx=left;tx<right;tx+=32)c.drawImage(atlas,240,64,32,16,tx,y,32,Math.min(h,18));
  }
  c.restore();
  // A restrained bright rim is a visual contract: this is the exact surface you can land on.
  c.fillStyle=p.kind==='spring'?'#e0bd7f':green?'#b5c791':'#c3b18b';c.fillRect(x,y,w,2);
  c.fillStyle='#0b1c2180';c.fillRect(x,y+h-3,w,3);
  if(p.kind==='wood' && p.oneWay) {
    slice(c,'forest-buildings.png',288,256,16,64,x+10,y+h,7,34);
    slice(c,'forest-buildings.png',288,256,16,64,x+w-17,y+h,7,34);
  }
  return true;
}

/** World-space decorations render behind actors, apart from low grass and mushrooms. */
export function drawArtDecoration(c: CanvasRenderingContext2D,d: Decoration,theme: number,now: number): boolean {
  if(!image('forest-tiles.png'))return false;
  const s=d.scale||1, x=Math.round(d.x), y=Math.round(d.y);
  c.save();c.imageSmoothingEnabled=false;
  switch(d.kind) {
    case 'tree': {
      if(theme===1) {
        const width=122*s;stamp(c,'town-house-a.png',x-width*.5,y-153*s,width,153*s,.78);
      } else if(theme===5||theme===6||theme===7) {
        slice(c,'castle-tiles.png',816,112,32,176,x-17*s,y-190*s,34*s,190*s);
      } else {
        const height=236*s;stamp(c,`pine-${theme===2?'gold':'green'}.png`,x-height*56/368,y-height,height*112/368,height,.83);
      }
      break;
    }
    case 'ruin': {
      if(theme===0||theme===2||theme===4) {
        slice(c,'rocks.png',0,160,64,96,x-31*s,y-96*s,62*s,96*s);
        slice(c,'rocks.png',144,256,64,32,x-24*s,y-74*s,48*s,24*s);
      } else if(theme===6) {
        // (1392,80,64,128) is several separate props, including a floating plaque,
        // not one column. A complete pillar cannot be mistaken for tiny ledges.
        slice(c,'castle-tiles.png',816,112,32,176,x-17*s,y-132*s,34*s,132*s);
        stamp(c,`crystal-${Math.floor(now*5)%4+1}.png`,x-9*s,y-93*s,18*s,54*s,.86);
        glow(c,x,y-66*s,34*s,'#9acfb636',.8);
      } else {
        slice(c,'castle-tiles.png',1392,80,64,128,x-29*s,y-132*s,58*s,132*s);
        slice(c,'castle-tiles.png',240,64,48,16,x-39*s,y-140*s,78*s,18*s);
        stamp(c,`crystal-${Math.floor(now*5)%4+1}.png`,x-9*s,y-93*s,18*s,54*s,.86);
        glow(c,x,y-66*s,34*s,'#9acfb636',.8);
      }
      break;
    }
    case 'lamp': {
      stamp(c,'town-street-lamp.png',x-17*s,y-108*s,35*s,108*s,.86);
      lantern(c,x+1*s,y-100*s,now,.55*s);
      break;
    }
    case 'mushroom':slice(c,'forest-tiles.png',256,240,32,32,x-14*s,y-28*s,28*s,28*s);break;
    case 'grass':slice(c,'forest-tiles.png',352,352,32,32,x-13*s,y-17*s,26*s,20*s);break;
    case 'crystal': {
      glow(c,x,y-27*s,35*s,'#8dd3b649',.8);
      stamp(c,`crystal-${Math.floor(now*6)%4+1}.png`,x-9*s,y-48*s,18*s,48*s);
      slice(c,'rocks.png',160,208,64,48,x-20*s,y-20*s,40*s,30*s);
      break;
    }
  }
  c.restore();return true;
}
