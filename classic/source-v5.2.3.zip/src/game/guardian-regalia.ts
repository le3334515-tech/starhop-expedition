import type { Boss } from './types';
import { ascensionProgress, ease, openingAscension, openingSeal, sealProgress } from './boss-seal';

// Pixel anchors measured on the original 250px sheets. Hood and staff move
// independently in the low casting and overhead strike poses.
const anchors: Record<string, number[][]> = {
  idle:[[121,123,147,99],[121,124,145,98],[121,125,145,99],[121,125,146,99],[121,125,146,98],[121,124,148,99],[121,123,150,101],[121,123,145,98]],
  run:[[137,123,117,120],[137,122,118,120],[137,121,117,119],[137,121,116,118],[138,123,117,120],[137,122,118,120],[137,121,117,120],[138,121,118,120]],
  attack1:[[115,138,90,130],[119,137,90,131],[123,134,98,130],[137,124,165,106],[137,124,167,102],[137,124,168,103],[137,124,167,100],[137,124,167,101]],
  attack2:[[131,115,159,76],[129,116,104,82],[129,116,103,82],[132,117,103,82],[143,132,173,131],[143,132,166,136],[143,132,164,128],[143,132,154,105]],
  jump:[[129,124,111,103],[129,124,111,104]], fall:[[129,125,154,103],[130,125,154,101]],
  hurt:[[115,126,130,99],[118,122,122,99],[121,122,124,103]],
  death:[[121,122,126,101],[124,124,131,102],[127,132,137,93],[128,133,141,81],[146,134,139,73],[156,152,146,101],[137,158,142,112]],
};
type Point = [number,number];
const ink='#201523', shadow='#342538', silk='#573343', red='#924454', bronze='#b57848', gold='#e2b470', hot='#ffe4ac';
function shape(c:CanvasRenderingContext2D,color:string,points:Point[]) {
  c.fillStyle=color; c.beginPath();
  points.forEach(([x,y],i)=>i?c.lineTo(Math.round(x),Math.round(y)):c.moveTo(Math.round(x),Math.round(y)));
  c.closePath();c.fill();
}
function line(c:CanvasRenderingContext2D,color:string,x:number,y:number,x2:number,y2:number,width=1) {
  c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(x,y);c.lineTo(x2,y2);c.stroke();
}

// Each funeral standard has a brass finial, crosspiece, split silk and a
// stitched eye. The farther standard is shorter and a beat behind the near one.
function standard(c:CanvasRenderingContext2D,length:number,width:number,t:number,far:boolean) {
  const flap=Math.sin(t)*3, hem=length*.65;
  line(c,ink,0,3,1,-length-4,3);
  line(c,bronze,1,1,2,-length-2);
  shape(c,gold,[[0,-length-2],[2,-length-8],[4,-length-3],[2,-length]]);
  c.translate(2,-length);
  line(c,ink,-width*.74,0,width*.39,0,4);
  line(c,gold,-width*.74,-1,width*.39,-1);
  const left=-width*.68, right=width*.32;
  shape(c,ink,[[left,0],[right,0],[right+flap,hem*.55],[right-3+flap,hem+2],[right-7+flap,hem-7],[left+width*.32+flap,hem+9],[left+width*.24+flap,hem-2],[left-2+flap,hem+4],[left-3,hem*.4]]);
  shape(c,far?shadow:silk,[[left+1,1],[right-1,1],[right-1+flap,hem*.65],[left+width*.44+flap,hem-3],[left+width*.35+flap,hem+3],[left+1,hem*.66]]);
  shape(c,red,[[left+2,2],[left+4,2],[left+5+flap,hem*.61],[left+3+flap,hem*.82]]);
  const mid=(left+right)/2, eye=hem*.34;
  shape(c,bronze,[[mid,eye-6],[mid+4,eye],[mid,eye+6],[mid-4,eye]]);
  shape(c,ink,[[mid,eye-3],[mid+2,eye],[mid,eye+3],[mid-2,eye]]);
  line(c,bronze,mid,eye+8,mid+flap*.5,hem*.8);
}

let atlas: HTMLCanvasElement | undefined;
export function guardianMantle(c: CanvasRenderingContext2D,b:Boss,file:string,frame:number,now:number,scale:number,front:boolean) {
  const pose=file.slice(file.lastIndexOf('boss-')+5,-4);
  const list=anchors[pose]; if (!list) return;
  const ix=Math.max(0,Math.min(list.length-1,Math.floor(frame)));
  const [hx,hy,sx,sy]=list[ix];
  const p=openingSeal(b)?sealProgress(b):1;
  const ascended = b.phase === 3 ? (openingAscension(b) ? ease(.52,.76,ascensionProgress(b)) : 1) : 0;
  const spread=ease(.39,.74,p), strength=ease(.30,.63,p)*(pose==='death'?1-ease(1,5.4,ix):1);
  if (strength<=0) return;
  atlas??=document.createElement('canvas');
  if(atlas.width!==260){atlas.width=260;atlas.height=260;}
  const a=atlas.getContext('2d')!;
  a.clearRect(0,0,260,260);a.save();a.translate(hx,hy);
  const rush=b.mode==='charge' || b.mode==='jump';
  const rhythm=now*(rush?11:4.5);
  if(!front) {
    a.save();a.translate(-1,9);a.rotate(.09+.40*spread+.12*ascended+.028*Math.sin(rhythm+1)-(rush?.38:0));
    standard(a,24+20*spread+9*ascended,14+4*ascended,rhythm+2,true);a.restore();
    a.save();a.translate(-6,8);a.rotate(-.19-(rush?.98:.62)*spread-.17*ascended+.041*Math.sin(rhythm));
    standard(a,26+24*spread+13*ascended,18+5*ascended,rhythm,false);a.restore();
    // Heavy cloak unfurls from the hood, catching up with the body on charges.
    const lift=rush?12:0, sweep=8+spread*(rush?31:17), flutter=Math.sin(rhythm)*2.7;
    shape(a,ink,[[-2,3],[-12,3],[-18,12],[-sweep-3,23-lift],[-sweep-10,31-lift+flutter],[-sweep-4,31-lift+flutter],[-sweep-12,38-lift+flutter],[-sweep+1,35-lift],[-sweep-1,41-lift],[-11,33],[2,31]]);
    shape(a,silk,[[-5,4],[-11,6],[-17,15],[-sweep-6,30-lift+flutter],[-sweep,28-lift],[-sweep-5,34-lift],[-12,29],[-4,16]]);
    shape(a,red,[[-10,7],[-13,12],[-sweep+1,27-lift],[-sweep-5,29-lift],[-17,19]]);
    line(a,bronze,-10,7,-17,19);
  } else {
    // The original face stays exposed between a broken diadem and layered collar.
    shape(a,ink,[[-11,1],[-13,-10],[-9,-8],[-4,-15],[-4,-6],[2,-10],[1,-3],[-3,0]]);
    shape(a,bronze,[[-11,-3],[-11,-8],[-8,-5],[-5,-11],[-6,-3]]);
    a.fillStyle=gold;a.fillRect(-6,-8,2,3);
    shape(a,ink,[[-18,5],[-8,2],[-3,6],[-7,11],[-17,10],[-21,12]]);
    shape(a,bronze,[[-18,5],[-9,3],[-5,6],[-14,6],[-19,9]]);
    shape(a,silk,[[-14,7],[-5,7],[-8,11],[-16,10]]);
    a.fillStyle=hot;a.fillRect(-9,5,2,2);
    if (ascended > 0) {
      // Segmented brass plates close around the old gold mask.
      a.save(); a.globalAlpha *= ascended;
      shape(a,ink,[[-14,-4],[-16,-13],[-9,-9],[-5,-19],[-1,-11],[6,-15],[4,-3],[-1,2],[-3,7],[-10,4]]);
      shape(a,bronze,[[-14,-4],[-14,-11],[-9,-7],[-5,-16],[-2,-9],[4,-12],[2,-4],[-3,-2],[-4,4],[-10,2]]);
      shape(a,gold,[[-10,-6],[-5,-13],[-3,-7],[2,-8],[1,-6],[-3,-5],[-7,-3],[-8,1],[-10,0]]);
      shape(a,gold,[[-20,7],[-12,3],[-7,5],[-10,8],[-16,8],[-19,11]]);
      a.fillStyle=hot; a.fillRect(-4,-4,3,1);
      a.restore();
    }
    a.save();a.translate(sx-hx,sy-hy);
    // The purple flame becomes the iris of an eclipsed, three-pronged staff.
    const aperture=7+spread*5+(b.mode==='windup'?2:0);
    for(const sign of [-1,1]){
      a.save();a.scale(sign,1);
      shape(a,ink,[[1,12],[7,9],[aperture,3],[aperture+2,-9],[aperture-2,-17],[aperture+5,-12],[aperture+6,-3],[aperture+4,7],[8,14],[2,16]]);
      shape(a,bronze,[[3,13],[9,9],[aperture+3,1],[aperture+3,-10],[aperture+5,-6],[aperture+4,3],[9,12],[4,15]]);
      a.fillStyle=gold;a.fillRect(aperture+2,-9,2,4); a.restore();
    }
    shape(a,red,[[-4,0],[0,-6],[4,0],[0,7]]);
    shape(a,hot,[[-1,0],[1,-3],[1,2],[-1,4]]);
    shape(a,gold,[[-2,15],[0,12],[3,15],[0,18]]);
    if (ascended > 0) {
      a.save(); a.globalAlpha *= ascended;
      for (const direction of [-1,1]) {
        a.save(); a.scale(direction,1);
        shape(a,ink,[[6,11],[15,5],[20,-9],[25,-16],[23,-5],[25,-2],[21,1],[19,10],[12,15]]);
        shape(a,bronze,[[9,11],[16,6],[21,-8],[23,-12],[21,-1],[20,2],[17,9],[13,12]]);
        a.fillStyle=gold; a.fillRect(21,-10,2,3);
        a.restore();
      }
      shape(a,gold,[[0,-17],[3,-10],[0,-7],[-3,-10]]);
      a.restore();
    }
    a.restore();
  }
  a.restore();c.save();c.globalAlpha*=strength;c.imageSmoothingEnabled=false;
  c.scale(1.28,1);c.drawImage(atlas,-130*scale,-167*scale,260*scale,260*scale);c.restore();
}

let spiritSurface: HTMLCanvasElement | undefined;
// The ancestral image repeats the guardian's narrow gold face and diagonal
// collar. Its arms and trailing hems end in open wisps above the playable floor.
export function drawGuardianSpirit(c:CanvasRenderingContext2D,b:Boss,now:number) {
  if(b.form!==2 || b.mode==='dead') return;
  const ritual=openingSeal(b), p=ritual?sealProgress(b):1;
  const ascension = openingAscension(b);
  const ascended = b.phase === 3 ? (ascension ? ease(.54,.82,ascensionProgress(b)) : 1) : 0;
  const compression = ascension ? ease(.06,.40,ascensionProgress(b)) * (1 - ease(.56,.82,ascensionProgress(b))) : 0;
  const arrival=ease(.23,.60,p); if(!arrival)return;
  const cast=b.mode==='windup'||b.mode==='barrage', broken=b.mode==='stagger';
  spiritSurface??=document.createElement('canvas');
  if(spiritSurface.width!==184){spiritSurface.width=184;spiritSurface.height=146;}
  const a=spiritSurface.getContext('2d')!;
  a.clearRect(0,0,184,146);a.save();a.translate(89,29);
  const jet=Math.round(Math.sin(now*3.4)*2), lift=cast?6:0;
  const base='#292030',darkSilk='#493046',tint='#674057',edge='#86616b';
  // Three broken lengths, rather than a second pair of legs.
  shape(a,base,[[-28,27],[-12,15],[10,17],[31,30],[33,49],[25,62],[24,83],[16,73],[14,95],[6,82],[-5,107+jet],[-7,80],[-21,94],[-17,65],[-29,72],[-24,47]]);
  shape(a,darkSilk,[[-20,35],[-9,23],[15,25],[13,63],[5,84],[-1,75],[-10,89],[-7,57],[-19,70]]);
  shape(a,tint,[[-25,28],[-14,22],[8,34],[6,40],[-7,35],[-1,42],[-17,34]]);
  // Flared sleeves, each ending in a floating articulated hand.
  for(const dir of [-1,1]){
    a.save();a.scale(dir,1);
    const raised=dir===1?lift+3:0, drift=dir===1?jet:-jet;
    a.translate(0,-raised);
    shape(a,base,[[12,20],[24,21],[37,27],[47,39],[60,32+drift],[64,32+drift],[62,44],[57,51],[51,51],[45,65],[42,58],[34,73],[36,52],[28,57],[26,41],[16,40]]);
    shape(a,darkSilk,[[16,24],[24,23],[38,30],[48,42],[61,35+drift],[56,46],[47,53],[40,62],[42,49],[34,48],[29,36]]);
    shape(a,edge,[[21,23],[29,24],[40,32],[37,33],[28,28],[23,28]]);
    shape(a,'#ab765d',[[46,42],[58,35+drift],[62,35+drift],[56,40+drift],[48,46]]);
    // Talon-like glove and two fingers lifted in the old magician's casting sign.
    shape(a,base,[[56,34+drift],[58,27+drift],[61,24+drift],[62,16+drift],[65,14+drift],[65,25+drift],[69,24+drift],[73,17+drift],[76,16+drift],[72,27+drift],[68,30+drift],[65,37+drift],[59,39+drift]]);
    shape(a,'#9c6a64',[[59,32+drift],[62,27+drift],[64,26+drift],[62,32+drift],[60,35+drift]]);
    a.fillStyle=bronze;a.fillRect(64,16+drift,1,6);a.fillRect(72,22+drift,2,2);
    a.restore();
  }
  // Empty cowl, ochre half-mask and collar repeat the physical actor's costume.
  shape(a,base,[[-23,18],[-18,0],[-11,-12],[-3,-18],[6,-17],[16,-10],[22,8],[18,16],[25,24],[11,22],[5,26],[-2,22],[-13,21],[-27,28]]);
  shape(a,darkSilk,[[-19,15],[-15,0],[-8,-11],[0,-15],[9,-13],[14,-8],[5,-9],[-3,-6],[-10,8],[-9,15]]);
  shape(a,tint,[[-13,-3],[-7,-12],[1,-16],[8,-13],[1,-12],[-4,-10]]);
  shape(a,'#171521',[[-7,3],[-2,-5],[7,-7],[14,-2],[15,10],[9,17],[1,18],[-5,12]]);
  shape(a,'#b17a4c',[[7,-3],[11,-2],[13,1],[12,7],[16,9],[11,10],[8,15],[4,12],[7,9]]);
  a.fillStyle=hot;a.fillRect(10,2,4,2);a.fillRect(3,4,2,1);
  shape(a,'#b48755',[[-26,24],[-14,17],[-7,17],[7,26],[24,20],[17,28],[7,31],[-9,21],[-16,21]]);
  shape(a,bronze,[[5,30],[9,33],[7,40],[4,36]]);
  // A fractured bronze nimbus frames the hood; the gap above it is intentional.
  a.strokeStyle='#a67b60';a.lineWidth=1;
  for(const [start,end] of [[-.32,.32],[.52,1.1],[2.10,2.72],[3.05,3.71],[4.02,4.46],[4.98,5.44]]){
    a.beginPath();a.arc(0,2,27,start,end);a.stroke();
  }
  if (ascended > 0) {
    a.save();
    a.globalAlpha *= ascended;
    // The new spirit crown has the same old gold as the actor's mask.
    shape(a, '#1a1420', [[-23,-2],[-21,-15],[-16,-11],[-12,-20],[-7,-15],[0,-25],[7,-15],[12,-20],[16,-11],[21,-15],[23,-2],[16,-7],[-16,-7]]);
    shape(a, bronze, [[-21,-5],[-20,-12],[-16,-8],[-11,-16],[-7,-11],[0,-22],[7,-11],[11,-16],[16,-8],[20,-12],[21,-5],[14,-8],[-13,-8]]);
    shape(a, gold, [[-12,-10],[-8,-13],[-6,-10],[0,-19],[6,-10],[8,-13],[12,-10],[4,-8],[0,-11],[-4,-8]]);
    shape(a, hot, [[-2,-16],[0,-19],[2,-16],[0,-12]]);
    line(a, '#c9936a', -19, 21, -8, 18, 1);
    line(a, '#c9936a', 8, 25, 20, 21, 1);
    for (const side of [-1,1]) {
      a.fillStyle = gold;
      a.fillRect(side * 17 - 1, -7, 2, 5);
      a.fillRect(side * 15 - 1, 24, 2, 6);
    }
    a.restore();
  }
  a.restore();c.save();c.imageSmoothingEnabled=false;
  const scale=1.40+arrival*.16+(ritual?.18*Math.sin(Math.PI*p):0)+ascended*.40-compression*.58;
  const x=b.x+b.w/2-(b.facing||1)*9, foot=b.y+b.h;
  c.translate(Math.round(x),Math.round(foot-74-arrival*63-ascended*15+compression*45+Math.sin(now*2)*2));
  c.scale((b.facing||1)*scale,scale);
  c.globalAlpha*=arrival*(broken?.29:ritual?.81:cast?.82:.64)*(1-compression*.55);
  c.drawImage(spiritSurface,-89,-62);c.restore();
}

