import { artImage } from './art-assets';
import { ease } from './boss-seal';
import { rangedWeaponPose } from './hero-weapon-pose';
import type { Hero } from './types';

const TAU = Math.PI * 2;
const JADE = '#8ce3ce';
const GOLD = '#e6b572';
const IVORY = '#fff0bc';
const RELEASE = .36;
export interface AwakeningOrigin { x: number; foot: number }

type Point = readonly [number, number];

function pixel(c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

function shape(c: CanvasRenderingContext2D, color: string, points: readonly Point[]) {
  c.fillStyle = color;
  c.beginPath();
  c.moveTo(Math.round(points[0][0]), Math.round(points[0][1]));
  for (const [x,y] of points.slice(1)) c.lineTo(Math.round(x), Math.round(y));
  c.closePath();
  c.fill();
}

function star(c: CanvasRenderingContext2D, x: number, y: number, radius: number, color: string) {
  c.fillStyle = color;
  pixel(c, x - radius, y, radius * 2 + 2, 2);
  pixel(c, x, y - radius, 2, radius * 2 + 2);
  pixel(c, x - 1, y - 1, 4, 4);
}

function drawSeal(c: CanvasRenderingContext2D, x: number, y: number, index: number) {
  c.save();
  c.translate(Math.round(x), Math.round(y));
  const trim = index % 2 ? GOLD : JADE;
  shape(c, '#173f3d', [[-7,-8],[-3,-12],[7,-12],[7,8],[4,10],[-7,10]]);
  c.strokeStyle = trim;
  c.lineWidth = 1;
  c.strokeRect(-5.5, -9.5, 11, 18);
  c.fillStyle = IVORY;
  c.fillRect(-3, -5, 6, 1);
  c.fillRect(0, -7, 1, 11);
  c.fillRect(-2, -1, 5, 1);
  c.fillRect(-2, 4, 4, 1);
  c.restore();
}

// A cached flat-colour silhouette keeps the echo crisp in Canvas even on browsers
// that ignore CanvasRenderingContext2D.filter.
let echo: HTMLCanvasElement | undefined;
function drawEchoes(c: CanvasRenderingContext2D, rise: number, release: number, alpha: number) {
  const runner = artImage('actors/hero-run.png');
  if (!runner) return;
  if (!echo) {
    echo = document.createElement('canvas');
    echo.width = echo.height = 200;
    const mask = echo.getContext('2d')!;
    mask.drawImage(runner, 400, 0, 200, 200, 0, 0, 200, 200);
    mask.globalCompositeOperation = 'source-in';
    mask.fillStyle = JADE;
    mask.fillRect(0,0,200,200);
  }
  const travel = 24 + 31 * (1 - rise) + release * 42;
  for (const side of [-1, 1]) {
    c.save();
    c.globalAlpha = alpha * .48;
    c.translate(Math.round(side * travel), Math.round(-9 - 25 * rise - 14 * release));
    c.scale(-side, 1);
    c.drawImage(echo, -100, -122);
    c.restore();
  }
}

function drawAncestralBlade(c: CanvasRenderingContext2D, rise: number, release: number, alpha: number) {
  c.save();
  c.translate(0, Math.round(-43 - rise * 18 + release * 27));
  c.scale(.52 + rise * .48, Math.max(.16, rise));
  c.globalAlpha = alpha * .42;
  shape(c, '#15433e', [[0,-126],[22,-92],[14,-39],[16,-13],[34,2],[20,10],[8,6],[9,28],[0,38],[-9,28],[-8,6],[-20,10],[-34,2],[-16,-13],[-14,-39],[-22,-92]]);
  c.globalAlpha = alpha * .94;
  shape(c, JADE, [[0,-114],[13,-90],[8,-24],[5,-7],[0,1],[-5,-7],[-8,-24],[-13,-90]]);
  shape(c, '#376f64', [[0,-113],[1,-102],[0,-16],[-6,-23],[-11,-87]]);
  shape(c, '#dbf5ca', [[0,-112],[4,-93],[2,-32],[0,-17],[-2,-32],[-1,-102]]);
  shape(c, GOLD, [[-23,-1],[-12,-3],[-8,-11],[0,-5],[8,-11],[12,-3],[23,-1],[17,6],[6,3],[3,14],[5,20],[0,24],[-5,20],[-3,14],[-6,3],[-17,6]]);
  star(c, -1, -13, 3, IVORY);
  c.restore();
}

function drawIgnition(c: CanvasRenderingContext2D, origin: AwakeningOrigin, age: number, strength: number, reducedMotion: boolean) {
  if (age >= 1.12) return;
  const rise = ease(.02, RELEASE, age);
  const release = ease(RELEASE, 1.04, age);
  const glow = strength * (1 - ease(.49, 1.07, age));
  c.save();
  c.translate(Math.round(origin.x), Math.round(origin.foot));

  // The seals and afterimages fold inward before the jade blade locks into place.
  if (!reducedMotion) drawEchoes(c, rise, release, glow);
  const orbitRadius = 65 - rise * 26 + release * (reducedMotion ? 16 : 62);
  const turn = reducedMotion ? 0 : age * TAU * .43;
  c.globalAlpha = glow * .55;
  c.strokeStyle = GOLD;
  c.lineWidth = 1.5;
  const focusY = -59 - rise * 19;
  for (let index = 0; index < 4; index++) {
    const a = turn + index * TAU / 4;
    c.beginPath();
    c.ellipse(0,focusY,orbitRadius,orbitRadius * .61,0,a,a + .9);
    c.stroke();
  }
  c.globalAlpha = glow * .88;
  for (let index = 0; index < (reducedMotion ? 4 : 6); index++) {
    const angle = turn + index * TAU / (reducedMotion ? 4 : 6);
    drawSeal(c, Math.cos(angle) * orbitRadius, focusY + Math.sin(angle) * orbitRadius * .62, index);
  }

  drawAncestralBlade(c, rise, release, glow * ease(0,.15,age));

  // The release uses narrow stair-stepped rays rather than a screen flash.
  const strike = ease(.26, RELEASE, age) * (1 - ease(.38, .64, age));
  if (strike > 0) {
    const reach = reducedMotion ? 45 : 102;
    c.globalAlpha = strike * strength * .75;
    shape(c, IVORY, [[-reach,-48],[0,-57],[reach,-48],[0,-46]]);
    c.globalAlpha *= .36;
    shape(c, JADE, [[-7,-54],[0,-175],[7,-54],[0,0]]);
  }

  if (!reducedMotion && release > 0) {
    c.globalAlpha = glow;
    for (let piece = 0; piece < 16; piece++) {
      const angle = piece * 2.399963;
      const radius = (37 + piece * 4) * release;
      const x = Math.cos(angle) * radius, y = -61 + Math.sin(angle) * radius * .66;
      if (piece % 4 === 0) star(c, x, y, 3, GOLD);
      else {
        c.fillStyle = piece % 2 ? JADE : IVORY;
        pixel(c, x, y, 2, 3 + piece % 5);
      }
    }
  }
  c.restore();
}

export function drawAwakeningGround(c: CanvasRenderingContext2D, hero: Hero, origin: AwakeningOrigin,
  age: number, strength: number, reducedMotion: boolean) {
  if (hero.hp <= 0) return;
  const center = hero.x + hero.w / 2;
  const foot = hero.y + hero.h;
  c.save();
  c.globalAlpha = strength * .54;
  c.strokeStyle = JADE;
  c.lineWidth = 1.5;
  c.beginPath();
  c.ellipse(center, foot + 1, 27, 6, 0, 0, TAU);
  c.stroke();
  c.globalAlpha *= .52;
  c.strokeStyle = GOLD;
  c.beginPath();
  c.ellipse(center, foot + 1, 20, 4, 0, 0, TAU);
  c.stroke();

  if (age < 1.06) {
    const unfold = ease(RELEASE, .98, age);
    const radius = 22 + unfold * (reducedMotion ? 35 : 119);
    const thickness = 5 + unfold * 18;
    c.globalAlpha = strength * .8 * (1 - ease(.46, 1.06, age));
    c.strokeStyle = GOLD;
    c.lineWidth = 2;
    c.beginPath();
    c.ellipse(origin.x, origin.foot, radius, thickness, 0, 0, TAU);
    c.stroke();
    for (let point = 0; point < 8; point++) {
      const angle = point * TAU / 8;
      star(c, origin.x + Math.cos(angle) * radius, origin.foot + Math.sin(angle) * thickness,
        point % 2 ? 2 : 3, point % 2 ? JADE : IVORY);
    }
    drawIgnition(c, origin, age, strength, reducedMotion);
  }
  c.restore();
}

function drawArmedAccents(c: CanvasRenderingContext2D, hero: Hero, age: number, opacity: number, reducedMotion: boolean) {
  if (hero.attackTimer <= 0) return;
  const pose = rangedWeaponPose(hero, age);
  c.save();
  c.translate(Math.round(hero.x + hero.w / 2), Math.round(hero.y + hero.h));
  c.scale(hero.facing || 1, 1);
  c.globalAlpha = opacity;

  switch (hero.weapon) {
    case 'blade': {
      const heavy = hero.attackStep === 3;
      const progress = ease(0, heavy ? .28 : .18, (heavy ? .28 : .18) - hero.attackTimer);
      const reverse = hero.attackStep === 2;
      const end = (reverse ? 1 : -1) * (1.36 - progress * 2.72);
      c.globalAlpha *= Math.sin(progress * Math.PI) * .68;
      c.strokeStyle = GOLD;
      c.lineWidth = heavy ? 3 : 2;
      c.beginPath();
      c.arc(8, -24, heavy ? 54 : 39, end + (reverse ? .53 : -.53), end, reverse);
      c.stroke();
      star(c, 8 + Math.cos(end) * (heavy ? 53 : 40), -24 + Math.sin(end) * (heavy ? 53 : 40), 3, IVORY);
      break;
    }
    case 'ember': {
      const phase = ease(0,.45,pose.attackProgress);
      c.globalAlpha *= 1 - phase;
      c.translate(Math.round(pose.staffGrip.x + Math.sin(pose.staffAngle) * 23),
        Math.round(pose.staffGrip.y - Math.cos(pose.staffAngle) * 23));
      const r = 9 + Math.round(phase * 12);
      shape(c, '#2b6456', [[-r,0],[0,-r],[r,0],[0,r]]);
      c.strokeStyle = GOLD;
      c.lineWidth = 1.5;
      c.stroke();
      shape(c, IVORY, [[-3,0],[0,-6],[3,0],[0,6]]);
      for (const side of [-1,1]) star(c, side * (r + 4), 0, 2, JADE);
      break;
    }
    case 'disc': {
      const phase = ease(0,.55,pose.attackProgress);
      c.globalAlpha *= 1 - phase;
      c.translate(Math.round(pose.hand.x + 11 + phase * 12), Math.round(pose.hand.y));
      if (!reducedMotion) c.rotate(age * 6);
      c.strokeStyle = JADE;
      c.lineWidth = 2;
      for (let part = 0; part < 3; part++) {
        const a = part * TAU / 3;
        c.beginPath();
        c.arc(0, 0, 12 + phase * 7, a, a + .9);
        c.stroke();
        star(c, Math.cos(a) * (12 + phase * 7), Math.sin(a) * (12 + phase * 7), 2, GOLD);
      }
      break;
    }
  }
  c.restore();
}

export function drawAwakeningSeals(c: CanvasRenderingContext2D, hero: Hero,
  age: number, strength: number, reducedMotion: boolean) {
  if (hero.hp <= 0) return;
  const center = hero.x + hero.w / 2;
  const focusY = hero.y + 15;
  const moving = Math.abs(hero.vx) > 85 || hero.dashTimer > 0;
  const turn = reducedMotion ? 0 : age * 4.5;
  const opacity = strength * ease(.14, .66, age);
  c.save();
  c.globalAlpha = opacity * .72;
  for (let light = 0; light < 3; light++) {
    const angle = turn + light * TAU / 3;
    star(c, center + Math.cos(angle) * 27, focusY - 6 + Math.sin(angle) * 18,
      light === 1 ? 3 : 2, light === 1 ? GOLD : JADE);
  }
  if (moving && !reducedMotion) {
    const direction = Math.sign(hero.vx) || hero.facing;
    for (let trail = 0; trail < 6; trail++) {
      const phase = (turn / 3 + trail / 6) % 1;
      const distance = 14 + phase * (hero.dashTimer > 0 ? 76 : 42);
      const y = focusY - 12 + trail * 4 + phase * 7;
      c.globalAlpha = opacity * (1 - phase) * .52;
      c.fillStyle = trail % 2 ? GOLD : JADE;
      pixel(c, center - direction * distance, y, 3 + phase * 14, trail % 2 ? 2 : 1);
    }
  }
  c.restore();
  drawArmedAccents(c, hero, age, opacity, reducedMotion);
}
