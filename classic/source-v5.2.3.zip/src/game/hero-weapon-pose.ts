import { WEAPONS, type Hero } from './types';

type Point = { x: number; y: number };
export interface RangedWeaponPose {
  attacking: boolean; attackProgress: number; lean: number;
  hand: Point; elbow: Point; offHand: Point; offElbow: Point; staffGrip: Point; staffAngle: number;
}
const cleanSheets = new WeakMap<HTMLImageElement, HTMLCanvasElement>();
// These four colors belong exclusively to this source character's sword and hilt.
// Keep the credited PNGs intact; only the cached ranged-body layer omits the sword.
const swordColors = new Set([0x5f4181, 0x442b61, 0x331685, 0x432792]);
export function weaponlessHeroSheet(image: HTMLImageElement): HTMLCanvasElement {
  const cached = cleanSheets.get(image); if (cached) return cached;
  const sheet = document.createElement('canvas');
  sheet.width = image.naturalWidth; sheet.height = image.naturalHeight;
  const c = sheet.getContext('2d')!;
  c.drawImage(image, 0, 0);
  const pixels = c.getImageData(0, 0, sheet.width, sheet.height), data = pixels.data;
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] && swordColors.has((data[i] << 16) | (data[i + 1] << 8) | data[i + 2])) data[i + 3] = 0;
  }
  c.putImageData(pixels, 0, 0); cleanSheets.set(image, sheet); return sheet;
}

const mix = (a: number, b: number, t: number) => a + (b - a) * t;
const easeOut = (t: number) => 1 - (1 - t) ** 3;
function key(p: number, frames: readonly (readonly [number, number])[]): number {
  for (let n = 1; n < frames.length; n++) if (p <= frames[n][0]) {
    const [start, a] = frames[n - 1], [end, b] = frames[n];
    return mix(a, b, easeOut(Math.max(0, Math.min(1, (p - start) / (end - start)))));
  }
  return frames[frames.length - 1][1];
}
/** A quick release followed by recovery matches the existing immediate projectiles.
 * Both actions use the original locomotion body; neither borrows a sword frame. */
export function rangedWeaponPose(h: Hero, now: number): RangedWeaponPose {
  const attacking = h.attackTimer > 0 && h.hp > 0;
  const p = attacking ? Math.max(0, Math.min(1, 1 - h.attackTimer / .2)) : 1;
  const bob = h.grounded && Math.abs(h.vx) < 15 ? Math.sin(now * 2.8) * .35 : 0;
  if (WEAPONS[h.weapon].archetype === 'ember' && h.weapon !== 'jadeNeedle') {
    // The same hand keeps the staff throughout: a sharp wrist point, a small
    // recoil, then a quick return to the outside of the silhouette.
    const hand = { x: attacking ? key(p, [[0,-2],[.12,0],[.42,11],[1,12]]) : 12,
      y: attacking ? key(p, [[0,-18],[.12,-17],[.42,-20],[1,-19]]) : -19 + bob };
    return { attacking, attackProgress: p,
      lean: attacking ? key(p, [[0,-.035],[.13,.018],[.48,-.005],[1,0]]) : 0,
      hand, elbow: { x: 7, y: -18 }, offHand: { x: -5, y: -15 + bob }, offElbow: { x: -6, y: -21 },
      staffGrip: hand, staffAngle: attacking ? key(p, [[0,1.25],[.12,1.39],[.45,.04],[1,.1]]) : .1 };
  }
  // A sidearm flick. The release is immediate, the elbow folds rather than
  // leaving both arms stretched out for the full attack window.
  return { attacking, attackProgress: p, lean: attacking ? key(p, [[0,-.055],[.12,-.07],[.38,.012],[1,0]]) : 0,
    hand: { x: attacking ? key(p, [[0,16],[.12,23],[.38,12],[.7,12],[1,13]]) : 13,
      y: attacking ? key(p, [[0,-16],[.12,-18],[.38,-10],[.7,-13],[1,-12]]) : -12 + bob },
    elbow: { x: attacking ? key(p, [[0,8],[.12,11],[.38,6],[1,7]]) : 7, y: -18 },
    offHand: { x: -6, y: -15 + bob }, offElbow: { x: -6, y: -21 },
    staffGrip: { x: 0, y: 0 }, staffAngle: 0 };
}

function arm(c: CanvasRenderingContext2D, shoulder: Point, elbow: Point, hand: Point, palm: boolean) {
  // Pixel steps use the source robe's plum shadows, ivory sleeve and pale glove.
  const segment = (a: Point, b: Point, color: string, size: number) => {
    c.fillStyle = color;
    const steps = Math.max(Math.abs(b.x - a.x), Math.abs(b.y - a.y), 1);
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      c.fillRect(Math.round(mix(a.x, b.x, t) - size / 2), Math.round(mix(a.y, b.y, t) - size / 2), size, size);
    }
  };
  segment(shoulder, elbow, '#49313e', 4); segment(elbow, hand, '#49313e', 3);
  segment(shoulder, elbow, '#b59fa8', 2); segment(elbow, hand, '#d1bfc1', 2);
  c.fillStyle = '#755568'; c.fillRect(Math.round(hand.x) - 3, Math.round(hand.y) - 1, 3, 3);
  c.fillStyle = '#ddcdcb'; c.fillRect(Math.round(hand.x) - 1, Math.round(hand.y) - 1, 3, 3);
  if (palm) c.fillRect(Math.round(hand.x) + 1, Math.round(hand.y) - 2, 1, 2);
}

export function drawRangedArms(c: CanvasRenderingContext2D, h: Hero, pose: RangedWeaponPose): void {
  if (h.weapon === 'blade' || h.hp <= 0) return;
  arm(c, { x: -3, y: -25 }, pose.offElbow, pose.offHand, false);
  arm(c, { x: 4, y: -25 }, pose.elbow, pose.hand, false);
}
