import { describe, expect, it } from 'vitest';
import { GameEngine } from './engine';
import { EMPTY_INPUT, type InputState, type ModifierId } from './types';

function flat(modifier: ModifierId = 'standard') {
  const game = new GameEngine();
  game.start({ seed: 42, modifier, weapon: 'blade' });
  const s = game.state;
  s.enemies = []; s.pickups = []; s.room.hazards = [];
  s.room.platforms = [{ x: 0, y: 448, w: s.room.width, h: 120, kind: 'ground' }];
  s.hero.x = 140; s.hero.y = 412;
  for (let n = 0; n < 5; n++) game.update(1 / 60, EMPTY_INPUT);
  return game;
}

function jumpArc(held: boolean) {
  const game = flat(), hero = game.state.hero;
  let peak = 448, apex = 0, landed = 0;
  for (let n = 0; n < 180; n++) {
    game.update(1 / 60, { ...EMPTY_INPUT, jumpPressed: n === 0, jumpHeld: held });
    if (hero.y + hero.h < peak) { peak = hero.y + hero.h; apex = (n + 1) / 60; }
    if (n > 3 && hero.grounded) { landed = (n + 1) / 60; break; }
  }
  return { height: 448 - peak, apex, landed };
}

describe('jump patch: one jump reaches normal platforms', () => {
  it('makes even a released tap high enough for a normal first ledge', () => {
    const tap = jumpArc(false);
    expect(tap.height).toBeGreaterThanOrEqual(140);
    expect(tap.landed).toBeGreaterThan(0);
    expect(tap.landed).toBeLessThan(.95);
  });

  it('reaches high ordinary platforms with one held jump, without a long float', () => {
    const hold = jumpArc(true);
    expect(hold.height).toBeGreaterThanOrEqual(190);
    expect(hold.height).toBeLessThan(240);
    expect(hold.apex).toBeLessThan(.5);
    expect(hold.landed).toBeLessThan(1);
    expect(hold.height - jumpArc(false).height).toBeGreaterThan(35);
  });

  it.each([{ rise: 126, held: false }, { rise: 180, held: true }])('lands on a $rise px ledge with exactly one jump', ({ rise, held }) => {
    const game = flat(), s = game.state, h = s.hero;
    s.room.platforms.push({ x: 235, y: 448 - rise, w: 260, h: 24, kind: 'stone', oneWay: true });
    let landed = false, maximumJumps = 0;
    for (let n = 0; n < 70; n++) {
      const input: InputState = { ...EMPTY_INPUT, right: true, jumpPressed: n === 0, jumpHeld: held };
      game.update(1 / 60, input);
      maximumJumps = Math.max(maximumJumps, h.jumps);
      if (h.grounded && Math.abs(h.y + h.h - (448 - rise)) < 1) { landed = true; break; }
    }
    expect(landed).toBe(true);
    expect(maximumJumps).toBe(1);
  });
});

describe('air jump is a modest correction, not another full jump', () => {
  it.each<ModifierId>(['standard', 'moon'])('limits the added height in %s while keeping the first jump', modifier => {
    const game = flat(modifier), h = game.state.hero;
    let second = false, secondFoot = 0, peak = 448, firstPeak = 448;
    for (let frame = 0; frame < 240; frame++) {
      const fireSecond = frame > 3 && !second && h.vy >= 0;
      if (fireSecond) { second = true; secondFoot = h.y + h.h; }
      game.update(1 / 60, { ...EMPTY_INPUT, jumpPressed: frame === 0 || fireSecond, jumpHeld: true });
      peak = Math.min(peak, h.y + h.h);
      if (!second) firstPeak = Math.min(firstPeak, h.y + h.h);
      if (frame > 3 && h.grounded) break;
    }
    expect(second).toBe(true);
    expect(448 - firstPeak).toBeGreaterThan(190);
    expect(secondFoot - peak).toBeGreaterThan(60);
    expect(secondFoot - peak).toBeLessThan(95);
    expect(448 - peak).toBeLessThan(modifier === 'moon' ? 325 : 300);
  });

  it('does not chop upward momentum if the second jump is pressed early', () => {
    const single = flat(), earlyDouble = flat();
    for (const game of [single, earlyDouble]) game.update(1 / 60, { ...EMPTY_INPUT, jumpPressed: true, jumpHeld: true });
    single.update(1 / 60, { ...EMPTY_INPUT, jumpHeld: true });
    earlyDouble.update(1 / 60, { ...EMPTY_INPUT, jumpPressed: true, jumpHeld: true });
    expect(earlyDouble.state.hero.vy).toBeCloseTo(single.state.hero.vy);
    expect(earlyDouble.state.hero.jumps).toBe(2);
  });

  it('still catches a falling hero but refuses a third jump', () => {
    const game = flat(), h = game.state.hero;
    game.update(1 / 60, { ...EMPTY_INPUT, jumpPressed: true, jumpHeld: true });
    for (let n = 0; n < 60 && h.vy < 100; n++) game.update(1 / 60, { ...EMPTY_INPUT, jumpHeld: true });
    expect(h.vy).toBeGreaterThan(0);
    game.update(1 / 60, { ...EMPTY_INPUT, jumpPressed: true, jumpHeld: true });
    expect(h.vy).toBeLessThan(-500); expect(h.vy).toBeGreaterThan(-620);
    const velocity = h.vy;
    game.update(1 / 60, { ...EMPTY_INPUT, jumpPressed: true, jumpHeld: true });
    expect(h.vy).toBeGreaterThan(velocity); expect(h.jumps).toBe(2);
  });
});
