import { describe, expect, it } from 'vitest';
import { createRoom, isSafeFloorPoint } from './levels';

describe('v4.2 exploration routes and standing safety', () => {
  it('checks the whole actor width and both sides of spikes', () => {
    const room = {
      platforms: [{ x: 0, y: 448, w: 500, h: 120, kind: 'ground' as const }],
      hazards: [{ x: 240, y: 430, w: 100, h: 18, kind: 'spikes' as const }],
    };
    expect(isSafeFloorPoint(room, 20)).toBe(false);
    expect(isSafeFloorPoint(room, 100)).toBe(true);
    expect(isSafeFloorPoint(room, 215)).toBe(false);
    expect(isSafeFloorPoint(room, 340)).toBe(false);
    expect(isSafeFloorPoint(room, 380)).toBe(true);
    expect(isSafeFloorPoint(room, 450)).toBe(false);
  });

  it('places ground enemies away from ledges and spike footprints for every authored variant', () => {
    for (let index = 0; index < 7; index++) for (let seed = 1; seed <= 90; seed++) {
      const { room, enemies } = createRoom(seed, index);
      for (const enemy of enemies.filter(item => item.kind !== 'bat')) {
        expect(isSafeFloorPoint(room, enemy.x, enemy.w), `${index}:${seed}:${enemy.id}`).toBe(true);
      }
    }
  });

  it('adds reachable upper reward paths and two supported healing opportunities in every normal room', () => {
    for (let index = 0; index < 7; index++) for (let seed = 1; seed <= 60; seed++) {
      const { room, pickups } = createRoom(seed, index);
      const upper = room.platforms.filter(platform => platform.oneWay && platform.y < 250);
      expect(upper.length).toBeGreaterThanOrEqual(1);
      expect(room.decorations.some(decor => decor.kind === 'crystal' && decor.y < 250)).toBe(true);
      const hearts = pickups.filter(pickup => pickup.kind === 'heart');
      expect(hearts).toHaveLength(2);
      for (const heart of hearts) {
        expect(room.platforms.some(platform => heart.x >= platform.x && heart.x + heart.w <= platform.x + platform.w && platform.y >= heart.y + heart.h && platform.y - heart.y - heart.h <= 40)).toBe(true);
        expect(room.hazards.some(hazard => heart.x + heart.w > hazard.x && heart.x < hazard.x + hazard.w && heart.y + heart.h > hazard.y && heart.y < hazard.y + hazard.h), `heart overlaps hazard: act=${index},seed=${seed},x=${heart.x},y=${heart.y}`).toBe(false);
      }
      for (const platform of room.platforms) {
        expect(platform.x).toBeGreaterThanOrEqual(0);
        expect(platform.x + platform.w).toBeLessThanOrEqual(room.width);
      }
    }
  });
});
