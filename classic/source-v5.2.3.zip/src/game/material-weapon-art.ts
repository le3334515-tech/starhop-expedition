import { artImage } from './art-assets';
import type { WeaponId } from './types';

const customWeapons = {
  frostStaff: { image: 'equipment/frost-branch-staff.png', gripX: 16, gripY: 8 },
  willowSword: { image: 'equipment/willow-sword.png', gripX: 7, gripY: 8 },
};

const polearms = {
  reedJavelin: { tile: 3, size: 10, pivotX: 6.7, pivotY: 5.7, scale: 1.22, butt: -21, neck: 25, wrap: '#9ba58d' },
  halberd: { tile: 4, size: 9, pivotX: 7.7, pivotY: 7.4, scale: 1.55, butt: -19, neck: 28, wrap: '#c4a479' },
};

export function drawMaterialWeapon(ctx: CanvasRenderingContext2D, weapon: WeaponId): boolean {
  if (weapon === 'frostStaff' || weapon === 'willowSword') {
    const art = customWeapons[weapon];
    const texture = artImage(art.image);
    if (!texture) return false;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(texture, -art.gripX, -art.gripY);
    ctx.restore();
    return true;
  }
  const sheet = artImage('equipment/steel-arms.png');
  if (!sheet) return false;
  if (weapon === 'halberd' || weapon === 'reedJavelin') {
    const { tile, size, pivotX, pivotY, scale, butt, neck, wrap } = polearms[weapon];
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    // Keep the author's blade and continue the socket through the character's hand.
    ctx.fillStyle = '#332e2a'; ctx.fillRect(butt, -1.75, neck - butt + 3, 3.5);
    ctx.fillStyle = '#846c55'; ctx.fillRect(butt + 1, -1, neck - butt + 1, 1.7);
    ctx.fillStyle = wrap; ctx.fillRect(neck - 6, -2, 6, 3);
    ctx.fillStyle = '#c9a680'; ctx.fillRect(-5, -1.15, 9, 2);
    ctx.translate(neck, 0);
    ctx.rotate(Math.PI * .75);
    ctx.scale(scale, scale);
    ctx.drawImage(sheet, tile * 16, 0, size, size, -pivotX, -pivotY, size, size);
    ctx.restore();
    return true;
  }
  if (weapon !== 'jadeNeedle') return false;
  // The atlas tile's tip points up-left. Align its grip with the hand.
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.rotate(Math.PI * .75);
  ctx.scale(1.38, 1.38);
  ctx.drawImage(sheet, 32, 0, 16, 16, -13, -13, 16, 16);
  ctx.restore();
  return true;
}
