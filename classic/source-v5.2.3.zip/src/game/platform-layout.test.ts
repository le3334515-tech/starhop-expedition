import { describe, expect, it } from 'vitest';
import { createThemedRoom } from './levels';
import { createCoopRoom } from './coop-levels';
import { GameEngine } from './engine';
import { EMPTY_INPUT, type Platform } from './types';

const intersection = (a: Platform, b: Platform) => ({ w: Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x), h: Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y) });

describe('authored platform surfaces do not cross each other', () => {
  it('separates the windward C wood and stone decks highlighted in the screenshot', () => {
    const room = createThemedRoom(2, 6, 2).room;
    const wood = room.platforms.find(p => p.oneWay && p.kind === 'wood' && p.x === 1290)!;
    const stone = room.platforms.find(p => p.oneWay && p.y === 332)!;
    expect(wood).toBeDefined(); expect(stone).toBeDefined();
    expect(stone.x - wood.x - wood.w).toBeGreaterThanOrEqual(20);
    expect(stone.x - wood.x - wood.w).toBeLessThanOrEqual(50);
  });

  it('keeps the celestial B reward step clear of its existing same-height landing', () => {
    const room = createThemedRoom(2, 0, 6).room;
    const sameHeight = room.platforms.filter(p => p.oneWay && p.y === 208).sort((a, b) => a.x - b.x);
    expect(sameHeight).toHaveLength(2);
    expect(sameHeight[1].x - sameHeight[0].x - sameHeight[0].w).toBeGreaterThanOrEqual(20);
  });

  it('keeps the later skyforge stone and wood landings distinct', () => {
    const room = createCoopRoom(1, 8, 4).room;
    const stone = room.platforms.find(p => p.oneWay && p.x === 2200)!;
    const wood = room.platforms.find(p => p.oneWay && p.y === 348 && p.x > 2300)!;
    expect(wood.x - stone.x - stone.w).toBeGreaterThanOrEqual(24);
    expect(wood.x - stone.x - stone.w).toBeLessThanOrEqual(80);
  });

  it('has no intersecting one-way decks in all eleven realms and authored seed variants', () => {
    const checked = new Set<string>(), realms = new Set<string>();
    for (let seed = 1; seed <= 90; seed++) for (let index = 0; index < 11; index++) for (const size of [1, 4]) {
      const room = createCoopRoom(seed, index, size).room;
      realms.add(room.name);
      const key = `${room.name}:${room.subtitle}:${size}`;
      if (checked.has(key)) continue;
      checked.add(key);
      const platforms = room.platforms.filter(p => p.oneWay && p.kind !== 'spring');
      for (let a = 0; a < platforms.length; a++) for (let b = a + 1; b < platforms.length; b++) {
        const area = intersection(platforms[a], platforms[b]);
        expect(area.w > 0 && area.h > 0, `${key}: ${JSON.stringify(platforms[a])} crosses ${JSON.stringify(platforms[b])}`).toBe(false);
      }
    }
    expect(realms.size).toBe(11);
    expect(checked.size).toBe(54);
  });

  it.each(['windward', 'celestial', 'skyforge'] as const)('can still cross the separated %s landing with one real jump', scene => {
    const contents = scene === 'skyforge' ? createCoopRoom(1, 8, 4) : createThemedRoom(2, scene === 'windward' ? 6 : 0, scene === 'windward' ? 2 : 6);
    const start = contents.room.platforms.find(p => p.oneWay && (scene === 'windward' ? p.x === 1290 : scene === 'celestial' ? p.x === 850 : p.x === 2200))!;
    const finish = contents.room.platforms.find(p => p.oneWay && (scene === 'windward' ? p.y === 332 : scene === 'celestial' ? p.y === 208 && p.x > 1030 : p.y === 348 && p.x > 2300))!;
    const game = new GameEngine(); game.start({ seed: 2, modifier: 'standard', weapon: 'blade' });
    const state = game.state; Object.assign(state, contents, { enemies: [], pickups: [] });
    Object.assign(state.hero, { x: start.x + start.w - 60, y: start.y - state.hero.h, vx: 0, vy: 0, grounded: true, invincible: 100 });
    let landed = false, maximumJumps = 0;
    for (let frame = 0; frame < 120; frame++) {
      game.update(1 / 120, { ...EMPTY_INPUT, right: state.hero.x < finish.x + 20, jumpPressed: frame === 0 });
      maximumJumps = Math.max(maximumJumps, state.hero.jumps);
      if (state.hero.grounded && Math.abs(state.hero.y + state.hero.h - finish.y) < .1 && state.hero.x >= finish.x && state.hero.x + state.hero.w <= finish.x + finish.w) { landed = true; break; }
    }
    expect(landed).toBe(true);
    expect(maximumJumps).toBe(1);
  });
});
