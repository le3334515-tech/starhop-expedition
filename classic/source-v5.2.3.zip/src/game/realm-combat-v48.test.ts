import { describe, expect, it } from 'vitest';
import { GameEngine } from './engine';
import { createThemedRoom } from './levels';
import { enemyDamageMultiplier } from './enemy-variants';
import { sampleTrap, TRAP_DESIGNS } from './realm-traps';
import { EMPTY_INPUT, type Enemy, type Projectile } from './types';

function arena(theme: number) {
  const game = new GameEngine();
  game.start({ seed: 42, modifier: 'standard', weapon: 'blade' });
  const content = createThemedRoom(42, 0, theme);
  const state = game.state;
  state.room = content.room;
  state.enemies = content.enemies;
  state.pickups = [];
  return { game, state };
}

describe('realm combat v4.8', () => {
  it('ramps enemy durability without modifying the seeded terrain or roster', () => {
    for (let theme = 0; theme < 7; theme++) {
      const opening = createThemedRoom(42, 0, theme);
      const late = createThemedRoom(42, 6, theme);
      expect(opening.room.hazards).toEqual(late.room.hazards);
      expect(opening.enemies.map(e => e.x)).toEqual(late.enemies.map(e => e.x));
      late.enemies.forEach((enemy, index) => {
        const earlyHp = opening.enemies[index].hp;
        expect(enemy.hp).toBeCloseTo(Math.min(8.5, earlyHp * 1.36));
      });
    }
  });

  it('places one shield fighter close enough to charge across a real vent in every forge layout', () => {
    for (const seed of [1, 2, 3, 4, 5, 6, 42, 87]) {
      const { room, enemies } = createThemedRoom(seed, 4, 5);
      const guards = enemies.filter(enemy => enemy.variant === 'forge-bulwark');
      expect(guards).toHaveLength(1);
      expect(room.hazards.some(hazard => hazard.kind === 'mechanism' && Math.abs(hazard.x - guards[0].x) <= 120)).toBe(true);
    }
  });

  it('lets the placed iron guard charge into the vent when lured across it', () => {
    const { game, state } = arena(5);
    const guard = state.enemies.find(e => e.variant === 'forge-bulwark')!;
    state.enemies = [guard];
    const vent = state.room.hazards.find(h => h.kind === 'mechanism' && Math.abs(h.x - guard.x) <= 120)!;
    if (vent.kind !== 'mechanism') throw Error('Expected a furnace vent');
    const design = TRAP_DESIGNS[5];
    state.time = design.period - vent.offset - design.active - .64;
    guard.attackCooldown = 0;
    state.hero.x = guard.x > vent.x ? vent.x - 76 : vent.x + vent.w + 76;
    state.hero.y = 448 - state.hero.h;
    for (let frame = 0; frame < 140 && !guard.nextMechanismHit; frame++) game.update(1 / 120, EMPTY_INPUT);
    expect(guard.aiCount).toBe(1);
    expect(guard.aiMode).toBe('recover');
    expect(guard.nextMechanismHit).toBeGreaterThan(state.time);
  });

  it.each([[3, 'crypt-bulwark'], [5, 'forge-bulwark']] as const)(
    'an active mechanism in theme %i interrupts the shield and holds a short vulnerability',
    (theme, variant) => {
      const { game, state } = arena(theme);
      const enemy = state.enemies.find(e => e.variant === variant)!;
      const trap = state.room.hazards.find(h => h.kind === 'mechanism')!;
      if (trap.kind !== 'mechanism') throw Error('Expected a realm mechanism');
      const design = TRAP_DESIGNS[theme];
      state.time = design.period - trap.offset - design.active * .5;
      const hit = sampleTrap(trap, state.time).hit!;
      Object.assign(enemy, { x: hit.x, vx: 120, y: 448 - enemy.h, facing: 1, aiMode: 'windup', aiTimer: .3 });
      state.hero.x = enemy.x + 150;
      const originalHp = enemy.hp;
      expect(enemyDamageMultiplier(enemy, state.hero)).toBe(.35);
      game.update(1 / 120, EMPTY_INPUT);
      expect(enemy.aiMode).toBe('recover');
      expect(enemyDamageMultiplier(enemy, state.hero)).toBe(1);
      expect(enemy.hp).toBe(originalHp);
      const timer = enemy.aiTimer!;
      game.update(1 / 120, EMPTY_INPUT);
      expect(enemy.aiTimer).toBeLessThan(timer);
    },
  );

  it('marks with a staff projectile, preserves the mark on the outward disc, and expends it on return', () => {
    const { game, state } = arena(0);
    const enemy: Enemy = state.enemies.find(e => e.kind !== 'bat')!;
    Object.assign(enemy, { x: 460, y: 448 - enemy.h, hp: 30, maxHp: 30, attackCooldown: 9 });
    state.enemies = [enemy];
    state.room.hazards = [];
    state.hero.x = 280;
    function shot(id: number, kind: 'ember' | 'disc', returning = false): Projectile {
      return { id, kind, returning, life: 1.6, damage: 1, owner: 'hero', hitIds: [], x: enemy.x + 12, y: enemy.y + 8,
        vx: 0, vy: 0, w: 16, h: 16, burn: kind === 'ember' ? 1.6 : undefined, primesEmber: kind === 'ember' };
    }
    state.projectiles = [shot(1, 'ember')];
    game.update(1 / 120, EMPTY_INPUT);
    expect(enemy.emberMark).toBe(2.75);
    game.state.hitstop = 0;
    state.projectiles = [shot(2, 'disc')];
    game.update(1 / 120, EMPTY_INPUT);
    expect(enemy.emberMark).toBeGreaterThan(2.7);
    game.state.hitstop = 0;
    enemy.aiMode = 'windup'; enemy.aiTimer = .4;
    const hp = enemy.hp;
    state.projectiles = [shot(3, 'disc', true)];
    game.update(1 / 120, EMPTY_INPUT);
    expect(enemy.emberMark).toBe(0);
    expect(enemy.burnTime).toBe(0);
    expect(enemy.aiMode).toBe('recover');
    expect(enemy.hp).toBeCloseTo(hp - 1.5);
  });
});
