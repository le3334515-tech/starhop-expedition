import { describe, expect, it } from 'vitest';
import { createThemedRoom, isSafeFloorPoint } from './levels';
import { isPlatformTrap, sampleTrap, TRAP_DESIGNS } from './realm-traps';
import { GameEngine } from './engine';
import { EMPTY_INPUT } from './types';

describe('realm mechanisms', () => {
  it.each(TRAP_DESIGNS.map((d,theme) => [theme,d.name] as const))('places readable timed hazards in realm %i (%s)', theme => {
    for (let seed = 0; seed < 18; seed++) {
      const {room,pickups} = createThemedRoom(seed,0,theme);
      const traps = room.hazards.filter(t => t.kind === 'mechanism');
      expect(traps).toHaveLength(2);
      expect(traps.filter(isPlatformTrap)).toHaveLength([0, 3, 6].includes(theme) ? 1 : 0);
      for (const trap of traps) {
        if (trap.kind !== 'mechanism') throw Error('unexpected trap');
        if (isPlatformTrap(trap)) {
          const ledge = room.platforms.find(p => p.oneWay && p.y === trap.y + trap.h && trap.x >= p.x + 40 && trap.x + trap.w <= p.x + p.w - 40);
          expect(ledge).toBeDefined();
          expect(pickups.some(p => p.x < trap.x + trap.w && p.x + p.w > trap.x && p.y < trap.y + trap.h && p.y + p.h > trap.y)).toBe(false);
        } else {
          expect(isSafeFloorPoint(room,trap.x)).toBe(false);
        }
        expect(isSafeFloorPoint(room,room.spawn.x)).toBe(true);
        const d=TRAP_DESIGNS[theme], end=d.period-trap.offset;
        const pre=sampleTrap(trap,end-d.active-.45);
        expect(pre.warning).toBe(true);expect(pre.hit).toBeNull();
        const mid=sampleTrap(trap,end-d.active*.5);
        expect(mid.active).toBe(true);expect(mid.hit?.w).toBeGreaterThan(0);
      }
    }
  });
  it('hits the traveller on the crypt shelf while leaving the same ground lane safe', () => {
    const game = new GameEngine();
    game.start({seed:42, modifier:'standard', weapon:'blade'});
    const state = game.state;
    state.room = createThemedRoom(42,0,3).room;
    const bell = state.room.hazards.find(trap => trap.kind === 'mechanism' && isPlatformTrap(trap));
    if (!bell || bell.kind !== 'mechanism') throw Error('missing raised bell');
    state.room.hazards = [bell]; state.enemies = []; state.pickups = []; state.roomCleared = true;
    const design = TRAP_DESIGNS[bell.theme];
    const time = design.period - bell.offset - design.active / 2;
    const hit = sampleTrap(bell,time).hit!;
    const hero = state.hero, hp = hero.hp, x = hit.x + hit.w / 2 - hero.w / 2;
    expect(isSafeFloorPoint(state.room,x)).toBe(true);
    for (const [foot,expectedHp] of [[448,hp], [bell.y + bell.h,hp - 1]]) {
      state.time = time;
      Object.assign(hero,{x,y:foot - hero.h,vx:0,vy:0,grounded:true,invincible:0});
      game.update(1/120,EMPTY_INPUT);
      expect(hero.hp).toBe(expectedHp);
    }
  });
  it.each([0,1,2,3,4,5,6])('applies the visible active shape for realm %i',theme=>{
    const game = new GameEngine(); game.start({seed:42, modifier:'standard', weapon:'blade'});
    const s=game.state; s.room = createThemedRoom(42,0,theme).room;
    const trap=s.room.hazards.find(t=>t.kind==='mechanism')!;
    if(trap.kind!=='mechanism') throw Error('missing mechanism');
    const d=TRAP_DESIGNS[theme];
    s.room.platforms=s.room.platforms.filter(p=>p.kind==='ground');
    s.room.hazards=[trap]; s.pickups=[]; s.enemies=[]; s.roomCleared=true;
    s.time=d.period-trap.offset-d.active*.5;
    const hit=sampleTrap(trap,s.time).hit!;
    const h=s.hero;
    Object.assign(h,{x:hit.x+hit.w/2-h.w/2,y:theme===6?hit.y:448-h.h,grounded:theme!==6,invincible:0});
    const oldX=h.x,oldHp=h.hp;
    game.update(1/120,EMPTY_INPUT);
    if(theme===4){expect(h.vy).toBeLessThan(-600);expect(h.hp).toBe(oldHp);}
    else if(theme===2){expect(h.x).toBeLessThan(oldX);expect(h.hp).toBe(oldHp);}
    else expect(h.hp).toBe(oldHp-1);
  });
  it('keeps the final arena clear of ordinary mechanisms',()=>{
    expect(createThemedRoom(42,7,7).room.hazards).toHaveLength(0);
  });
});
