import type { Hazard, Platform, Rect, RealmTrap } from './types';

const GROUND_FLOOR = 448;
const PLATFORM_FOOTING = 40;
const PLATFORM_TRAP_THEMES = new Set([0, 3, 6]);

export const TRAP_DESIGNS = [
  { kind: 'bamboo', name: '伏竹阵', hint: '冒出青芽时，跳过突起的竹刺。', color: '#9cc88c', w: 60, h: 51, period: 4.8, active: .76 },
  { kind: 'lantern', name: '流火灯索', hint: '朱灯亮起后会扫过地面，从灯后穿过去。', color: '#e49c69', w: 124, h: 102, period: 5.1, active: 1.1 },
  { kind: 'gust', name: '回风口', hint: '风旗倒向左时会起逆风，贴地疾行或跳上栈桥。', color: '#bacfb0', w: 94, h: 70, period: 4.7, active: 1.2 },
  { kind: 'bell', name: '沉钟地鸣', hint: '跳过钟波，让它震停追来的守卫。', color: '#d0b784', w: 128, h: 35, period: 5, active: .92 },
  { kind: 'tide', name: '涌泉眼', hint: '水面泛白时踩入泉眼，可借潮跃上高台。', color: '#91cfc0', w: 56, h: 86, period: 4.2, active: .92 },
  { kind: 'kiln', name: '丹炉地火', hint: '炉栅发红时引铁卫踏入，借火破甲。', color: '#e99b63', w: 46, h: 108, period: 5.4, active: 1.04 },
  { kind: 'star', name: '错星光闸', hint: '两端星石对齐后射出横光，沿落脚面从光束下穿过。', color: '#bcb2d0', w: 110, h: 75, period: 5.2, active: .86 },
] as const;

export function isPlatformTrap(trap: RealmTrap): boolean { return trap.y + trap.h < GROUND_FLOOR; }

export function placeRealmTraps(theme: number, variant: number, platforms: Platform[], obstacles: Rect[], width: number): RealmTrap[] {
  const design = TRAP_DESIGNS[theme];
  if (!design) return [];
  const ground = platforms.filter(platform => platform.kind === 'ground');
  const result: RealmTrap[] = [];
  for (const target of [width * .28, width * .67]) {
    let best: number | undefined;
    for (let x = 258; x < width - 180 - design.w; x += 8) {
      if (best !== undefined && Math.abs(x - target) >= Math.abs(best - target)) continue;
      if (!ground.some(p => x >= p.x + 65 && x + design.w < p.x + p.w - 65)) continue;
      if (obstacles.some(p => x < p.x + p.w + 26 && x + design.w > p.x - 26)) continue;
      if (result.some(p => Math.abs(x - p.x) < 340)) continue;
      best = x;
    }
    if (best !== undefined) result.push({ kind: 'mechanism', theme, x: best, y: GROUND_FLOOR - design.h, w: design.w, h: design.h, offset: variant * .41 + result.length * 1.71 });
  }
  // Elevate the later trap onto a broad ledge. Leave the first ground encounter
  // and the high reward shelves in place, with room to land at either end.
  if (result.length === 2 && PLATFORM_TRAP_THEMES.has(theme)) {
    const groundTrap = result[1];
    const ledges = platforms.filter(platform => platform.oneWay && platform.y >= 260 && platform.w >= groundTrap.w + 2 * PLATFORM_FOOTING);
    let raised: RealmTrap | undefined;
    for (const platform of ledges) {
      const x = platform.x + Math.round((platform.w - groundTrap.w) / 2);
      const y = platform.y - groundTrap.h;
      if (Math.abs(x - result[0].x) < 340) continue;
      if (platforms.some(p => x - 8 < p.x + p.w && x + groundTrap.w + 8 > p.x && y - 20 < p.y + p.h && platform.y > p.y)) continue;
      if (!raised || Math.abs(x - groundTrap.x) < Math.abs(raised.x - groundTrap.x)) raised = { ...groundTrap, x, y };
    }
    if (raised) result[1] = raised;
  }
  return result;
}

export function sampleTrap(trap: RealmTrap, time: number) {
  const d = TRAP_DESIGNS[trap.theme];
  const beat = (time + trap.offset) % d.period;
  const left = d.period - beat;
  const active = left <= d.active;
  const warning = !active && left <= d.active + .85;
  const progress = active ? 1 - left / d.active : warning ? 1 - (left - d.active) / .85 : 0;
  const floor = trap.y + trap.h;
  const extent = Math.min(1, progress * 6, (1 - progress) * 7);
  let hit: Rect | null = null;
  if (active) {
    switch (d.kind) {
      case 'lantern': {
        const x = trap.x + 8 + (trap.w - 16) * (1 - Math.cos(progress * Math.PI)) / 2;
        hit = { x: x - 8, y: floor - 26 - Math.abs(Math.cos(progress * Math.PI)) * 19, w: 16, h: 20 }; break;
      }
      case 'bell': hit = { x: trap.x + (trap.w - 20) * progress, y: floor - 24, w: 20, h: 24 }; break;
      case 'star': hit = { x: trap.x + 5, y: trap.y + 6, w: trap.w - 10, h: 8 }; break;
      default: {
        const height = Math.round(trap.h * extent);
        if (height > 3) hit = { x: trap.x + 3, y: floor - height, w: trap.w - 6, h: height };
      }
    }
  }
  return { active, warning, progress, hit };
}

export function hasUnsafeFloor(h: Hazard) { return h.kind === 'spikes' || (h.kind === 'mechanism' && !isPlatformTrap(h)); }
