import { describe, expect, it } from 'vitest';
import { GameEngine, UPGRADES } from './engine';
import { EMPTY_INPUT, type Enemy, type WeaponId } from './types';

const target = (x: number, hp = 100, id = 70): Enemy => ({ id, kind: 'sentry', x, y: 406, w: 32, h: 42, vx: 0, vy: 0, hp, maxHp: hp, facing: -1, timer: 0, hurt: 0, dead: false, originX: x, originY: 406, attackCooldown: 99 });
function arena(weapon: WeaponId = 'blade', sound?: (name: string) => void) {
  const game = new GameEngine({ sound }); game.start({ seed: 42, modifier: 'standard', weapon });
  const s = game.state;
  s.room.platforms = [{ x: 0, y: 448, w: s.room.width, h: 120, kind: 'ground' }];
  s.room.hazards = []; s.pickups = []; s.enemies = [target(1900)];
  Object.assign(s.hero, { x: 300, y: 412, grounded: true, critChance: 0, invincible: 0 });
  return game;
}
function grant(game: GameEngine, id: string) {
  game.state.phase = 'upgrade'; game.state.upgradeChoices = [UPGRADES.find(upgrade => upgrade.id === id)!];
  game.chooseUpgrade(id);
}
function advance(game: GameEngine, seconds: number, attackHeld = false) {
  for (let n = 0; n < Math.ceil(seconds * 120); n++) game.update(1 / 120, { ...EMPTY_INPUT, attackHeld });
}

describe('v4.3 upgrades change combat and rewards', () => {
  it('turns a normal two-hit enemy into a one-hit blade kill', () => {
    const plain = arena(), forged = arena(); grant(forged, 'edge');
    for (const game of [plain, forged]) {
      game.state.enemies = [target(355, 2), target(1900, 100, 71)];
      game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    }
    expect(plain.state.enemies[0].dead).toBe(false);
    expect(forged.state.enemies[0].dead).toBe(true);
  });

  it.each<WeaponId>(['ember', 'disc'])('also gives %s visibly stronger real projectile hits', weapon => {
    const plain = arena(weapon), forged = arena(weapon); grant(forged, 'edge');
    for (const game of [plain, forged]) {
      game.state.enemies = [target(470)];
      game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true }); advance(game, 1.1);
    }
    expect(100 - forged.state.enemies[0].hp).toBeGreaterThan((100 - plain.state.enemies[0].hp) * 1.5);
  });

  it('extends actual blade reach instead of only drawing a longer slash', () => {
    const plain = arena(), forged = arena(); grant(forged, 'edge');
    for (const game of [plain, forged]) {
      game.state.enemies = [target(405)];
      game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    }
    expect(plain.state.enemies[0].hp).toBe(100);
    expect(forged.state.enemies[0].hp).toBeLessThan(100);
  });

  it('tempo produces more complete attacks in the same time', () => {
    let normal = 0, fast = 0;
    const plain = arena('blade', name => { if (name === 'attack') normal++; });
    const swift = arena('blade', name => { if (name === 'attack') fast++; }); grant(swift, 'tempo');
    advance(plain, 2, true); advance(swift, 2, true);
    expect(fast).toBeGreaterThanOrEqual(normal + 2);
  });

  it('stride damages an enemy with a dash alone and never double-hits that dash', () => {
    const game = arena(); grant(game, 'stride'); const enemy = target(350); game.state.enemies = [enemy];
    game.update(1 / 120, { ...EMPTY_INPUT, dashPressed: true, right: true }); advance(game, .24);
    expect(enemy.hp).toBeCloseTo(99.2);
    expect(game.state.hero.speed).toBeGreaterThan(300);
    expect(game.state.floatingTexts.some(text => text.text === '追风刃')).toBe(true);
  });

  it('vigor grants two real hearts and fully restores health', () => {
    const game = arena(); game.state.hero.hp = 1; grant(game, 'vigor');
    expect(game.state.hero.hp).toBe(7); expect(game.state.hero.maxHp).toBe(7);
  });

  it('multishot gives blade a ranged attack and increases staff projectiles', () => {
    for (const weapon of ['blade', 'ember'] as const) {
      const game = arena(weapon); grant(game, 'multishot');
      game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
      expect(game.state.projectiles.filter(p => p.owner === 'hero')).toHaveLength(weapon === 'blade' ? 1 : 2);
    }
  });

  it('moon shield really absorbs three hits before health is lost', () => {
    const game = arena(); grant(game, 'shield'); const h = game.state.hero;
    for (let hit = 0; hit < 3; hit++) {
      h.invincible = 0; game.state.enemies = [target(h.x)];
      game.update(1 / 120, EMPTY_INPUT); expect(h.hp).toBe(5);
    }
    expect(h.shield).toBe(0);
    h.invincible = 0; game.state.enemies = [target(h.x)]; game.update(1 / 120, EMPTY_INPUT);
    expect(h.hp).toBe(4);
  });

  it('blood heals on every kill while wounded, with a real recovery label', () => {
    const game = arena(); grant(game, 'blood'); game.state.hero.hp = 2;
    game.state.enemies = [target(350, .1, 70), target(360, .1, 71), target(1900, 100, 72)];
    game.update(1 / 120, { ...EMPTY_INPUT, attackPressed: true });
    expect(game.state.hero.hp).toBe(4);
    expect(game.state.floatingTexts.filter(text => text.text === '汲取 +1 ♥')).toHaveLength(2);
  });

  it('magnet attracts drops that previously remained out of reach', () => {
    const plain = arena(), magnetic = arena(); grant(magnetic, 'magnet');
    for (const game of [plain, magnetic]) {
      game.state.pickups = [{ id: 99, kind: 'coin', x: 560, y: 420, w: 13, h: 16, value: 1, vy: 0, bob: 0, collected: false }];
      game.update(1 / 120, EMPTY_INPUT);
    }
    expect(plain.state.pickups[0].x).toBe(560); expect(magnetic.state.pickups[0].x).toBeLessThan(560);
  });

  it('fortune turns one pickup into three coins plus usable awakening energy', () => {
    const game = arena(); grant(game, 'fortune');
    game.state.pickups = [{ id: 99, kind: 'coin', x: 310, y: 420, w: 13, h: 16, value: 1, vy: 0, bob: 0, collected: false }];
    game.update(1 / 120, EMPTY_INPUT);
    expect(game.state.coins).toBe(3); expect(game.state.resonance).toBe(3);
  });

  it('never offers already-maxed attack speed, extra shots, stride, or blood', () => {
    for (let seed = 1; seed <= 24; seed++) {
      const game = arena(); game.state.seed = seed;
      Object.assign(game.state.hero, { attackSpeed: 2.8, speed: 460, extraProjectiles: 3, lifesteal: 1, xp: 9 });
      game.state.pickups = [{ id: 99, kind: 'xp', x: 310, y: 420, w: 11, h: 11, value: 5, vy: 0, bob: 0, collected: false }];
      game.update(1 / 120, EMPTY_INPUT);
      expect(game.state.phase).toBe('upgrade');
      expect(game.state.upgradeChoices.some(upgrade => ['tempo', 'stride', 'multishot', 'blood'].includes(upgrade.id))).toBe(false);
    }
  });
});

describe('v4.6 situational seals', () => {
  it('damages nearby targets on the second jump and spares distant enemies', () => {
    const game = arena(); grant(game, 'frost'); grant(game, 'frost');
    const s = game.state; s.enemies = [target(345), target(570, 100, 71)];
    Object.assign(s.hero, { grounded: false, coyote: 0, jumps: 1, y: 380 });
    game.update(1 / 120, { ...EMPTY_INPUT, jumpPressed: true, jumpHeld: true });
    expect(s.enemies[0].hp).toBe(96); expect(s.enemies[1].hp).toBe(100);
    expect(s.particles.some(p => p.color === '#b9d9d4' && p.gravity === 0)).toBe(true);
  });
  it('sounds one bell pulse only when a guard actually catches an attack', () => {
    const game = arena(); grant(game, 'bell');
    const s = game.state; s.enemies = [target(395), target(650, 100, 71)];
    game.requestGuard(); game.update(1 / 120, EMPTY_INPUT);
    expect(s.enemies[0].hp).toBe(100);
    s.projectiles.push({ id:81, kind:'enemy', owner:'enemy', x:320, y:422, w:8, h:8,
      vx:-20, vy:0, life:1, damage:1, hitIds:[] });
    game.update(1 / 120, EMPTY_INPUT);
    expect(s.hero.hp).toBe(s.hero.maxHp);
    expect(s.enemies[0].hp).toBe(97); expect(s.enemies[1].hp).toBe(100);
  });
  it('subtracts the shown amount of dash cooldown for each collected XP orb', () => {
    const game = arena(); grant(game,'breeze'); grant(game,'breeze');
    const s = game.state; s.hero.dashCooldown = 1.2;
    s.pickups = [{ id:10,x:308,y:423,w:10,h:10,kind:'xp',value:1,bob:0,collected:false,vy:0 }];
    game.update(1 / 120,EMPTY_INPUT);
    expect(s.hero.dashCooldown).toBeCloseTo(1.2 - .7 - 1/120);
  });
});
