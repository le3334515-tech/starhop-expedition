import { artImage } from './art-assets';
import { ascensionProgress, BOSS_ASCENSION_IMPACT, BOSS_ASCENSION_TIME, BOSS_TRANSFORM_TIME, ease, ECLIPSE_WINDUP, openingAscension, openingSeal, sealProgress } from './boss-seal';
import type { Boss } from './types';

const CELL_W = 144, CELL_H = 94, PIVOT_X = 54, PIVOT_Y = 89;
const TEMPER_AT = 2.04 / BOSS_TRANSFORM_TIME;
const ASCEND_AT = BOSS_ASCENSION_IMPACT / BOSS_ASCENSION_TIME;
const TAU = Math.PI * 2;
const clamp = (n: number, low = 0, high = 1) => Math.max(low, Math.min(high, n));
const count = { idle: 11, run: 8, jump: 3, fall: 3, strike: 7, cleave: 7, hurt: 4, death: 11 };
type Motion = keyof typeof count;
const deaths = new WeakMap<Boss, number>();

type Cinematic = { progress: number; impact: number };
function cinematic(b: Boss): Cinematic | null {
  if (openingSeal(b)) return { progress: sealProgress(b), impact: TEMPER_AT };
  if (openingAscension(b)) return { progress: ascensionProgress(b), impact: ASCEND_AT };
  return null;
}

function pose(b: Boss, now: number, scene: Cinematic | null): [Motion, number] {
  if (scene) {
    if (scene.progress < scene.impact) return ['strike', 1];
    return ['idle', Math.floor(now * 7) % count.idle];
  }
  if (b.mode === 'dead') {
    if (!deaths.has(b)) deaths.set(b, now);
    return ['death', Math.min(count.death - 1, Math.floor((now - deaths.get(b)!) * 10))];
  }
  deaths.delete(b);
  if (b.mode === 'windup') {
    const duration = b.intent === 'eclipse' ? ECLIPSE_WINDUP : .82 - (b.phase - 1) * .17;
    const close = b.intent === 'leap' || b.intent === 'slam' || b.intent === 'rift';
    return [close ? 'strike' : 'cleave', Math.floor(clamp(1 - b.timer / duration) * 2.9)];
  }
  if (b.mode === 'charge') return ['run', Math.floor(now * 21) % count.run];
  if (b.mode === 'jump') {
    return [b.vy < 0 ? 'jump' : 'fall', Math.min(2, Math.floor(Math.abs(b.vy) / 175))];
  }
  if (b.mode === 'slam') return ['strike', 3 + Math.min(3, Math.floor(clamp(1 - b.timer / .12) * 4))];
  if (b.mode === 'barrage') return ['cleave', 3 + Math.floor(now * 17) % 4];
  if (b.mode === 'stagger' || b.hurt > .065) return ['hurt', b.mode === 'stagger' ? 3 : 2];
  return ['idle', Math.floor(now * (b.mode === 'recover' ? 5 : 8)) % count.idle];
}

function sword(c: CanvasRenderingContext2D, x: number, y: number, length: number, angle: number, fill: string) {
  c.save(); c.translate(Math.round(x), Math.round(y)); c.rotate(angle);
  const wide = length * .105;
  c.fillStyle = '#171a28';
  c.fillRect(-2, -2, 4, length + 10);
  c.fillStyle = fill;
  c.fillRect(-wide * 1.5, 2, wide * 3, 3);
  c.fillRect(-2, -6, 4, 5);
  c.beginPath();
  c.moveTo(-wide, 6); c.lineTo(wide, 6); c.lineTo(wide, length * .74);
  c.lineTo(0, length); c.lineTo(-wide, length * .74); c.closePath(); c.fill();
  c.fillStyle = '#fff0b2'; c.fillRect(-1, 9, 2, length * .73);
  c.restore();
}

export function drawWardenBackdrop(c: CanvasRenderingContext2D, b: Boss, now: number, reduce: boolean) {
  const x = Math.round(b.x + b.w / 2), foot = Math.round(b.y + b.h);
  const scene = cinematic(b);
  if (scene) {
    const { progress, impact } = scene;
    const rise = ease(.02, impact, progress);
    const spent = ease(impact, 1, progress);
    const gold = b.phase === 3 ? '#ffca70' : '#f49865';
    c.save(); c.translate(x, foot);
    // The swords converge on the armor before the new crest lights up.
    for (let i = 0; i < 6; i++) {
      const direction = i % 2 ? 1 : -1, row = Math.floor(i / 2);
      const magnitude = 196 - row * 37 - rise * 125 + spent * 148;
      c.globalAlpha = (reduce ? .52 : .86) * (1 - spent) * ease(0, .14 + row * .035, progress);
      sword(c, direction * magnitude, -118 - row * 22 + spent * 25, 76 - row * 9,
        direction * (-.7 + row * .14 - rise * .5 + spent * 1.8), gold);
    }
    c.strokeStyle = gold; c.lineWidth = 2;
    for (let i = 0; i < 3; i++) {
      const size = 38 + i * 17 + spent * (122 + i * 20);
      c.globalAlpha = (.55 - i * .1) * (1 - spent) * ease(0, .15, progress);
      c.beginPath(); c.ellipse(0, -3 - i * 3, size, size * .18, 0, 0, TAU); c.stroke();
    }
    if (!reduce) {
      const flash = Math.max(0, 1 - Math.abs(progress - impact) * 13);
      c.globalAlpha = flash * .32; c.fillStyle = '#ffd38f';
      c.fillRect(-4, -300, 8, 298);
      c.globalAlpha = flash * .16; c.fillRect(-25, -246, 50, 243);
    }
    c.restore();
    return;
  }
  if (b.phase < 2 || b.mode === 'stagger') return;
  const end = b.phase >= 3;
  const raised = b.mode === 'windup' || b.mode === 'barrage';
  const gold = end ? '#eab05c' : '#a6534c';
  c.save(); c.translate(x, foot);
  c.globalAlpha = raised ? .67 : .47;
  for (let i = 0; i < (end ? 5 : 2); i++) {
    const side = i % 2 ? 1 : -1, depth = Math.floor(i / 2);
    const sway = reduce ? 0 : Math.round(Math.sin(now * 3.4 + i) * 5);
    const px = side * (65 + depth * 19), py = -119 - depth * 15 + sway;
    sword(c, px, py, (end ? 51 : 40) - depth * 5, side * (raised ? .58 : -.45 - depth * .29), gold);
  }
  if (end) {
    c.strokeStyle = '#a9674f'; c.lineWidth = 2; c.globalAlpha = .48;
    c.beginPath(); c.ellipse(0, -2, 78, 11, 0, 0, TAU); c.stroke();
    c.strokeStyle = '#ce9055'; c.globalAlpha *= .65;
    c.beginPath(); c.ellipse(0, -3, 98, 14, 0, 0, TAU); c.stroke();
  }
  c.restore();
}

export function drawWardenArt(c: CanvasRenderingContext2D, b: Boss, now: number): boolean {
  const scene = cinematic(b);
  const [motion, frame] = pose(b, now, scene);
  const art = artImage(`actors/warden-${motion}.png`);
  if (!art) return false;
  const phase = scene && scene.progress < scene.impact ? b.phase - 1 : b.phase;
  const scale = b.h / 52;
  const foot = b.y + b.h - (scene ? Math.round(Math.sin(scene.progress * Math.PI) * 17) : 0);
  const x = b.x + b.w / 2;
  c.save();
  c.translate(Math.round(x), Math.round(foot));
  c.scale((b.facing || -1) * (1 + (phase - 1) * .065), 1);
  c.imageSmoothingEnabled = false;
  if (b.hurt > .085 && b.mode !== 'dead') c.filter = 'brightness(1.42) saturate(.65)';
  c.drawImage(art, frame * CELL_W, (phase - 1) * CELL_H, CELL_W, CELL_H,
    -Math.round(PIVOT_X * scale), -Math.round(PIVOT_Y * scale),
    Math.round(CELL_W * scale), Math.round(CELL_H * scale));
  c.restore();
  return true;
}
