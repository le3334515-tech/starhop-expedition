export type CharacterImpactSound = `${'blade' | 'staff' | 'wheel' | 'spear' | 'monk'}${'Contact' | 'Finisher'}`;

type Tone = {
  frequency: number;
  duration: number;
  type: OscillatorType;
  volume: number;
  at: number;
  endFrequency?: number;
};
type Noise = { frequency: number; duration: number; volume: number; at: number };
type ImpactVoice = { cooldown: number; tones: readonly Tone[]; noise: readonly Noise[] };

const tone = (frequency: number, duration: number, type: OscillatorType, volume: number, endFrequency?: number, at = 0): Tone =>
  ({ frequency, duration, type, volume, at, endFrequency });
const noise = (frequency: number, duration: number, volume: number, at = 0): Noise =>
  ({ frequency, duration, volume, at });

const VOICES: Record<CharacterImpactSound, ImpactVoice> = {
  // Fine steel, with a shorter and higher scrape than the original sword.
  bladeContact: {
    cooldown: .057,
    tones: [tone(324, .074, 'triangle', .15, 123), tone(1568, .072, 'sine', .10, 1080)],
    noise: [noise(4700, .036, .16)],
  },
  bladeFinisher: {
    cooldown: .105,
    tones: [tone(189, .14, 'sine', .25, 53), tone(1760, .13, 'triangle', .13, 960),
      tone(2480, .086, 'sine', .08, 1380, .029)],
    noise: [noise(5200, .063, .22), noise(3700, .035, .09, .030)],
  },
  // A hollow bell blooms out of the spell impact.
  staffContact: {
    cooldown: .068,
    tones: [tone(262, .15, 'sine', .16, 126), tone(659, .19, 'sine', .12, 554, .009),
      tone(987, .14, 'sine', .06, 880, .018)],
    noise: [noise(1160, .052, .11)],
  },
  staffFinisher: {
    cooldown: .125,
    tones: [tone(147, .21, 'sine', .25, 58), tone(523, .27, 'triangle', .11, 466),
      tone(784, .24, 'sine', .12, 698, .021), tone(1175, .15, 'sine', .09, 988, .047)],
    noise: [noise(1450, .088, .16), noise(4100, .07, .08, .043)],
  },
  // A narrow fabric snap and a higher wooden tick.
  wheelContact: {
    cooldown: .059,
    tones: [tone(565, .047, 'triangle', .16, 340), tone(880, .095, 'sine', .09, 1320, .015)],
    noise: [noise(6100, .040, .19)],
  },
  wheelFinisher: {
    cooldown: .105,
    tones: [tone(490, .084, 'triangle', .18, 188), tone(912, .079, 'triangle', .13, 1410, .031),
      tone(1397, .115, 'sine', .09, 1060, .054)],
    noise: [noise(5700, .063, .22), noise(7400, .060, .12, .042)],
  },
  // One dry puncture with tension from the shaft.
  spearContact: {
    cooldown: .058,
    tones: [tone(381, .057, 'square', .062, 181), tone(1780, .084, 'triangle', .13, 1440, .010)],
    noise: [noise(2500, .030, .15)],
  },
  spearFinisher: {
    cooldown: .11,
    tones: [tone(235, .123, 'triangle', .23, 54), tone(770, .064, 'square', .07, 270, .014),
      tone(1940, .16, 'triangle', .11, 1140, .024)],
    noise: [noise(3350, .047, .21), noise(1520, .054, .13, .032)],
  },
  // The hand hits just before the lower body thump; the heavy punch cracks.
  monkContact: {
    cooldown: .063,
    tones: [tone(478, .045, 'triangle', .15, 126), tone(142, .13, 'sine', .24, 50, .007)],
    noise: [noise(1440, .061, .17)],
  },
  monkFinisher: {
    cooldown: .115,
    tones: [tone(260, .14, 'triangle', .18, 71), tone(112, .23, 'sine', .31, 38, .011),
      tone(497, .07, 'triangle', .09, 132, .041)],
    noise: [noise(1700, .074, .23), noise(4300, .056, .15, .046)],
  },
};

export function characterImpactVoice(name: string): ImpactVoice | undefined {
  return Object.hasOwn(VOICES, name) ? VOICES[name as CharacterImpactSound] : undefined;
}
