import { describe, expect, it } from 'vitest';
import { GameEngine } from './engine';
import { CHARACTER_IDS, EMPTY_INPUT, getCharacterWeapons, type Enemy, type CharacterId, type WeaponId } from './types';

const SECONDS = 12;

function damagePerSecond(character: CharacterId, weapon: WeaponId, distance: number, level: number) {
  const run = new GameEngine();
  run.start({ seed: 26, modifier: 'standard', character, weapon });
  const state = run.state;
  state.room.platforms = [{ x: 0, y: 448, w: state.room.width, h: 120, kind: 'ground' }];
  state.room.hazards = [];
  state.pickups = [];
  Object.assign(state.hero, { x: 340, y: 412, grounded: true, critChance: 0, level });
  const x = state.hero.x + distance;
  const target: Enemy = {
    id: 10, kind: 'sentry', x, y: 406, w: 32, h: 42, hp: 10000, maxHp: 10000,
    originX: x, originY: 406, vx: 0, vy: 0, facing: -1, hurt: 0, dead: false, timer: 0, attackCooldown: 999,
  };
  state.enemies = [target];
  for (let tick = 0; tick < 120 * SECONDS; tick++) {
    // Keep the target in position so reach, cooldown and projectile return paths can be compared.
    Object.assign(target, { x, y: target.originY, vx: 0, vy: 0, hurt: .4 });
    run.update(1 / 120, { ...EMPTY_INPUT, attackHeld: true });
  }
  return (target.maxHp - target.hp) / SECONDS;
}

describe('traveller balance through continuous normal attacks', () => {
  it.each([1, 7])('keeps every traveller’s best close-range output within the level %i band', level => {
    const best = CHARACTER_IDS.map(character => Math.max(...getCharacterWeapons(character)
      .map(weapon => damagePerSecond(character, weapon, 43, level))));
    console.info(`LV ${level} close damage/sec: ${best.map(v => v.toFixed(2)).join(' / ')}`);
    expect(Math.max(...best) / Math.min(...best)).toBeLessThan(1.24);
  });

  it('gives Shen Xiao, Wen Shuo and Huai Yue stronger close-range weapons while keeping ranged alternatives', () => {
    expect(damagePerSecond('blade', 'willowSword', 43, 1)).toBeGreaterThan(6);
    expect(damagePerSecond('spear', 'spear', 43, 1)).toBeGreaterThan(8.5);
    expect(damagePerSecond('monk', 'ironGauntlet', 43, 1)).toBeGreaterThan(8.8);
    expect(damagePerSecond('spear', 'reedJavelin', 220, 1)).toBeGreaterThan(5.5);
    expect(damagePerSecond('monk', 'prayerBeads', 220, 1)).toBeGreaterThan(6);
  });
});
