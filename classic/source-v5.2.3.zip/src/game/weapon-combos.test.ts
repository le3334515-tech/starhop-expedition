import { describe, expect, it } from 'vitest';
import { GameEngine } from './engine';
import { EMPTY_INPUT, getCharacterWeapons, type Boss, type CharacterId, type Enemy, type Projectile, type WeaponId } from './types';
import { getWeaponCombo } from './weapon-combos';

const DT = 1 / 120;
const enemy = (id = 1): Enemy => ({
  id, kind: 'sentry', x: 350, y: 406, w: 32, h: 42,
  vx: 0, vy: 0, hp: 150, maxHp: 150, facing: -1, timer: 0, hurt: 0, dead: false,
  originX: 350, originY: 406, attackCooldown: 99,
});

function arena(character: CharacterId, target = enemy()): GameEngine {
  const game = new GameEngine();
  game.start({ seed: 42, modifier: 'standard', weapon: getCharacterWeapons(character)[0], character });
  const { state } = game;
  state.room.platforms = [{ x: 0, y: 448, w: state.room.width, h: 130, kind: 'ground' }];
  state.room.hazards = []; state.pickups = []; state.enemies = [target];
  Object.assign(state.hero, { x: 300, y: 412, grounded: true, facing: 1, critChance: 0, invincible: 0 });
  return game;
}

function swing(game: GameEngine, weapon: WeaponId) {
  game.state.hitstop = 0;
  game.state.projectiles = [];
  game.equipWeapon(weapon);
  game.state.hero.attackCooldown = 0;
  game.update(DT, { ...EMPTY_INPUT, attackPressed: true });
}

function melee(game: GameEngine, weapon: WeaponId, target: Enemy | Boss) {
  const hp = target.hp;
  swing(game, weapon);
  for (let tick = 0; tick < 36 && target.hp === hp; tick++) game.update(DT, EMPTY_INPUT);
  expect(target.hp).toBeLessThan(hp);
}

function hitProjectile(game: GameEngine, projectile: Projectile, target: Enemy | Boss, returning = false) {
  const hp = target.hp;
  game.state.hitstop = 0;
  Object.assign(projectile, { x: target.x + 12, y: target.y + 9, vx: 0, vy: 0 });
  if (returning) projectile.life = (projectile.returnAt ?? 1.3) - DT;
  game.state.projectiles = [projectile];
  game.update(DT, EMPTY_INPUT);
  expect(target.hp).toBeLessThan(hp);
}

function shot(game: GameEngine, weapon: WeaponId, target: Enemy | Boss, returning = false): Projectile {
  const projectile = cast(game, weapon);
  hitProjectile(game, projectile, target, returning);
  return projectile;
}

function cast(game: GameEngine, weapon: WeaponId): Projectile {
  // Give the projectile a clean launch, then isolate the collision under test.
  const hero = game.state.hero, originalX = hero.x;
  hero.x = 120;
  swing(game, weapon);
  hero.x = originalX;
  const projectile = game.state.projectiles.find(p => p.weapon === weapon)!;
  expect(projectile).toBeTruthy();
  return projectile;
}

function labelled(game: GameEngine): boolean {
  const combo = getWeaponCombo(game.state.character);
  return game.state.floatingTexts.some(text => text.text === combo?.name);
}

describe('personal weapon links', () => {
  it('boosts the Swallow Dart only on return, consumes once, and uses its cast-time weapon even after another switch', () => {
    const target = enemy(), game = arena('blade', target);
    melee(game, 'willowSword', target);
    const dart = cast(game, 'swallowDart');
    hitProjectile(game, dart, target);
    expect(labelled(game)).toBe(false);
    game.equipWeapon('blade');
    const hp = target.hp;
    hitProjectile(game, dart, target, true);
    expect(hp - target.hp).toBeCloseTo(dart.damage * 1.35);
    expect(labelled(game)).toBe(true);
    const secondHp = target.hp;
    const secondDart = shot(game, 'swallowDart', target, true);
    expect(secondHp - target.hp).toBeCloseTo(secondDart.damage);
  });

  it('grants the marked target four additional stars from the mirror', () => {
    const target = enemy(), game = arena('staff', target);
    shot(game, 'frostStaff', target);
    game.state.resonance = 0;
    game.state.hero.swapCooldown = 2;
    shot(game, 'moonMirror', target);
    expect(game.state.resonance).toBe(8 + 4);
    expect(labelled(game)).toBe(true);
  });

  it('stops the marked enemy and interrupts its AI for a half-second', () => {
    const target = enemy(), game = arena('wheel', target);
    shot(game, 'jadeNeedle', target);
    shot(game, 'silkFan', target);
    expect(target.comboStagger).toBe(.5);
    expect(labelled(game)).toBe(true);
    const where = [target.x, target.y];
    for (let tick = 0; tick < 54; tick++) game.update(DT, EMPTY_INPUT);
    expect(target.comboStagger).toBeGreaterThan(0);
    expect([target.x, target.y]).toEqual(where);
    for (let tick = 0; tick < 20; tick++) game.update(DT, EMPTY_INPUT);
    expect(target.comboStagger).toBe(0);
  });

  it('makes the halberd strike heavy against ordinary enemies', () => {
    const target = enemy(), game = arena('spear', target);
    shot(game, 'reedJavelin', target);
    melee(game, 'halberd', target);
    expect(target.hurt).toBe(.25);
    expect(labelled(game)).toBe(true);
  });

  it('removes exactly six additional guard points from a marked boss', () => {
    function guardLoss(prime: boolean) {
      const game = arena('spear');
      const boss: Boss = {
        x: 350, y: 330, w: 104, h: 118, hp: 400, maxHp: 480, phase: 1, form: 1, mode: 'idle',
        timer: 99, vx: 0, vy: 0, facing: -1, hurt: 0, attackCount: 0, active: true,
        intent: 'charge', targetX: 300, chain: 0, guard: 36, maxGuard: 36, exposed: 0,
      };
      game.state.room.isBoss = true; game.state.enemies = []; game.state.boss = boss;
      if (prime) shot(game, 'reedJavelin', boss);
      game.state.hero.swapBoost = 0; game.state.hero.swapCooldown = 2;
      const guard = boss.guard;
      melee(game, 'halberd', boss);
      expect(labelled(game)).toBe(prime);
      return guard - boss.guard;
    }
    expect(guardLoss(true) - guardLoss(false)).toBeCloseTo(6);
  });

  it('reduces dash recovery only after the beads touch the marked enemy on return', () => {
    function recovery(prime: boolean) {
      const target = enemy(), game = arena('monk', target);
      if (prime) melee(game, 'ironGauntlet', target);
      game.state.hero.dashCooldown = 1;
      shot(game, 'prayerBeads', target, true);
      expect(labelled(game)).toBe(prime);
      return game.state.hero.dashCooldown;
    }
    expect(recovery(false) - recovery(true)).toBeCloseTo(.4);
  });

  it('rejects another target, an expired mark, and another player on the same shared enemy', () => {
    const target = enemy(), owner = arena('staff', target), peer = arena('staff', target);
    shot(owner, 'frostStaff', target);
    shot(peer, 'moonMirror', target);
    expect(labelled(peer)).toBe(false);
    const wrong = enemy(2);
    owner.state.enemies = [wrong, target];
    target.x = 1400;
    shot(owner, 'moonMirror', wrong);
    expect(labelled(owner)).toBe(false);
    target.x = 350; wrong.x = 1500;
    owner.state.time += 2.41;
    shot(owner, 'moonMirror', target);
    expect(labelled(owner)).toBe(false);
  });

  it('does not let the blade auxiliary projectile prime a melee mark or a character weapon steal the traveller mark', () => {
    const target = enemy(), blade = arena('blade', target);
    const traveller = arena('traveller', target);
    shot(traveller, 'ember', target);
    expect(target.emberMark).toBeGreaterThan(0);
    target.x = 530;
    blade.state.hero.extraProjectiles = 1;
    const auxiliary = shot(blade, 'willowSword', target);
    expect(auxiliary.kind).toBe('ember');
    shot(blade, 'swallowDart', target, true);
    expect(labelled(blade)).toBe(false);
    expect(target.emberMark).toBeGreaterThan(0);
  });
});
