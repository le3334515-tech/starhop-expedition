import { WEAPONS, type Hero, type Projectile, type Vec, type WeaponArchetype, type WeaponId } from './types';
import { drawMaterialWeapon } from './material-weapon-art';

type VariantWeapon = Exclude<WeaponId, WeaponArchetype>;
const LINE = '#253233';
const LIGHT = '#ece6d2';

export function isVariantWeapon(weapon: WeaponId | undefined): weapon is VariantWeapon {
  if (!weapon) return false;
  const definition = WEAPONS[weapon];
  return !!definition && definition.archetype !== weapon;
}

function shape(c: CanvasRenderingContext2D, points: readonly number[], color: string, border = LINE) {
  c.beginPath();
  c.moveTo(points[0], points[1]);
  for (let i = 2; i < points.length; i += 2) c.lineTo(points[i], points[i + 1]);
  c.closePath();
  c.fillStyle = color;
  c.fill();
  c.strokeStyle = border;
  c.lineWidth = 1;
  c.stroke();
}

function line(c: CanvasRenderingContext2D, points: readonly number[], color: string, width = 1) {
  c.beginPath();
  c.moveTo(points[0], points[1]);
  for (let i = 2; i < points.length; i += 2) c.lineTo(points[i], points[i + 1]);
  c.strokeStyle = color;
  c.lineWidth = width;
  c.stroke();
}

function stone(c: CanvasRenderingContext2D, x: number, y: number, r: number, color: string) {
  c.beginPath();
  c.arc(x,y,r,0,Math.PI * 2);
  c.fillStyle = color;
  c.fill();
  c.lineWidth = 1;
  c.strokeStyle = LINE;
  c.stroke();
}

/** Shen Xiao's cuts leave a thin, silver feather at the edge of his sword. */
export function drawWillowCut(c: CanvasRenderingContext2D, step: number, progress: number) {
  const heavy = step === 3;
  const reverse = step === 2;
  const reach = heavy ? 74 : 57;
  const end = -.89 + progress * 1.78;
  c.save();
  c.translate(8, -25);
  if (reverse) c.scale(1, -1);
  c.globalAlpha *= Math.sin(Math.PI * progress) * .95;
  c.rotate(end * .43);
  shape(c,[16,-26,38,-22,reach-10,-3,reach,14,reach-12,6,37,-10,18,-17],
    '#8ac0c8','#344d5b');
  line(c,[22,-21,38,-16,reach-9,1,reach,14],'#e0eed9',heavy ? 2.5 : 1.4);
  for (let i = 0; i < (heavy ? 6 : 4); i++) {
    const x = reach - 10 + i * 5 + progress * 10;
    const y = 9 + i * i * .6;
    c.fillStyle = i % 2 ? '#daca98' : '#b6dcd5';
    c.fillRect(Math.round(x), Math.round(y), heavy ? 4 : 3, 2);
  }
  c.restore();
}

/** A brief half-moon opens beside Lu Zhaoyue's staff before each cast. */
export function drawMoonfireCast(c: CanvasRenderingContext2D, step: number, progress: number) {
  const charged = step === 3;
  const radius = (charged ? 16 : 11) + progress * 3;
  c.save();
  c.translate(charged ? 24 : 22, charged ? -35 : -30);
  c.globalAlpha *= Math.sin(Math.PI * progress) * .88;
  c.rotate(-.6 + progress);
  c.strokeStyle = '#d6b3ea';
  c.lineWidth = charged ? 2 : 1.25;
  c.beginPath(); c.arc(0, 0, radius, -.9, 2.7); c.stroke();
  c.strokeStyle = '#ecd5b6'; c.lineWidth = 1;
  c.beginPath(); c.arc(2, 0, radius - 4, -.68, 2.4); c.stroke();
  shape(c,[-7,0,0,-5,6,0,0,5],'#e9cbca','#82586d');
  for (let i = 0; i < 3; i++) {
    const angle = -1.03 + i * 1.25 + progress;
    c.fillStyle = i % 2 ? '#deb493' : '#ceb7ee';
    c.fillRect(Math.round(Math.cos(angle) * (radius + 4)), Math.round(Math.sin(angle) * (radius + 4)), 2, 2);
  }
  c.restore();
}

export function drawTigerGauntlet(c: CanvasRenderingContext2D, step: number, progress: number) {
  const heavy = step === 3;
  const flash = Math.max(0, 1 - Math.abs(progress - .46) * 2.25);
  if (flash === 0) return;
  c.save();
  c.translate((heavy ? 28 : 21) + progress * 8, heavy ? -22 : step === 2 ? -24 : -28);
  c.globalAlpha *= flash;
  const reach = heavy ? 47 : 31;
  for (let i = 0; i < 3; i++) {
    const x = i * 4, y = i * (heavy ? 11 : 8) - (heavy ? 13 : 10);
    shape(c, [x,y+10,x+7,y+3,x+reach-13,y-4,x+reach,y-7,x+reach-9,y+2,x+13,y+9],
      i === 1 ? '#f5d599' : '#cd9764', '#613e38');
    line(c, [x+10,y+4,x+reach-10,y-4], '#f0c88e', heavy ? 1.7 : 1.2);
  }
  const fragments = [[19,-15],[26,14],[37,-20],[42,7],[49,17],[53,-10]];
  for (const [i, [x, y]] of fragments.slice(0, heavy ? 6 : 4).entries()) {
    const px = Math.round(x + progress * (i + 4)), py = Math.round(y * (1 + progress * .30));
    const size = i % 2 ? 4 : 3;
    shape(c, [px-size,py,px,py-size,px+size,py,px+1,py+size], i % 2 ? '#b6724c' : '#eeba7d','#614443');
  }
  c.restore();
}

export function drawCharacterProjectile(c: CanvasRenderingContext2D, p: Projectile, now: number): boolean {
  if (p.kind !== 'ember') return false;
  const moonfire = p.ownerCharacter === 'staff' && p.weapon === 'ember';
  const snowFeather = p.ownerCharacter === 'blade' && p.weapon === 'blade';
  if (!moonfire && !snowFeather) return false;
  const charged = p.style === 'charged';
  c.save();
  c.rotate(Math.atan2(p.vy, p.vx));
  if (snowFeather) {
    shape(c,[-25,0,-10,-3,5,-4,16,0,6,4,-13,2],'#99c7cc','#344d5b');
    line(c,[-19,0,13,0],'#e0eed9');
    line(c,[-8,1,-18,6,-9,4],'#c6b182',1.4);
  } else {
    const r = charged ? 14 : 10;
    const wake = charged ? 43 : 30;
    c.globalAlpha *= .82;
    shape(c,[-wake,0,-15,-4,-6,-r,7,-r,13,-5,14,4,7,r,-5,r,-11,5,-23,2],
      '#836fb2','#42374d');
    c.beginPath();
    c.arc(1, 0, r, -1.6, 1.6);
    c.quadraticCurveTo(1, r * .70, 3, r * .21);
    c.quadraticCurveTo(6, -r * .67, 1, -r);
    c.closePath(); c.fillStyle = '#eae0d6'; c.fill();
    c.strokeStyle = '#cc9cd9'; c.lineWidth = 1.2;
    c.beginPath(); c.ellipse(-1, 0, r * 1.23, r * .8, -.28, -.6, 2.34); c.stroke();
    shape(c,[-5,0,-1,-4,3,0,-1,4],'#f2dab8','#976a8a');
    for (let i = 0; i < (charged ? 5 : 3); i++) {
      const x = -r - 6 - 5 * i;
      const y = Math.sin(now * 17 + i * 2) * (4 + i);
      c.fillStyle = i % 2 ? '#e5b88d' : '#d2b9ee'; c.fillRect(x, Math.round(y), 3, 2);
    }
  }
  c.restore();
  return true;
}

function drawWeaponShape(c: CanvasRenderingContext2D, weapon: VariantWeapon) {
  if (drawMaterialWeapon(c, weapon)) return;
  const tint = WEAPONS[weapon].color;
  switch (weapon) {
    case 'willowSword':
      line(c,[-8,0,5,0],'#816854',3); line(c,[4,-4,4,4],'#dac982',2);
      shape(c,[5,-2,12,-4,26,-3,40,-6,32,0,14,2,5,2],tint);
      line(c,[7,0,24,-1,37,-5],LIGHT);
      break;
    case 'swallowDart':
      shape(c,[-7,0,-11,-6,-3,-3,4,-3,14,0,4,3,-3,3,-11,6],tint);
      line(c,[-4,0,12,0],LIGHT);
      break;
    case 'frostStaff':
      line(c,[-22,2,-9,1,3,-1,24,0],'#424a58',3);
      line(c,[-20,1,-7,0,9,-2,23,-1],'#a09274');
      line(c,[12,-1,22,-6,29,-5,32,-1],'#83adbd',2);
      line(c,[16,0,22,4,30,6,33,2],'#83adbd',2);
      shape(c,[23,-3,32,-6,37,0,32,5,23,2],tint);
      line(c,[27,-2,33,-3,35,0],LIGHT);
      break;
    case 'moonMirror':
      line(c,[-8,0,4,0],'#8c7858',3);
      stone(c,10,0,10,'#b69b72');
      stone(c,10,0,7,tint);
      line(c,[6,-5,12,4],LIGHT,2);
      stone(c,10,-9,1.4,'#f0d29c');
      break;
    case 'jadeNeedle':
      shape(c,[-8,1,-7,-1,21,-1,26,0,21,1],tint);
      line(c,[-5,-2,-5,2],'#d5ab78',2);
      line(c,[2,0,24,0],LIGHT);
      break;
    case 'silkFan':
      line(c,[-7,0,7,0],'#9b7866',3);
      stone(c,13,0,12,'#8b6c63');
      stone(c,13,0,10,tint);
      c.strokeStyle='#f7dfbb'; c.lineWidth=1;
      for (const [x,y] of [[18,-8],[20,-4],[21,0],[20,4],[18,8]]) {
        c.beginPath(); c.moveTo(4,0); c.quadraticCurveTo(15, y*.55, x, y); c.stroke();
      }
      stone(c,2,0,1.8,'#dfb67e');
      break;
    case 'reedJavelin':
      line(c,[-20,1,28,0],'#886e4c',2.5);
      line(c,[-19,0,28,-1],'#dae1af');
      shape(c,[22,0,28,-4,37,-2,44,0,35,4,28,4],tint);
      line(c,[26,0,41,0],LIGHT);
      shape(c,[-14,1,-21,-4,-18,1,-24,5,-16,3],'#638f78');
      break;
    case 'halberd':
      line(c,[-20,1,25,0],'#765646',3);
      line(c,[-20,0,24,-1],'#cfad7e');
      line(c,[18,-4,18,4],'#edc68d',2);
      shape(c,[21,-3,24,-11,30,-16,34,-12,30,-8,29,-3,42,0,30,4,27,12,21,7,23,1],tint);
      line(c,[24,-9,29,-15,33,-12],LIGHT);
      line(c,[26,2,29,9,26,10],LIGHT);
      break;
    case 'ironGauntlet':
      shape(c,[-5,-4,1,-6,10,-5,14,-2,14,4,7,7,-5,5],tint);
      shape(c,[5,-5,8,-7,11,-5,14,-3,14,0,8,1,6,0],'#edc186');
      line(c,[-2,-4,-2,5],'#544855',2);
      line(c,[10,-5,10,0],'#886040');
      break;
    case 'prayerBeads':
      c.beginPath(); c.ellipse(6,3,10,7,.32,0,Math.PI*2);
      c.lineWidth=1; c.strokeStyle='#dbc390'; c.stroke();
      for (let i=0;i<9;i++) {
        const a=i*Math.PI*2/9;
        const x=6+Math.sin(a)*9, y=3+Math.cos(a)*6;
        stone(c,x,y,i===1 ? 2.35 : 1.85,i%3===0 ? '#876b56' : tint);
      }
      break;
  }
}

/** The grip is placed by the character pose. The weapon follows it in both the room and the race ghost. */
export function drawHeldVariant(c: CanvasRenderingContext2D, hero: Hero, grip: Vec, progress: number) {
  const weapon = hero.weapon;
  if (hero.hp<=0 || !isVariantWeapon(weapon)) return;
  const attacking = hero.attackTimer>0;
  const aimed = attacking ? progress : 0;
  const rotation = weapon === 'halberd' || weapon === 'reedJavelin' || weapon === 'frostStaff'
    ? attacking ? -.65 + aimed*.75 : -1.04
    : weapon === 'willowSword'
      ? attacking ? -1.6 + aimed*2.8 : -.31
      : -.26 + aimed*.38;
  c.save();
  c.translate(Math.round(grip.x),Math.round(grip.y));
  c.rotate(rotation);
  drawWeaponShape(c,weapon);
  c.restore();
}

/** Only variant projectiles draw here, so the original three weapons retain their existing animation. */
export function drawVariantProjectile(c: CanvasRenderingContext2D, p: Projectile): boolean {
  const weapon = p.weapon;
  if (!isVariantWeapon(weapon)) return false;
  const tint = WEAPONS[weapon].color;
  const charged = p.style==='charged';
  const angle = Math.atan2(p.vy,p.vx);
  c.save();
  if (weapon === 'frostStaff' || weapon === 'jadeNeedle' || weapon === 'reedJavelin') {
    c.rotate(angle);
    const length = weapon==='reedJavelin' ? 55 : weapon==='jadeNeedle' ? 43 : 32;
    const halfWidth = weapon==='frostStaff' ? 6 : 2;
    c.globalAlpha *= .78;
    shape(c,[-length,0,5,-halfWidth,20,0,5,halfWidth],tint,'#43665f');
    line(c,[-length+4,0,18,0],LIGHT,charged ? 2.6 : 1.2);
    if (weapon==='reedJavelin') { c.translate(2,0); c.scale(.62,.62); drawWeaponShape(c,weapon); }
  } else if (weapon==='moonMirror' || weapon==='silkFan') {
    c.rotate(angle);
    const width=charged ? 25 : 15;
    const streak=weapon==='moonMirror' ? 52 : 34;
    c.globalAlpha *= .76;
    c.beginPath(); c.moveTo(-streak,0);
    c.quadraticCurveTo(7,-width,21,0);
    c.quadraticCurveTo(8,width,-streak,0);
    c.fillStyle=tint; c.fill();
    c.beginPath(); c.moveTo(-streak*.61,0);
    c.quadraticCurveTo(12,-width*.72,21,0);
    c.quadraticCurveTo(3,width*.71,-streak*.61,0);
    c.strokeStyle=LIGHT; c.lineWidth=charged ? 2.5 : 1.25; c.stroke();
    if (weapon==='moonMirror') { c.translate(12,0); stone(c,0,0,charged ? 6 : 3,LIGHT); }
  } else if (weapon==='prayerBeads') {
    c.rotate(angle);
    c.globalAlpha *= .62; line(c,[-26,0,0,0],tint,2); c.globalAlpha *= 1.6;
    stone(c,1,0,6,'#9c7954'); stone(c,2,-1,3.5,tint);
    line(c,[0,-3,3,-3,5,-1],LIGHT);
  } else if (weapon==='swallowDart') {
    c.rotate(angle); line(c,[-23,0,1,0],tint,1.2);
    drawWeaponShape(c,weapon);
  } else {
    // A melee weapon's bonus marks stay small, even with multishot.
    c.rotate(angle); line(c,[-15,0,8,0],tint,2);
    shape(c,[1,0,6,-3,10,0,6,3],LIGHT);
  }
  c.restore();
  return true;
}

