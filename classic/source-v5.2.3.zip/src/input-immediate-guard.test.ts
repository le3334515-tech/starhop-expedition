import { afterEach, describe, expect, it, vi } from 'vitest';
import { GameInput } from './input';

afterEach(() => vi.unstubAllGlobals());

class Classes {
  values = new Set<string>();
  add(value: string) { this.values.add(value); }
  remove(value: string) { this.values.delete(value); }
}
class Surface extends EventTarget {
  dataset: Record<string, string> = {};
  classList = new Classes();
  closest() { return null; }
  setPointerCapture() {}
}
function setup() {
  let active = true, calls = 0;
  const surface = new Surface(), guard = new Surface(); guard.dataset.touch = 'guard';
  const buttons = Array.from({ length: 16 }, () => ({ pressed: false }));
  const stored = new Map<string, string>();
  vi.stubGlobal('window', surface);
  vi.stubGlobal('document', { querySelectorAll: () => [guard], querySelector: () => null });
  vi.stubGlobal('localStorage', { getItem: (key: string) => stored.get(key) ?? null, setItem: (key: string, value: string) => stored.set(key, value) });
  vi.stubGlobal('navigator', { getGamepads: () => [{ axes: [0, 0], buttons }] });
  const input = new GameInput(() => active, () => {}, () => calls++);
  function key(code: string, type = 'keydown') {
    const event = new Event(type, { cancelable: true });
    Object.defineProperties(event, { code: { value: code }, repeat: { value: false } }); surface.dispatchEvent(event);
  }
  function pointer(type = 'pointerdown') {
    const event = new Event(type, { cancelable: true }); Object.defineProperty(event, 'pointerId', { value: 7 }); guard.dispatchEvent(event);
  }
  return { input, guard, key, pointer, buttons, setActive: (value: boolean) => { active = value; }, calls: () => calls };
}

describe('guard dispatch is synchronous with the actual input edge', () => {
  it('calls guard on keydown before any read or fixed update, once per press', () => {
    const fixture = setup(); fixture.key('KeyF');
    expect(fixture.calls()).toBe(1); expect(fixture.input.read().guardPressed).toBe(true);
    fixture.key('KeyF'); expect(fixture.calls()).toBe(1);
    fixture.key('KeyF', 'keyup'); fixture.key('KeyF'); expect(fixture.calls()).toBe(2);
  });
  it('calls guard on touch pointerdown before the next render frame', () => {
    const fixture = setup(); fixture.pointer();
    expect(fixture.calls()).toBe(1); expect(fixture.input.read().guardPressed).toBe(true);
    expect(fixture.guard.classList.values.has('pressed')).toBe(true);
    fixture.pointer('pointercancel'); expect(fixture.guard.classList.values.has('pressed')).toBe(false);
  });
  it('honors remapping and ignores inactive UI interactions', () => {
    const fixture = setup(); expect(fixture.input.rebind('guard', 'KeyC').ok).toBe(true);
    fixture.key('KeyF'); expect(fixture.calls()).toBe(0);
    fixture.key('KeyC'); expect(fixture.calls()).toBe(1);
    fixture.input.clear(); fixture.setActive(false); fixture.key('KeyC'); fixture.pointer(); expect(fixture.calls()).toBe(1);
    fixture.setActive(true); fixture.input.resetBindings(); fixture.key('KeyF'); expect(fixture.calls()).toBe(2);
  });
  it('dispatches the gamepad guard edge once in the polling frame', () => {
    const fixture = setup(); fixture.buttons[5].pressed = true;
    expect(fixture.input.read().guardPressed).toBe(true); expect(fixture.calls()).toBe(1);
    fixture.input.read(); expect(fixture.calls()).toBe(1);
    fixture.buttons[5].pressed = false; fixture.input.read(); fixture.buttons[5].pressed = true;
    fixture.input.read(); expect(fixture.calls()).toBe(2);
  });
});
