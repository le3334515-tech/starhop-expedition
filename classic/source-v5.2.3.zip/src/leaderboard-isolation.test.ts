import { describe, expect, it, vi } from 'vitest';
import { LEADERBOARD_CONFIG, LiveLeaderboard } from './leaderboard';
import { LEADERBOARD_VERSION, makeSnapshot, type LeaderboardRecord } from './leaderboard-core';
import type { GameResult } from './game/types';

function memoryStorage(): Storage {
  const values = new Map<string, string>();
  return {
    getItem: key => values.get(key) ?? null,
    setItem: (key, value) => { values.set(key, String(value)); },
    removeItem: key => { values.delete(key); }, clear: () => values.clear(),
    key: index => [...values.keys()][index] ?? null, get length() { return values.size; },
  };
}
const result = (time: number): GameResult => ({
  seed: 42, modifier: 'standard', weapon: 'blade', won: true, time, score: 1200, coins: 20,
  kills: 24, level: 5, deaths: 0, roomsCleared: 8, maxCombo: 6, upgrades: ['edge'],
  overdriveCount: 1, synergies: [],
});
const oldRecord: LeaderboardRecord = {
  version: LEADERBOARD_VERSION, playerId: 'player_existing', runId: 'original_v41_run',
  name: '旧榜名字', createdAt: '2026-11-16T10:00:00.000Z', result: result(82),
};

describe('classic v4.2 score isolation', () => {
  it('retains identity and display-only history without importing old scores, queue, or acknowledgements', () => {
    const storage = memoryStorage();
    storage.setItem('starhop.leaderboard.v2.player', JSON.stringify(oldRecord.playerId));
    storage.setItem('starhop.leaderboard.v3.cache', JSON.stringify(makeSnapshot([oldRecord])));
    storage.setItem('starhop.leaderboard.v3.queue', JSON.stringify([oldRecord]));
    storage.setItem('starhop.leaderboard.v3.ack', JSON.stringify([oldRecord.runId]));
    const request = vi.fn() as unknown as typeof fetch;
    const board = new LiveLeaderboard({ storage, fetch: request, autoRetry: false });
    expect(board.getPlayerId()).toBe(oldRecord.playerId);
    expect(board.getState().records).toEqual([]);
    expect(board.getState().pending).toBe(0);
    expect(board.getState().historicalRecords).toEqual([oldRecord]);
    expect(storage.getItem('starhop.leaderboard.v3.queue')).toBe(JSON.stringify([oldRecord]));
    expect(request).not.toHaveBeenCalled();
  });

  it('posts victories and profile edits only to the new topic while preserving old eight-act history', async () => {
    const storage = memoryStorage();
    storage.setItem('starhop.leaderboard.v2.player', JSON.stringify(oldRecord.playerId));
    const posts: { url: string; payload: Record<string, unknown> }[] = [];
    const request = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}) => {
      const url = String(input);
      if (init.method === 'POST') {
        const payload = JSON.parse(String(init.body)); posts.push({ url, payload });
        return new Response(JSON.stringify({ event: 'message', message: JSON.stringify(payload) }));
      }
      if (url.includes('/json?')) return new Response('');
      return new Response(JSON.stringify(makeSnapshot(url.startsWith(LEADERBOARD_CONFIG.historicalSnapshotUrl) ? [oldRecord] : [])));
    }) as typeof fetch;
    const board = new LiveLeaderboard({ storage, fetch: request, autoRetry: false });
    await board.refresh();
    expect(board.getState().records).toEqual([]);
    expect(board.getState().historicalRecords).toEqual([oldRecord]);
    expect((await board.submit('新版名字', result(112))).status).toBe('submitted');
    expect((await board.rename('新版改名')).status).toBe('submitted');
    expect(posts).toHaveLength(2);
    expect(posts.every(post => post.url === `${LEADERBOARD_CONFIG.baseUrl}/${LEADERBOARD_CONFIG.topic}`)).toBe(true);
    expect(posts[1].payload.type).toBe('profile');
    expect(board.getState().records[0].name).toBe('新版改名');
    expect(board.getState().historicalRecords[0].name).toBe('旧榜名字');
    expect(board.getState().historicalRecords[0].result.time).toBe(82);
    const reloaded = new LiveLeaderboard({ storage, fetch: request, autoRetry: false });
    expect(reloaded.getState().records[0].result.time).toBe(112);
    expect(reloaded.getState().historicalRecords[0].result.time).toBe(82);
    expect(storage.getItem('starhop.leaderboard.classic.v42.cache')).not.toBeNull();
  });

  it('reports an unavailable original-history service separately from a healthy new board', async () => {
    const request = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.startsWith(LEADERBOARD_CONFIG.historicalSnapshotUrl) || url.includes(LEADERBOARD_CONFIG.historicalTopic)) throw new Error('History offline');
      return new Response(url.includes('/json?') ? '' : JSON.stringify(makeSnapshot([])));
    }) as typeof fetch;
    const board = new LiveLeaderboard({ storage: memoryStorage(), fetch: request, autoRetry: false });
    await board.refresh();
    expect(board.getState().error).toBeNull();
    expect(board.getState().historicalError).toMatch(/v4.1/);
    expect(board.getState().records).toEqual([]);
  });
});
