import type { GameResult } from './game/types';
import { LEADERBOARD_VERSION, makeSnapshot, mergeRecords, mergeHeroRecords, mergeLegacyRecords, mergeProfiles, applyProfiles, parseFeed, parseFeedState, parseSnapshot, sanitizeName, validateRecord, validateProfile, type LeaderboardRecord, type LeaderboardProfile } from './leaderboard-core';

export const LEADERBOARD_CONFIG = {
  topic: 'starhop-classic-v42-f3b7e2d96a1048bc965f7d013a82c46e',
  baseUrl: 'https://ntfy.sh',
  snapshotUrl: 'https://raw.githubusercontent.com/le3334515-tech/starhop-expedition/main/classic/leaderboard/v3.json',
  historicalTopic: 'starhop-v3-79cd3cc8ca0b43a5a2de69ad61af31e8',
  historicalSnapshotUrl: 'https://raw.githubusercontent.com/le3334515-tech/starhop-expedition/main/leaderboard/v3.json',
  legacyTopic: 'starhop-v2-bb44ce0019a44e73a212d732ced64e5b',
  legacySnapshotUrl: 'https://raw.githubusercontent.com/le3334515-tech/starhop-expedition/main/leaderboard/v2.json',
};
export type SubmissionStatus = 'submitted' | 'pending' | 'duplicate' | 'rejected';
export interface Submission { status: SubmissionStatus; record?: LeaderboardRecord; error?: string }
export interface LeaderboardState {
  historicalRecords: LeaderboardRecord[]; historicalError: string | null;
  records: LeaderboardRecord[]; heroRecords: LeaderboardRecord[]; legacyRecords: LeaderboardRecord[]; profiles: LeaderboardProfile[]; legacyError: string | null; pendingRenames: number; lastRename: { name: string; status: SubmissionStatus } | null; loading: boolean; connection: 'idle' | 'connecting' | 'live' | 'polling' | 'offline';
  pending: number; error: string | null; lastUpdated: string | null;
  lastSubmission: { runId: string; status: SubmissionStatus } | null;
}
interface Options {
  topic?: string; baseUrl?: string; snapshotUrl?: string; legacyTopic?: string; legacySnapshotUrl?: string; historicalTopic?: string; historicalSnapshotUrl?: string;
  storage?: Storage | null; fetch?: typeof globalThis.fetch; EventSource?: typeof globalThis.EventSource | null;
  autoRetry?: boolean; timeoutMs?: number; pollMs?: number;
}
const PREFIX = 'starhop.leaderboard.classic.v42.';
const IDENTITY_KEY = 'starhop.leaderboard.v2.player';
function hash(text: string, seed = 2166136261): string {
  let value = seed;
  for (let i = 0; i < text.length; i++) value = Math.imul(value ^ text.charCodeAt(i), 16777619);
  return (value >>> 0).toString(36);
}
function randomId(): string {
  try { return `player_${crypto.randomUUID().replace(/-/g, '')}`; }
  catch { return `player_${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`; }
}

export class LiveLeaderboard {
  private config: typeof LEADERBOARD_CONFIG;
  private storage: Storage | null;
  private fetcher: typeof globalThis.fetch;
  private EventSourceType: typeof globalThis.EventSource | null;
  private timeoutMs: number;
  private pollMs: number;
  private playerId: string;
  private queue: LeaderboardRecord[] = [];
  private pendingProfile: LeaderboardProfile | null = null;
  private acknowledged = new Set<string>();
  private queuePersisted = true;
  private profilePersisted = true;
  private readError: string | null = null;
  private historicalProfiles: LeaderboardProfile[] = [];
  private listeners = new Set<(state: LeaderboardState) => void>();
  private state: LeaderboardState = { records: [], heroRecords: [], historicalRecords: [], historicalError: null, legacyRecords: [], profiles: [], legacyError: null, pendingRenames: 0, lastRename: null, loading: false, connection: 'idle', pending: 0, error: null, lastUpdated: null, lastSubmission: null };
  private opened = false;
  private stream: EventSource | null = null;
  private pollTimer: ReturnType<typeof setInterval> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private retryTimer: ReturnType<typeof setTimeout> | null = null;
  private refreshPromise: Promise<void> | null = null;
  private uploadPromise: Promise<void> | null = null;

  constructor(options: Options = {}) {
    this.config = { ...LEADERBOARD_CONFIG, ...Object.fromEntries(['topic', 'baseUrl', 'snapshotUrl', 'legacyTopic', 'legacySnapshotUrl', 'historicalTopic', 'historicalSnapshotUrl'].filter(k => options[k as keyof Options] !== undefined).map(k => [k, options[k as keyof Options]])) };
    try { this.storage = options.storage === undefined ? globalThis.localStorage ?? null : options.storage; } catch { this.storage = null; }
    this.fetcher = options.fetch ?? globalThis.fetch.bind(globalThis);
    this.EventSourceType = options.EventSource === undefined ? globalThis.EventSource ?? null : options.EventSource;
    this.timeoutMs = options.timeoutMs ?? 12000;
    this.pollMs = options.pollMs ?? 20000;
    let storedId: unknown;
    try { storedId=JSON.parse(this.storage?.getItem(IDENTITY_KEY)??'null'); } catch { storedId=null; }
    storedId=storedId??this.read('player');
    this.playerId = typeof storedId === 'string' && /^[a-zA-Z0-9_-]{8,100}$/.test(storedId) ? storedId : randomId();
    this.write('player', this.playerId);
    try { this.storage?.setItem(IDENTITY_KEY,JSON.stringify(this.playerId)); } catch { /* Use this session's identity if persistence is unavailable. */ }
    const cached = parseSnapshot(this.read('cache'));
    if (cached) { this.state.records = cached.records; this.state.heroRecords = cached.heroRecords; this.state.legacyRecords=cached.legacyRecords; this.state.profiles=cached.profiles; this.state.lastUpdated = cached.updatedAt; }
    // An old v4.1 cache is display-only history. Its upload queue and ACKs are never imported.
    let oldCache: unknown;
    try { oldCache = JSON.parse(this.storage?.getItem('starhop.leaderboard.v3.cache') ?? 'null'); } catch { oldCache = null; }
    const historicalCache = parseSnapshot(this.read('historyCache')) ?? parseSnapshot(oldCache);
    if (historicalCache) { this.state.historicalRecords = historicalCache.records; this.historicalProfiles = historicalCache.profiles; }
    const legacyCache=parseSnapshot(this.readLegacy('cache'));
    if(legacyCache) this.state.legacyRecords=mergeLegacyRecords(this.state.legacyRecords,legacyCache.legacyRecords);
    this.pendingProfile=validateProfile(this.read('pendingProfile'));
    if(this.pendingProfile) this.state.lastRename={name:this.pendingProfile.name,status:'pending'};
    const queued = this.read('queue');
    if (Array.isArray(queued)) this.queue = queued.slice(0, 50).map(validateRecord).filter((r): r is LeaderboardRecord => !!r && r.playerId === this.playerId);
    const acknowledged = this.read('ack');
    if (Array.isArray(acknowledged)) this.acknowledged = new Set(acknowledged.filter(v => typeof v === 'string').slice(-200));
    this.queue = this.queue.filter(r => !this.acknowledged.has(r.runId));
    this.state.pending = this.queue.length;
    if (options.autoRetry !== false) {
      globalThis.addEventListener?.('online', () => { void this.refresh(); });
      if (this.queue.length || this.pendingProfile) void this.retryPending();
    }
  }
  private readLegacy(key: string): unknown {
    try { return JSON.parse(this.storage?.getItem('starhop.leaderboard.v2.'+key)??'null'); } catch { return null; }
  }
  private read(key: string): unknown {
    try { const text = this.storage?.getItem(PREFIX + key); return text && text.length < 500000 ? JSON.parse(text) : null; } catch { return null; }
  }
  private write(key: string, value: unknown): boolean {
    try { if (!this.storage) return false; this.storage.setItem(PREFIX + key, JSON.stringify(value)); return true; }
    catch { return false; }
  }
  private pendingMessage(): string {
    return this.queuePersisted ? '成绩已保存在本机，联网后自动补交。' : '成绩暂存在本页面，请保持页面开启，联网后自动补交。';
  }
  getPlayerId(): string { return this.playerId; }
  getState(): LeaderboardState {
    const profiles=mergeProfiles(this.state.profiles,this.pendingProfile?[this.pendingProfile]:[]);
    return { ...this.state,records:applyProfiles(mergeRecords(this.state.records),profiles),heroRecords:applyProfiles(mergeHeroRecords(this.state.heroRecords),profiles),historicalRecords:applyProfiles(mergeRecords(this.state.historicalRecords),this.historicalProfiles),legacyRecords:applyProfiles(mergeLegacyRecords(this.state.legacyRecords),profiles),profiles,
      pendingRenames:this.pendingProfile?1:0,lastRename:this.state.lastRename&&{...this.state.lastRename},lastSubmission:this.state.lastSubmission&&{...this.state.lastSubmission} };
  }
  subscribe(listener: (state: LeaderboardState) => void): () => void {
    this.listeners.add(listener); listener(this.getState());
    return () => { this.listeners.delete(listener); };
  }
  private emit(): void { this.state.pending = this.queue.length; const state = this.getState(); for (const listener of this.listeners) listener(state); }
  private merge(records: LeaderboardRecord[], profiles: LeaderboardProfile[] = [], legacyRecords: LeaderboardRecord[] = [], heroRecords: LeaderboardRecord[] = []): void {
    this.state.records = mergeRecords(this.state.records, records, heroRecords);
    this.state.heroRecords = mergeHeroRecords(this.state.heroRecords, records, heroRecords);
    this.state.legacyRecords = mergeLegacyRecords(this.state.legacyRecords, legacyRecords);
    this.state.profiles = mergeProfiles(this.state.profiles,profiles);
    this.state.lastUpdated = new Date().toISOString();
    this.write('cache', makeSnapshot(this.state.records, this.state.lastUpdated,this.state.profiles,this.state.legacyRecords,this.state.heroRecords));
  }
  private mergeHistorical(records: LeaderboardRecord[], profiles: LeaderboardProfile[] = []): void {
    this.state.historicalRecords = mergeRecords(this.state.historicalRecords, records);
    this.historicalProfiles = mergeProfiles(this.historicalProfiles, profiles);
    this.write('historyCache', makeSnapshot(this.state.historicalRecords, new Date().toISOString(), this.historicalProfiles));
  }
  private async request(url: string, options: RequestInit = {}): Promise<{ text: string; truncated: boolean }> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.fetcher(url, { ...options, signal: controller.signal, cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return { text: await response.text(), truncated: response.headers.get('X-Messages-Truncated') === '1' };
    } finally { clearTimeout(timer); }
  }
  private get topicUrl(): string { return `${this.config.baseUrl.replace(/\/$/, '')}/${encodeURIComponent(this.config.topic)}`; }
  open(): void {
    if (this.opened) return;
    this.opened = true; this.state.connection = 'connecting'; this.emit();
    this.connect(); void this.refresh();
    this.pollTimer = setInterval(() => { void this.refresh(); }, this.pollMs);
  }
  close(): void {
    this.opened = false; this.stream?.close(); this.stream = null;
    if (this.pollTimer) clearInterval(this.pollTimer); this.pollTimer = null;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer); this.reconnectTimer = null;
    this.state.connection = 'idle'; this.emit();
  }
  private connect(): void {
    if (!this.opened || !this.EventSourceType) { if (this.opened) { this.state.connection = 'polling'; this.emit(); } return; }
    try {
      const stream = new this.EventSourceType(`${this.topicUrl}/sse?since=all`);
      this.stream = stream;
      stream.onopen = () => { if (this.opened && this.stream === stream) { this.state.connection = 'live'; this.state.error = this.readError ?? (this.pendingProfile ? this.renamePendingMessage() : this.queue.length ? this.pendingMessage() : null); this.emit(); } };
      stream.onmessage = event => {
        if (!this.opened || this.stream !== stream) return;
        const feed = parseFeedState(event.data);
        if (feed.records.length || feed.profiles.length || feed.legacyRecords.length) { this.merge(feed.records,feed.profiles,feed.legacyRecords,feed.heroRecords); this.state.connection = 'live'; this.state.error = this.readError ?? (this.pendingProfile ? this.renamePendingMessage() : this.queue.length ? this.pendingMessage() : null); this.emit(); }
      };
      stream.onerror = () => {
        if (this.stream !== stream) return;
        stream.close(); this.stream = null;
        if (!this.opened) return;
        this.state.connection = 'polling'; this.emit();
        this.reconnectTimer = setTimeout(() => { this.reconnectTimer = null; this.connect(); }, 30000);
      };
    } catch { this.state.connection = 'polling'; this.emit(); }
  }
  refresh(): Promise<void> {
    if (this.refreshPromise) return this.refreshPromise;
    this.refreshPromise = this.doRefresh().finally(() => { this.refreshPromise = null; });
    return this.refreshPromise;
  }
  private async doRefresh(): Promise<void> {
    this.state.loading = true; this.emit();
    let feedTruncated = false;
    const results = await Promise.allSettled([
      this.request(`${this.config.snapshotUrl}${this.config.snapshotUrl.includes('?') ? '&' : '?'}t=${Date.now()}`).then(({ text }) => {
        const snapshot = parseSnapshot(JSON.parse(text));
        if (!snapshot) throw new Error('Invalid snapshot');
        this.merge(snapshot.records,snapshot.profiles,snapshot.legacyRecords,snapshot.heroRecords);
      }),
      this.request(`${this.topicUrl}/json?poll=1&since=all`).then(({ text, truncated }) => { feedTruncated = truncated; const feed=parseFeedState(text);this.merge(feed.records,feed.profiles,feed.legacyRecords,feed.heroRecords); }),
      this.retryPending(),
      this.request(`${this.config.legacySnapshotUrl}?t=${Date.now()}`).then(({text})=>{
        const snapshot=parseSnapshot(JSON.parse(text));if(!snapshot)throw new Error('Invalid legacy snapshot');
        this.merge([],snapshot.profiles,snapshot.legacyRecords);
      }),
      this.request(`${this.config.baseUrl.replace(/\/$/,'')}/${encodeURIComponent(this.config.legacyTopic)}/json?poll=1&since=all`).then(({text,truncated})=>{
        if(truncated)throw new Error('Legacy replay incomplete'); const feed=parseFeedState(text);this.merge([],[],feed.legacyRecords);
      }),
      this.request(`${this.config.historicalSnapshotUrl}?t=${Date.now()}`).then(({text}) => {
        const snapshot = parseSnapshot(JSON.parse(text));
        if (!snapshot) throw new Error('Invalid v4.1 snapshot');
        this.mergeHistorical(snapshot.records, snapshot.profiles);
      }),
      this.request(`${this.config.baseUrl.replace(/\/$/,'')}/${encodeURIComponent(this.config.historicalTopic)}/json?poll=1&since=all`).then(({text,truncated}) => {
        if (truncated) throw new Error('v4.1 replay incomplete');
        const feed = parseFeedState(text); this.mergeHistorical(feed.records, feed.profiles);
      }),
    ]);
    const snapshotReadable = results[0].status === 'fulfilled';
    const feedReadable = results[1].status === 'fulfilled';
    this.state.loading = false;
    this.state.legacyError=results[3].status==='fulfilled'&&results[4].status==='fulfilled'?null:'旧四幕纪录暂未完整同步，稍后自动重试。';
    this.state.historicalError=results[5].status==='fulfilled'&&results[6].status==='fulfilled'?null:'v4.1 八幕历史纪录暂未完整同步，稍后自动重试。';
    if (!snapshotReadable && !feedReadable) {
      this.readError = '暂时无法连接排行榜，已保留最近同步的成绩。';
      if (this.opened) this.state.connection = 'offline';
    } else {
      this.readError = !snapshotReadable ? '历史榜暂时无法读取，成绩可能尚未完整同步。' :
        !feedReadable ? '即时成绩同步暂时中断，稍后自动重试。' :
        feedTruncated ? '近期成绩同步不完整，已保留可读取的成绩，稍后重试。' :
        null;
      if (this.opened && (this.state.connection !== 'live' || !feedReadable || feedTruncated)) this.state.connection = 'polling';
    }
    this.state.error = this.readError ?? (this.pendingProfile ? this.renamePendingMessage() : this.queue.length ? this.pendingMessage() : null);
    this.emit();
  }
  async submit(name: string, result: GameResult): Promise<Submission> {
    const normalized = validateRecord({ version: LEADERBOARD_VERSION, runId: 'run_validation', playerId: this.playerId, name: sanitizeName(name), createdAt: new Date().toISOString(), result });
    const identity = JSON.stringify(normalized?.result ?? result);
    const runId = `run_${hash(this.playerId + identity)}_${hash(identity + this.playerId, 5381)}`;
    const record = normalized && { ...normalized, runId };
    if (!record || new TextEncoder().encode(JSON.stringify(record)).length > 4000) {
      this.state.lastSubmission = { runId, status: 'rejected' }; this.emit();
      return { status: 'rejected', error: '只有当前版本完整通关的成绩可以登榜。' };
    }
    if (this.acknowledged.has(runId)) { this.state.lastSubmission = { runId, status: 'duplicate' }; this.emit(); return { status: 'duplicate', record }; }
    if (!this.queue.some(r => r.runId === runId)) this.queue.push(record);
    this.queuePersisted = this.write('queue', this.queue); this.state.lastSubmission = { runId, status: 'pending' }; this.emit();
    await this.retryPending();
    const status = this.acknowledged.has(runId) ? 'submitted' : 'pending';
    this.state.lastSubmission = { runId, status }; this.emit();
    return { status, record, ...(status === 'pending' ? { error: this.pendingMessage() } : {}) };
  }
  async rename(name: string): Promise<{status:SubmissionStatus;name:string;error?:string}> {
    const cleaned=sanitizeName(name);
    const current=mergeProfiles(this.state.profiles).find(profile=>profile.playerId===this.playerId);
    if(!this.pendingProfile && current?.name===cleaned){this.state.lastRename={name:cleaned,status:'duplicate'};this.emit();return {status:'duplicate',name:cleaned};}
    const previousTime=Math.max(Date.parse(current?.updatedAt??'')||0,Date.parse(this.pendingProfile?.updatedAt??'')||0);
    this.pendingProfile={version:LEADERBOARD_VERSION,type:'profile',playerId:this.playerId,name:cleaned,updatedAt:new Date(Math.max(Date.now(),previousTime+1)).toISOString()};
    this.profilePersisted=this.write('pendingProfile',this.pendingProfile);
    this.state.lastRename={name:cleaned,status:'pending'};this.emit();
    await this.retryPending();
    const shared=mergeProfiles(this.state.profiles).find(profile=>profile.playerId===this.playerId);
    const status=shared?.name===cleaned?'submitted':'pending';
    return {status,name:cleaned,...(status==='pending'?{error:this.renamePendingMessage()}:{} )};
  }
  private renamePendingMessage(): string {return this.profilePersisted?'昵称已在本机应用，联网后自动同步到排行榜。':'昵称暂存在本页面，请保持页面开启以完成同步。';}
  private retryPending(): Promise<void> {
    if (this.uploadPromise) return this.uploadPromise;
    this.uploadPromise = this.uploadQueue().finally(() => { this.uploadPromise = null; });
    return this.uploadPromise;
  }
  private async uploadQueue(): Promise<void> {
    if (this.retryTimer) clearTimeout(this.retryTimer); this.retryTimer = null;
    while (this.queue.length || this.pendingProfile) {
      if(this.pendingProfile) {
        const profile=this.pendingProfile;
        try {
          const {text}=await this.request(this.topicUrl,{method:'POST',headers:{'Content-Type':'text/plain'},body:JSON.stringify(profile)});
          const acknowledged=parseFeedState(text).profiles.find(p=>p.playerId===profile.playerId&&p.name===profile.name&&p.updatedAt===profile.updatedAt);
          if(!acknowledged)throw new Error('Profile not acknowledged');
          this.merge([], [acknowledged]);
          if(this.pendingProfile?.updatedAt===profile.updatedAt){this.pendingProfile=null;this.write('pendingProfile',null);this.state.lastRename={name:profile.name,status:'submitted'};}
          this.state.error=this.readError;this.emit();continue;
        } catch {
          this.state.error=this.renamePendingMessage();this.state.lastRename={name:this.pendingProfile?.name??profile.name,status:'pending'};this.emit();
          this.retryTimer=setTimeout(()=>{this.retryTimer=null;void this.retryPending();},60000);break;
        }
      }
      const record = this.queue[0];
      try {
        const { text } = await this.request(this.topicUrl, { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: JSON.stringify(record) });
        const acknowledged = parseFeed(text).find(r => r.runId === record.runId && r.playerId === record.playerId);
        if (!acknowledged) throw new Error('The server did not acknowledge the score');
        this.merge([acknowledged]); this.acknowledged.add(record.runId);
        this.write('ack', [...this.acknowledged].slice(-200));
        this.queue = this.queue.filter(r => r.runId !== record.runId); this.queuePersisted = this.write('queue', this.queue);
        this.state.lastSubmission = { runId: record.runId, status: 'submitted' }; this.state.error = this.readError; this.emit();
      } catch {
        this.state.error = this.pendingMessage();
        this.state.lastSubmission = { runId: record.runId, status: 'pending' }; this.emit();
        this.retryTimer = setTimeout(() => { this.retryTimer = null; void this.retryPending(); }, 60000);
        break;
      }
    }
  }
}
