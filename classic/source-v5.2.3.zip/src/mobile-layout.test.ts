import { describe, expect, it } from 'vitest';
import { separateTouchTargets, type TouchLayoutItem, type TouchLayoutRect } from './touch-layout';

const intersects = (a: TouchLayoutRect, b: TouchLayoutRect) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
const positioned = (item: TouchLayoutItem, point: { x: number; y: number }): TouchLayoutRect => ({ x: point.x - item.w / 2, y: point.y - item.h / 2, w: item.w, h: item.h });

describe('mobile control safety', () => {
  it('preserves an already-separated saved position exactly', () => {
    const items = [{ action: 'move', x: 24, y: 240, w: 112, h: 112, custom: true }, { action: 'jump', x: 550, y: 290, w: 64, h: 64 }];
    expect(separateTouchTargets(items, [], 667, 375)).toEqual({ move: { x: 80, y: 296 }, jump: { x: 582, y: 322 } });
  });

  it.each([.75, 1, 1.4])('repairs a legacy all-overlapping layout at scale %s without hiding actions', scale => {
    const sizes = { move: 112 * scale, jump: Math.max(48, 64 * scale), attack: Math.max(48, 58 * scale), dash: Math.max(44, 46 * scale), guard: Math.max(44, 46 * scale), overdrive: Math.max(44, 44 * scale) };
    const items = Object.entries(sizes).map(([action, size]) => ({ action, x: 333.5 - size / 2, y: 187.5 - size / 2, w: size, h: size, custom: true }));
    const reserved = [{ x: 20, y: 14, w: 209, h: 142 }, { x: 603, y: 14, w: 44, h: 44 }, { x: 515, y: 64, w: 132, h: 36 }, { x: 609, y: 108, w: 38, h: 36 }, { x: 190, y: 311, w: 148, h: 44 }];
    const result = separateTouchTargets(items, reserved, 667, 375);
    expect(Object.keys(result)).toHaveLength(6);
    const rects = items.map(item => positioned(item, result[item.action]));
    for (let i = 0; i < rects.length; i++) {
      expect(rects[i].x).toBeGreaterThanOrEqual(8); expect(rects[i].y).toBeGreaterThanOrEqual(8);
      expect(rects[i].x + rects[i].w).toBeLessThanOrEqual(659); expect(rects[i].y + rects[i].h).toBeLessThanOrEqual(367);
      for (const obstacle of [...reserved, ...rects.slice(0, i)]) expect(intersects(rects[i], obstacle)).toBe(false);
    }
  });

  it('moves a default control rather than displacing a valid custom control', () => {
    const items = [{ action: 'move', x: 30, y: 220, w: 112, h: 112 }, { action: 'guard', x: 60, y: 250, w: 44, h: 44, custom: true }];
    const result = separateTouchTargets(items, [], 667, 375);
    expect(result.guard).toEqual({ x: 82, y: 272 });
    expect(intersects(positioned(items[0], result.move), positioned(items[1], result.guard))).toBe(false);
  });
});
