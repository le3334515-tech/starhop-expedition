// Native top-layer dialogs and a CSS-rotated canvas use different coordinate
// spaces in several mobile WebViews. Keep the mobile sheet in its stage.
export function openPanel(panel: HTMLDialogElement, onBackdrop: () => void) {
  if (panel.hasAttribute('open')) return;
  if (!navigator.maxTouchPoints && typeof panel.showModal === 'function') {
    try { panel.showModal(); return; } catch { /* A WebView can deny the top layer. */ }
  }
  const shell = document.getElementById('game-shell');
  const inStage = document.body.classList.contains('mobile-playing') && shell;
  const layer = document.createElement('div');
  layer.className = 'panel-layer' + (inStage ? ' panel-in-stage' : '');
  (inStage || document.body).append(layer);
  const placeholder = document.createComment('dialog position');
  panel.before(placeholder);
  layer.append(panel);
  panel.setAttribute('open', '');
  panel.setAttribute('aria-modal', 'true');
  panel.setAttribute('role', 'dialog');
  layer.addEventListener('click', event => { if (event.target === layer) onBackdrop(); });
  const focusable = () => Array.from(panel.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), textarea, select, a[href]')).filter(el => el.getClientRects().length);
  layer.onkeydown = event => {
    if (event.key !== 'Tab') return;
    const items = focusable();
    const edge = event.shiftKey ? items[0] : items[items.length - 1];
    if (edge && edge === document.activeElement) { event.preventDefault(); (event.shiftKey ? items[items.length - 1] : items[0]).focus(); }
  };
  panelCleanup.set(panel, () => { placeholder.replaceWith(panel); layer.remove(); });
  focusable()[0]?.focus({ preventScroll: true });
}
const panelCleanup = new WeakMap<HTMLDialogElement, () => void>();
export function closePanel(panel: HTMLDialogElement) {
  const cleanup = panelCleanup.get(panel);
  if (cleanup) {
    panel.removeAttribute('open'); panel.removeAttribute('aria-modal'); cleanup(); panelCleanup.delete(panel);
  } else if (panel.hasAttribute('open')) panel.close();
}
