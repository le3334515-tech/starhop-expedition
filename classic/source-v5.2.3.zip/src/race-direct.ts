import Peer, { util, type DataConnection } from 'peerjs';
import type { GameConfig } from './game/types';
import { HostRound, raceKey, RaceRuleError } from './race-host';
import { parseRaceResponse, type RaceResponse } from './race-types';

import { RacePipe } from './race-pipe';

type Body = Record<string, unknown>;
const prefix = 'starhop-classic-';
type Waiter = {
  resolve: (value: RaceResponse) => void;
  reject: (reason: Error) => void;
};
const offline = () => new Error('直连已中断，正在等待房主。');

function waitFor<T>(
  start: (ok: (value: T) => void, fail: (e: Error) => void) => () => void,
  milliseconds: number,
  message: string,
): Promise<T> {
  return new Promise((resolve, reject) => {
    let clean = () => {};
    const finish = () => {
      clearTimeout(timer);
      clean();
    };
    const fail = (e: Error) => {
      finish();
      reject(e);
    };
    const timer = setTimeout(() => fail(new Error(message)), milliseconds);
    clean = start((value) => {
      finish();
      resolve(value);
    }, fail);
  });
}

export class DirectRace {
  private pipe: RacePipe | null = null;
  private usingPipe = false;
  get pollInterval() {
    return this.usingPipe ? 1000 : 200;
  }
  private peer: Peer | null = null;
  private round: HostRound | null = null;
  private channel: DataConnection | null = null;
  private connecting: Promise<DataConnection> | null = null;
  private pending = new Map<number, Waiter>();
  private seq = 0;
  private closed = false;
  private remoteClosed = false;
  private reconnectTimer?: ReturnType<typeof setTimeout>;
  constructor(readonly id: string) {}

  async host(config: GameConfig, name: string) {
    this.round = new HostRound(this.id, config, name);
    await this.preparePipe();
    const round = this.round;
    if (this.pipe)
      void this.pipe.listen((body) => {
        const result = round.handle(false, body);
        const previous = this.channel;
        this.channel = null;
        previous?.close();
        return result;
      });
    try {
      await this.register(prefix + this.id);
    } catch (error) {
      if (this.closed || !this.pipe || !(await this.pipe.available()))
        throw error;
      this.dropPeer();
    }
  }
  private async preparePipe() {
    if (!globalThis.crypto?.subtle) return;
    const pipe = await RacePipe.open(this.id);
    if (this.closed) {
      pipe.close();
      throw offline();
    }
    this.pipe = pipe;
  }
  private dropPeer() {
    clearTimeout(this.reconnectTimer);
    this.peer?.destroy();
    this.peer = null;
  }
  async guest() {
    await this.preparePipe();
    try {
      await this.register(prefix + 'guest-' + raceKey());
    } catch (error) {
      if (this.closed || !this.pipe) throw error;
      this.dropPeer();
      this.usingPipe = true;
    }
  }

  private async register(id: string) {
    if (!globalThis.RTCPeerConnection || !globalThis.WebSocket)
      throw new Error('此浏览器未开放好友直连，可使用服务器房间。');
    const config = {
      ...util.defaultConfig,
      iceServers: [
        ...util.defaultConfig.iceServers,
        { urls: 'stun:stun.cloudflare.com:3478' },
      ],
    };
    const peer = new Peer(id, { secure: true, debug: 0, config });
    this.peer = peer;
    peer.on('connection', (c) => {
      if (!this.round || c.label !== 'starhop-race-v1') {
        c.close();
        return;
      }
      c.on('error', () => c.close());
      c.on('data', (data) => this.serve(c, data));
      c.on('close', () => {
        if (c !== this.channel) return;
        this.channel = null;
        this.round?.seatLost();
      });
    });
    peer.on('disconnected', () => this.restoreSignaling());
    peer.on('error', () => {
      if (peer.disconnected) this.restoreSignaling();
    });
    await waitFor<void>(
      (ok, fail) => {
        const opened = () => ok();
        const failed = () => fail(new Error('直连信令服务未响应。'));
        peer.once('open', opened);
        peer.once('error', failed);
        peer.once('close', failed);
        return () => {
          peer.off('open', opened);
          peer.off('error', failed);
          peer.off('close', failed);
        };
      },
      5500,
      '直连信令连接超时。',
    );
  }
  private restoreSignaling() {
    if (this.closed || this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = undefined;
      if (this.peer?.disconnected && !this.peer.destroyed && !this.closed) {
        try {
          this.peer.reconnect();
        } catch {
          this.restoreSignaling();
        }
      }
    }, 1200);
  }
  private serve(c: DataConnection, data: unknown) {
    if (!data || typeof data !== 'object' || !this.round || !c.open) return;
    const m = data as { n?: number; body?: Body };
    if (!Number.isSafeInteger(m.n) || !m.body || typeof m.body !== 'object')
      return;
    try {
      const reply = this.round.handle(false, m.body);
      c.send({ n: m.n, reply });
      if (m.body.action === 'leave') {
        if (this.channel === c) this.channel = null;
      } else if (this.channel !== c) {
        const old = this.channel;
        this.channel = c;
        old?.close();
      }
    } catch (e) {
      c.send({
        n: m.n,
        error: e instanceof Error ? e.message : '房间请求无效。',
        status: e instanceof RaceRuleError ? e.status : 400,
      });
    }
  }
  private async connectHost(): Promise<DataConnection> {
    if (this.closed || !this.peer || this.peer.destroyed) throw offline();
    if (this.remoteClosed)
      throw new RaceRuleError('房主已离开，请重新发起竞速。', 410);
    if (this.channel?.open) return this.channel;
    if (this.connecting) return this.connecting;
    const peer = this.peer;
    const c = peer.connect(prefix + this.id, {
      label: 'starhop-race-v1',
      reliable: true,
      serialization: 'json',
    });
    if (!c) throw offline();
    c.on('data', (data) => {
      if (c !== this.channel || !data || typeof data !== 'object') return;
      const msg = data as {
        n: number;
        reply?: unknown;
        error?: string;
        status?: number;
        closed?: boolean;
      };
      if (msg.closed) {
        this.remoteClosed = true;
        this.rejectPending(
          new RaceRuleError('房主已离开，请重新发起竞速。', 410),
        );
        return;
      }
      const request = this.pending.get(msg.n);
      if (!request) return;
      if (msg.error)
        request.reject(
          new RaceRuleError(String(msg.error).slice(0, 160), msg.status ?? 400),
        );
      else
        try {
          request.resolve(parseRaceResponse(msg.reply));
        } catch {
          request.reject(new Error('房间数据不完整。'));
        }
    });
    const lost = () => {
      if (this.channel === c) {
        this.channel = null;
        this.rejectPending(offline());
      }
    };
    c.on('close', lost);
    c.on('error', lost);
    this.connecting = waitFor<DataConnection>(
      (ok, fail) => {
        const opened = () => {
          if (this.closed) {
            fail(offline());
            return;
          }
          this.channel = c;
          ok(c);
        };
        const failed = () => fail(offline());
        const peerError = (e: Error & { type?: string }) => {
          if (e.type === 'peer-unavailable')
            fail(new RaceRuleError('房主已离开或邀请已失效。', 404));
        };
        c.once('open', opened);
        c.once('error', failed);
        c.once('close', failed);
        peer.on('error', peerError);
        return () => {
          c.off('open', opened);
          c.off('error', failed);
          c.off('close', failed);
          peer.off('error', peerError);
        };
      },
      6500,
      '正在尝试 HTTPS 备用线路。',
    );
    try {
      return await this.connecting;
    } catch (e) {
      c.close();
      throw e;
    } finally {
      this.connecting = null;
    }
  }
  async request(body: Body): Promise<RaceResponse> {
    if (this.closed) throw offline();
    if (this.round) return parseRaceResponse(this.round.handle(true, body));
    if (this.usingPipe && this.pipe) return this.pipe.request(body);
    let c: DataConnection;
    try {
      c = await this.connectHost();
    } catch (error) {
      if (this.closed || !this.pipe || this.remoteClosed) throw error;
      this.usingPipe = true;
      this.dropPeer();
      return this.pipe.request(body);
    }
    const n = ++this.seq;
    return waitFor<RaceResponse>(
      (resolve, reject) => {
        this.pending.set(n, { resolve, reject });
        try {
          c.send({ n, body });
        } catch {
          this.pending.delete(n);
          reject(offline());
        }
        return () => {
          this.pending.delete(n);
        };
      },
      5000,
      '房主暂时没有响应，请回到游戏页面。',
    );
  }
  private rejectPending(e: Error) {
    for (const waiter of [...this.pending.values()]) waiter.reject(e);
    this.pending.clear();
  }
  close() {
    this.closed = true;
    if (this.round && this.channel?.open) this.channel.send({ closed: true });
    clearTimeout(this.reconnectTimer);
    this.rejectPending(offline());
    this.pipe?.close();
    this.pipe = null;
    this.dropPeer();
    this.channel = null;
    this.round = null;
  }
}
