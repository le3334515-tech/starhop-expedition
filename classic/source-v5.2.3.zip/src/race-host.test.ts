import { describe, expect, it } from 'vitest';
import { HostRound, directRoom, raceKey } from './race-host';
import { RACE_RULESET } from './race-types';

function seats() {
  const room = new HostRound(
    'p2_' + raceKey(),
    { seed: 24, modifier: 'standard', weapon: 'blade' },
    '甲',
    1000,
  );
  const hostToken = room.handle(true, { action: 'create' }, 1000).token;
  const guestToken = room.handle(
    false,
    { action: 'join', clientId: 'guest_id_1', name: '乙', ruleset: RACE_RULESET },
    1001,
  ).token;
  return {
    room,
    hostToken,
    guestToken,
    host: (action: string, now: number, extra = {}) =>
      room.handle(true, { token: hostToken, action, ...extra }, now),
    guest: (action: string, now: number, extra = {}) =>
      room.handle(false, { token: guestToken, action, ...extra }, now),
  };
}
describe('direct and encrypted HTTPS race rooms', () => {
  it('rejects outdated battle rules before assigning the guest seat', () => {
    const round = new HostRound('p2_' + raceKey(), { seed:24,modifier:'standard',weapon:'blade' }, '甲', 1000);
    const join = { action:'join', clientId:'guest_id_1' };
    expect(round.handle(true, { action:'create' }, 1001).room.ruleset).toBe(RACE_RULESET);
    expect(() => round.handle(false, join, 1002)).toThrow('不同版本');
    expect(() => round.handle(false, { ...join, ruleset:'different-rules' }, 1003)).toThrow('不同版本');
    expect(round.room.guest).toBeNull();
    expect(round.handle(false, { ...join, ruleset:RACE_RULESET }, 1004).room.guest?.id).toBe('guest');
  });
  it('gives each seat a separate credential and refuses a third player', () => {
    const { room, hostToken, guestToken } = seats();
    expect(directRoom(room.room.id)).toBe(true);
    expect(directRoom('legacyroomnumber')).toBe(false);
    expect(hostToken).not.toBe(guestToken);
    expect(
      room.handle(false, { action: 'join', clientId: 'guest_id_1', ruleset: RACE_RULESET }, 1010)
        .token,
    ).toBe(guestToken);
    expect(() =>
      room.handle(false, { action: 'join', clientId: 'guest_id_2', ruleset: RACE_RULESET }, 1010),
    ).toThrow('两名玩家');
    expect(() =>
      room.handle(false, { action: 'ready', token: hostToken }, 1010),
    ).toThrow('凭据');
  });
  it('keeps one host deadline and cancels countdown if a peer leaves before starting', () => {
    const { room, host, guest } = seats();
    expect(host('ready', 2000).room.startAt).toBeNull();
    expect(guest('ready', 3000).room.startAt).toBe(8000);
    expect(host('ready', 3300).room.startAt).toBe(8000);
    room.seatLost(3400);
    expect(room.room.startAt).toBeNull();
    expect(guest('ready', 4000).room.startAt).toBe(9000);
    expect(guest('leave', 4100).room.guest).toBeNull();
    expect(
      room.handle(false, { action: 'join', clientId: 'guest_id_2', ruleset: RACE_RULESET }, 4500).room
        .host.readyAt,
    ).toBeNull();
  });
  it('accepts current-round progress in order and pins finish to host time', () => {
    const { host, guest, room } = seats();
    host('ready', 2000);
    guest('ready', 2000);
    const frame = { seq: 8, roomIndex: 6, finished: false };
    expect(
      guest('state', 3000, { epoch: 0, frame }).room.guest?.frame,
    ).toBeNull();
    guest('state', 8000, { epoch: 0, frame });
    guest('state', 8500, {
      epoch: 0,
      frame: { ...frame, seq: 7, roomIndex: 7 },
    });
    expect(room.room.guest?.frame?.roomIndex).toBe(6);
    guest('state', 9000, {
      epoch: 0,
      frame: { ...frame, seq: 9, won: true, finished: true },
    });
    expect(room.room.guest?.finishedAt).toBeNull();
    const win = { ...frame, seq: 10, roomIndex: 7, won: true, finished: true };
    guest('state', 10000, { epoch: 0, frame: win });
    guest('state', 11000, { epoch: 0, frame: win });
    expect(room.room.guest?.finishedAt).toBe(10000);
    expect(host('state', 15000, { epoch: 0, frame: win }).room.status).toBe(
      'finished',
    );
    expect(() => guest('reset', 16000)).toThrow();
    expect(host('reset', 17000, { epoch:0 }).room.epoch).toBe(1);
    expect(
      guest('state', 18000, { epoch: 0, frame: win }).room.guest?.frame,
    ).toBeNull();
    host('ready', 18000);
    const deadline = guest('ready', 18100).room.startAt;
    expect(host('reset', 18200, { epoch:0 }).room).toMatchObject({ epoch:1, startAt:deadline });
  });
  it('closes when the host leaves and expires inactive rooms', () => {
    const { host, guest } = seats();
    expect(() => guest('state', 7201001)).toThrow('过期');
    host('leave', 2000);
    expect(() => guest('state', 2100)).toThrow('离开');
  });
  it('keeps character picks per seat and shares the selected kit in accepted frames', () => {
    const { room, host, guest } = seats();
    expect(room.room.characterSelection).toBe(true);
    expect(host('character', 1200, { character: 'wheel' }).room.host.character).toBe('wheel');
    expect(guest('character', 1300, { character: 'wheel' }).room.guest?.character).toBe('wheel');
    expect(() => guest('character', 1400, { character: 'outside-roster' })).toThrow('角色无效');
    expect(guest('character', 1500, { character: 'spear' }).room.guest?.character).toBe('spear');
    host('ready', 2000);
    expect(() => host('character', 2100, { character: null })).toThrow('取消准备');
    expect(guest('ready', 2300).room.startAt).toBe(7300);
    expect(() => guest('character', 2400, { character: 'staff' })).toThrow('取消准备');
    const accepted = guest('state', 7400, { epoch: 0, frame: { seq: 1, roomIndex: 0, weapon: 'halberd', character: 'monk' } });
    expect(accepted.room.guest?.frame).toMatchObject({ character: 'spear', weapon: 'halberd' });
    const illegal = host('state', 7500, { epoch: 0, frame: { seq: 1, roomIndex: 0, weapon: 'halberd' } });
    expect(illegal.room.host.frame).toMatchObject({ character: 'wheel', weapon: 'fan' });
    expect(accepted.room.config).toEqual({ seed: 24, modifier: 'standard', weapon: 'blade' });
  });
});
