import { isCharacterId, type CharacterId, type GameConfig } from './game/types';
import {
  RACE_RULESET, RACE_RULESET_MISMATCH,
  sanitizeRaceFrame,
  type RacePlayer,
  type RaceResponse,
  type RaceRoom,
  type RaceSeat,
} from './race-types';

export class RaceRuleError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}
export function raceKey() {
  return Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) =>
    byte.toString(16).padStart(2, '0'),
  ).join('');
}
export function directRoom(id: unknown): id is string {
  return typeof id === 'string' && /^p2_[0-9a-f]{32}$/.test(id);
}
const player = (id: RaceSeat, name: unknown, now: number, character: CharacterId | null = 'traveller'): RacePlayer => ({
  id,
  name:
    typeof name === 'string'
      ? [...name.replace(/[<>\u0000-\u001f]/g, '').trim()]
          .slice(0, 16)
          .join('') || '星际旅人'
      : '星际旅人',
  readyAt: null,
  finishedAt: null,
  lastSeen: now,
  leftAt: null,
  frame: null,
  character,
});

// Only the host browser owns this round. Guests can update their own seat.
export class HostRound {
  readonly room: RaceRoom;
  private guestClient = '';
  private guestToken = '';
  private hostToken = raceKey();
  private closed = false;
  constructor(id: string, config: GameConfig, name: string, now = Date.now()) {
    const { character, ...route } = config;
    this.room = {
      id,
      config: route,
      ruleset: RACE_RULESET,
      characterSelection: true,
      epoch: 0,
      createdAt: now,
      status: 'waiting',
      startAt: null,
      host: player('host', name, now, isCharacterId(character) ? character : 'traveller'),
      guest: null,
    };
  }
  seatLost(now = Date.now()) {
    const room = this.room;
    if (room.guest && (room.startAt === null || now < room.startAt)) {
      room.guest.readyAt = null;
      room.startAt = null;
    }
  }
  handle(
    local: boolean,
    body: Record<string, unknown>,
    now = Date.now(),
  ): RaceResponse {
    const room = this.room;
    if (this.closed || now - room.createdAt > 7200000)
      throw new RaceRuleError('房主已离开或房间过期。', 410);
    const seat = local ? 'host' : 'guest';
    let token: string | undefined;
    if (body.action === 'create' && local) {
      token = this.hostToken;
    } else if (body.action === 'join' && !local) {
      if (body.ruleset !== room.ruleset) throw new RaceRuleError(RACE_RULESET_MISMATCH, 409);
      if (
        typeof body.clientId !== 'string' ||
        !/^[a-zA-Z0-9_-]{8,100}$/.test(body.clientId)
      )
        throw new RaceRuleError('入房凭据无效。', 400);
      if (room.guest && this.guestClient !== body.clientId)
        throw new RaceRuleError('房间已有两名玩家。', 409);
      if (!room.guest) {
        if (room.startAt !== null)
          throw new RaceRuleError('这场竞速已经开始。', 409);
        this.guestClient = body.clientId;
        this.guestToken = raceKey();
        room.guest = player('guest', body.name, now);
      }
      token = this.guestToken;
    } else {
      const self = room[seat];
      if (!self || body.token !== (local ? this.hostToken : this.guestToken))
        throw new RaceRuleError('入房凭据失效，请重新加入。', 401);
      self.lastSeen = now;
      switch (body.action) {
        case 'state': {
          if (body.epoch !== room.epoch || self.finishedAt !== null) break;
          self.leftAt = null;
          if (!body.frame) break;
          const incoming = sanitizeRaceFrame({ ...Object(body.frame), character: self.character });
          if (
            self.frame &&
            (incoming.seq <= self.frame.seq ||
              incoming.roomIndex < self.frame.roomIndex)
          )
            break;
          if (
            !room.startAt ||
            now < room.startAt ||
            (incoming.won && (!incoming.finished || incoming.roomIndex !== 7))
          )
            break;
          self.frame = incoming;
          if (incoming.finished) self.finishedAt = now;
          break;
        }
        case 'character':
          if (room.startAt !== null || self.readyAt !== null)
            throw new RaceRuleError('请取消准备后再更换角色。', 409);
          if (body.character !== null && !isCharacterId(body.character))
            throw new RaceRuleError('竞速角色无效。', 400);
          self.character = body.character;
          break;
        case 'ready':
          if (room.startAt !== null && now >= room.startAt)
            throw new RaceRuleError('竞速已经开始。', 409);
          self.readyAt = body.ready === false ? null : (self.readyAt ?? now);
          if (
            room.host.readyAt !== null &&
            room.guest &&
            room.guest.readyAt !== null
          )
            room.startAt ??= now + 5000;
          else room.startAt = null;
          break;
        case 'leave':
          self.leftAt = now;
          if (local) this.closed = true;
          else if (room.startAt === null || now < room.startAt) {
            room.guest = null;
            this.guestClient = this.guestToken = '';
            room.startAt = room.host.readyAt = null;
          }
          break;
        case 'reset':
          if (!local) throw new RaceRuleError('由房主发起下一场竞速。', 403);
          if (Number.isInteger(body.epoch) && body.epoch !== room.epoch) break;
          if (room.startAt === null || now < room.startAt) break;
          if (!room.host.finishedAt || !room.guest?.finishedAt)
            throw new RaceRuleError('双方结算后由房主发起再赛。', 409);
          room.epoch = (room.epoch ?? 0) + 1;
          room.startAt = null;
          room.host = player('host', room.host.name, now, room.host.character);
          room.guest = player('guest', room.guest.name, now, room.guest.character);
          break;
        default:
          throw new RaceRuleError('未知竞速操作。', 400);
      }
    }
    room.status =
      room.startAt === null
        ? 'waiting'
        : now < room.startAt
          ? 'countdown'
          : room.host.finishedAt && room.guest?.finishedAt
            ? 'finished'
            : 'racing';
    return { ok: true, serverNow: now, selfId: seat, token, room };
  }
}
