import { raceKey, RaceRuleError } from './race-host';
import { parseRaceResponse, type RaceResponse } from './race-types';

type Body = Record<string, unknown>;
const origin = 'https://ppng.io';
const encoder = new TextEncoder();
const decoder = new TextDecoder();
const pause = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, ms));
const hex = (bytes: ArrayBuffer) =>
  Array.from(new Uint8Array(bytes), (b) =>
    b.toString(16).padStart(2, '0'),
  ).join('');
type Wire = {
  replyId?: string;
  body?: Body;
  value?: unknown;
  error?: string;
  status?: number;
};

// Some mobile webviews have HTTPS but no RTCDataChannel. The room secret stays
// in the invitation. Only a derived path and AES-GCM ciphertext reach the pipe.
export class RacePipe {
  private controllers = new Set<AbortController>();
  private stopped = false;
  private queue: Promise<unknown> = Promise.resolve();
  private constructor(
    private path: string,
    private key: CryptoKey,
  ) {}
  static async open(roomId: string) {
    const secret = Uint8Array.from(roomId.slice(3).match(/../g)!, (b) =>
      parseInt(b, 16),
    );
    const key = await crypto.subtle.importKey('raw', secret, 'AES-GCM', false, [
      'encrypt',
      'decrypt',
    ]);
    const route = hex(
      await crypto.subtle.digest(
        'SHA-256',
        encoder.encode('starhop.route.1/' + roomId),
      ),
    );
    return new RacePipe(origin + '/starhop-v1/' + route, key);
  }
  private async encrypt(message: Wire) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const data = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      this.key,
      encoder.encode(JSON.stringify(message)),
    );
    return btoa(String.fromCharCode(...iv, ...new Uint8Array(data)));
  }
  private async decrypt(text: string): Promise<Wire> {
    if (text.length > 16000) throw new Error('房间数据过长。');
    const data = Uint8Array.from(atob(text), (c) => c.charCodeAt(0));
    return JSON.parse(
      decoder.decode(
        await crypto.subtle.decrypt(
          { name: 'AES-GCM', iv: data.slice(0, 12) },
          this.key,
          data.slice(12),
        ),
      ),
    );
  }
  private async transfer(url: string, body?: string, wait = 9000) {
    if (this.stopped) throw new Error('房间已关闭。');
    const controller = new AbortController();
    this.controllers.add(controller);
    const timer = setTimeout(() => controller.abort(), wait);
    try {
      const response = await fetch(url, {
        method: body === undefined ? 'GET' : 'POST',
        body,
        credentials: 'omit',
        referrerPolicy: 'no-referrer',
        signal: controller.signal,
      });
      if (!response.ok) throw new Error('备用线路暂未连接。');
      return await response.text();
    } finally {
      clearTimeout(timer);
      this.controllers.delete(controller);
    }
  }
  async available() {
    return /^\d+\.\d+/.test(
      await this.transfer(origin + '/version', undefined, 5000),
    );
  }
  async listen(handle: (body: Body) => RaceResponse) {
    while (!this.stopped) {
      try {
        const packet = await this.decrypt(
          await this.transfer(this.path + '/in', undefined, 90000),
        );
        if (!packet.body || !/^[a-f0-9]{32}$/.test(packet.replyId ?? ''))
          continue;
        let response: Wire;
        try {
          response = { value: handle(packet.body) };
        } catch (e) {
          response = {
            error: e instanceof Error ? e.message : '房间请求无效。',
            status: e instanceof RaceRuleError ? e.status : 400,
          };
        }
        const answer = await this.encrypt(response);
        // Accept the next message immediately, irrespective of a previous reader.
        if (this.controllers.size < 5)
          void this.transfer(this.path + '/' + packet.replyId, answer).catch(
            () => {},
          );
      } catch {
        if (!this.stopped) await pause(900);
      }
    }
  }
  request(body: Body): Promise<RaceResponse> {
    const send = async () => {
      const replyId = raceKey();
      const payload = await this.encrypt({ replyId, body });
      const [, text] = await Promise.all([
        this.transfer(this.path + '/in', payload),
        this.transfer(this.path + '/' + replyId),
      ]);
      const result = await this.decrypt(text);
      if (result.error)
        throw new RaceRuleError(result.error, result.status ?? 400);
      return parseRaceResponse(result.value);
    };
    const pending = this.queue.then(send);
    this.queue = pending.catch(() => {});
    return pending.catch((error) => {
      if (error instanceof RaceRuleError) throw error;
      throw new Error(
        '暂时联系不到房主。请确认房主仍在本页，或请房主切换服务器后再邀你。',
      );
    });
  }
  close() {
    this.stopped = true;
    for (const controller of this.controllers) controller.abort();
  }
}
