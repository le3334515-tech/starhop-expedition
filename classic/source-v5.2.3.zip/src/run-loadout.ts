import { isCharacterId, isLoadoutWeapon, type GameConfig } from './game/types';

/** Read character and starting weapon together, including classic runs saved before character selection. */
export function readRunLoadout(weapon: unknown, character: unknown): Pick<GameConfig, 'weapon' | 'character'> | null {
  if (character === undefined) return isLoadoutWeapon(undefined, weapon) ? { weapon } : null;
  return isCharacterId(character) && isLoadoutWeapon(character, weapon) ? { weapon, character } : null;
}
