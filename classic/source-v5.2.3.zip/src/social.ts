import type { GameConfig, GameResult, ModifierId } from './game/types';
import { readRunLoadout } from './run-loadout';

export interface Rival { name: string; result: GameResult }
export interface Challenge extends GameConfig { v: 1; rival?: Rival }
export interface RunRecord { id: string; createdAt: string; name: string; result: GameResult }

const PLAYER_KEY = 'starhop.player.v1';
const RECORDS_KEY = 'starhop.runs.v1';
const DEFAULT_NAME = '星际旅人';
const MAX_CODE_LENGTH = 12_000;
const MAX_INPUT_LENGTH = 16_000;
const MODIFIERS = new Set<ModifierId>(['standard', 'moon', 'haste', 'iron']);
let memoryName = DEFAULT_NAME;
let memoryRecords: RunRecord[] = [];
let recordSequence = 0;
// A browser can still read old values when writes fail (for example, a full quota).
// Until a later write succeeds, those stale values must not replace newer memory.
const failedWrites = new Set<string>();

function fail(message = '这份挑战码不完整，请重新复制好友发来的链接。'): never {
  throw new Error(message);
}

function object(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail();
  return value as Record<string, unknown>;
}

function number(value: unknown, min: number, max: number, integer = false): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value))) fail();
  return value;
}

function modifier(value: unknown): ModifierId {
  if (typeof value !== 'string' || !MODIFIERS.has(value as ModifierId)) fail('挑战中的规则不存在，请检查挑战链接。');
  return value as ModifierId;
}

function cleanName(value: string): string {
  const safe = value.normalize('NFC')
    .replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069<>&"'`]/g, '')
    .replace(/\s+/g, ' ').trim();
  return Array.from(safe).slice(0, 12).join('') || DEFAULT_NAME;
}

function validateResult(value: unknown): GameResult {
  const result = object(value);
  if (typeof result.won !== 'boolean' || !Array.isArray(result.upgrades) || result.upgrades.length > 100) fail();
  const identifiers = (value: unknown, max: number): string[] => {
    if (!Array.isArray(value) || value.length > max) fail();
    return value.map((id) => {
      if (typeof id !== 'string' || !/^[a-zA-Z0-9_-]{1,64}$/.test(id)) fail();
      return id;
    });
  };
  const upgrades = identifiers(result.upgrades, 100);
  // Version-one links made before the awakening update remain playable.
  const synergies = result.synergies === undefined ? [] : identifiers(result.synergies, 32);
  const overdriveCount = result.overdriveCount === undefined ? 0 : number(result.overdriveCount, 0, 100_000, true);
  return {
    seed: number(result.seed, 0, 0xffffffff, true), modifier: modifier(result.modifier),
    ...(readRunLoadout(result.weapon, result.character) ?? fail('纪录中的角色或武器无效。')),
    won: result.won, time: number(result.time, 0, 86_400), score: number(result.score, 0, 100_000_000, true),
    coins: number(result.coins, 0, 1_000_000, true), kills: number(result.kills, 0, 100_000, true),
    level: number(result.level, 1, 10_000, true), deaths: number(result.deaths, 0, 100_000, true),
    roomsCleared: number(result.roomsCleared, 0, 10_000, true), maxCombo: number(result.maxCombo, 0, 100_000, true), upgrades,
    overdriveCount, synergies,
  };
}

function validateChallenge(value: unknown): Challenge {
  const challenge = object(value);
  if (challenge.v !== 1) fail('这份挑战使用了不同版本，请使用当前版本生成的挑战链接。');
  const validated: Challenge = {
    v: 1, seed: number(challenge.seed, 0, 0xffffffff, true), modifier: modifier(challenge.modifier),
    ...(readRunLoadout(challenge.weapon, challenge.character) ?? fail('挑战中的角色或武器无效。')),
  };
  if (challenge.rival !== undefined) {
    const rival = object(challenge.rival);
    if (typeof rival.name !== 'string' || Array.from(rival.name).length > 80) fail();
    const result = validateResult(rival.result);
    if (result.seed !== validated.seed || result.modifier !== validated.modifier || result.weapon !== validated.weapon || result.character !== validated.character) fail('好友成绩与挑战条件不一致，请重新生成战书。');
    if (!result.won) fail('这份战书没有已通关的好友纪录，请重新生成战书。');
    validated.rival = { name: cleanName(rival.name), result };
  }
  return validated;
}

function hash(text: string): number {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return h >>> 0;
}

function bytesToBase64(bytes: Uint8Array): string {
  let text = '';
  for (const byte of bytes) text += String.fromCharCode(byte);
  return btoa(text).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64ToText(value: string): string {
  if (!/^[A-Za-z0-9_-]+$/.test(value)) fail();
  const binary = atob(value.replace(/-/g, '+').replace(/_/g, '/'));
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
}

/** A date seed is keyed to the Hong Kong calendar day, independently of device timezone. */
export function getDailySeed(date = new Date()): number {
  if (!Number.isFinite(date.getTime())) throw new Error('日期无法识别。');
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Hong_Kong', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(date);
  const part = (type: Intl.DateTimeFormatPartTypes) => parts.find((item) => item.type === type)?.value;
  return hash(`STARHOP:${part('year')}-${part('month')}-${part('day')}`);
}

export function randomSeed(): number {
  try {
    if (typeof globalThis.crypto !== 'undefined') return crypto.getRandomValues(new Uint32Array(1))[0];
  } catch { /* Fall back to a local random seed when crypto is unavailable. */ }
  return (Math.floor(Math.random() * 0x100000000) ^ Date.now()) >>> 0;
}

export function encodeChallenge(challenge: Challenge): string {
  const payload = bytesToBase64(new TextEncoder().encode(JSON.stringify(validateChallenge(challenge))));
  const code = `SH1.${payload}.${hash(payload).toString(16).padStart(8, '0')}`;
  if (code.length > MAX_CODE_LENGTH) fail('挑战内容太长，请重新生成一份战书。');
  return code;
}

export function decodeChallenge(codeOrUrl: string): Challenge {
  if (typeof codeOrUrl !== 'string' || codeOrUrl.length > MAX_INPUT_LENGTH) fail('挑战内容过长，请只粘贴挑战链接或挑战码。');
  let code = codeOrUrl.trim();
  if (!code) fail('请先粘贴好友发来的挑战链接或挑战码。');
  try {
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(code)) {
      const url = new URL(code);
      const fragment = new URLSearchParams(url.hash.replace(/^#/, ''));
      code = fragment.get('c') || url.searchParams.get('c') || '';
    } else if (/^#?c=/.test(code)) {
      code = new URLSearchParams(code.replace(/^#/, '')).get('c') || '';
    }
    if (code.length > MAX_CODE_LENGTH) fail('挑战内容过长，请重新复制链接。');
    const match = /^SH1\.([A-Za-z0-9_-]+)\.([0-9a-f]{8})$/.exec(code);
    if (!match || hash(match[1]).toString(16).padStart(8, '0') !== match[2]) fail();
    return validateChallenge(JSON.parse(base64ToText(match[1])));
  } catch (error) {
    if (error instanceof Error && /挑战|好友|战书|版本|武器|规则/.test(error.message)) throw error;
    fail();
  }
}

export function makeChallengeUrl(challenge: Challenge, base?: string): string {
  const url = new URL(base || globalThis.location?.href || 'http://localhost:5173/');
  url.searchParams.delete('race');
  url.hash = `c=${encodeChallenge(challenge)}`;
  return url.toString();
}

export function formatTime(seconds: number): string {
  const centiseconds = Math.floor(Math.max(0, Number.isFinite(seconds) ? seconds : 0) * 100 + 1e-7);
  const minutes = Math.floor(centiseconds / 6000).toString().padStart(2, '0');
  const second = Math.floor((centiseconds % 6000) / 100).toString().padStart(2, '0');
  return `${minutes}:${second}.${(centiseconds % 100).toString().padStart(2, '0')}`;
}

function readStorage(key: string): string | null | undefined {
  if (failedWrites.has(key)) return undefined;
  try { return globalThis.localStorage?.getItem(key); } catch { return undefined; }
}

function writeStorage(key: string, value: string): void {
  try {
    const storage = globalThis.localStorage;
    if (!storage) { failedWrites.add(key); return; }
    storage.setItem(key, value);
    failedWrites.delete(key);
  } catch { failedWrites.add(key); }
}

export function getPlayerName(): string {
  const stored = readStorage(PLAYER_KEY);
  if (stored !== undefined) memoryName = stored === null ? DEFAULT_NAME : cleanName(stored);
  return memoryName;
}

export function setPlayerName(name: string): string {
  memoryName = cleanName(typeof name === 'string' ? name : '');
  writeStorage(PLAYER_KEY, memoryName);
  return memoryName;
}

function validateRecord(value: unknown): RunRecord | null {
  try {
    const record = object(value);
    if (typeof record.id !== 'string' || !/^[a-zA-Z0-9_-]{1,100}$/.test(record.id) || typeof record.createdAt !== 'string' ||
      !Number.isFinite(Date.parse(record.createdAt)) || typeof record.name !== 'string' || record.name.length > 100) return null;
    return { id: record.id, createdAt: new Date(record.createdAt).toISOString(), name: cleanName(record.name), result: validateResult(record.result) };
  } catch { return null; }
}

function cloneRecords(records: RunRecord[]): RunRecord[] {
  return records.map((record) => ({ ...record, result: { ...record.result, upgrades: [...record.result.upgrades], synergies: [...record.result.synergies] } }));
}

export function getRecords(): RunRecord[] {
  const raw = readStorage(RECORDS_KEY);
  if (raw !== undefined) {
    try {
      if (raw && raw.length > 500_000) throw new Error('Storage exceeds record limit');
      const values: unknown = raw ? JSON.parse(raw) : [];
      memoryRecords = Array.isArray(values) ? values.slice(0, 50).map(validateRecord).filter((record): record is RunRecord => !!record) : [];
    } catch {
      memoryRecords = [];
      writeStorage(RECORDS_KEY, '[]');
    }
  }
  return cloneRecords(memoryRecords);
}

export function saveRecord(name: string, result: GameResult): RunRecord {
  const record: RunRecord = {
    id: `run_${Date.now().toString(36)}_${(++recordSequence).toString(36)}_${randomSeed().toString(36)}`,
    createdAt: new Date().toISOString(), name: cleanName(name), result: validateResult(result),
  };
  memoryRecords = [record, ...getRecords()].slice(0, 50);
  writeStorage(RECORDS_KEY, JSON.stringify(memoryRecords));
  return { ...record, result: { ...record.result, upgrades: [...record.result.upgrades], synergies: [...record.result.synergies] } };
}

export function clearRecords(): void {
  memoryRecords = [];
  writeStorage(RECORDS_KEY, '[]');
}
