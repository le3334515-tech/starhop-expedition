import { afterEach, describe, expect, it, vi } from 'vitest';
import { clampPosition, parseTouchSettings, TouchLayout } from './touch-layout';

afterEach(() => { vi.unstubAllGlobals(); });

describe('touch layout parsing and safe positions', () => {
  it('uses independent complete defaults for invalid, missing and unknown versions', () => {
    for (const value of [null, undefined, [], 'bad', {}, { v: 2 }, { v: 1, scale: NaN, opacity: Infinity }]) {
      expect(parseTouchSettings(value)).toEqual({ v: 1, scale: 1, opacity: 0.65, positions: { landscape: {}, portrait: {} } });
    }
    const first = parseTouchSettings(null); first.positions.landscape.jump = { x: 10, y: 20 };
    expect(parseTouchSettings(null).positions.landscape).toEqual({});
  });
  it('bounds scale, opacity and percent positions without accepting non-finite or unknown actions', () => {
    expect(parseTouchSettings({ v: 1, scale: 100, opacity: -2, positions: {
      landscape: { left: { x: -20, y: 400 }, jump: { x: Infinity, y: 10 }, custom: { x: 20, y: 30 }, attack: { x: '30', y: 20 } },
      portrait: { right: { x: 80, y: 90 } },
    } })).toEqual({ v: 1, scale: 1.4, opacity: 0.25, positions: { landscape: { left: { x: 0, y: 100 } }, portrait: { right: { x: 80, y: 90 } } } });
  });
  it('does not retain incoming nested references or prototype keys', () => {
    const incoming = JSON.parse('{"v":1,"positions":{"landscape":{"left":{"x":12,"y":85},"__proto__":{"polluted":true}},"portrait":{"left":{"x":22,"y":75}}}}');
    const settings = parseTouchSettings(incoming);
    settings.positions.landscape.left.x = 99;
    expect(incoming.positions.landscape.left.x).toBe(12);
    expect(settings.positions.portrait.left.x).toBe(22);
    expect(({} as Record<string, unknown>).polluted).toBeUndefined();
  });
  it('keeps the whole button on screen with a margin, even in a tiny viewport', () => {
    expect(clampPosition({ x: -20, y: 200 }, 1000, 500, 80, 60, 10)).toEqual({ x: 5, y: 92 });
    expect(clampPosition({ x: 50, y: 50 }, 20, 20, 80, 60)).toEqual({ x: 50, y: 50 });
    expect(clampPosition({ x: NaN, y: Infinity }, 0, -1)).toEqual({ x: 50, y: 50 });
    expect(clampPosition({ x: 90, y: 90 }, 1000, 500, 80, 60, 10)).toEqual({ x: 90, y: 90 });
  });
});

class FakeStyle {
  private properties = new Map<string, string>();
  position = ''; left = ''; top = ''; right = ''; bottom = ''; transform = ''; width = ''; height = ''; margin = '';
  setProperty(key: string, value: string) { this.properties.set(key, value); }
  getPropertyValue(key: string) { return this.properties.get(key) || ''; }
}
class FakeClasses {
  private values = new Set<string>();
  add(value: string) { this.values.add(value); }
  remove(value: string) { this.values.delete(value); }
  contains(value: string) { return this.values.has(value); }
}
class FakeElement extends EventTarget {
  style = new FakeStyle();
  classList = new FakeClasses();
  dataset: Record<string, string> = {};
  buttons: FakeElement[] = [];
  rect = { left: 0, top: 0, width: 1000, height: 500 };
  captures = new Set<number>();
  getBoundingClientRect() { return { ...this.rect, right: this.rect.left + this.rect.width, bottom: this.rect.top + this.rect.height }; }
  querySelectorAll() { return this.buttons; }
  contains(button: FakeElement) { return this.buttons.includes(button); }
  closest() { return this.dataset.touch ? this : null; }
  setPointerCapture(id: number) { this.captures.add(id); }
  hasPointerCapture(id: number) { return this.captures.has(id); }
  releasePointerCapture(id: number) { this.captures.delete(id); }
}
function fixture(stored?: unknown, throws = false) {
  const windowMock = Object.assign(new EventTarget(), { innerWidth: 1000, innerHeight: 500 });
  const documentMock = new EventTarget();
  const values = new Map<string, string>();
  if (stored !== undefined) values.set('starhop.touch.v1', typeof stored === 'string' ? stored : JSON.stringify(stored));
  const storage = {
    getItem: (key: string) => { if (throws) throw new Error('Denied'); return values.get(key) ?? null; },
    setItem: (key: string, value: string) => { if (throws) throw new Error('QuotaExceededError'); values.set(key, value); },
  };
  vi.stubGlobal('window', windowMock); vi.stubGlobal('document', documentMock); vi.stubGlobal('localStorage', storage);
  vi.stubGlobal('getComputedStyle', () => ({ width: '56px', height: '56px' }));
  const stage = new FakeElement(); const controls = new FakeElement();
  const left = new FakeElement(); left.dataset.touch = 'left'; left.rect = { left: 40, top: 400, width: 56, height: 56 };
  const jump = new FakeElement(); jump.dataset.touch = 'jump'; jump.rect = { left: 850, top: 390, width: 70, height: 70 };
  controls.buttons = [left, jump];
  const layout = new TouchLayout(stage as unknown as HTMLElement, controls as unknown as HTMLElement);
  const pointer = (type: string, target: FakeElement, x: number, y: number, id = 1) => {
    const event = new Event(type, { cancelable: true });
    Object.defineProperties(event, { target: { value: target }, clientX: { value: x }, clientY: { value: y }, pointerId: { value: id } });
    stage.dispatchEvent(event); return event;
  };
  return { stage, controls, left, jump, layout, windowMock, storage, pointer, values };
}

describe('touch layout lifecycle without a DOM dependency', () => {
  it('survives damaged/unavailable storage, clamps settings and restores default CSS on reset', () => {
    const { layout, controls, stage, left } = fixture('{broken', true);
    expect(layout.settings).toEqual({ scale: 1, opacity: 0.65, positions: {} });
    layout.setScale(2); layout.setOpacity(0);
    expect(layout.settings.scale).toBe(1.4); expect(layout.settings.opacity).toBe(0.25);
    expect(controls.style.getPropertyValue('--touch-scale')).toBe('1.4');
    expect(stage.style.getPropertyValue('--touch-opacity')).toBe('0.25');
    layout.beginEdit(); expect(layout.editing).toBe(true);
    layout.reset(); expect(layout.settings).toEqual({ scale: 1, opacity: 0.65, positions: {} });
    expect(left.style.position).toBe('');
    layout.endEdit(); expect(layout.editing).toBe(false); layout.dispose();
  });
  it('loads independent orientations, keeps percent placement after resizing, and returns copies', () => {
    const { layout, left, windowMock, stage } = fixture({ v: 1, scale: 1.2, opacity: 0.8, positions: { landscape: { left: { x: 15, y: 85 } }, portrait: { left: { x: 25, y: 75 } } } });
    expect(left.style.left).toBe('15%');
    const settings = layout.settings; settings.positions.left.x = 90;
    expect(layout.settings.positions.left.x).toBe(15);
    stage.rect.width = 1400; windowMock.dispatchEvent(new Event('resize'));
    expect(left.style.left).toBe('15%');
    windowMock.innerWidth = 500; windowMock.innerHeight = 1000; windowMock.dispatchEvent(new Event('orientationchange'));
    expect(layout.settings.positions.left.x).toBe(25); expect(left.style.left).toBe('25%');
    windowMock.innerWidth = 1000; windowMock.innerHeight = 500; windowMock.dispatchEvent(new Event('resize'));
    expect(layout.settings.positions.left.x).toBe(15); expect(left.style.left).toBe('15%');
    layout.dispose();
  });
  it('intercepts edit gestures, overrides only dragged buttons, clamps offscreen drags and persists', () => {
    const { layout, left, jump, pointer, values } = fixture();
    const inactive = pointer('pointerdown', left, 68, 428);
    expect(inactive.defaultPrevented).toBe(false);
    layout.beginEdit();
    const down = pointer('pointerdown', left, 68, 428);
    expect(down.defaultPrevented).toBe(true); expect(left.captures.has(1)).toBe(true);
    pointer('pointermove', left, 300, 300);
    expect(layout.settings.positions.left).toEqual({ x: 30, y: 60 });
    expect(jump.style.position).toBe(''); expect(left.style.transform).toBe('translate(-50%, -50%)');
    pointer('pointermove', left, -200, 3000);
    expect(layout.settings.positions.left).toEqual({ x: 4, y: 92 });
    pointer('pointerup', left, -200, 3000);
    expect(left.captures.has(1)).toBe(false);
    expect(JSON.parse(values.get('starhop.touch.v1')!).positions.landscape.left).toEqual({ x: 4, y: 92 });
    layout.endEdit(); layout.reset(); expect(left.style.position).toBe(''); expect(left.style.width).toBe('');
    layout.dispose();
  });
  it('keeps landscape and portrait drags separate and releases capture/listeners on dispose', () => {
    const { layout, left, pointer, windowMock } = fixture();
    layout.beginEdit(); pointer('pointerdown', left, 68, 428); pointer('pointermove', left, 200, 350); pointer('pointerup', left, 200, 350);
    expect(layout.settings.positions.left).toEqual({ x: 20, y: 70 });
    windowMock.innerWidth = 500; windowMock.innerHeight = 1000; windowMock.dispatchEvent(new Event('orientationchange'));
    expect(layout.settings.positions).toEqual({});
    pointer('pointerdown', left, 68, 428); pointer('pointermove', left, 600, 250);
    expect(layout.settings.positions.left).toEqual({ x: 60, y: 50 });
    expect(left.captures.has(1)).toBe(true);
    layout.dispose(); expect(left.captures.has(1)).toBe(false); expect(layout.editing).toBe(false);
    expect(left.style.position).toBe('');
    expect(pointer('pointerdown', left, 68, 428).defaultPrevented).toBe(false);
  });
  it('uses declared button base sizes when scaling custom positions and clamping', () => {
    const { layout, left, pointer } = fixture();
    left.dataset.baseSize = '80';
    layout.setScale(1.4); layout.beginEdit();
    pointer('pointerdown', left, 68, 428); pointer('pointermove', left, -100, 1000);
    expect(left.style.width).toBe('112px'); expect(left.style.height).toBe('112px');
    expect(layout.settings.positions.left).toEqual({ x: 6.800000000000001, y: 86.4 });
    layout.dispose();
  });
  it('uses landscape settings in a rotated portrait window and restores portrait settings when rotation ends', () => {
    const { layout, left, windowMock, stage, pointer } = fixture({ v: 1, positions: {
      landscape: { left: { x: 15, y: 85 } }, portrait: { left: { x: 25, y: 75 } },
    } });
    windowMock.innerWidth = 500; windowMock.innerHeight = 1000;
    stage.rect = { left: 0, top: 0, width: 500, height: 1000 };
    windowMock.dispatchEvent(new Event('resize'));
    expect(left.style.left).toBe('25%');
    layout.setLandscapeRotation(true);
    expect(layout.settings.positions.left).toEqual({ x: 15, y: 85 });
    expect(left.style.left).toBe('15%'); expect(left.style.top).toBe('85%');
    layout.beginEdit(); pointer('pointerdown', left, 68, 428);
    expect(left.captures.has(1)).toBe(true);
    layout.setLandscapeRotation(false);
    expect(left.captures.has(1)).toBe(false);
    expect(layout.settings.positions.left).toEqual({ x: 25, y: 75 });
    expect(left.style.left).toBe('25%'); expect(left.style.top).toBe('75%');
    layout.dispose();
  });
  it('maps rotated screen drags to local coordinates, preserves the grab offset and persists clamped landscape positions', () => {
    const { layout, left, stage, windowMock, pointer, values } = fixture({ v: 1, positions: {
      landscape: {}, portrait: { left: { x: 25, y: 75 } },
    } });
    windowMock.innerWidth = 500; windowMock.innerHeight = 1000;
    stage.rect = { left: 20, top: 30, width: 500, height: 1000 };
    left.rect = { left: 100, top: 200, width: 56, height: 56 };
    layout.setLandscapeRotation(true); layout.beginEdit();
    // Grab 7px right and 5px above the screen-space center, then move the
    // local button center to (400, 300) inside the rotated 1000 x 500 stage.
    pointer('pointerdown', left, 135, 223);
    pointer('pointermove', left, 227, 425);
    expect(layout.settings.positions.left).toEqual({ x: 40, y: 60 });
    expect(left.style.left).toBe('40%'); expect(left.style.top).toBe('60%');
    pointer('pointermove', left, -2000, -1000);
    expect(layout.settings.positions.left).toEqual({ x: 4, y: 92 });
    expect(left.style.left).toBe('4%'); expect(left.style.top).toBe('92%');
    pointer('pointerup', left, -2000, -1000);
    const persisted = JSON.parse(values.get('starhop.touch.v1')!);
    expect(persisted.positions.landscape.left).toEqual({ x: 4, y: 92 });
    expect(persisted.positions.portrait.left).toEqual({ x: 25, y: 75 });
    layout.setLandscapeRotation(false);
    expect(layout.settings.positions.left).toEqual({ x: 25, y: 75 });
    layout.dispose();
  });
});
