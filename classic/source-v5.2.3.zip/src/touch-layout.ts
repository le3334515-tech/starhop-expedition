export interface TouchPosition { x: number; y: number }
export type TouchOrientation = 'landscape' | 'portrait';
export interface TouchSettings { scale: number; opacity: number; positions: Record<string, TouchPosition> }
export interface StoredTouchSettings {
  v: 1;
  scale: number;
  opacity: number;
  positions: Record<TouchOrientation, Record<string, TouchPosition>>;
}

const STORAGE_KEY = 'starhop.touch.v1';
const ACTIONS = ['left', 'right', 'move', 'jump', 'attack', 'dash', 'guard', 'interact', 'overdrive'] as const;
const POSITION_PROPERTIES = ['position', 'left', 'top', 'right', 'bottom', 'transform', 'width', 'height', 'margin'] as const;
const finite = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value);
const bounded = (value: unknown, min: number, max: number, fallback: number) => finite(value) ? Math.min(max, Math.max(min, value)) : fallback;
const plainObject = (value: unknown): Record<string, unknown> | null => value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;
const defaultSettings = (): StoredTouchSettings => ({ v: 1, scale: 1, opacity: 0.65, positions: { landscape: {}, portrait: {} } });
const copyPositions = (positions: Record<string, TouchPosition>) => Object.fromEntries(Object.entries(positions).map(([action, position]) => [action, { ...position }]));

/** Accept only known buttons, finite coordinates and the current storage version. */
export function parseTouchSettings(value: unknown): StoredTouchSettings {
  const parsed = plainObject(value);
  if (!parsed || parsed.v !== 1) return defaultSettings();
  const positions = plainObject(parsed.positions);
  const readPositions = (orientation: TouchOrientation): Record<string, TouchPosition> => {
    const source = plainObject(positions?.[orientation]);
    const result: Record<string, TouchPosition> = {};
    for (const action of ACTIONS) {
      const point = plainObject(source?.[action]);
      if (point && finite(point.x) && finite(point.y)) result[action] = { x: bounded(point.x, 0, 100, 50), y: bounded(point.y, 0, 100, 50) };
    }
    return result;
  };
  return {
    v: 1, scale: bounded(parsed.scale, 0.75, 1.4, 1), opacity: bounded(parsed.opacity, 0.25, 0.95, 0.65),
    positions: { landscape: readPositions('landscape'), portrait: readPositions('portrait') },
  };
}

/** Percent coordinates, constrained so the whole button stays within a pixel safety margin. */
export function clampPosition(position: TouchPosition, stageWidth: number, stageHeight: number, buttonWidth = 56, buttonHeight = buttonWidth, margin = 12): TouchPosition {
  const width = finite(stageWidth) && stageWidth > 0 ? stageWidth : 1;
  const height = finite(stageHeight) && stageHeight > 0 ? stageHeight : 1;
  const safeMargin = bounded(margin, 0, 1000, 12);
  const minX = Math.min(50, (Math.max(0, finite(buttonWidth) ? buttonWidth : 56) / 2 + safeMargin) / width * 100);
  const minY = Math.min(50, (Math.max(0, finite(buttonHeight) ? buttonHeight : 56) / 2 + safeMargin) / height * 100);
  return { x: bounded(position.x, minX, 100 - minX, 50), y: bounded(position.y, minY, 100 - minY, 50) };
}

export interface TouchLayoutRect { x: number; y: number; w: number; h: number }
export interface TouchLayoutItem extends TouchLayoutRect { action: string; custom?: boolean }

/** Keep valid custom positions, then find the nearest free rectangle for a
 * collision. Obstacle edges form enough candidates without scanning every pixel. */
export function separateTouchTargets(items: TouchLayoutItem[], reserved: TouchLayoutRect[], width: number, height: number, gap = 8): Record<string, TouchPosition> {
  const placed = [...reserved];
  const result: Record<string, TouchPosition> = {};
  const order = [...items].sort((a, b) => Number(!!b.custom) - Number(!!a.custom));
  for (const item of order) {
    const minX = item.w / 2 + gap, maxX = width - minX;
    const minY = item.h / 2 + gap, maxY = height - minY;
    const x = bounded(item.x + item.w / 2, minX, maxX, width / 2);
    const y = bounded(item.y + item.h / 2, minY, maxY, height / 2);
    const free = (point: TouchPosition) => !placed.some(rect => point.x + item.w / 2 + gap > rect.x && point.x - item.w / 2 - gap < rect.x + rect.w && point.y + item.h / 2 + gap > rect.y && point.y - item.h / 2 - gap < rect.y + rect.h);
    let point = { x, y };
    if (!free(point)) {
      const xs = [x, minX, maxX], ys = [y, minY, maxY];
      for (const rect of placed) {
        xs.push(rect.x - item.w / 2 - gap, rect.x + rect.w + item.w / 2 + gap);
        ys.push(rect.y - item.h / 2 - gap, rect.y + rect.h + item.h / 2 + gap);
      }
      const candidates = xs.flatMap(nextX => ys.map(nextY => ({ x: nextX, y: nextY })))
        .filter(candidate => candidate.x >= minX && candidate.x <= maxX && candidate.y >= minY && candidate.y <= maxY)
        .sort((a, b) => (a.x - x) ** 2 + (a.y - y) ** 2 - (b.x - x) ** 2 - (b.y - y) ** 2);
      point = candidates.find(free) ?? point;
    }
    result[item.action] = point;
    placed.push({ x: point.x - item.w / 2, y: point.y - item.h / 2, w: item.w, h: item.h });
  }
  return result;
}

interface ButtonInfo {
  button: HTMLButtonElement;
  original: Record<(typeof POSITION_PROPERTIES)[number], string>;
}
interface Drag { pointerId: number; info: ButtonInfo; action: string; offsetX: number; offsetY: number }

/** The controls element must cover the stage; its default groups remain positioned by CSS. */
export class TouchLayout {
  private stored: StoredTouchSettings = defaultSettings();
  private buttons = new Map<string, ButtonInfo>();
  private drags = new Map<number, Drag>();
  private orientation: TouchOrientation;
  private landscapeRotation = false;
  private _editing = false;
  private disposed = false;
  private resizeObserver: ResizeObserver | null = null;
  private originalProperties: { stageScale: string; stageOpacity: string; controlsScale: string; controlsOpacity: string };

  constructor(private stage: HTMLElement, private controls: HTMLElement) {
    try { this.stored = parseTouchSettings(JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null')); } catch { /* Keep defaults when storage is unavailable or damaged. */ }
    this.orientation = this.getOrientation();
    this.originalProperties = {
      stageScale: stage.style.getPropertyValue('--touch-scale'), stageOpacity: stage.style.getPropertyValue('--touch-opacity'),
      controlsScale: controls.style.getPropertyValue('--touch-scale'), controlsOpacity: controls.style.getPropertyValue('--touch-opacity'),
    };
    controls.querySelectorAll<HTMLButtonElement>('[data-touch]').forEach(button => {
      const action = button.dataset.touch;
      if (!action || !(ACTIONS as readonly string[]).includes(action)) return;
      this.buttons.set(action, { button, original: Object.fromEntries(POSITION_PROPERTIES.map(property => [property, button.style[property]])) as ButtonInfo['original'] });
    });
    // Capture before GameInput's button listeners, including when they were registered first.
    this.stage.addEventListener('pointerdown', this.onPointerDown, true);
    this.stage.addEventListener('pointermove', this.onPointerMove, true);
    this.stage.addEventListener('pointerup', this.onPointerUp, true);
    this.stage.addEventListener('pointercancel', this.onPointerCancel, true);
    this.stage.addEventListener('lostpointercapture', this.onPointerCancel, true);
    this.stage.addEventListener('click', this.onClick, true);
    window.addEventListener('resize', this.onResize);
    window.addEventListener('orientationchange', this.onResize);
    document.addEventListener('fullscreenchange', this.onResize);
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(this.onResize);
      this.resizeObserver.observe(stage);
      stage.querySelectorAll<HTMLElement>('.weapon-hud,#buff-seal-hud,.hero-hud,.objective-hud,.boss-hud,.resonance-hud,.build-hud,.control-settings-button').forEach(element => this.resizeObserver!.observe(element));
    }
    this.apply();
  }

  get editing(): boolean { return this._editing; }
  get settings(): TouchSettings {
    return { scale: this.stored.scale, opacity: this.stored.opacity, positions: copyPositions(this.stored.positions[this.getOrientation()]) };
  }

  setScale(value: number): void {
    if (this.disposed) return;
    this.stored.scale = bounded(value, 0.75, 1.4, this.stored.scale);
    this.apply(); this.persist();
  }

  setOpacity(value: number): void {
    if (this.disposed) return;
    this.stored.opacity = bounded(value, 0.25, 0.95, this.stored.opacity);
    this.apply(); this.persist();
  }

  /** Match a stage displayed with a clockwise 90 degree CSS rotation. */
  setLandscapeRotation(enabled: boolean): void {
    if (this.disposed || this.landscapeRotation === enabled) return;
    this.cancelDrags();
    this.landscapeRotation = enabled;
    this.apply();
  }

  beginEdit(): void {
    if (this.disposed) return;
    this._editing = true;
    this.stage.classList.add('touch-editing');
    this.controls.classList.add('touch-editing');
    this.controls.dataset.editing = 'true';
    this.apply();
  }

  endEdit(): void {
    if (this.disposed) return;
    this.cancelDrags();
    this._editing = false;
    this.stage.classList.remove('touch-editing');
    this.controls.classList.remove('touch-editing');
    delete this.controls.dataset.editing;
    this.persist();
  }

  reset(): void {
    if (this.disposed) return;
    this.cancelDrags();
    this.stored = defaultSettings();
    this.apply(); this.persist();
  }

  dispose(): void {
    if (this.disposed) return;
    this.endEdit();
    this.disposed = true;
    this.stage.removeEventListener('pointerdown', this.onPointerDown, true);
    this.stage.removeEventListener('pointermove', this.onPointerMove, true);
    this.stage.removeEventListener('pointerup', this.onPointerUp, true);
    this.stage.removeEventListener('pointercancel', this.onPointerCancel, true);
    this.stage.removeEventListener('lostpointercapture', this.onPointerCancel, true);
    this.stage.removeEventListener('click', this.onClick, true);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('orientationchange', this.onResize);
    document.removeEventListener('fullscreenchange', this.onResize);
    this.resizeObserver?.disconnect();
    for (const info of this.buttons.values()) this.restore(info);
    this.stage.style.setProperty('--touch-scale', this.originalProperties.stageScale);
    this.stage.style.setProperty('--touch-opacity', this.originalProperties.stageOpacity);
    this.controls.style.setProperty('--touch-scale', this.originalProperties.controlsScale);
    this.controls.style.setProperty('--touch-opacity', this.originalProperties.controlsOpacity);
  }

  private getOrientation(): TouchOrientation {
    if (this.landscapeRotation) return 'landscape';
    if (window.innerWidth > 0 && window.innerHeight > 0) return window.innerWidth >= window.innerHeight ? 'landscape' : 'portrait';
    const rect = this.stage.getBoundingClientRect();
    return rect.width >= rect.height ? 'landscape' : 'portrait';
  }

  private localSize(rect: DOMRect): { width: number; height: number } {
    return this.landscapeRotation ? { width: rect.height, height: rect.width } : { width: rect.width, height: rect.height };
  }

  private localPoint(clientX: number, clientY: number, rect: DOMRect): TouchPosition {
    return this.landscapeRotation
      ? { x: clientY - rect.top, y: rect.right - clientX }
      : { x: clientX - rect.left, y: clientY - rect.top };
  }

  private persist(): void {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(this.stored)); } catch { /* The current session keeps its settings even if storage is full or disabled. */ }
  }

  private restore(info: ButtonInfo): void {
    for (const property of POSITION_PROPERTIES) info.button.style[property] = info.original[property];
    delete info.button.dataset.customPosition;
    delete info.button.dataset.layoutAdjusted;
    info.button.classList.remove('touch-dragging');
  }

  private size(info: ButtonInfo): { width: number; height: number } {
    const button = info.button;
    const baseSize = Number(button.dataset.baseSize);
    if (Number.isFinite(baseSize) && baseSize > 0 && baseSize <= 240) {
      return { width: baseSize * this.stored.scale, height: baseSize * this.stored.scale };
    }
    // Remove only size overrides to read the current responsive CSS base size.
    button.style.width = info.original.width;
    button.style.height = info.original.height;
    const computed = getComputedStyle(button);
    const rect = button.getBoundingClientRect();
    const local = this.localSize(rect);
    const width = parseFloat(computed.width) || local.width || 56 * this.stored.scale;
    const height = parseFloat(computed.height) || local.height || width;
    return { width, height };
  }

  private apply(): void {
    if (this.disposed) return;
    const currentOrientation = this.getOrientation();
    if (this.orientation !== currentOrientation) { this.cancelDrags(); this.orientation = currentOrientation; }
    const { scale, opacity } = this.stored;
    this.stage.style.setProperty('--touch-scale', String(scale));
    this.stage.style.setProperty('--touch-opacity', String(opacity));
    this.controls.style.setProperty('--touch-scale', String(scale));
    this.controls.style.setProperty('--touch-opacity', String(opacity));
    const rect = this.stage.getBoundingClientRect();
    const local = this.localSize(rect);
    const positions = this.stored.positions[this.orientation];
    for (const [action, info] of this.buttons) {
      const point = positions[action];
      if (!point) { this.restore(info); continue; }
      const dimensions = this.size(info);
      const safe = local.width > 0 && local.height > 0 ? clampPosition(point, local.width, local.height, dimensions.width, dimensions.height) : point;
      Object.assign(info.button.style, {
        position: 'absolute', left: `${safe.x}%`, top: `${safe.y}%`, right: 'auto', bottom: 'auto',
        transform: 'translate(-50%, -50%)', width: `${dimensions.width}px`, height: `${dimensions.height}px`, margin: '0',
      });
      info.button.dataset.customPosition = 'true';
    }
    this.separateMobileTargets(local.width, local.height, rect);
  }

  private separateMobileTargets(width: number, height: number, stageRect: DOMRect): void {
    if (!document.body?.classList.contains('mobile-playing') || width <= 0 || height <= 0) return;
    const visible = (element: HTMLElement) => element.getBoundingClientRect().width > 0 && element.getBoundingClientRect().height > 0 && getComputedStyle(element).display !== 'none' && !element.closest('[hidden]');
    const localRect = (element: HTMLElement): TouchLayoutRect => {
      const rect = element.getBoundingClientRect();
      const center = this.localPoint(rect.left + rect.width / 2, rect.top + rect.height / 2, stageRect);
      const size = this.localSize(rect);
      return { x: center.x - size.width / 2, y: center.y - size.height / 2, w: size.width, h: size.height };
    };
    const positions = this.stored.positions[this.orientation];
    const items = [...this.buttons].filter(([, info]) => visible(info.button)).map(([action, info]) => ({ action, custom: !!positions[action], ...localRect(info.button) }));
    const reserved = [...this.stage.querySelectorAll<HTMLElement>('.hud-weapon,.hud-pause,.control-settings-button,.build-hud,.hero-hud,.objective-hud,.boss-hud,#buff-seal-hud,.resonance-hud')].filter(visible).map(localRect);
    const separated = separateTouchTargets(items, reserved, width, height);
    let repairedCustom = false;
    for (const item of items) {
      const point = separated[item.action];
      if (Math.abs(point.x - item.x - item.w / 2) < .5 && Math.abs(point.y - item.y - item.h / 2) < .5) continue;
      const info = this.buttons.get(item.action)!;
      Object.assign(info.button.style, { position: 'absolute', left: `${point.x / width * 100}%`, top: `${point.y / height * 100}%`, right: 'auto', bottom: 'auto', transform: 'translate(-50%, -50%)', margin: '0' });
      info.button.dataset.layoutAdjusted = 'true';
      if (positions[item.action]) {
        positions[item.action] = { x: point.x / width * 100, y: point.y / height * 100 };
        repairedCustom = true;
      }
    }
    if (repairedCustom) this.persist();
  }

  private findInfo(event: Event): { action: string; info: ButtonInfo } | null {
    const target = event.target;
    if (!target || typeof (target as Element).closest !== 'function') return null;
    const button = (target as Element).closest<HTMLButtonElement>('[data-touch]');
    if (!button || !this.controls.contains(button)) return null;
    const action = button.dataset.touch!;
    const info = this.buttons.get(action);
    return info?.button === button ? { action, info } : null;
  }

  private onPointerDown = (event: PointerEvent): void => {
    if (!this._editing || this.disposed) return;
    const found = this.findInfo(event);
    if (!found) return;
    event.preventDefault(); event.stopImmediatePropagation();
    const rect = found.info.button.getBoundingClientRect();
    const stageRect = this.stage.getBoundingClientRect();
    const point = this.localPoint(event.clientX, event.clientY, stageRect);
    const center = this.localPoint(rect.left + rect.width / 2, rect.top + rect.height / 2, stageRect);
    this.drags.set(event.pointerId, {
      pointerId: event.pointerId, ...found,
      offsetX: point.x - center.x, offsetY: point.y - center.y,
    });
    found.info.button.classList.add('touch-dragging');
    try { found.info.button.setPointerCapture(event.pointerId); } catch { /* Capture can be unavailable in older browsers. */ }
  };

  private onPointerMove = (event: PointerEvent): void => {
    const drag = this.drags.get(event.pointerId);
    if (!this._editing || !drag || this.disposed) return;
    event.preventDefault(); event.stopImmediatePropagation();
    const rect = this.stage.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    const local = this.localSize(rect);
    const point = this.localPoint(event.clientX, event.clientY, rect);
    const dimensions = this.size(drag.info);
    this.stored.positions[this.orientation][drag.action] = clampPosition({
      x: (point.x - drag.offsetX) / local.width * 100,
      y: (point.y - drag.offsetY) / local.height * 100,
    }, local.width, local.height, dimensions.width, dimensions.height);
    this.apply();
  };

  private onPointerUp = (event: PointerEvent): void => {
    if (!this.drags.has(event.pointerId)) return;
    event.preventDefault(); event.stopImmediatePropagation();
    this.finishDrag(event.pointerId); this.persist();
  };

  private onPointerCancel = (event: PointerEvent): void => {
    if (!this.drags.has(event.pointerId)) return;
    this.finishDrag(event.pointerId); this.persist();
  };

  private onClick = (event: MouseEvent): void => {
    if (this._editing && this.findInfo(event)) { event.preventDefault(); event.stopImmediatePropagation(); }
  };

  private finishDrag(pointerId: number): void {
    const drag = this.drags.get(pointerId);
    if (!drag) return;
    this.drags.delete(pointerId);
    drag.info.button.classList.remove('touch-dragging');
    try { if (drag.info.button.hasPointerCapture(pointerId)) drag.info.button.releasePointerCapture(pointerId); } catch { /* Capture may already have been lost. */ }
  }

  private cancelDrags(): void { for (const pointerId of [...this.drags.keys()]) this.finishDrag(pointerId); }
  private onResize = (): void => { this.apply(); };
}
