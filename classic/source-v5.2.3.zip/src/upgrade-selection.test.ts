import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { UpgradeSelectionGate, UPGRADE_REVEAL_MS } from './upgrade-selection';

class Surface {
  listeners = new Map<string, Set<(event: any) => void>>();
  addEventListener(type: string, listener: (event: any) => void) {
    if (!this.listeners.has(type)) this.listeners.set(type, new Set());
    this.listeners.get(type)!.add(listener);
  }
  removeEventListener(type: string, listener: (event: any) => void) { this.listeners.get(type)?.delete(listener); }
  emit(type: string, event: any) { for (const listener of [...(this.listeners.get(type) ?? [])]) listener(event); }
}
class ElementFixture extends Surface {
  dataset: Record<string, string> = {};
  attributes = new Map<string, string>();
  blur = vi.fn();
  setAttribute(name: string, value: string) { this.attributes.set(name, value); }
  removeAttribute(name: string) { this.attributes.delete(name); }
  closest() { return this; }
}
class ButtonFixture extends ElementFixture { disabled = false; tabIndex = 0; }
class ContainerFixture extends ElementFixture {
  buttons = ['edge', 'tempo', 'vigor'].map(id => { const button = new ButtonFixture(); button.dataset.upgrade = id; return button; });
  querySelectorAll() { return this.buttons; }
  contains(button: ElementFixture) { return this.buttons.includes(button as ButtonFixture); }
}
function setup() {
  const container = new ContainerFixture(), windowSurface = new Surface(), active = new ElementFixture();
  vi.stubGlobal('window', windowSurface); vi.stubGlobal('document', { activeElement: active });
  vi.stubGlobal('Element', ElementFixture); vi.stubGlobal('HTMLElement', ElementFixture);
  vi.stubGlobal('performance', { now: () => Date.now() });
  const gate = new UpgradeSelectionGate(), choose = vi.fn();
  gate.open(container as unknown as HTMLElement, choose);
  const event = (target = container.buttons[0], overrides = {}) => ({ target, button: 0, detail: 1, pointerId: 7, isPrimary: true, isTrusted: true, preventDefault: vi.fn(), stopImmediatePropagation: vi.fn(), ...overrides });
  const send = (type: string, overrides = {}, target = container.buttons[0]) => { const e = event(target, overrides); container.emit(type, e); return e; };
  const click = (target = container.buttons[0]) => { send('pointerdown', {}, target); send('pointerup', {}, target); send('click', {}, target); };
  return { container, windowSurface, active, gate, choose, event, send, click };
}
beforeEach(() => vi.useFakeTimers());
afterEach(() => { vi.useRealTimers(); vi.unstubAllGlobals(); });

describe('upgrade selection requires the reveal and a new deliberate pointer gesture', () => {
  it('keeps all cards disabled during the reveal and enables them without moving keyboard focus', () => {
    const f = setup();
    expect(f.container.dataset.upgradeState).toBe('opening');
    expect(f.container.buttons.every(button => button.disabled && button.tabIndex === -1)).toBe(true);
    expect(f.active.blur).toHaveBeenCalledOnce();
    vi.advanceTimersByTime(UPGRADE_REVEAL_MS - 1); expect(f.container.buttons.every(button => button.disabled)).toBe(true);
    vi.advanceTimersByTime(1); expect(f.container.dataset.upgradeState).toBe('ready');
    expect(f.container.buttons.every(button => !button.disabled && button.tabIndex === -1)).toBe(true);
  });
  it('never lets a press started during the reveal carry through when the cards unlock', () => {
    const f = setup(); f.send('pointerdown'); vi.advanceTimersByTime(UPGRADE_REVEAL_MS);
    f.send('pointerup'); f.send('click'); expect(f.choose).not.toHaveBeenCalled();
    f.click(); expect(f.choose).toHaveBeenCalledExactlyOnceWith('edge');
  });
  it('rejects keyboard/programmatic clicks even after opening and even after an old pointer gesture', () => {
    const f = setup(); vi.advanceTimersByTime(UPGRADE_REVEAL_MS);
    f.send('click', { detail: 0 }); f.send('click', { isTrusted: false });
    f.send('pointerdown'); f.send('pointerup'); f.send('click', { detail: 0 });
    expect(f.choose).not.toHaveBeenCalled();
    f.click(); expect(f.choose).toHaveBeenCalledExactlyOnceWith('edge');
  });
  it('blocks every keyboard activation path and clears any partial pointer intent', () => {
    const f = setup(); vi.advanceTimersByTime(UPGRADE_REVEAL_MS);
    for (const code of ['Space', 'Enter', 'Digit1', 'Digit2', 'Digit3', 'Tab', 'Escape', 'KeyJ']) {
      for (const type of ['keydown', 'keyup']) {
        f.send('pointerdown'); f.send('pointerup');
        const event = f.event(undefined, { code }); f.windowSurface.emit(type, event);
        expect(event.preventDefault).toHaveBeenCalledOnce(); expect(event.stopImmediatePropagation).toHaveBeenCalledOnce();
        f.send('click'); expect(f.choose).not.toHaveBeenCalled();
      }
    }
  });
  it('requires a matching card, primary left pointer and a completed uncancelled gesture', () => {
    const f = setup(); vi.advanceTimersByTime(UPGRADE_REVEAL_MS);
    f.send('pointerup'); f.send('click');
    f.send('pointerdown', { button: 2 }); f.send('pointerup'); f.send('click');
    f.send('pointerdown', { isPrimary: false }); f.send('pointerup'); f.send('click');
    f.send('pointerdown'); f.send('pointerup', { pointerId: 8 }); f.send('click');
    f.send('pointerdown'); f.send('pointerup', {}, f.container.buttons[1]); f.send('click');
    f.send('pointerdown'); f.send('pointercancel'); f.send('pointerup'); f.send('click');
    expect(f.choose).not.toHaveBeenCalled();
    f.click(f.container.buttons[1]); expect(f.choose).toHaveBeenCalledExactlyOnceWith('tempo');
  });
  it('consumes one pointer click exactly once and locks old cards immediately', () => {
    const f = setup(); vi.advanceTimersByTime(UPGRADE_REVEAL_MS); f.click(); f.click();
    expect(f.choose).toHaveBeenCalledOnce(); expect(f.container.buttons.every(button => button.disabled)).toBe(true);
  });
  it('starts a chained upgrade with a fresh reveal and never unlocks it from an earlier timer', () => {
    const f = setup(); vi.advanceTimersByTime(400);
    const next = vi.fn(); f.gate.open(f.container as unknown as HTMLElement, next);
    vi.advanceTimersByTime(UPGRADE_REVEAL_MS - 400);
    expect(f.container.dataset.upgradeState).toBe('opening'); f.click(); expect(next).not.toHaveBeenCalled();
    vi.advanceTimersByTime(400); expect(f.container.dataset.upgradeState).toBe('ready');
    f.click(); expect(next).toHaveBeenCalledExactlyOnceWith('edge'); expect(f.choose).not.toHaveBeenCalled();
  });
  it('unhooks keyboard and pending timers when leaving the overlay', () => {
    const f = setup(); f.gate.close(); vi.runAllTimers();
    expect(f.container.dataset.upgradeState).toBeUndefined(); expect(f.container.buttons.every(button => button.disabled)).toBe(true);
    const event = f.event(); f.windowSurface.emit('keydown', event); expect(event.preventDefault).not.toHaveBeenCalled();
    f.click(); expect(f.choose).not.toHaveBeenCalled();
  });
});
