/** The reveal and the deliberate pointer press belong to the UI, not combat time. */
export const UPGRADE_REVEAL_MS = 640;
type PointerIntent = { button: HTMLButtonElement; id: number; releasedAt: number | null };

export class UpgradeSelectionGate {
  private container: HTMLElement | null = null;
  private onChoose: ((id: string) => void) | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private generation = 0;
  private ready = false;
  private pointer: PointerIntent | null = null;

  open(container: HTMLElement, onChoose: (id: string) => void): void {
    this.close();
    this.container = container; this.onChoose = onChoose;
    this.ready = false; this.pointer = null;
    const generation = this.generation;
    container.dataset.upgradeState = 'opening';
    container.setAttribute('aria-busy', 'true');
    for (const button of container.querySelectorAll<HTMLButtonElement>('[data-upgrade]')) {
      button.disabled = true; button.tabIndex = -1;
    }
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    container.addEventListener('pointerdown', this.onPointerDown, true);
    container.addEventListener('pointerup', this.onPointerUp, true);
    container.addEventListener('pointercancel', this.onPointerCancel, true);
    container.addEventListener('click', this.onClick, true);
    window.addEventListener('keydown', this.onKey, true);
    window.addEventListener('keyup', this.onKey, true);
    this.timer = setTimeout(() => {
      if (this.generation !== generation || this.container !== container) return;
      this.timer = null; this.ready = true;
      container.dataset.upgradeState = 'ready';
      container.setAttribute('aria-busy', 'false');
      for (const button of container.querySelectorAll<HTMLButtonElement>('[data-upgrade]')) button.disabled = false;
    }, UPGRADE_REVEAL_MS);
  }

  close(): void {
    this.generation++;
    if (this.timer !== null) clearTimeout(this.timer);
    this.timer = null; this.ready = false; this.pointer = null; this.onChoose = null;
    if (this.container) {
      this.container.removeEventListener('pointerdown', this.onPointerDown, true);
      this.container.removeEventListener('pointerup', this.onPointerUp, true);
      this.container.removeEventListener('pointercancel', this.onPointerCancel, true);
      this.container.removeEventListener('click', this.onClick, true);
      for (const button of this.container.querySelectorAll<HTMLButtonElement>('[data-upgrade]')) button.disabled = true;
      delete this.container.dataset.upgradeState;
      this.container.removeAttribute('aria-busy');
    }
    window.removeEventListener('keydown', this.onKey, true);
    window.removeEventListener('keyup', this.onKey, true);
    this.container = null;
  }

  private choice(target: EventTarget | null): HTMLButtonElement | null {
    if (!(target instanceof Element)) return null;
    const button = target.closest<HTMLButtonElement>('button[data-upgrade]');
    return button && this.container?.contains(button) ? button : null;
  }
  private onKey = (event: KeyboardEvent): void => {
    this.pointer = null;
    event.preventDefault(); event.stopImmediatePropagation();
  };
  private onPointerDown = (event: PointerEvent): void => {
    this.pointer = null;
    const button = this.choice(event.target);
    if (!this.ready || !button || button.disabled || !event.isTrusted || event.button !== 0 || event.isPrimary === false) return;
    this.pointer = { button, id: event.pointerId, releasedAt: null };
  };
  private onPointerUp = (event: PointerEvent): void => {
    if (!this.ready || !event.isTrusted || !this.pointer || this.pointer.id !== event.pointerId || this.choice(event.target) !== this.pointer.button) {
      this.pointer = null; return;
    }
    this.pointer.releasedAt = performance.now();
  };
  private onPointerCancel = (): void => { this.pointer = null; };
  private onClick = (event: MouseEvent): void => {
    const button = this.choice(event.target);
    if (!button) return;
    event.preventDefault(); event.stopImmediatePropagation();
    const pointer = this.pointer; this.pointer = null;
    if (!this.ready || button.disabled || !event.isTrusted || event.detail <= 0 || event.button !== 0 || !pointer || pointer.button !== button || pointer.releasedAt === null || performance.now() - pointer.releasedAt > 1000) return;
    const callback = this.onChoose, id = button.dataset.upgrade;
    this.close();
    if (id) callback?.(id);
  };
}
