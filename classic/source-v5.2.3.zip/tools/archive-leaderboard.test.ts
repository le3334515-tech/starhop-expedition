import { afterEach, describe, expect, it, vi } from 'vitest';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { archiveLeaderboard, collectMessages, parseCursor } from './archive-leaderboard';
import { LEADERBOARD_VERSION, makeSnapshot, parseSnapshot, recordHero, type LeaderboardRecord } from '../src/leaderboard-core';
import { LEADERBOARD_CONFIG } from '../src/leaderboard';

const temporary: string[] = [];
afterEach(async () => { await Promise.all(temporary.splice(0).map(root => rm(root, { recursive: true, force: true }))); });
async function workspace() {
  const root = await mkdtemp(path.join(tmpdir(), 'starhop-archive-'));
  temporary.push(root);
  await mkdir(path.join(root, 'leaderboard'));
  return root;
}
function record(player = 'player_0001', time = 90): LeaderboardRecord {
  return { version: LEADERBOARD_VERSION, playerId: player, runId: `run_${player}_${time}`, name: '归档验证', createdAt: '2026-11-16T10:00:00.000Z',
    result: { won: true, seed: 1, modifier: 'standard', weapon: 'blade', time, score: 1000, coins: 15, kills: 16,
      level: 3, deaths: 0, roomsCleared: 8, maxCombo: 4, upgrades: ['edge'], overdriveCount: 1, synergies: [] } };
}
function event(id: string, score: unknown, time = 1794823200) {
  return JSON.stringify({ id, time, event: 'message', message: JSON.stringify(score) });
}
const response = (body: string, status = 200, headers = {}) => new Response(body, { status, headers });

describe('permanent leaderboard archive', () => {
  it('migrates old snapshots and backfills a second hero from retained events before the existing cursor', async () => {
    const root = await workspace();
    const old = record('player_0001',80);
    const second = record('player_0001',110);
    second.result = { ...second.result,character:'spear',weapon:'halberd' };
    const pathToSnapshot = path.join(root,'leaderboard/v3.json');
    await writeFile(pathToSnapshot,JSON.stringify({
      version:LEADERBOARD_VERSION,updatedAt:old.createdAt,records:[old],legacyRecords:[],profiles:[],
    }));
    await writeFile(path.join(root,'leaderboard/cursor-v3.json'),JSON.stringify({
      version:LEADERBOARD_VERSION,lastEventId:'latest_cursor',lastEventTime:1794824200,
    }));
    const fetcher = vi.fn(async (input: string | URL | Request) =>
      response(String(input).includes(LEADERBOARD_CONFIG.topic) ? event('recover_hero',second) : ''));
    const archived = await archiveLeaderboard({root,fetch:fetcher});
    expect(archived).toMatchObject({records:1,recordsChanged:true,cursorChanged:false});
    expect(new URL(fetcher.mock.calls[0][0] as string).searchParams.get('since')).toBe('all');
    const snapshot = parseSnapshot(JSON.parse(await readFile(pathToSnapshot,'utf8')))!;
    expect(snapshot.records.map(r=>r.runId)).toEqual([old.runId]);
    expect(snapshot.heroRecords.map(r=>[recordHero(r),r.result.time])).toEqual([['traveller',80],['spear',110]]);
    expect((await archiveLeaderboard({root,fetch:fetcher})).recordsChanged).toBe(false);
  });
  it('archives the new topic under classic without rewriting the original eight-act snapshot', async () => {
    const root = await workspace();
    const original = JSON.stringify(makeSnapshot([record('old_player_0001', 70)]));
    await writeFile(path.join(root, 'leaderboard/v3.json'), original);
    const classic = path.join(root, 'classic');
    const requests: string[] = [];
    const fetcher = vi.fn(async (input: string | URL | Request) => {
      const url = String(input); requests.push(url);
      return response(url.includes(LEADERBOARD_CONFIG.topic) ? event('new_event_001', record('new_player_0001', 110)) : '');
    });
    await archiveLeaderboard({ root: classic, fetch: fetcher });
    const snapshot = JSON.parse(await readFile(path.join(classic, 'leaderboard/v3.json'), 'utf8'));
    expect(snapshot.records.map((score: LeaderboardRecord) => score.playerId)).toEqual(['new_player_0001']);
    expect(await readFile(path.join(root, 'leaderboard/v3.json'), 'utf8')).toBe(original);
    expect(requests[0]).toContain(LEADERBOARD_CONFIG.topic);
    expect(requests.some(url => url.includes(LEADERBOARD_CONFIG.historicalTopic))).toBe(false);
  });
  it('accepts only complete valid scores, but safely advances over unrelated messages', () => {
    const events = collectMessages([JSON.stringify({ event: 'open' }), event('event0001', record()), event('event0002', { ...record(), result: { ...record().result, won: false } }), event('event0003', 'hello')].join('\n'));
    expect(events).toHaveLength(3);
    expect(events.filter(e => e.record)).toHaveLength(1);
    expect(() => collectMessages('{"event":')).toThrow('Malformed');
    expect(() => collectMessages(JSON.stringify({ code: 42905, error: 'quota' }))).toThrow('Unexpected');
    expect(parseCursor({ version: 'old', lastEventId: 'event0001', lastEventTime: 1 })).toBeNull();
  });

  it('merges independent submissions with permanent scores instead of replacing them', async () => {
    const root = await workspace();
    await writeFile(path.join(root, 'leaderboard/v3.json'), JSON.stringify(makeSnapshot([record('player_0001', 100)], '2026-11-16T09:00:00.000Z')));
    const fetcher = vi.fn(async () => response([event('event0001', record('player_0002', 85)), event('event0002', record('player_0001', 90))].join('\n')));
    const result = await archiveLeaderboard({ root, fetch: fetcher, now: () => new Date('2026-11-16T11:00:00Z') });
    expect(result).toEqual({ records: 2, received: 2, recordsChanged: true, cursorChanged: true });
    const snapshot = JSON.parse(await readFile(path.join(root, 'leaderboard/v3.json'), 'utf8'));
    expect(snapshot.records.map((r: LeaderboardRecord) => r.result.time)).toEqual([85, 90]);
    expect(snapshot.updatedAt).toBe('2026-11-16T11:00:00.000Z');
    expect(new URL(fetcher.mock.calls[0][0]).searchParams.get('since')).toBe('all');
  });

  it('keeps durable scores after the live cache is empty, without timestamp-only commits', async () => {
    const root = await workspace();
    const snapshot = `${JSON.stringify(makeSnapshot([record()], '2026-11-15T00:00:00.000Z'), null, 2)}\n`;
    await writeFile(path.join(root, 'leaderboard/v3.json'), snapshot);
    await writeFile(path.join(root, 'leaderboard/cursor-v3.json'), JSON.stringify({ version: LEADERBOARD_VERSION, lastEventId: 'event0001', lastEventTime: 1794823200 }));
    const fetcher = vi.fn(async (_input: string | URL | Request) => response(''));
    const result = await archiveLeaderboard({ root, fetch: fetcher });
    expect(result.recordsChanged).toBe(false);
    expect(result.cursorChanged).toBe(false);
    expect(await readFile(path.join(root, 'leaderboard/v3.json'), 'utf8')).toBe(snapshot);
    expect(fetcher.mock.calls.map(call => new URL(call[0] as string).searchParams.get('since'))).toEqual(['event0001', '1794823080', 'all']);
  });

  it('uses a timestamp overlap to recover delayed replication and expired message ids', async () => {
    const root = await workspace();
    await writeFile(path.join(root, 'leaderboard/v3.json'), JSON.stringify(makeSnapshot([record('player_0001', 90)])));
    await writeFile(path.join(root, 'leaderboard/cursor-v3.json'), JSON.stringify({ version: LEADERBOARD_VERSION, lastEventId: 'event0002', lastEventTime: 1794823201 }));
    const fetcher = vi.fn(async (_input: string | URL | Request) => response(''))
      .mockResolvedValueOnce(response('', 404)).mockResolvedValueOnce(response(event('event0001', record('player_0002', 80), 1794823200)));
    const result = await archiveLeaderboard({ root, fetch: fetcher });
    expect(result.records).toBe(2);
    expect(result.recordsChanged).toBe(true);
    const cursor = JSON.parse(await readFile(path.join(root, 'leaderboard/cursor-v3.json'), 'utf8'));
    expect(cursor.lastEventId).toBe('event0002');
  });

  it.each(['truncated', 'invalid', 'http'])('does not erase or advance the archive on a %s response', async mode => {
    const root = await workspace();
    const snapshot = JSON.stringify(makeSnapshot([record()]));
    const cursor = JSON.stringify({ version: LEADERBOARD_VERSION, lastEventId: 'event0001', lastEventTime: 1794823200 });
    await writeFile(path.join(root, 'leaderboard/v3.json'), snapshot);
    await writeFile(path.join(root, 'leaderboard/cursor-v3.json'), cursor);
    const fetcher = vi.fn(async () => mode === 'http' ? response('unavailable', 503) : mode === 'truncated' ? response('', 200, { 'X-Messages-Truncated': '1' }) : response('{broken'));
    await expect(archiveLeaderboard({ root, fetch: fetcher })).rejects.toThrow();
    expect(await readFile(path.join(root, 'leaderboard/v3.json'), 'utf8')).toBe(snapshot);
    expect(await readFile(path.join(root, 'leaderboard/cursor-v3.json'), 'utf8')).toBe(cursor);
  });

  it('starts a genuine empty snapshot without inventing players', async () => {
    const root = await workspace();
    const result = await archiveLeaderboard({ root, fetch: async () => response('') });
    expect(result).toEqual({ records: 0, received: 0, recordsChanged: true, cursorChanged: false });
    expect(JSON.parse(await readFile(path.join(root, 'leaderboard/v3.json'), 'utf8')).records).toEqual([]);
  });
});


describe('editable names and legacy preservation in permanent storage',()=>{
  it('archives a profile without inventing a score and leaves the original v2 snapshot untouched',async()=>{
    const root=await workspace();
    const legacy={...record(),version:'starhop-v2',result:{...record().result,roomsCleared:4,time:54.87},name:'旧昵称'};
    const oldFile=JSON.stringify({version:'starhop-v2',updatedAt:'2026-11-16T12:00:00Z',records:[legacy]});
    await writeFile(path.join(root,'leaderboard/v2.json'),oldFile);
    const profile={version:LEADERBOARD_VERSION,type:'profile',playerId:legacy.playerId,name:'琉璃客',updatedAt:'2026-11-16T14:00:00Z'};
    const request=vi.fn(async(input:string|URL|Request)=>response(String(input).includes('starhop-v2-')?'':event('rename_event_1',profile)));
    const first=await archiveLeaderboard({root,fetch:request});
    expect(first.records).toBe(0);
    const snapshot=JSON.parse(await readFile(path.join(root,'leaderboard/v3.json'),'utf8'));
    expect(snapshot.records).toEqual([]);expect(snapshot.legacyRecords[0].name).toBe('琉璃客');expect(snapshot.legacyRecords[0].result.time).toBe(54.87);
    expect(snapshot.profiles).toHaveLength(1);expect(await readFile(path.join(root,'leaderboard/v2.json'),'utf8')).toBe(oldFile);
    const second=await archiveLeaderboard({root,fetch:request});expect(second.recordsChanged).toBe(false);
  });
  it('imports old client scores that arrive after the upgrade and applies the latest independent profile',async()=>{
    const root=await workspace();
    const profile={version:LEADERBOARD_VERSION,type:'profile' as const,playerId:'player_0001',name:'已经改好的名',updatedAt:'2026-11-16T14:00:00Z'};
    await writeFile(path.join(root,'leaderboard/v3.json'),JSON.stringify(makeSnapshot([],undefined,[profile])));
    const legacy={...record(),version:'starhop-v2',createdAt:'2026-11-16T15:00:00Z',name:'迟到的旧客户端名',result:{...record().result,roomsCleared:4,time:49}};
    const request=vi.fn(async(input:string|URL|Request)=>response(String(input).includes('starhop-v2-')?event('legacy_late_1',legacy):''));
    await archiveLeaderboard({root,fetch:request});
    const snapshot=JSON.parse(await readFile(path.join(root,'leaderboard/v3.json'),'utf8'));
    expect(snapshot.records).toEqual([]);expect(snapshot.legacyRecords[0].name).toBe('已经改好的名');expect(snapshot.legacyRecords[0].result.time).toBe(49);
  });
});
