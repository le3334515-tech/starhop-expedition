import { build } from 'esbuild';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, 'output/leaderboard-deploy');
await mkdir(path.join(output, 'scripts'), { recursive: true });
await mkdir(path.join(output, 'leaderboard'), { recursive: true });
await build({
  entryPoints: [path.join(root, 'tools/archive-leaderboard.ts')],
  outfile: path.join(output, 'scripts/archive-leaderboard.mjs'),
  platform: 'node', format: 'esm', target: 'node22', bundle: true,
});
const snapshot = path.join(output, 'leaderboard/v3.json');
try { await readFile(snapshot); }
catch (error) {
  if (error.code !== 'ENOENT') throw error;
  await writeFile(snapshot, `${JSON.stringify({ version: 'starhop-v3', updatedAt: new Date().toISOString(), records: [], heroRecords: [], legacyRecords: [], profiles: [] }, null, 2)}\n`);
}
console.log(`Leaderboard deployment bundle: ${output}`);

await mkdir(path.join(output,'.github/workflows'),{recursive:true});
await writeFile(path.join(output,'.github/workflows/archive-classic-leaderboard.yml'), `name: Archive classic v4.2 leaderboard

on:
  schedule:
    - cron: '37 * * * *'
  workflow_dispatch:

permissions:
  contents: write

concurrency:
  group: archive-leaderboard
  cancel-in-progress: false

jobs:
  archive:
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@v4
        with:
          ref: main
      - uses: actions/setup-node@v4
        with:
          node-version: '22'
      - name: Merge completed runs and shared profile edits
        run: node classic/scripts/archive-leaderboard.mjs classic
      - name: Save changed leaderboard data
        shell: bash
        run: |
          git add classic/leaderboard/*.json
          if git diff --cached --quiet; then exit 0; fi
          git config user.name "starhop-leaderboard[bot]"
          git config user.email "starhop-leaderboard[bot]@users.noreply.github.com"
          git commit -m "Archive classic v4.2 leaderboard results and names"
          git push origin HEAD:main
`);
