"""Rebuild the original score with numpy, scipy, ffmpeg and the CC0 VCSL recordings."""
import hashlib
import json
import subprocess
import sys
import tempfile
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
from scipy import signal
from scipy.io import wavfile

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = json.loads((ROOT / "tools/score-samples.json").read_text())
CACHE = Path(tempfile.gettempdir()) / ("starhop-vcsl-" + MANIFEST["revision"][:10])
CACHE.mkdir(exist_ok=True)
SR = 32000


def acquire(item):
    path, digest = item
    target = CACHE / Path(path).name
    def verified():
        if not target.exists():
            return False
        data = target.read_bytes()
        return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == digest
    if not verified():
        url = "https://raw.githubusercontent.com/sgossner/VCSL/" + MANIFEST["revision"] + "/" + urllib.parse.quote(path)
        subprocess.run(["curl", "-fsSL", "--retry", "3", "--max-time", "65", url, "-o", str(target)], check=True)
        if not verified():
            raise ValueError(path)
    return target


def read_sample(path):
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", str(path), "-ar", str(SR), "-ac", "1", "-f", "f32le", "-"])
    y = np.frombuffer(raw, dtype="<f4").copy()
    peak = max(abs(y))
    if peak == 0:
        raise ValueError(path)
    y /= peak
    start = np.argmax(abs(y) > .008)
    return y[max(0,start-int(.009*SR)):]


if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=5) as pool:
        files = list(pool.map(acquire, MANIFEST["samples"]))
    print("Verified", len(files), "CC0 recordings.", flush=True)

# The common cell D-A-C-D is an invitation in the valley, a summons at the
# gate, and a displaced low ostinato once the guardian breaks its seal.
class Arrangement:
    def __init__(self, seconds, bank):
        self.frames = round(seconds * SR)
        self.mix = np.zeros((self.frames + 7*SR, 2), dtype=np.float32)
        self.rng = np.random.default_rng(5813)
        self.bank = bank

    def strike(self, at, instrument, note, duration, level, pan=0, bend=0, reverse=False):
        samples = self.bank[instrument]
        root, wave = min(samples, key=lambda p: abs(p[0]-note))
        t = np.arange(round(duration*SR)) / SR
        ratio = 2 ** ((note-root + bend*np.exp(-t/.075))/12)
        pos = np.cumsum(ratio) - ratio[0]
        y = np.interp(pos, np.arange(len(wave)),wave,right=0)
        if reverse:
            y = y[::-1].copy()
        release = min(.18 if instrument in ('wind','bow') else .12, duration*.27)
        env = np.minimum(1,t/(.032 if instrument=='bow' else .004)) * np.minimum(1,(duration-t)/release)
        if instrument=='bow':
            env *= .78+.22*np.sin(np.pi*t/duration)
        y *= env*level
        offset = round(at*SR)
        count = min(len(y),len(self.mix)-offset)
        if count<=0:return
        self.mix[offset:offset+count,0] += y[:count]*np.sqrt((1-pan)*.5)
        self.mix[offset:offset+count,1] += y[:count]*np.sqrt((1+pan)*.5)

    def floor(self,at,note,duration,level,pulse=False):
        t=np.arange(round(duration*SR))/SR
        phi=2*np.pi*440*2**((note-69)/12)*t
        y=(np.sin(phi)+.36*np.sin(2*phi+.18*np.sin(phi))+.18*np.sin(3*phi)) * level
        y*=np.minimum(1,t/(.015 if pulse else .24))*np.minimum(1,(duration-t)/min(.25,duration*.35))
        if pulse:y*=np.exp(-t*3.6)
        offset=round(at*SR); self.mix[offset:offset+len(y)] += y[:,None]

    def finish(self,name,target,loop=True):
        mix=self.mix
        # A short wood room and two long, dark, differently spaced temple tails.
        for ch,taps in enumerate([[(.067,.15),(.129,.09),(.218,.065)],[(.083,.15),(.154,.09),(.237,.065)]]):
            dry=mix[:,ch].copy()
            for delay,gain in taps:
                lag=round(delay*SR); mix[lag:,ch]+=gain*dry[:-lag]
            noise=self.rng.normal(0,1,int(SR*1.55))
            noise=signal.sosfilt(signal.butter(2,3300,fs=SR,output='sos'),noise)
            impulse=noise*np.exp(-np.arange(len(noise))/(SR*.23))
            impulse*=.15/np.linalg.norm(impulse)
            mix[:,ch]+=signal.oaconvolve(dry,impulse,'full')[:len(mix)]
        if loop:
            tail=mix[self.frames:]; mix[:len(tail)]+=tail
        mix=mix[:self.frames]
        mix=signal.sosfilt(signal.butter(2,30,fs=SR,btype='highpass',output='sos'),mix,axis=0)
        mix=np.tanh(mix*1.15)
        if not loop:
            mix[-round(.06*SR):] *= np.linspace(1,0,round(.06*SR))[:,None]
        tmp=CACHE/(name+'.wav')
        wavfile.write(tmp,SR,(mix*.93*32767).astype('int16'))
        meter=subprocess.run(['ffmpeg','-hide_banner','-i',str(tmp),'-af','loudnorm=print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
        stats=json.JSONDecoder().raw_decode(meter.stderr[meter.stderr.rfind('{'):])[0]
        gain=min(target-float(stats['input_i']),-1.7-float(stats['input_tp']))
        out=ROOT/'src/assets/music'/(name+'.mp3')
        out.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(tmp),'-af',f'volume={gain:.3f}dB','-codec:a','libmp3lame','-b:a','112k','-ar','32000',str(out)],check=True)
        print(name,round(self.frames/SR,2),'seconds',round(float(stats['input_i'])+gain,1),'LUFS',flush=True)


def render(bank):
    # (beat, MIDI pitch, length in beats). Each section leaves room for breath.
    valley=[
      [(0,74,1.25),(1.75,81,.7),(2.75,84,.42),(3.25,86,.7)],
      [(.25,81,1.35),(2,79,.65),(3,77,.85)],[(.5,74,2),(3.25,72,.55)],[],
      [(0,69,.75),(1,72,.75),(2,74,1.55)],[(0,77,1.25),(2,79,.52),(3,77,.75)],
      [(.25,74,1.55),(2.5,69,.95)],[(1,72,1.7)]]
    beat=60/84
    a=Arrangement(24*4*beat,bank)
    for bar in range(24):
        start=bar*4*beat; root=[50,48,43,45,46,48,50,45][bar%8]
        a.floor(start,root-12,beat*3.85,.078)
        for k,interval in enumerate([0,7,12,7,15,12]):
            if (bar+k)%6==2:continue
            a.strike(start+[0,.75,1.5,2.25,2.75,3.5][k]*beat,'zither',root+interval,1.75,.21 if k==0 else .13,(-.47,.22)[k%2])
        line=valley[bar%8]
        if bar in (11,19):line=[(0,77,.65),(1,79,.45),(1.75,81,1.6)]
        for off,n,length in line:
            a.strike(start+off*beat,'wind',n-(5 if 8<=bar<12 else 0),length*beat,.32,.13,-.2)
        if bar%2==0:a.strike(start,'drum',0,1.8,.16)
        if bar%4 in (1,3):a.strike(start+3*beat,'wood',0,.38,.105,-.42)
        if bar>=8:a.strike(start+.12,'bow',root+7,3.1*beat,.105,-.35)
        if bar in (7,15,23):a.strike(start+2.5*beat,'gong',-3,2.4,.09,.38)
    a.finish('mist-pass',-17.5)

    beat=60/104
    a=Arrangement(20*4*beat,bank)
    for bar in range(20):
        start=bar*4*beat; root=[38,38,34,36,38,41,31,33][bar%8]
        a.strike(start,'bow',root+12,3.75*beat,.21,-.22)
        a.floor(start,root,3.6*beat,.145)
        for off,vel in [(0,.63),(1.5,.24),(2.75,.38),(3.5,.17)]:
            if bar%4==3 and 1<off<3:continue
            a.strike(start+off*beat,'drum',-2 if off==0 else 1,1.35,vel)
        for off in ([.75,2,3.25] if bar%2==0 else [.5,1.75,2.5,3,3.75]):
            a.strike(start+off*beat,'frame',1, .52,.27 if off==2 else .19,.46)
        for i,interval in enumerate([0,7,10,12]):
            a.strike(start+i*beat,'short',root+interval+12,.43,.33,-.38)
        call=[(0,62,1.3),(1.75,69,.62),(2.75,72,.45),(3.25,74,.7)] if bar%4==0 else [(0,69,1.6),(2,65,1.2)] if bar%4==1 else [(1,62,1.9)] if bar%4==2 else []
        if bar>=8 and bar%4==3:call=[(.5,67,.5),(1.25,65,.5),(2,62,1.4)]
        for off,n,l in call:a.strike(start+off*beat,'wind',n,l*beat,.33,.16,-.2)
        if bar%4==0:a.strike(start,'gong',-1,3.3,.22,-.20)
        if bar>=8:
            for off in [.5,2.25,3.5]:a.strike(start+off*beat,'zither',root+24,.68,.16,.30)
    a.finish('ember-vigil',-16.3)

    # Seven eighths (3+2+2); the old ceremonial call returns inside the faster meter.
    eighth=60/136/2
    a=Arrangement(24*7*eighth,bank)
    for bar in range(24):
        start=bar*7*eighth; root=[38,39,38,36,34,36,31,33][bar%8]
        a.floor(start,root,6.8*eighth,.16)
        for i,iv in enumerate([0,7,12,0,10,7,12]):
            if bar%8 in (6,7) and i in (2,4):continue
            a.strike(start+i*eighth,'short',root+iv+12,.27,.37 if i in (0,3,5) else .23,[-.48,.24][i%2])
            if i in (0,3,5):
                a.strike(start+i*eighth,'drum2',0 if i==0 else 2,1.15,.66 if i==0 else .39)
                a.floor(start+i*eighth,root+12,.24,.13,True)
            else:a.strike(start+i*eighth,'frame',3,.31,.25,.46)
        if bar%4==3:
            for j in [4.5,5.5,6.5]:a.strike(start+j*eighth,'frame',5,.24,.19,-.40)
        if bar%4==0:a.strike(start,'gong',1,2.55,.21,.25)
        n=[74,75,81,79,77,72,67,69][bar%8]
        a.strike(start+.025,'bow',n-12,6.5*eighth,.24,-.2)
        if bar<8 or bar>=16:
            for i,k in enumerate(([0,3,5] if bar%4==0 else [0,4])):
                a.strike(start+k*eighth,'wind',n+[0,7,10][i] if bar%4==0 else n-(2 if i else 0),(.78 if i==0 else .35),.28,.18,-.32)
        if bar>=8:
            for k in [0,1.5,3,5.5]:a.strike(start+k*eighth,'zither',root+24+(7 if k%2 else 0),.55,.24,.32)
    a.finish('broken-seal',-15.8)

    a=Arrangement(3.2,bank)
    a.strike(0,'gong',-6,1.9,.27);a.floor(0,38,2.2,.17)
    a.strike(.35,'scrape',0,1.55,.36,.15,reverse=True)
    for i,t in enumerate([.30,.87,1.23,1.48,1.68,1.83]):
        a.strike(t,'zither',[50,57,62,69,72,74][i],.72,.30+i*.025, -.42+i*.14)
    a.strike(2.04,'gong',0,1.16,.81);a.strike(2.04,'drum2',-2,1.16,.92)
    a.floor(2.04,38,1.1,.36);a.strike(2.72,'frame',-2,.42,.44)
    a.finish('seal-break',-16.2,False)


def render_final(bank):
    # The first three notes restate the guardian's D-A-C call. The last note
    # lands with the mask and the gong in BOSS_ASCENSION_IMPACT.
    duration = 2.8
    impact = 1.82
    ascension = Arrangement(duration, bank)
    ascension.floor(.035, 38, .58, .23, pulse=True)
    ascension.strike(.08, 'drum', -6, .51, .43)
    ascension.strike(.52, 'drum', -5, .42, .48)
    ascension.strike(.18, 'scrape', -1, 1.52, .72, .28, reverse=True)
    for time, note, pan in [(.47, 62, -.43), (.96, 69, .28), (1.33, 72, -.2)]:
        ascension.strike(time, 'zither', note, .35, .25, pan, bend=-.27)
    ascension.strike(impact, 'gong', -4, .98, 1.02)
    ascension.strike(impact, 'drum2', -4, .98, .94)
    ascension.strike(impact + .017, 'frame', 1, .50, .51, -.38)
    ascension.strike(impact + .024, 'wind', 74, .60, .32, .16, bend=-.4)
    ascension.floor(impact, 38, .83, .45, pulse=True)
    ascension.strike(2.39, 'frame', 3, .27, .27, .42)
    ascension.strike(2.59, 'short', 69, .20, .23, -.18)
    ascension.finish('ascension', -16.2, False)

    # 4/4 at 168 BPM. The returning call stresses D-A-C-D above a faster
    # picked rhythm and alternating deep drum and rim accents.
    beat = 60 / 168
    bars = 20
    tempest = Arrangement(bars * 4 * beat, bank)
    roots = [38, 39, 38, 36, 34, 37, 31, 33,
             34, 36, 38, 41, 34, 39, 37, 33, 38, 39, 36, 37]
    calls = [
        [(0, 74, .60), (.86, 81, .43), (1.52, 84, .37), (2.1, 86, .66)],
        [(.37, 84, .48), (1.24, 81, .60), (2.60, 77, .73)],
        [(0, 74, .78), (1.77, 77, .44), (2.54, 79, .44), (3.15, 81, .62)],
        [(0, 79, .57), (1.0, 75, .60), (2.34, 74, 1.25)],
    ]
    for bar, root in enumerate(roots):
        start = bar * 4 * beat
        lift = 8 <= bar < 16
        turnaround = bar % 4 == 3
        tempest.floor(start, root, beat * 3.95, .13)
        tempest.strike(start, 'bow', root + 12, beat * 3.75, .25 if lift else .16, -.35)
        if bar in (0, 4, 8, 12, 16):
            tempest.strike(start, 'gong', 1 if bar != 16 else -2, 2.8, .28, .13)
        accents = [0, 1.75, 3.25] if lift else [0, .75, 1.5, 2.5, 3.25]
        for i, moment in enumerate(accents):
            loudness = .72 if i == 0 else (.45 if moment >= 2.5 else .32)
            drum = 'drum2' if i % 2 == 0 else 'drum'
            tempest.strike(start + moment * beat, drum, -1 if i == 0 else i % 3, .97, loudness)
        for i, moment in enumerate((.5, 1.0, 2.0, 2.25, 3.0, 3.5)):
            if i == 3 and bar % 2 == 0:
                continue
            tempest.strike(start + moment * beat, 'frame', 2 + i % 3, .26, .23 if i % 2 else .15, .5 if i % 2 else -.54)
        for i, (moment, step) in enumerate(zip((0, .5, .75, 1.5, 1.75, 2.0, 2.5, 3, 3.5, 3.75),
                                                (0, 7, 12, 0, 10, 7, 15, 12, 7, 12))):
            if turnaround and i in (2, 3):
                continue
            instrument = 'zither' if lift or i % 3 == 1 else 'short'
            octave = 24 if instrument == 'zither' else 12
            tempest.strike(start + moment * beat, instrument, root + octave + step, .29, .24 if i % 3 else .38, -.42 if i % 2 else .29)
        for moment, note, length in calls[bar % len(calls)]:
            transpose = [0, -2, -5, 0, 0][bar // 4]
            mark = start + moment * beat
            tempest.strike(mark, 'wind', note + transpose, length * beat, .38 if lift else .36, .19, bend=-.32)
            if bar >= 16 or (lift and moment < .5):
                tempest.strike(mark+.024, 'short', note - 12 + transpose, length * beat, .20, -.53, bend=.2)
        if turnaround:
            for i, moment in enumerate((2.64, 3.18, 3.43, 3.72)):
                tempest.strike(start + moment * beat, 'wood' if i % 2 else 'frame', i, .19, .185 + i * .03, -.30 + .2 * i)
    tempest.finish('ember-tempest', -15.4)


if __name__ == "__main__" and '--fetch-only' not in sys.argv:
    samples=[read_sample(f) for f in files]
    bank={'zither':list(zip([47,59,71,78],samples[:4])), 'wind':[(74,samples[4]),(80,samples[5])],
          'bow':[(74,samples[6])], 'short':[(74,samples[7])]}
    for key,i in [('gong',8),('scrape',9),('drum',10),('drum2',11),('frame',13),('wood',14)]:
        bank[key]=[(0,samples[i])]
    if '--final-only' not in sys.argv:
        render(bank)
    render_final(bank)

