"""Render the co-op route and second guardian's score with the shared VCSL bank."""
from concurrent.futures import ThreadPoolExecutor

from compose_score import MANIFEST, Arrangement, acquire, read_sample


def assemble_bank():
    with ThreadPoolExecutor(max_workers=5) as pool:
        samples = list(pool.map(read_sample, pool.map(acquire, MANIFEST["samples"])))
    bank = {
        "zither": list(zip([47, 59, 71, 78], samples[:4])),
        "wind": [(74, samples[4]), (80, samples[5])],
        "bow": [(74, samples[6])],
        "short": [(74, samples[7])],
    }
    for key, index in (("gong", 8), ("scrape", 9), ("drum", 10), ("drum2", 11), ("frame", 13), ("wood", 14)):
        bank[key] = [(0, samples[index])]
    return bank


def road(bank):
    beat = 60 / 91
    score = Arrangement(16 * 4 * beat, bank)
    replies = [
        [(0, 69, 1.4), (1.5, 70, .48), (2.5, 76, 1.35)],
        [(0.5, 74, 1.33), (2.75, 72, .91)],
        [(0, 69, .83), (1, 67, 1.35), (3, 69, .85)],
        [(1, 65, 1.6)],
    ]
    for bar in range(16):
        start = bar * 4 * beat
        root = [45, 46, 41, 40, 45, 48, 46, 40][bar % 8]
        score.floor(start, root - 12, 3.9 * beat, .08)
        score.strike(start, "bow", root + 12, 3.8 * beat, .12, -.29)
        for offset, interval, pan in ((0, 12, -.22), (.75, 19, .30), (2, 24, -.36), (2.75, 19, .25), (3.5, 12, -.15)):
            score.strike(start + offset * beat, "zither", root + interval, 1.27, .2, pan)
        for offset, note, length in replies[bar % 4]:
            score.strike(start + offset * beat, "wind", note + (12 if bar in (8, 12) else 0), length * beat, .26, .06, -.3)
        score.strike(start, "frame", -2, .62, .12, -.27)
        if bar % 2:
            score.strike(start + 3.2 * beat, "wood", -3, .36, .13, .36)
        if bar % 8 == 7:
            score.strike(start + 2.5 * beat, "gong", 0, 2.1, .19, .21)
    score.finish("warden-road", -17.2)


def battle(bank, cue, bpm, beats_per_bar, roots, rhythm, bars, stage, target):
    beat = 60 / bpm
    score = Arrangement(bars * beats_per_bar * beat, bank)
    melody = [69, 70, 76, 74, 72, 70, 74, 76]
    for bar in range(bars):
        start = bar * beats_per_bar * beat
        root = roots[bar % len(roots)]
        score.floor(start, root - 12, (beats_per_bar - .15) * beat, .095)
        score.strike(start, "bow", root + 12, (beats_per_bar - .1) * beat, .18, -.39)
        score.strike(start + .23 * beat, "bow", root + (19 if bar % 4 != 3 else 18), (beats_per_bar - .35) * beat, .11, .36)
        for index, pulse in enumerate(rhythm):
            at = start + pulse * beat
            accent = index in (0, len(rhythm) - 2)
            note = root + [0, 0, 12, 7, 0, 1, 7, 12][index % 8]
            score.strike(at, "zither", note + 12, (.48 if stage == 3 else .66), .30 if accent else .17, (-.33, .33)[index % 2], .15)
            score.strike(at, ("drum" if accent else "frame"), -3 if accent else -1, .72 if accent else .29, .39 if accent else .21, .05)
            if accent:
                score.floor(at, root, .42, .14, pulse=True)
            if stage >= 2 and index % 2 == bar % 2:
                score.strike(at + beat * .25, "wood", -1, .23, .14, (-.35, .35)[index % 2])
        if bar % 4 in (0, 1, 3):
            first_note = melody[bar % len(melody)]
            instruments = ("wind", "short") if stage >= 2 else ("wind", "zither")
            for index, offset in enumerate((.5, 1.5, beats_per_bar - 1.25)):
                note = first_note + (0, 12 if stage == 3 else 0, 7)[index]
                score.strike(start + offset * beat, instruments[index % 2], note, beat * (1.12 if index==2 else .66), .31, .17, -.35)
        if bar % 4 == 0 or (stage == 3 and bar % 4 == 3):
            score.strike(start, "gong", 0, 2.6, .26, .07)
        if bar % 4 == 3:
            for index in range(stage + 1):
                score.strike(start + (beats_per_bar - 1 + index * .24) * beat, "drum2", 0, .34, .20 + .045 * index, .13)
        if stage == 3 and bar % 4 == 2:
            score.strike(start, "scrape", -3, .85, .18, -.41)
    score.finish(cue, target)


def phase_change(bank, cue, duration, impact, stage):
    score = Arrangement(duration, bank)
    score.strike(0, "scrape", -4, impact, .28, -.3, reverse=True)
    score.strike(.08, "bow", 46 if stage == 2 else 40, impact, .27, .3, bend=-.4)
    score.floor(0, 33, impact, .13)
    for index, fraction in enumerate((.12, .41, .65, .81, .92)):
        score.strike(fraction * impact, "drum2", -5 + index, .36, .11 + index * .065, -.22 + index * .11)
    score.strike(impact, "gong", -2 if stage == 2 else 2, 2.4, .6)
    score.strike(impact, "drum", -2, 1.25, .63)
    score.floor(impact, 33 if stage == 2 else 28, .88, .28, pulse=True)
    score.strike(impact + .08, "zither", 77 if stage == 2 else 82, .77, .31, .27)
    score.finish(cue, -14.4, loop=False)


if __name__ == "__main__":
    sounds = assemble_bank()
    road(sounds)
    battle(sounds, "warden-oath", 104, 3.5, [45, 45, 46, 40, 45, 43, 41, 40], [0, 1, 1.5, 2.5, 3], 20, 1, -15.8)
    battle(sounds, "warden-fracture", 133, 4, [45, 46, 45, 40, 45, 48, 41, 40], [0, .75, 1.5, 2, 2.75, 3.5], 24, 2, -15.0)
    battle(sounds, "warden-crown", 156, 5, [45, 45, 40, 46, 45, 43, 40, 40], [0, .5, 1.25, 2, 2.75, 3.5, 4, 4.5], 24, 3, -14.4)
    phase_change(sounds, "warden-temper", 3.2, 2.04, 2)
    phase_change(sounds, "warden-eclipse", 2.8, 1.82, 3)
