$ErrorActionPreference = 'Stop'
$gameRoot = Split-Path -Parent $PSScriptRoot
$gameNode = (Get-Command node.exe -ErrorAction Stop).Source
if (-not (Test-Path -LiteralPath (Join-Path $gameRoot 'dist\index.html'))) {
  $portableGame = Get-ChildItem -LiteralPath (Join-Path $gameRoot 'delivery') -Filter '*.html' | Select-Object -First 1
  Start-Process $portableGame.FullName
  exit
}
$gamePort = 4173
for ($candidatePort = 4173; $candidatePort -le 4183; $candidatePort++) {
  try {
    $health = Invoke-RestMethod -Uri "http://localhost:$candidatePort/__starhop_health" -TimeoutSec 1
    if ($health.app -eq 'starhop') { Start-Process "http://localhost:$candidatePort/"; exit }
  } catch { }
  $listener = Get-NetTCPConnection -LocalPort $candidatePort -State Listen -ErrorAction SilentlyContinue
  if (-not $listener) { $gamePort = $candidatePort; break }
}
Start-Process -FilePath $gameNode -ArgumentList @('tools/server.mjs', '--port', $gamePort) -WorkingDirectory $gameRoot -WindowStyle Hidden
for ($attempt = 0; $attempt -lt 15; $attempt++) {
  try { $null = Invoke-RestMethod -Uri "http://localhost:$gamePort/__starhop_health" -TimeoutSec 1; break } catch { Start-Sleep -Milliseconds 200 }
}
Start-Process "http://localhost:$gamePort/"
