"""Prepare credited itch.io environment sprites. Originals and licenses remain in output/asset-sources."""
from pathlib import Path
from PIL import Image, ImageEnhance
import json

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / 'output/asset-sources'
DEST = ROOT / 'src/assets/art/environment'
DEST.mkdir(parents=True, exist_ok=True)
forest = SOURCES / 'legacy-high-forest/extracted/Legacy-Fantasy - High Forest 2.3'
castle = SOURCES / 'szadiart-castle/extracted'
cliffs = SOURCES / 'magic-cliffs/extracted/Magic-Cliffs-Gamekit/Assets/Environment/PNG'
town = SOURCES / 'gothicvania-town/extracted/GothicVania-town-files/PNG/environment'
manifest = []

def save(name, source, crop=None, tone=None, brighten=1):
    im = Image.open(source).convert('RGBA')
    if crop: im = im.crop(crop)
    if tone:
        # Retain the source's authored shading and color distinctions while sharing a restrained palette.
        pixels = im.load()
        low, high = tone
        for y in range(im.height):
            for x in range(im.width):
                r,g,b,a = pixels[x,y]
                if not a: continue
                lum = (r*.299+g*.587+b*.114)/255
                lum = min(1, lum*brighten)
                mix = [low[i]+(high[i]-low[i])*lum for i in range(3)]
                pixels[x,y] = tuple(round(v*.25+mix[i]*.75) for i,v in enumerate((r,g,b)))+(a,)
    elif brighten != 1:
        alpha = im.getchannel('A'); im = ImageEnhance.Brightness(im).enhance(brighten); im.putalpha(alpha)
    im.save(DEST / name, optimize=True)
    manifest.append({'file':name,'source':str(source.relative_to(ROOT)).replace('\\','/'),'crop':crop,'tone':tone,'brighten':brighten,'size':im.size})

JADE = ((9,28,31),(155,194,157))
GOLD = ((35,26,24),(215,173,104))
RED = ((32,20,28),(191,124,99))
STONE = ((15,28,33),(151,168,150))

save('forest-sky.png', forest/'Background/Background.png', tone=JADE)
save('forest-far.png', forest/'Trees/Background.png', (112,0,208,256), tone=JADE, brighten=1.25)
save('forest-near.png', forest/'Trees/Background.png', (464,0,560,256), tone=JADE, brighten=1.05)
for color, tone in [('green',JADE),('gold',GOLD),('red',RED)]:
    src = forest/f'Trees/{"Green" if color=="green" else "Golden" if color=="gold" else "Red"}-Tree.png'
    save(f'pine-{color}.png',src,(0,0,112,368),tone=tone,brighten=1.45)
save('forest-tiles.png',forest/'Assets/Tiles.png',tone=JADE,brighten=1.3)
save('rocks.png',forest/'Assets/Props-Rocks.png',tone=STONE,brighten=1.4)
save('forest-buildings.png',forest/'Assets/Buildings.png',tone=GOLD,brighten=1.25)
save('cliff-sky.png',cliffs/'sky.png',tone=JADE)
save('cliff-clouds.png',cliffs/'clouds.png',tone=JADE)
save('cliff-island.png',cliffs/'far-grounds.png',tone=JADE,brighten=1.1)
save('cliff-sea.png',cliffs/'sea.png',tone=JADE)
save('cliff-tiles.png',cliffs/'tileset.png',tone=JADE,brighten=1.35)
save('town-sky.png',town/'layers/background.png',tone=RED)
save('town-near.png',town/'layers/middleground.png',tone=RED,brighten=1.5)
save('town-tiles.png',town/'layers/tileset.png',tone=GOLD,brighten=1.8)
for name in ['house-a','house-b','house-c','street-lamp','wagon','well','barrel','crate','sign']:
    save(f'town-{name}.png',town/f'props-sliced/{name}.png',tone=GOLD if name!='street-lamp' else RED,brighten=1.65)
for index, name in enumerate(['01 background','02 background','03 background A','03 background B','04 background','05 background']):
    save(f'castle-layer-{index}.png',castle/f'Background/{name}.png',tone=RED if index<4 else JADE,brighten=1.2)
save('castle-tiles.png',castle/'main_lev_build.png',tone=STONE,brighten=1.8)
save('castle-props.png',castle/'other_and_decorative.png',tone=RED,brighten=1.8)
for i in range(1,5):
    save(f'torch-{i}.png',castle/f'Anim/torch-A-0{i}.png',brighten=1.4)
    save(f'crystal-{i}.png',castle/f'Anim/light-0{i}.png',tone=JADE,brighten=1.7)
(SOURCES/'environment-prepared.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
print(f'Prepared {len(manifest)} environment images in {DEST}')
