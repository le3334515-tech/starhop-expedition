"""Adapt the CC0 Hero Knight (LuizMelo) using its original ZIP as the input."""
from argparse import ArgumentParser
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
RAW_CELL = 180
CROP = (36, 25, 180, 119)
# Per-frame top of the helmet, in the original 180-pixel cell.
POSES = {
    "idle": ("Idle", [(96, 69), (96, 69), (96, 70), (96, 70), (96, 71), (96, 71),
                      (96, 71), (96, 70), (96, 70), (96, 69), (96, 69)]),
    "run": ("Run", [(100, 66), (100, 66), (101, 65), (102, 65), (101, 65), (101, 64),
                    (101, 64), (102, 65)]),
    "jump": ("Jump", [(97, 56), (97, 56), (97, 56)]),
    "fall": ("Fall", [(99, 60), (99, 61), (99, 61)]),
    "strike": ("Attack1", [(82, 67), (84, 67), (87, 67), (100, 71), (100, 71),
                           (103, 70), (103, 70)]),
    "cleave": ("Attack2", [(101, 68), (99, 67), (99, 67), (129, 70), (135, 70),
                           (136, 77), (137, 82)]),
    "hurt": ("Take Hit", [(96, 69), None, (81, 68), (91, 70)]),
    "death": ("Death", [(96, 69), (96, 68), (97, 68), (102, 77), (101, 81),
                        (102, 79), (101, 77), (102, 83), (101, 93), None, None]),
}

PALETTES = {
    1: ((24, 30, 33), (155, 149, 130), (210, 190, 136), (197, 107, 58)),
    2: ((24, 23, 35), (143, 104, 104), (242, 158, 104), (237, 104, 62)),
    3: ((17, 19, 32), (166, 122, 104), (255, 209, 124), (237, 116, 65)),
}


def recolor(source, phase):
    dark, plate, gold, red = PALETTES[phase]
    colors = []
    for r, g, b, a in source.getdata():
        if not a:
            colors.append((0, 0, 0, 0))
            continue
        brightness = (r + g + b) / 3
        if r > g * 1.18 and r > b * 1.15:
            low, high, t = dark, red, min(1, r / 135)
        elif brightness > 148:
            low, high, t = plate, gold, (brightness - 148) / 107
        else:
            low, high, t = dark, plate, brightness / 148
        colors.append(tuple(round(lo + (hi - lo) * t) for lo, hi in zip(low, high)) + (a,))
    output = Image.new("RGBA", source.size)
    output.putdata(colors)
    return output


def decorate(frame, anchor, phase, index, emblem=True):
    x, y = anchor
    gold, shadow, light = ("#9f7d4a", "#333347", "#f2cb82") if phase == 1 else (
        ("#bb5b4a", "#371f2a", "#ffd29d") if phase == 2 else ("#ec9e50", "#241d33", "#fff0b2"))
    if phase > 1:
        cape = Image.new("RGBA", frame.size)
        ink = ImageDraw.Draw(cape)
        flutter = (index % 4) - 1
        reach = 32 if phase == 2 else 40
        ink.polygon([(x - 2, y + 12), (x - 15, y + 10), (x - 23, y + 16),
                     (x - reach, y + 35 + flutter), (x - reach + 8, y + 33),
                     (x - reach + 6, y + 41 + flutter), (x - 20, y + 35),
                     (x - 8, y + 22)], fill=shadow)
        ink.line([(x - 7, y + 13), (x - 19, y + 16), (x - reach + 3, y + 30 + flutter)],
                 fill=gold, width=2)
        frame = Image.alpha_composite(cape, frame)
    ink = ImageDraw.Draw(frame)
    if phase == 1:
        ink.polygon([(x - 5, y + 6), (x - 6, y + 1), (x - 3, y + 2), (x + 2, y - 4),
                     (x + 4, y - 1), (x + 7, y + 2), (x + 6, y + 5)], fill=shadow, outline=gold)
    else:
        side = 10 if phase == 2 else 15
        spike = 7 if phase == 2 else 13
        ink.polygon([(x - 7, y + 7), (x - side, y - spike), (x - 6, y - 3),
                     (x - 3, y + 1), (x + 2, y - spike - 4), (x + 6, y - 4),
                     (x + side, y - spike + 3), (x + 10, y + 3), (x + 8, y + 7)],
                    fill=shadow, outline=gold)
        ink.line([(x + 1, y + 1), (x + 2, y - spike)], fill=light)
        if emblem:
            ink.polygon([(x - 12, y + 10), (x - 20, y + 4), (x - 18, y + 13),
                         (x - 12, y + 18), (x - 5, y + 14)], fill=shadow, outline=gold)
            ink.line([(x - 14, y + 15), (x - 8, y + 19), (x - 11, y + 23)],
                     fill=gold, width=1)
    ink.line([(x + 2, y + 7), (x + 6, y + 7)], fill=light, width=1)
    return frame


def build(source):
    left, top, right, bottom = CROP
    width, height = right - left, bottom - top
    directory = ROOT / "src/assets/art/actors"
    with ZipFile(source) as files:
        for name, (source_name, anchors) in POSES.items():
            raw = Image.open(BytesIO(files.read(f"Hero Knight/Sprites/{source_name}.png"))).convert("RGBA")
            if raw.size != (RAW_CELL * len(anchors), RAW_CELL):
                raise ValueError(f"Unexpected dimensions for {source_name}: {raw.size}")
            sheet = Image.new("RGBA", (width * len(anchors), height * 3))
            for i, anchor in enumerate(anchors):
                frame = raw.crop((i * RAW_CELL, 0, (i + 1) * RAW_CELL, RAW_CELL))
                for phase in (1, 2, 3):
                    variant = recolor(frame, phase)
                    if anchor:
                        variant = decorate(variant, anchor, phase, i, name != "death" or i < 4)
                    sheet.paste(variant.crop(CROP), (i * width, (phase - 1) * height))
            sheet.save(directory / f"warden-{name}.png", optimize=True)


if __name__ == "__main__":
    args = ArgumentParser(description=__doc__)
    args.add_argument("asset_zip", type=Path)
    build(args.parse_args().asset_zip)
