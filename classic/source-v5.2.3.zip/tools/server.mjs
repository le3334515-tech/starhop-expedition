import http from 'node:http';
import path from 'node:path';
import { readFile, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { networkInterfaces } from 'node:os';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../dist');
const index = process.argv.indexOf('--port');
const port = index >= 0 ? Number(process.argv[index+1]) : 4173;
if (!Number.isInteger(port) || port<1024 || port>65535) throw new Error('Invalid port');
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'};
const server=http.createServer(async(req,res)=>{
  if(req.url==='/__starhop_health') { res.setHeader('Content-Type','application/json');res.end(JSON.stringify({app:'starhop',port}));return; }
  if(!['GET','HEAD'].includes(req.method||'')){res.writeHead(405);res.end();return;}
  try {
    const url=new URL(req.url||'/','http://localhost');
    const relative=decodeURIComponent(url.pathname).replace(/^\/+/, '');
    let file=path.resolve(root,relative||'index.html');
    if(file!==root&&!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
    if((await stat(file)).isDirectory())file=path.join(file,'index.html');
    const body=await readFile(file);
    res.setHeader('Content-Type',mime[path.extname(file)]||'application/octet-stream');
    res.setHeader('Cache-Control','no-cache');
    res.writeHead(200);res.end(req.method==='HEAD'?undefined:body);
  }catch{res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end('页面不存在');}
});
server.listen(port,'0.0.0.0',()=>{
  console.log(`Starhop: http://localhost:${port}/`);
  for(const entries of Object.values(networkInterfaces())) for(const address of entries||[]) if(address.family==='IPv4'&&!address.internal)console.log(`Local network: http://${address.address}:${port}/`);
});
server.on('error',error=>{console.error(error.message);process.exitCode=1;});
