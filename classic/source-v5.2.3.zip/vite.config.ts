import { defineConfig } from 'vite';
export default defineConfig(({mode}) => ({
  base: './',
  build: {
    target: ['chrome80', 'safari13.1', 'firefox80'],
    ...(mode==='portable' ? {outDir:'delivery/.portable-build',rollupOptions:{output:{inlineDynamicImports:true}}} : {}),
  },
}));
