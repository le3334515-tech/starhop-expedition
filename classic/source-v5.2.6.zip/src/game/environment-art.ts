import { artImage } from './art-assets';
import type { Decoration, Platform } from './types';

const W = 960, H = 540;
const image = (name: string) => artImage(`environment/${name}`);
const mod = (n: number, divisor: number) => ((n % divisor) + divisor) % divisor;
const panels = new Map<string, HTMLCanvasElement>();

/** Environment art uses authored pixel sprites; effects only light and frame those sprites. */
function stamp(c: CanvasRenderingContext2D, name: string, x: number, y: number, width: number, height?: number, alpha = 1) {
  const sprite = image(name);
  if (!sprite) return false;
  c.save(); c.globalAlpha *= alpha;
  c.drawImage(sprite, Math.round(x), Math.round(y), Math.round(width), Math.round(height ?? width * sprite.height / sprite.width));
  c.restore(); return true;
}

function slice(c: CanvasRenderingContext2D, name: string, sx: number, sy: number, sw: number, sh: number, x: number, y: number, w: number, h: number) {
  const sprite = image(name);
  if (sprite) c.drawImage(sprite, sx, sy, sw, sh, Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

function layer(c: CanvasRenderingContext2D, name: string, camera: number, speed: number, y: number, height: number, alpha = 1) {
  const sprite = image(name);
  if (!sprite) return;
  const width = Math.round(sprite.width * height / sprite.height);
  const start = -Math.round(mod(camera * speed, width));
  for (let x = start; x < W; x += width) stamp(c, name, x, y, width, height, alpha);
}

function glow(c: CanvasRenderingContext2D, x: number, y: number, radius: number, color: string, alpha = 1) {
  const light = c.createRadialGradient(x, y, 0, x, y, radius);
  light.addColorStop(0, color); light.addColorStop(1, color.slice(0, 7) + '00');
  c.save(); c.globalAlpha *= alpha; c.fillStyle = light;
  c.fillRect(x-radius, y-radius, radius*2, radius*2); c.restore();
}

function lantern(c: CanvasRenderingContext2D, x: number, y: number, now: number, scale = 1) {
  const s = scale, bob = Math.sin(now * 1.3 + x * .03) * 2;
  x = Math.round(x); y = Math.round(y + bob);
  glow(c, x, y+14*s, 54*s, '#f29c6460', .6);
  c.fillStyle = '#8d7350'; c.fillRect(x-s, y-25*s, 2*s, 25*s);
  c.fillStyle = '#713c3a'; c.fillRect(x-9*s, y+1*s, 18*s, 24*s);
  c.fillStyle = '#c85e49'; c.fillRect(x-7*s, y+3*s, 14*s, 20*s);
  c.fillStyle = '#edb97a'; c.fillRect(x-2*s,y+4*s,4*s,18*s);
  c.fillStyle = '#b9a06b'; c.fillRect(x-10*s,y,20*s,3*s); c.fillRect(x-10*s,y+24*s,20*s,3*s);
  c.fillStyle = '#b35845'; c.fillRect(x-s,y+27*s,2*s,10*s);
}

function sky(c: CanvasRenderingContext2D, name: string, shade: string) {
  stamp(c, name, 0, 0, W, H);
  c.fillStyle = shade; c.fillRect(0,0,W,H);
}

function trees(c: CanvasRenderingContext2D, camera: number, color: 'green' | 'gold' | 'red', y = 455, alpha = .68, spacing = 270) {
  const offset = Math.round(mod(camera * .28, spacing));
  for (let i=-1;i<5;i++) {
    const height = 254 + (i % 2 ? 76 : 0), width = height * 112/368;
    stamp(c, `pine-${color}.png`, i*spacing-offset+70, y-height, width, height, alpha);
  }
}

function town(c: CanvasRenderingContext2D, camera: number, now: number, ember = false) {
  sky(c, 'town-sky.png', ember ? '#32161955' : '#14212724');
  layer(c, 'town-near.png', camera, .11, 20, 432, .75);
  const spacing = 422, offset = Math.round(mod(camera*.26, spacing));
  for(let i=-1;i<4;i++) {
    const x=i*spacing-offset;
    stamp(c, `town-house-${i%2===0?'a':'c'}.png`, x+22, 212, 186, 202, .59);
    stamp(c,'town-house-b.png',x+214,160,190,250,.45);
    lantern(c,x+190,250,now,.8);
  }
  c.fillStyle = ember ? '#210d194a' : '#172b2c3a'; c.fillRect(0,330,W,120);
}

/** Build stone architecture once, then scroll the finished panel instead of filtering large images each frame. */
function hallPanel(theme: number): HTMLCanvasElement | undefined {
  const key=`hall-${theme}`;
  const cached=panels.get(key); if(cached) return cached;
  const atlas=image('castle-tiles.png'); if(!atlas) return;
  const panel=document.createElement('canvas'); panel.width=480; panel.height=448;
  const c=panel.getContext('2d')!; c.imageSmoothingEnabled=false;
  if(theme===6) {
    // The celestial hall is outdoors. The window-wall atlas patch at
    // (1088,240,64,128) includes an opaque rectangular wall, so use the authored
    // transparent arch cap and complete column sprites instead of a wall matte.
    for(const x of [40,264]) {
      c.drawImage(atlas,448,272,32,32,x,92,128,128);
      c.drawImage(atlas,816,112,32,176,x,160,22,234);
      c.drawImage(atlas,816,112,32,176,x+106,160,22,234);
      glow(c,x+64,238,62,'#a2d4bb30',.45);
    }
    // Only the distant architecture fades. The foreground collision platforms
    // keep their existing crisp two-pixel landing edge.
    c.globalCompositeOperation='destination-in';
    const horizontal=c.createLinearGradient(0,0,480,0);
    horizontal.addColorStop(0,'#ffffff00');horizontal.addColorStop(.15,'#ffffffff');
    horizontal.addColorStop(.85,'#ffffffff');horizontal.addColorStop(1,'#ffffff00');
    c.fillStyle=horizontal;c.fillRect(0,0,480,448);
    const vertical=c.createLinearGradient(0,0,0,448);
    vertical.addColorStop(0,'#ffffff00');vertical.addColorStop(.16,'#ffffffff');
    vertical.addColorStop(.77,'#ffffffff');vertical.addColorStop(1,'#ffffff00');
    c.fillStyle=vertical;c.fillRect(0,0,480,448);
    c.globalCompositeOperation='source-over';
    panels.set(key,panel);return panel;
  }
  c.fillStyle=theme===5?'#342c2a':theme===7?'#33252b':'#1a3036'; c.fillRect(0,0,480,448);
  for(let y=0;y<448;y+=48) for(let x=0;x<480;x+=48) {
    c.globalAlpha=.42;
    c.drawImage(atlas,1184,96,32,32,x,y,48,48);
  }
  c.globalAlpha=1;
  // Authored arch windows and pillars frame the playable space without covering it.
  for(const x of [68,292]) {
    glow(c,x+36,205,88,theme===5?'#ec9a6359':'#a2d4bb45');
    c.fillStyle=theme===5?'#744b37':'#40685f'; c.fillRect(x+10,128,52,162);
    c.drawImage(atlas,1088,240,64,128,x,112,80,192);
    c.globalAlpha=.55;
    c.drawImage(atlas,816,112,32,176,x-44,42,40,352);
    c.drawImage(atlas,816,112,32,176,x+90,42,40,352);
    c.globalAlpha=1;
  }
  for(let x=0;x<480;x+=48) {
    c.drawImage(atlas,240,64,48,16,x,22,48,20);
    c.drawImage(atlas,240,64,48,16,x,390,48,24);
  }
  c.fillStyle='#07191b6b'; c.fillRect(0,320,480,128);
  if(theme===5) {
    c.strokeStyle='#947454'; c.lineWidth=9;
    c.beginPath(); c.moveTo(18,0);c.lineTo(18,330);c.lineTo(150,330);c.lineTo(150,448);c.stroke();
    c.strokeStyle='#3b4542';c.lineWidth=4;c.stroke();
    c.fillStyle='#ba674542'; c.fillRect(0,316,480,2);
  }
  panels.set(key,panel); return panel;
}

function hall(c: CanvasRenderingContext2D, camera: number, theme: number, now: number) {
  const panel=hallPanel(theme); if(!panel) return;
  const offset=Math.round(mod(camera*.18,480));
  for(let x=-offset;x<W;x+=480)c.drawImage(panel,x,0);
  for(let i=-1;i<5;i++) {
    const x=i*270-Math.round(mod(camera*.24,270));
    if(theme===5 || theme===7) lantern(c,x+190,82,now,.85);
    else {
      stamp(c,`crystal-${Math.floor(now*5)%4+1}.png`,x+100,252,24,72,.72);
      glow(c,x+112,284,68,'#8bcdb844',.8);
    }
  }
  if(theme===3) {
    // A slow suspended ritual bell gives the crypt a unique silhouette.
    const x=735-camera*.035;
    c.strokeStyle='#b69b69'; c.lineWidth=2;c.beginPath();c.moveTo(x,0);c.lineTo(x,108);c.stroke();
    c.fillStyle='#314c48';c.beginPath();c.moveTo(x-37,129);c.quadraticCurveTo(x,77,x+37,129);c.lineTo(x+47,192);c.lineTo(x-47,192);c.closePath();c.fill();
    c.strokeStyle='#b39f70';c.lineWidth=2;c.stroke();c.fillStyle='#b7a277';c.fillRect(x-50,190,100,6);
    c.fillStyle='#162c2f';c.fillRect(x-2,198,4,34);
  }
}

function water(c: CanvasRenderingContext2D, now: number, y: number, camera: number) {
  layer(c,'cliff-sea.png',camera,.17,y,H-y,.68);
  c.save();c.globalAlpha=.26;c.strokeStyle='#b0d1b4';c.lineWidth=1;
  for(let i=0;i<15;i++) {
    const x=mod(i*113-camera*.12+Math.sin(now*.5+i)*22,W+180)-80;
    c.beginPath();c.moveTo(x,y+9+i*7);c.lineTo(x+28+(i%4)*19,y+9+i*7);c.stroke();
  }
  c.restore();
}

function celestialWater(c: CanvasRenderingContext2D, camera: number) {
  const sprite=image('cliff-sea.png');if(!sprite)return;
  const height=149,width=Math.round(sprite.width*height/sprite.height),key=`celestial-water-${width}`;
  let panel=panels.get(key);
  if(!panel) {
    panel=document.createElement('canvas');panel.width=width;panel.height=height;
    const context=panel.getContext('2d')!;context.imageSmoothingEnabled=false;
    context.drawImage(sprite,0,0,width,height);
    context.globalCompositeOperation='destination-in';
    const fade=context.createLinearGradient(0,0,0,height);
    fade.addColorStop(0,'#ffffff00');fade.addColorStop(.4,'#ffffff20');
    fade.addColorStop(.8,'#ffffff38');fade.addColorStop(1,'#ffffff00');
    context.fillStyle=fade;context.fillRect(0,0,width,height);
    panels.set(key,panel);
  }
  const start=-Math.round(mod(camera*.17,width));
  for(let x=start;x<W;x+=width)c.drawImage(panel,x,391);
}

/** The additional realms share the original stone pixels, jade shadows and cinnabar lights. */
function eaves(c: CanvasRenderingContext2D, x: number, y: number, width: number) {
  const atlas=image('castle-tiles.png');if(!atlas)return;
  // Shallow stepped tiles and lifted ends keep the silhouette in the same pixel grid.
  for(let row=0;row<6;row++) {
    const inset=(5-row)*16, left=x+inset, span=width-inset*2;
    c.fillStyle=row%2?'#425b59':'#506a64';c.fillRect(left,y-24+row*4,span,4);
    c.fillStyle='#2c4546';
    for(let tile=left+14;tile<left+span;tile+=24)c.fillRect(tile,y-24+row*4,2,4);
  }
  for(let offset=0;offset<width;offset+=32) {
    const span=Math.min(32,width-offset);
    c.drawImage(atlas,240,64,span,16,x+offset,y,span,12);
  }
  c.fillStyle='#526a62';c.fillRect(x-8,y-6,14,8);c.fillRect(x+width-6,y-6,14,8);
  c.fillStyle='#927f59';c.fillRect(x-8,y+2,width+16,2);
  c.fillStyle='#192f32';c.fillRect(x+8,y+12,width-16,8);
}

function courtPanel(realm: number): HTMLCanvasElement | undefined {
  const key=`coop-court-${realm}`, cached=panels.get(key);if(cached)return cached;
  const atlas=image('castle-tiles.png');if(!atlas)return;
  const panel=document.createElement('canvas');panel.width=480;panel.height=448;
  const c=panel.getContext('2d')!;c.imageSmoothingEnabled=false;
  const open=realm===9, roof=open?262:206, foot=432;
  if(!open) {
    c.fillStyle='#1f3537';c.fillRect(64,roof+20,352,foot-roof-20);
    // Reuse the authored masonry at its native scale instead of stretching a window matte.
    c.globalAlpha=.55;
    for(let y=roof+32;y<foot;y+=32)for(let x=64;x<416;x+=32)c.drawImage(atlas,1184,96,32,32,x,y,32,Math.min(32,foot-y));
    c.globalAlpha=1;
    for(const x of [120,272]) {
      c.fillStyle='#62523d';c.fillRect(x,roof+48,88,112);
      c.fillStyle='#1b3436';c.fillRect(x+6,roof+54,76,100);
      c.fillStyle='#586b58';
      for(let dx=12;dx<84;dx+=18)c.fillRect(x+dx,roof+54,2,100);
      for(let dy=74;dy<152;dy+=22)c.fillRect(x+6,roof+dy,76,2);
    }
  }
  for(const x of [68,380]) {
    // A whole column, with matching aspect ratio; no cut-out plaque or floating props.
    c.drawImage(atlas,816,112,32,176,x,foot-176,32,176);
    if(!open)c.drawImage(atlas,816,112,32,64,x,roof+18,32,64);
  }
  eaves(c,42,roof,396);
  if(realm===8) {
    c.fillStyle='#6e634a';c.fillRect(24,148,6,246);c.fillRect(24,388,90,6);
    c.fillStyle='#344b49';c.fillRect(26,148,2,242);c.fillRect(26,390,84,2);
    for(const y of [178,282,374]){c.fillStyle='#95815b';c.fillRect(20,y,14,5);}
  }
  // Individual buildings fade into the mist; they never form opaque panel seams.
  c.globalCompositeOperation='destination-in';
  const fade=c.createLinearGradient(0,0,480,0);
  fade.addColorStop(0,'#ffffff00');fade.addColorStop(.1,'#ffffffff');fade.addColorStop(.9,'#ffffffff');fade.addColorStop(1,'#ffffff00');
  c.fillStyle=fade;c.fillRect(0,0,480,448);c.globalCompositeOperation='source-over';
  panels.set(key,panel);return panel;
}

function royalCourt(): HTMLCanvasElement | undefined {
  const key='coop-royal-court',cached=panels.get(key);if(cached)return cached;
  const atlas=image('castle-tiles.png');if(!atlas)return;
  const panel=document.createElement('canvas');panel.width=1104;panel.height=448;
  const c=panel.getContext('2d')!;c.imageSmoothingEnabled=false;
  // A single central audience hall and its low covered wings identify the final arena.
  // Every upper roof has a masonry/timber storey underneath it.
  for(const [x,y,w,h] of [[42,292,1020,140],[276,198,552,234],[364,140,376,58]]) {
    c.fillStyle='#20383a';c.fillRect(x,y,w,h);
    c.globalAlpha=.52;
    for(let ty=0;ty<h;ty+=32)for(let tx=0;tx<w;tx+=32)c.drawImage(atlas,1184,96,32,32,x+tx,y+ty,Math.min(32,w-tx),Math.min(32,h-ty));
    c.globalAlpha=1;
  }
  for(const x of [76,218,854,996]) {
    c.drawImage(atlas,816,112,32,176,x,276,28,154);
    c.fillStyle='#102d30';c.fillRect(x+28,310,112,98);
    c.fillStyle='#4d655b';c.fillRect(x+28,320,112,3);c.fillRect(x+28,374,112,3);
  }
  for(const x of [306,766]) {
    c.drawImage(atlas,816,112,32,176,x,254,32,176);
    c.drawImage(atlas,816,112,32,64,x,204,32,64);
  }
  // The recessed throne doorway is a complete facade rather than a cut-out wall patch.
  c.fillStyle='#102a2e';c.fillRect(406,230,292,202);
  c.fillStyle='#4b655c';c.fillRect(398,226,8,206);c.fillRect(698,226,8,206);c.fillRect(398,226,308,8);
  c.fillStyle='#7d7b59';
  for(const x of [422,682]){c.fillRect(x,246,2,166);c.fillRect(x-4,266,10,3);c.fillRect(x-4,382,10,3);}
  c.fillStyle='#293f3e';c.fillRect(460,252,184,180);
  c.fillStyle='#3f5952';
  for(let x=472;x<642;x+=22)c.fillRect(x,254,2,174);
  for(let y=272;y<424;y+=24)c.fillRect(462,y,180,2);
  // A bronze square seal anchors the palace without competing with combat warnings.
  c.fillStyle='#827956';c.fillRect(525,244,54,30);c.fillStyle='#233d3d';c.fillRect(529,248,46,22);
  c.fillStyle='#827956';c.fillRect(549,251,5,16);c.fillRect(539,258,25,3);
  eaves(c,24,282,276);eaves(c,804,282,276);
  eaves(c,252,186,600);eaves(c,342,128,420);
  // Distant columns and crossbeams tie the top storey to the roof below.
  for(const x of [386,692]){c.fillStyle='#405b53';c.fillRect(x,142,8,44);}
  c.fillStyle='#314e49';c.fillRect(394,148,298,4);
  panels.set(key,panel);return panel;
}

function cooperativeBackground(c: CanvasRenderingContext2D,camera: number,realm: number,now: number) {
  const forge=realm===8, court=realm===10;
  sky(c,'cliff-sky.png',forge?'#19313291':court?'#10262cbd':'#18363772');
  layer(c,'cliff-clouds.png',camera,.045,8,302,forge?.3:court?.22:.4);
  layer(c,'cliff-island.png',camera,.105,294,160,court?.2:.34);
  layer(c,'forest-far.png',camera,.075,162,290,court?.12:.18);
  const panel=court?royalCourt():courtPanel(realm);
  if(panel && court) {
    c.save();c.globalAlpha=.66;c.drawImage(panel,Math.round(210-camera*.18),0);c.restore();
  } else if(panel) {
    const span=540, offset=Math.round(mod(camera*.18,span));
    c.save();c.globalAlpha=forge?.7:.46;
    for(let x=-offset-span;x<W;x+=span)c.drawImage(panel,x,0);
    c.restore();
  }
  if(forge) {
    const span=540, offset=Math.round(mod(camera*.18,span));
    for(let x=-offset;x<W+span;x+=span) {
      lantern(c,x+126,264,now,.62);
      lantern(c,x+362,264,now,.62);
    }
  } else if(court) {
    const left=Math.round(210-camera*.18);
    for(const x of [340,764])lantern(c,left+x,252,now,.76);
  }
  if(realm===9) {
    celestialWater(c,camera);
    const x=580-camera*.025,y=184;
    c.save();c.translate(x,y);c.rotate(now*.025);c.strokeStyle='#b6ab7580';c.lineWidth=2;
    for(const r of [61,91,117]){c.beginPath();c.ellipse(0,0,r,r*.73,Math.PI*.15,0,Math.PI*2);c.stroke();}
    for(let i=0;i<12;i++){c.rotate(Math.PI/6);c.fillStyle='#c2ad76';c.fillRect(104,-2,8,3);}
    c.restore();glow(c,x,y,48,'#b5d6bd35');
  } else if(court) {
    const x=658-camera*.025;
    glow(c,x,122,86,'#c2c7a638',.6);
    c.fillStyle='#a4b3a659';
    for(let dy=-38;dy<38;dy+=2){const half=Math.floor(Math.sqrt(38*38-dy*dy));c.fillRect(Math.round(x)-half,122+dy,half*2,2);}
  }
  const mist=c.createLinearGradient(0,286,0,454);
  mist.addColorStop(0,'#9ebca200');mist.addColorStop(.78,'#9ebca220');mist.addColorStop(1,'#10272924');
  c.fillStyle=mist;c.fillRect(0,286,W,168);
  for(let i=0;i<12;i++) {
    const x=mod(i*97.3+now*(3+i%3)-camera*.04,W),y=60+mod(i*43+Math.sin(now*.4+i)*18,290);
    c.fillStyle=forge?'#d6ae7254':'#c2d4b744';c.fillRect(Math.round(x),Math.round(y),i%3===0?2:1,1);
  }
}

export function drawArtBackground(c: CanvasRenderingContext2D, camera: number, theme: number, now: number, realm = -1): boolean {
  if(!image('forest-sky.png') || !image('castle-tiles.png') || !image('town-sky.png')) return false;
  c.save(); c.imageSmoothingEnabled=false;
  if(realm>=8 && realm<=10) {cooperativeBackground(c,camera,realm,now);c.restore();return true;}
  const t=Math.max(0,Math.min(7,theme));
  if(t===1 || t===7) {
    town(c,camera,now,t===7);
    if(t===7) {
      c.fillStyle='#211e2ba8';c.fillRect(0,0,W,H);
      c.save();c.globalAlpha=.8;hall(c,camera,7,now);c.restore();
      glow(c,640-camera*.025,160,108,'#da9a6655');
      c.strokeStyle='#d1b37b80';c.lineWidth=2;c.beginPath();c.arc(640-camera*.025,160,75,0,Math.PI*2);c.stroke();
      c.strokeStyle='#d1b37b40';c.beginPath();c.arc(640-camera*.025,160,92,0,Math.PI*2);c.stroke();
    }
  } else if(t===3 || t===5) {
    sky(c,'forest-sky.png',t===5?'#312220bd':'#0c1c2cab');
    hall(c,camera,t,now);
  } else if(t===2 || t===4 || t===6) {
    sky(c,'cliff-sky.png',t===6?'#1023325e':'#1a353128');
    layer(c,'cliff-clouds.png',camera,.045,8,302,t===6?.42:.75);
    layer(c,'castle-layer-2.png',camera,.075,26,426,t===6?.45:.22);
    layer(c,'cliff-island.png',camera,.105,t===4?276:294,160,t===6?.4:.7);
    if(t===6)celestialWater(c,camera);
    else water(c,now,t===4?344:391,camera);
    if(t===4) {
      layer(c,'forest-far.png',camera,.16,140,308,.3);
      trees(c,camera,'green',447,.38,410);
    }
    if(t===6) {
      c.save();c.globalAlpha=.4;
      const panel=hallPanel(6);if(panel)c.drawImage(panel,520-camera*.07,24,480,448);
      c.restore();
      const x=580-camera*.025, y=198;
      c.save();c.translate(x,y);c.rotate(now*.025);c.strokeStyle='#d9bc7b88';c.lineWidth=2;
      for(const r of [61,91,117]) {c.beginPath();c.ellipse(0,0,r,r*.73,Math.PI*.15,0,Math.PI*2);c.stroke();}
      for(let i=0;i<12;i++){c.rotate(Math.PI/6);c.fillStyle='#d9bc7b';c.fillRect(104,-2,8,3);}
      c.restore();glow(c,x,y,48,'#cbe3c34c');
    }
  } else {
    sky(c,'forest-sky.png','#0d252b26');
    layer(c,'forest-far.png',camera,.065,52,400,.53);
    layer(c,'forest-near.png',camera,.13,108,342,.55);
    trees(c,camera,'green',459,.74,256);
    // Warm votive lights punctuate the cool forest and distinguish the combat plane.
    const offset=mod(camera*.2,510);
    for(let i=-1;i<3;i++)lantern(c,i*510-offset+350,239,now,.65);
  }
  // A low mist band separates sprite layers; it never obscures enemies or platforms.
  const mist=c.createLinearGradient(0,300,0,454);
  mist.addColorStop(0,'#a8c9ae00');mist.addColorStop(.78,t===1||t===7?'#d3a88a12':'#b2d9c416');mist.addColorStop(1,t===6?'#10272900':'#10272926');
  c.fillStyle=mist;c.fillRect(0,300,W,154);
  // Small drifting motes are deliberately kept out of the immediate combat foreground.
  for(let i=0;i<12;i++) {
    const x=mod(i*97.3+now*(3+i%3)-camera*.04,W), y=60+mod(i*43+Math.sin(now*.4+i)*18,290);
    c.fillStyle=t===5||t===7?'#e9ad725f':'#d6e7c44a';c.fillRect(Math.round(x),Math.round(y),i%3===0?2:1,1);
  }
  c.restore();return true;
}

function textured(c: CanvasRenderingContext2D, atlas: HTMLImageElement, sx: number, sy: number, sw: number, sh: number, x: number, y: number, w: number, h: number, unit=32) {
  for(let ty=0;ty<h;ty+=unit) for(let tx=0;tx<w;tx+=unit) {
    const dw=Math.min(unit,w-tx),dh=Math.min(unit,h-ty);
    c.drawImage(atlas,sx,sy,sw*dw/unit,sh*dh/unit,x+tx,y+ty,dw,dh);
  }
}

/** World-space rendering. The visible top is precisely the collision rectangle's y coordinate. */
export function drawArtPlatform(c: CanvasRenderingContext2D,p: Platform,theme: number,camera: number): boolean {
  const atlas=image('castle-tiles.png'), forest=image('forest-tiles.png'),cliff=image('cliff-tiles.png');
  if(!atlas || !forest || !cliff)return false;
  const x=Math.round(p.x),y=Math.round(p.y),w=Math.round(p.w),h=Math.round(p.h);
  const left=Math.max(x,Math.floor((camera-x-48)/32)*32+x), right=Math.min(x+w,camera+W+48);
  c.save();c.imageSmoothingEnabled=false;c.beginPath();c.rect(x,y,w,h);c.clip();
  c.fillStyle=theme===1||theme===5||theme===7?'#302e2a':'#1c3637';c.fillRect(x,y,w,h);
  const green=theme===0||theme===2||theme===4;
  if(p.kind==='wood') {
    textured(c,atlas,1888,176,32,16,left,y,right-left,h,32);
    c.fillStyle='#c3ad78';c.fillRect(x,y,w,2);
  } else if(p.kind==='spring') {
    textured(c,atlas,240,272,32,16,left,y,right-left,h,24);
    c.fillStyle='#c9b176';c.fillRect(x,y,w,3);
    c.fillStyle='#b9674f';c.fillRect(x+3,y+3,w-6,4);
    c.strokeStyle='#d3c394';c.lineWidth=2;c.beginPath();c.moveTo(x+13,y+9);c.lineTo(x+34,y+12);c.lineTo(x+13,y+16);c.lineTo(x+34,y+20);c.stroke();
  } else if(green) {
    if(p.kind==='ground') {
      textured(c,forest,16,32,32,32,left,y+12,right-left,Math.max(0,h-12),32);
      // Original moss and rock tiles retain all their small authored details.
      for(let tx=left;tx<right;tx+=32)c.drawImage(forest,16,0,32,16,tx,y,32,24);
    } else {
      textured(c,cliff,384,184,32,16,left,y,right-left,h,32);
    }
  } else {
    textured(c,atlas,1184,96,32,32,left,y,right-left,h,32);
    for(let tx=left;tx<right;tx+=32)c.drawImage(atlas,240,64,32,16,tx,y,32,Math.min(h,18));
  }
  c.restore();
  // A restrained bright rim is a visual contract: this is the exact surface you can land on.
  c.fillStyle=p.kind==='spring'?'#e0bd7f':green?'#b5c791':'#c3b18b';c.fillRect(x,y,w,2);
  c.fillStyle='#0b1c2180';c.fillRect(x,y+h-3,w,3);
  if(p.kind==='wood' && p.oneWay) {
    slice(c,'forest-buildings.png',288,256,16,64,x+10,y+h,7,34);
    slice(c,'forest-buildings.png',288,256,16,64,x+w-17,y+h,7,34);
  }
  return true;
}

/** World-space decorations render behind actors, apart from low grass and mushrooms. */
export function drawArtDecoration(c: CanvasRenderingContext2D,d: Decoration,theme: number,now: number,realm = -1): boolean {
  if(!image('forest-tiles.png'))return false;
  const s=d.scale||1, x=Math.round(d.x), y=Math.round(d.y);
  c.save();c.imageSmoothingEnabled=false;
  switch(d.kind) {
    case 'tree': {
      if(theme===1) {
        const width=122*s;stamp(c,'town-house-a.png',x-width*.5,y-153*s,width,153*s,.78);
      } else if(theme===5||theme===6||theme===7) {
        slice(c,'castle-tiles.png',816,112,32,176,x-17*s,y-190*s,34*s,190*s);
      } else {
        const height=236*s;stamp(c,`pine-${theme===2?'gold':'green'}.png`,x-height*56/368,y-height,height*112/368,height,.83);
      }
      break;
    }
    case 'ruin': {
      if(realm>=8 && realm<=10) {
        c.globalAlpha*=.74;
        slice(c,'castle-tiles.png',816,112,32,176,x-12*s,y-132*s,24*s,132*s);
      } else if(theme===0||theme===2||theme===4) {
        slice(c,'rocks.png',0,160,64,96,x-31*s,y-96*s,62*s,96*s);
        slice(c,'rocks.png',144,256,64,32,x-24*s,y-74*s,48*s,24*s);
      } else if(theme===6) {
        // (1392,80,64,128) is several separate props, including a floating plaque,
        // not one column. A complete pillar cannot be mistaken for tiny ledges.
        slice(c,'castle-tiles.png',816,112,32,176,x-17*s,y-132*s,34*s,132*s);
        stamp(c,`crystal-${Math.floor(now*5)%4+1}.png`,x-9*s,y-93*s,18*s,54*s,.86);
        glow(c,x,y-66*s,34*s,'#9acfb636',.8);
      } else {
        slice(c,'castle-tiles.png',1392,80,64,128,x-29*s,y-132*s,58*s,132*s);
        slice(c,'castle-tiles.png',240,64,48,16,x-39*s,y-140*s,78*s,18*s);
        stamp(c,`crystal-${Math.floor(now*5)%4+1}.png`,x-9*s,y-93*s,18*s,54*s,.86);
        glow(c,x,y-66*s,34*s,'#9acfb636',.8);
      }
      break;
    }
    case 'lamp': {
      stamp(c,'town-street-lamp.png',x-17*s,y-108*s,35*s,108*s,.86);
      lantern(c,x+1*s,y-100*s,now,.55*s);
      break;
    }
    case 'mushroom':slice(c,'forest-tiles.png',256,240,32,32,x-14*s,y-28*s,28*s,28*s);break;
    case 'grass':slice(c,'forest-tiles.png',352,352,32,32,x-13*s,y-17*s,26*s,20*s);break;
    case 'crystal': {
      glow(c,x,y-27*s,35*s,'#8dd3b649',.8);
      stamp(c,`crystal-${Math.floor(now*6)%4+1}.png`,x-9*s,y-48*s,18*s,48*s);
      slice(c,'rocks.png',160,208,64,48,x-20*s,y-20*s,40*s,30*s);
      break;
    }
  }
  c.restore();return true;
}
