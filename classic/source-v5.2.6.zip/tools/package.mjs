import { readFile, writeFile, mkdir, readdir, copyFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'vite';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
await build({root, mode:'portable'});
const compiled=path.join(root,'delivery/.portable-build');
let html = await readFile(path.join(compiled,'index.html'), 'utf8');
const script = html.match(/<script[^>]*src="([^"]+)"[^>]*><\/script>/);
const style = html.match(/<link[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/);
if (!script || !style) throw new Error('The Vite output must contain a script and stylesheet.');
let js = await readFile(path.join(compiled, script[1]), 'utf8');
let css = await readFile(path.join(compiled, style[1]), 'utf8');
// Keep the web build cacheable while making the delivered HTML truly portable.
for (const file of await readdir(path.join(compiled, 'assets'))) {
  const mime = file.endsWith('.mp3') ? 'audio/mpeg' : file.endsWith('.png') ? 'image/png' : null;
  if (!mime) continue;
  const data = `data:${mime};base64,${(await readFile(path.join(compiled, 'assets', file))).toString('base64')}`;
  for (const relative of [`./assets/${file}`, `assets/${file}`, `/assets/${file}`, file]) {
    js = js.replaceAll(JSON.stringify(relative), JSON.stringify(data));
    css = css.replaceAll(relative, data);
  }
}
const favicon = await readFile(path.join(root,'public/favicon.svg'),'utf8');
html = html.replace(script[0], () => `<script type="module">${js.replace(/<\/script/gi,'<\\/script')}</script>`)
  .replace(style[0], () => `<style>${css}</style>`)
  .replace(/href="\.\/favicon.svg"/, () => `href="data:image/svg+xml,${encodeURIComponent(favicon)}"`);
const delivery = path.join(root, 'delivery');
await mkdir(delivery, { recursive: true });
await copyFile(path.join(root, 'public/third-party-licenses.txt'), path.join(delivery, 'third-party-licenses.txt'));
await copyFile(path.join(root, 'docs/素材来源与许可.md'), path.join(delivery, '素材来源与许可.md'));
await writeFile(path.join(delivery, '星跃远征.html'), html, 'utf8');
await writeFile(path.join(delivery, '开始游戏.cmd'), '@echo off\r\nchcp 65001 >nul\r\nstart "" "%~dp0星跃远征.html"\r\n', 'utf8');
const playGuide = `星跃远征 v5.2.6 · 玄阙同征 / STARHOP

公共游玩链接：https://le3334515-tech.github.io/starhop-expedition/classic/?v=5.2.6
离线压缩包：https://le3334515-tech.github.io/starhop-expedition/classic/offline-v5.2.6.zip
源码压缩包：https://le3334515-tech.github.io/starhop-expedition/classic/source-v5.2.6.zip
大厅可查看成就进度，解锁的纪念印记保存在当前浏览器。
电脑和手机均可通过公网页面游玩。离线玩单人远征时，解压后直接双击“星跃远征.html”，画面、角色、特效和音乐均已内嵌。

四人合作远征
从公网页面进入大厅，点击“四人合作远征”，复制邀请发给好友。最多四人，可各自在六个角色中选择一个角色并点击“准备”，最后由房主点击“全队出发”。远征期间，房主应保持游戏页在前台。
单人大厅和双人竞速房也可选择六位旅人；双人可以使用同一角色。默认红笠主角沿用原作的短刃、法杖和飞轮。
六位旅人的兵器按 1 / 2 / 3 排列，手机可直接点武器格：
沈霄：星陨短刃、柳叶软剑、归燕镖
陆照月：萤火法杖、霜枝杖、照月镜
青翎：青羽折扇、翠翎针、绫罗团扇
闻朔：金霆长枪、芦影标枪、断岳戟
裴行舟（原版主角）：星陨短刃、萤火法杖、回声飞轮
怀岳：镇岳拳、伏虎铁拳、回山佛珠
裴行舟沿用原版星陨觉醒。其余五位的觉醒分别是万刃归鞘、月蚀照庭、翠羽天幕、孤城列戟与山门金身。打开操作指南可查看当前旅人的换武连招。
怀岳的镇岳拳、伏虎铁拳与回山佛珠伤害各提高 35%、45%、约 23%。陆照月的霜枝杖采用原创银玉月牙造型。
通关排行分总榜与六个英雄榜。总榜显示英雄和通关时间，英雄榜分别保留每个角色的最佳纪录。
合作中角色各不相同，每人独立切换武器；队友倒地时，靠近即可援救。
本局强化由每个人独立选择。强化面板展开640毫秒后，鼠标或触屏需要再点一次才能选中，其他队员可以继续战斗。
普通守卫与合作增援血量翻倍，两位首领的血量提高约 25%。人数增多仍会提升敌人生命、攻击频率和首领护甲，部分关卡还会增加守卫。合作第五关迎战余烬守卫，击败后通过星门继续前进。第八关之后开启赤铸悬城、断月星桥，最终在玄阙王庭迎战三阶段首领玄阙镇星王。
新增关卡播放《炉桥行》，新首领三个阶段依次使用《镇星誓》《开锋》《王刃裁天》，两次变身配有《熔甲》和《加冕》。队伍共同结算通过关数与用时。

本版基于提供的 v4.1，沿用原像素武侠画风、人物素材与八幕主题。
v4.5 武器动作：法杖利落施法，飞轮独立甩投收手；远程角色清理残留剑影，不再拔刀。
短刃保留原三连斩；原角色、像素配色以及伤害、判定、出手时机保持。
增加章节剧情，丰富主路与高台支路，调整平台衔接、起跳与落地体验。
三种武器随修为在LV.4、LV.7同步进阶，武器栏显示当前阶数。
2号法杖强化追踪贯穿、焰爆与灼烧；3号飞轮强化双轮往返、回锋与破弹。
七个普通关采用不同的地区怪物组合、预警与招式，沿用统一像素画风。
闪避可伤敌，升级恢复生命，地图可拾取回血补给。
格挡按下即响应，可取消冲刺并穿过顿帧立即架势；精准窗口0.24秒，恢复0.36秒。
Boss第一形态余烬守卫，击败后玄烬魔君满血黑化觉醒；第二形态包括地裂墨柱、墨雨等新技能。
v4.4 保持一跳轻点约150、长按约202逻辑像素；二段跳满按额外补高约75，两跳合计约277。
空中轻点补高更小；过早二跳保留已有的更强上升速度，不能三段连跳。
修正天仪中枢远景的矩形硬边和海面色带，保留原像素武侠风格。
升级改为青玉行牒与三道符印，直接展示强化前后的数值；选中后获得本局常驻效果与对应特效。

十八种强化
星刃淬火：每层伤害增加65%基础值，伴随朱金余焰。
疾风节拍：每层攻击速度乘1.35，最高2.8倍，伴随疾风残影。
不灭星心：每层生命上限+2，立即回满生命，伴随气血暖辉。
追风旅靴：每层移动速度乘1.18，最高460；缩短闪避冷却，闪避附带伤敌风刃。
双星共鸣：每层额外飞弹+1，最多额外3枚；近战同样能带出星光弹。
月光守护：立即获得3层护盾，每层抵挡一次伤害；进入新关补1层。
生命余烬：击杀必定回复1颗心，伴随红纹与回流星火。
星尘引力：每层吸取半径+220，伴随聚灵阵。
踏雪生梅：二段跳绽开霜梅，伤及附近敌人。
金钟回响：完美格挡时向四周发出钟波。
拾玉还风：每枚经验缩短闪避冷却，每层0.35秒。
闪耀口袋：每层让拾取星币额外获得2金币和3点觉醒星能，伴随金色星屑。
错金换锋：换武追击的第一招每层额外 +25% 基础伤害。
三星照命：每轮连招第三次出手每层增加 4 星能。
惊鸿留影：完美闪避每层缩短 0.32 秒闪避冷却。
玉关照胆：精准格挡每层额外增加 4 星能。
碎玉鸣泉：每颗回血心每层额外增加 5 星能。
穿云落印：二段跳后的首次落地震击周围 96 像素，每层 3 点基础伤害。
这六道星纹最多叠三重，每次触发都有对应的招式特效。
除星心直接回满外，选择强化时通常恢复1颗心。效果持续到本局结束，重开远征重新成长。

默认电脑操作
A/D 或方向键：移动
空格/K：跳跃、二段跳；轻点也能跳上高台，长按跳得更高
J/X：攻击；按住短刃攻击可打出三连重斩
Shift/L：闪避
F：格挡；在攻击即将命中时起手可精准格挡
1/2/3：切换当前旅人的三件兵器
Q：积满 100 星能，释放所选旅人的六秒觉醒
E：电脑可在星门边互动；清理主路后直接走入星门也能过关
ESC/P：暂停或继续
在按键设置中可以修改键盘绑定。

手机操作
左侧移动摇杆控制方向，右侧动作键支持多指同时操作。
手机已移除E互动按钮；清理主路敌人后直接走进星门，自动进入下一关。
格挡、攻击和武器HUD避免互相遮挡，放大按键及读取旧布局时也会检查碰撞。
确认开始后进入横屏游戏；可在按键布局中调整摇杆和动作键的位置、大小、透明度。
键位与触控布局保存在当前浏览器，下次打开会恢复。

单人及竞速八幕路线
部分机关设在高台。萤火法杖对首领的生命伤害下调 9%。
雾竹山门、朱灯旧街、回风栈道、沉钟地宫、琉璃水庭、丹炉机坊、天仪中枢随种子真实换序，每境只出现一次；单人和双人竞速的余烬神殿固定在第八关，合作远征中位于第五关。
行牒、地图册、目标与剧情使用本局实际顺序，同一挑战种子可复现同一路线。
清理主路敌人后进入星门；升级面板展开640毫秒后，用新的一次鼠标点击或触屏点按选择强化，键盘和手柄不选强化。
注意地图上的回血补给。

配乐与变身
v4.8：普通关逐幕加压，沉钟与炉火可以反制敌人。法杖灼印可用回程飞轮引爆。玄烬魔君二形态半血时会进入最终形态，独立转场和战曲随战斗切换。星陨觉醒另有玉金符阵。
《雾关行》《余烬守夜》《玄烬破阵》随探索、守卫迎战、破封后的第二形态自动切换。双幡与杖冠展开后，避开连冲结束时的地面杖印。

双人在线竞速
点击“发起挑战”创建双人竞速房间，分享邀请链接给一位朋友。两人都准备后同步倒数5秒，开始相同路线的八境竞速。
对方以半透明影像显示，不参与碰撞；竞速计时包含强化选择和暂停，完成后同步双方成绩。
房主请保持游戏页面打开。不能直连时自动尝试加密 HTTPS 线路。需要切换房间时，房主可在等待页切换服务器并发送新邀请。在线竞速需要联网。

同图挑战
在竞速房间选择“只分享同图挑战 / 通关纪录”，或用挑战码让朋友接受相同条件的单人远征。
在线版本的链接可以直接分享；离线版本请把 HTML 文件和挑战码一起发给朋友。
本机远征记录保存在当前浏览器。共享成绩与双人在线竞速需要联网；离线成绩等待恢复联网后重试。
v4.4 沿用当前经典版榜单、玩家身份和历史纪录，不清空已有成绩。

素材鸣谢
LuizMelo、Anokolisa、ansimuz、Szadi art.、Pimen。
配乐由项目编排和混音，选用 Versilian Community Sample Library 的 CC0 乐器录音，战斗音效由项目合成。新增素材的来源与许可详见《素材来源与许可.md》。
`;
await writeFile(path.join(delivery, '游玩说明.txt'), playGuide.replace(/\r?\n/g, '\r\n'), 'utf8');
console.log(`Portable game created: ${path.join(delivery, '星跃远征.html')}`);
