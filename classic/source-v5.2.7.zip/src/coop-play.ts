import { GameEngine } from './game/engine';
import { EMPTY_INPUT, getCharacterWeapons, isLoadoutWeapon, type Boss, type Enemy, type FloatingText, type GameResult, type Hero, type Impact, type InputState,
  type Particle, type Phase, type Pickup, type Projectile, type SoundName, type Upgrade, type WeaponId } from './game/types';
import { getWeaponCombo } from './game/weapon-combos';
import type { CoopCharacterId, CoopPlayer, CoopRoom, CoopSeat, CoopSession } from './coop-transport';

const inputKeys = ['left','right','jumpHeld','attackHeld','jumpPressed','attackPressed','dashPressed','guardPressed','overdrivePressed'] as const;
const heldKeys = inputKeys.slice(0,4);
const edges = inputKeys.slice(4);
const nextInput = (held: InputState, pending: InputState) => {
  const result = { ...held };
  for (const key of edges) { result[key] = pending[key] === true; pending[key] = false; }
  return result;
};

const isContactSound = (name: SoundName) => typeof name === 'string' && (name.endsWith('Contact') || name.endsWith('Finisher'));

type UpgradeChoice = { id: string; level: number };
type Command = { kind: 'input'; seq: number; bits: number; upgrade?: UpgradeChoice; weapon?: WeaponId; room: number; };
interface ContactBeat { tick: number; name: SoundName }
interface Actor {
  engine: GameEngine;
  seq: number;
  weaponAck: number;
  lastPacket: number;
  held: InputState;
  pending: InputState;
  revived: boolean;
  aid: number;
  sounds: SoundName[];
  lastContact?: ContactBeat & { at: number };
}
export interface PartyTraveller {
  seat: CoopSeat; name: string; color: string; role: CoopCharacterId | null; connected: boolean; hero: Hero;
  phase: Phase; overdrive: number; resonance: number; overdriveCount: number; aid: number;
}
interface PartyStatus {
  choices: Upgrade[]; sounds: SoundName[]; synergies: string[]; coins: number; kills: number; deaths: number; shake: number; flash: number;
  announcement: string; announcementTimer: number; transition: number; cameraX: number;
  maxCombo?: number;
  weaponAck?: number;
  contactBeat?: ContactBeat;
  comboTexts?: FloatingText[];
}
interface World {
  kind: 'world'; tick: number; room: number; time: number; cleared: boolean;
  enteredAt: number; clearedAt: number | null;
  enemies: Enemy[]; boss: Boss | null; shots: Projectile[]; pickups: Pickup[];
  effects: Impact[]; sparks: Particle[]; people: PartyTraveller[];
  status: (PartyStatus | null)[]; result: GameResult | null;
}

function isCommand(data: unknown): data is Command {
  if (!data || typeof data !== 'object') return false;
  const p = data as Partial<Command>;
  return p.kind === 'input' && Number.isSafeInteger(p.seq) && p.seq! > 0 && Number.isSafeInteger(p.bits)
    && p.bits! >= 0 && p.bits! < 512 && Number.isSafeInteger(p.room);
}
function isWorld(data: unknown): data is World {
  if (!data || typeof data !== 'object') return false;
  const s = data as Partial<World>;
  return s.kind === 'world' && Number.isSafeInteger(s.tick) && Number.isSafeInteger(s.room)
    && typeof s.time === 'number' && Number.isFinite(s.time) && Number.isFinite(s.enteredAt)
    && (s.clearedAt === null || Number.isFinite(s.clearedAt))
    && Array.isArray(s.people) && s.people.length <= 4 && s.people.every(p => p && p.hero &&
      Number.isFinite(p.hero.x) && Number.isFinite(p.hero.y) && Number.isFinite(p.hero.hp))
    && Array.isArray(s.status) && s.status.length === 4 && Array.isArray(s.enemies) && s.enemies.length <= 24
    && Array.isArray(s.shots) && s.shots.length <= 96 && Array.isArray(s.pickups) && s.pickups.length <= 84
    && Array.isArray(s.effects) && s.effects.length <= 18 && Array.isArray(s.sparks) && s.sparks.length <= 60;
}

export class CoopPlay {
  private readonly actors = new Map<CoopSeat, Actor>();
  private tickNumber = 0;
  private inputSeq = Date.now() * 1000;
  private clock = 0;
  private lastSend = -1;
  private lastWorld = -1;
  private lastContactTick = -1;
  private enemyDeaths = 0;
  private movePending: InputState = { ...EMPTY_INPUT };
  private pendingUpgrade?: UpgradeChoice;
  private pendingWeapon?: { id: WeaponId; firstInput: number };
  private world: World | null = null;
  private chapterIndex = 0;
  private enteredAt = 0;
  private clearedAt: number | null = null;
  private pendingPortal = 0;
  private lastStandAt: number | null = null;
  private closed = false;
  private countdownTime = 0;
  private viewRoom = -1;
  private viewCamera = 0;
  private readonly viewHeroes = new Map<CoopSeat, { x:number; y:number }>();

  constructor(private readonly session: CoopSession, private readonly engine: GameEngine, readonly room: CoopRoom, private readonly sound?: (name:SoundName)=>void) {
    const startActor = (game: GameEngine, player: CoopPlayer | undefined) => {
      const character = player?.role ?? undefined;
      const weapon = getCharacterWeapons(character)[0];
      game.startCoop({ ...room.config, weapon, character }, room.players.length);
      game.setCoopReplica(player?.seat ?? 0);
    };
    startActor(this.engine, room.players.find(player => player.seat === session.view.seat));
    if (!session.view.isHost) return;
    for (const p of room.players) {
      const sounds: SoundName[] = [];
      const game = p.seat === 0 ? engine : new GameEngine({ sound: name => { if (sounds.length < 12) sounds.push(name); } });
      if (game !== engine) startActor(game, p);
      this.actors.set(p.seat, { engine: game, seq: 0, weaponAck:0, lastPacket: -2, revived: false, aid: 0, sounds,
        held: { ...EMPTY_INPUT }, pending: { ...EMPTY_INPUT } });
    }
    this.engine.setCoopTargets(() => this.activeActors().map(({actor}) => actor.engine.state.hero));
    this.countdownTime = .15;
  }

  private activeActors(): { player: CoopPlayer; actor: Actor }[] {
    const players = this.session.view.room?.players ?? [];
    return players.flatMap(player => {
      const actor = this.actors.get(player.seat);
      return actor && player.connected ? [{player, actor}] : [];
    });
  }

  acceptInput(seat: CoopSeat, value: unknown) {
    const actor = this.actors.get(seat);
    if (seat === 0 || !actor || !isCommand(value) || value.seq <= actor.seq) return;
    actor.seq = value.seq;
    const choice = value.upgrade;
    if (choice && typeof choice.id === 'string' && choice.id.length < 32 && choice.level === actor.engine.state.hero.level) {
      actor.engine.chooseUpgrade(choice.id);
    }
    if (value.room !== this.engine.state.roomIndex) return;
    actor.lastPacket = this.clock;
    const target = actor.engine.state;
    if (target.character && target.phase === 'playing' && target.hero.hp > 0 && isLoadoutWeapon(target.character,value.weapon)) {
      actor.engine.equipWeapon(value.weapon);
      if (target.hero.weapon === value.weapon) actor.weaponAck = value.seq;
    }
    inputKeys.forEach((key, index) => {
      const down = (value.bits & (1 << index)) !== 0;
      if (index < heldKeys.length) actor.held[key] = down;
      else if (down) actor.pending[key] = true;
    });
  }

  acceptWorld(value: unknown) {
    if (this.session.view.isHost || !isWorld(value) || value.tick <= this.lastWorld) return;
    const seat = this.session.view.seat, mine = value.people.find(p => p.seat === seat);
    if (!mine || seat === null || !value.status[seat]) return;
    if (value.room < 0 || value.room >= this.engine.state.roomCount) return;
    this.lastWorld = value.tick;
    const s = this.engine.state, status = value.status[seat]!, oldPhase = s.phase;
    if (s.roomIndex !== value.room) this.engine.forceCoopRoom(value.room);
    s.hero = mine.hero; s.enemies = value.enemies; s.boss = value.boss;
    s.projectiles = value.shots; s.pickups = value.pickups; s.impacts = value.effects; s.particles = value.sparks;
    s.floatingTexts = Array.isArray(status.comboTexts) ? status.comboTexts.slice(-6) : [];
    s.time = value.time; s.roomCleared = value.cleared; s.roomIndex = value.room;
    s.roomsCleared = value.result?.roomsCleared ?? value.room + Number(value.cleared);
    s.overdrive = mine.overdrive; s.resonance = mine.resonance; s.overdriveCount = mine.overdriveCount;
    s.phase = value.result ? value.result.won ? 'victory' : 'gameover' : mine.phase;
    s.upgradeChoices = status.choices; s.synergies = status.synergies;
    s.coins = status.coins; s.kills = status.kills; s.deaths = status.deaths;
    s.maxCombo = status.maxCombo ?? 0;
    s.shake = status.shake; s.flash = status.flash; s.cameraX = status.cameraX;
    s.announcement = status.announcement; s.announcementTimer = status.announcementTimer;
    s.transition = status.transition; s.result = value.result;
    const beat = status.contactBeat;
    for (const sound of status.sounds ?? []) {
      if (!beat || !isContactSound(sound)) this.sound?.(sound);
    }
    if (beat && Number.isSafeInteger(beat.tick) && beat.tick > this.lastContactTick && isContactSound(beat.name)) {
      this.lastContactTick = beat.tick;
      this.sound?.(beat.name);
    }
    if (this.pendingUpgrade && (s.phase !== 'upgrade' || s.hero.level !== this.pendingUpgrade.level)) this.pendingUpgrade = undefined;
    if (this.pendingWeapon && (status.weaponAck ?? 0) >= this.pendingWeapon.firstInput && s.hero.weapon === this.pendingWeapon.id) {
      this.pendingWeapon = undefined;
    }
    this.movePending = s.phase === 'playing' && oldPhase === 'playing' ? this.movePending : { ...EMPTY_INPUT };
    this.world = value;
  }

  chooseUpgrade(id: string) {
    if (this.session.view.isHost) this.engine.chooseUpgrade(id);
    else this.pendingUpgrade = { id, level: this.engine.state.hero.level };
  }

  equipWeapon(id: WeaponId) {
    const state = this.engine.state;
    if (this.closed || state.phase !== 'playing' || state.hero.hp <= 0 || !state.character || !isLoadoutWeapon(state.character,id)) return;
    if (this.session.view.isHost) this.engine.equipWeapon(id);
    else if (this.pendingWeapon?.id !== id && (this.pendingWeapon || id !== state.hero.weapon)) {
      this.pendingWeapon = { id,firstInput:this.inputSeq+1 };
    }
  }

  tick(dt: number, input: InputState): void {
    if (this.closed) return;
    this.clock += dt;
    if (!this.session.view.isHost) {
      for (const key of edges) this.movePending[key] ||= input[key] === true;
      if (this.clock - this.lastSend >= .045) {
        this.lastSend = this.clock;
        const sampled = nextInput(input, this.movePending);
        const bits = inputKeys.reduce((value,key,index) => value | (sampled[key] ? 1 << index : 0),0);
        this.session.send({kind:'input', seq:++this.inputSeq, bits,
          upgrade:this.pendingUpgrade, weapon:this.pendingWeapon?.id, room:this.engine.state.roomIndex} satisfies Command);
      }
      return;
    }
    if (this.countdownTime > 0) { this.countdownTime -= dt; return; }
    if (!this.engine.state.result) this.advance(dt, input);
    if (this.clock - this.lastSend >= .083) {
      this.lastSend = this.clock;
      const snapshot = this.snapshot();
      this.world = snapshot;
      this.session.broadcast(snapshot);
    }
  }

  private advance(dt: number, input: InputState) {
    const host = this.engine.state, originalPhase = host.boss?.phase, originalForm = host.boss?.form;
    this.engine.tickCoop(dt, input);
    const active = this.activeActors();
    for (const {player, actor} of active) {
      if (player.seat === 0 || host.result) continue;
      const engine = actor.engine, s = engine.state;
      if (s.roomIndex !== host.roomIndex) engine.forceCoopRoom(host.roomIndex);
      s.enemies = host.enemies; s.boss = host.boss; s.pickups = host.pickups;
      s.time = host.time - dt; s.roomCleared = host.roomCleared;
      // Each actor runs the same movement/combat code. Enemy bolts get a small
      // per-actor copy so a deflection or hit can retire the authoritative bolt.
      const enemyShots = host.projectiles.filter(p=>p.owner==='enemy' && p.life>0);
      s.projectiles = [...s.projectiles.filter(p => p.owner==='hero'),
        ...enemyShots.map(p=>({...p,hitIds:[...p.hitIds]}))];
      const action = nextInput(this.clock-actor.lastPacket < .9 ? actor.held : EMPTY_INPUT, actor.pending);
      engine.tickCoop(dt, action);
      host.pickups = s.pickups;
      const remaining = new Set(s.projectiles.filter(p=>p.owner==='enemy').map(p=>p.id));
      if (originalPhase === host.boss?.phase && originalForm === host.boss?.form) {
        for (const p of enemyShots) if (!remaining.has(p.id) && !p.delay && p.life > dt) p.life = 0;
      }
      s.projectiles = s.projectiles.filter(p=>p.owner==='hero');
    }
    if (originalPhase !== host.boss?.phase || originalForm !== host.boss?.form)
      host.projectiles = host.projectiles.filter(p => p.owner==='hero');

    this.aidParty(active, dt);
    const hasLivingAlly = active.some(({actor}) => actor.engine.state.hero.hp > 0);
    if (hasLivingAlly) this.lastStandAt = null;
    else {
      const canReconnect = [...this.actors.values()].some(actor => actor.engine.state.hero.hp > 0);
      this.lastStandAt ??= this.clock;
      if (!canReconnect || this.clock - this.lastStandAt >= 12) {
        this.engine.completeCoop(false); return;
      }
    }
    const defeated = host.enemies.filter(e=>e.dead).length;
    if (defeated > this.enemyDeaths) {
      for (const {actor} of active) actor.engine.grantCoopXP(2 * (defeated - this.enemyDeaths));
      this.enemyDeaths = defeated;
    }
    if (host.boss?.mode === 'dead' && host.roomIndex === host.roomCount - 1) {
      host.roomsCleared = host.roomCount; this.engine.completeCoop(true); return;
    }
    const clear = host.room.isBoss ? host.boss?.mode === 'dead' : host.enemies.every(e=>e.dead);
    if (clear && !host.roomCleared) {
      host.roomCleared = true; host.roomsCleared = host.roomIndex+1;
      host.announcement = '全队已清场 · 在星门会合'; host.announcementTimer = 3;
      for (const {actor} of active) actor.engine.grantCoopXP(5);
    }
    if (!clear) return;
    const living = active.filter(({actor}) => actor.engine.state.hero.hp > 0);
    const nearGate = living.filter(({actor}) => {
      const h = actor.engine.state.hero, gate = host.room.exit;
      return Math.abs(h.x+h.w/2-(gate.x+gate.w/2)) < 112 && h.y+h.h >= gate.y - 30;
    });
    this.pendingPortal = nearGate.length > 0 ? this.pendingPortal + dt : 0;
    if (nearGate.length && (nearGate.length === living.length || this.pendingPortal >= 5)) {
      const next = host.roomIndex + 1;
      if (next >= host.roomCount) return;
      for (const actor of this.actors.values()) {
        actor.engine.forceCoopRoom(next); actor.aid = 0; actor.revived = false;
        const h = actor.engine.state.hero;
        if (h.hp <= 0) { h.hp = 2; h.invincible = 2; }
      }
      this.enemyDeaths = this.pendingPortal = 0;
    }
  }

  private aidParty(active: ReturnType<CoopPlay['activeActors']>, dt: number) {
    for (const {actor} of active) {
      const h = actor.engine.state.hero;
      if (h.hp > 0 || actor.revived) { actor.aid = 0; continue; }
      const helping = active.some(({actor: other}) => {
        const ally = other.engine.state.hero;
        return ally.hp > 0 && Math.abs(ally.x-h.x) < 61 && Math.abs(ally.y-h.y) < 45;
      });
      actor.aid = helping ? Math.min(1.15, actor.aid + dt) : 0;
      if (actor.aid >= 1.15) { actor.revived = true; h.hp = Math.ceil(h.maxHp * .45); h.invincible = 2; actor.aid = 0; }
    }
  }

  private snapshot(): World {
    const h = this.engine.state, status: World['status'] = [null,null,null,null];
    if (this.chapterIndex !== h.roomIndex) {
      this.chapterIndex = h.roomIndex;
      this.enteredAt = h.time;
      this.clearedAt = null;
    }
    if (h.roomCleared && this.clearedAt === null) this.clearedAt = h.time;
    const people: PartyTraveller[] = [], combined: Projectile[] = [...h.projectiles];
    const effects = [...h.impacts], sparks = [...h.particles];
    const players = this.session.view.room?.players ?? [];
    for (const player of players) {
      const actor = this.actors.get(player.seat);
      if (!actor) continue;
      const s=actor.engine.state, hero = s.hero;
      people.push({ ...player, hero:{...hero,upgrades:[...hero.upgrades]}, phase:s.phase, overdrive:s.overdrive,
        overdriveCount:s.overdriveCount, resonance:s.resonance, aid:actor.aid });
      const combo = getWeaponCombo(s.character);
      const sounds = actor.sounds.splice(0);
      const contact = sounds.find(name => name.endsWith('Finisher')) ?? sounds.find(isContactSound);
      if (contact) actor.lastContact = { tick: this.tickNumber + 1, name: contact, at: this.clock };
      // A polling guest can skip the short snapshot which contained the original hit.
      const beat = actor.lastContact;
      const contactBeat = beat && this.clock - beat.at < .5 ? { tick: beat.tick, name: beat.name } : undefined;
      status[player.seat] = {choices:s.upgradeChoices,sounds,contactBeat,synergies:s.synergies,coins:s.coins,kills:s.kills,deaths:s.deaths,maxCombo:s.maxCombo,
        shake:s.shake,flash:s.flash,announcement:s.announcement,announcementTimer:s.announcementTimer,
        transition:s.transition,cameraX:s.cameraX,weaponAck:actor.weaponAck,
        comboTexts:player.seat !== 0 && combo ? s.floatingTexts.filter(text => text.text === combo.name).slice(-6) : undefined};
      if (player.seat !== 0 && player.connected) {
        combined.push(...s.projectiles);
        effects.push(...s.impacts.slice(-4)); sparks.push(...s.particles.slice(-10));
      }
    }
    return {kind:'world',tick:++this.tickNumber,room:h.roomIndex,time:h.time,cleared:h.roomCleared,
      enteredAt:this.enteredAt,clearedAt:this.clearedAt,
      enemies:h.enemies.map(e=>({...e})),boss:h.boss&&{...h.boss},
      shots:combined.filter(p=>p.life>0).slice(-96).map(p=>({...p,hitIds:[]})),
      pickups:h.pickups.filter(p=>!p.collected).slice(-84).map(p=>({...p})),
      effects:effects.slice(-18).map(p=>({...p})),sparks:sparks.slice(-60).map(p=>({...p})),
      people,status,result:h.result};
  }

  party(): readonly PartyTraveller[] {
    return this.world?.people ?? [];
  }
  get chapterClock(): Readonly<Pick<World,'room'|'time'|'enteredAt'|'clearedAt'>> | null {
    return this.world;
  }
  display(dt: number) {
    const state = this.engine.state, seat = this.session.view.seat;
    if (state.roomIndex !== this.viewRoom) {
      this.viewRoom = state.roomIndex;
      this.viewHeroes.clear(); this.viewCamera = state.cameraX;
    }
    const blend = 1 - Math.exp(-dt * 21);
    const people = this.party().map(person => {
      const target = this.actors.get(person.seat)?.engine.state.hero ?? person.hero;
      const previous = this.viewHeroes.get(person.seat);
      const snap = !previous || Math.hypot(target.x - previous.x, target.y - previous.y) > 160;
      const p = snap ? {x:target.x,y:target.y} : { x:previous.x+(target.x-previous.x)*blend, y:previous.y+(target.y-previous.y)*blend };
      this.viewHeroes.set(person.seat,p);
      return {...person,hero:{...target,...p}};
    });
    const self = people.find(person=>person.seat===seat);
    this.viewCamera += (state.cameraX-this.viewCamera)*blend;
    let visual = self && !this.session.view.isHost ? {...state,hero:self.hero,cameraX:this.viewCamera} : state;
    if (this.session.view.isHost) {
      const alliedHits = people.flatMap(person => person.seat !== seat && person.connected
        ? this.actors.get(person.seat)?.engine.state.impacts.filter(effect => effect.contact).slice(-4) ?? [] : []);
      if (alliedHits.length) visual = { ...state, impacts: [...state.impacts, ...alliedHits] };
    }
    return { state:visual, party:{people,seat,shots:this.partyProjectiles()} };
  }

  private partyProjectiles(): readonly Projectile[] {
    return this.session.view.isHost ? this.world?.shots.filter(p=>p.owner==='hero' && p.id>=1000000) ?? [] : [];
  }
  stop() { this.closed = true; this.actors.clear(); this.world = null; }
}
