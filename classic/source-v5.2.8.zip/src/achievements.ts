import { COOP_CHARACTERS } from './coop-characters';
import { COOP_ROOM_COUNT } from './game/coop-levels';
import { CHARACTER_IDS, EXPEDITION_ROOM_COUNT, MODIFIERS, type GameResult, type ModifierId } from './game/types';
import type { RunRecord } from './social';

type Group = '远征' | '英雄' | '规则' | '战斗';
export interface Achievement {
  id: string;
  group: Group;
  name: string;
  detail: string;
  icon: string;
}

export type AchievementMode = { kind: 'solo' | 'race' | 'previous' } | { kind: 'coop'; players: number };
type StorageAccess = Pick<Storage, 'getItem' | 'setItem'>;
const prefix = 'starhop.achievements.v1.';
const historyImported = `${prefix}history-imported`;
const speedGoals = [
  { id: 'speed-8', minutes: 8, name: '踏星而归' },
  { id: 'speed-5', minutes: 5, name: '疾星过境' },
  { id: 'speed-3', minutes: 3, name: '追星逐月' },
];
const ruleIds = Object.keys(MODIFIERS) as ModifierId[];
const heroIds = CHARACTER_IDS.map(hero => `hero-${hero}`);
const rules = ruleIds.map(rule => `rule-${rule}`);

export const ACHIEVEMENTS: readonly Achievement[] = [
  { id: 'solo-win', group: '远征', name: '独行八境', detail: '首次完成单人八境远征', icon: 'flag' },
  { id: 'race-win', group: '远征', name: '与友竞速', detail: '首次通关双人在线竞速的八境路线', icon: 'bolt' },
  { id: 'coop-win', group: '远征', name: '同袍并进', detail: '至少两人组队完成合作远征', icon: 'users' },
  { id: 'four-win', group: '远征', name: '四星镇阙', detail: '与完整四人队伍通关合作远征', icon: 'trophy' },
  ...speedGoals.map(({id,minutes,name}): Achievement => ({ id, group:'远征', name, detail:`单人八境用时不超过 ${minutes} 分钟`, icon:'bolt' })),
  ...CHARACTER_IDS.map((hero): Achievement => ({
    id: `hero-${hero}`, group: '英雄', name: COOP_CHARACTERS[hero].name,
    detail: '使用此英雄完成单人、竞速或合作远征', icon: COOP_CHARACTERS[hero].icon,
  })),
  { id: 'all-heroes', group: '英雄', name: '六星齐辉', detail: '六名英雄都已通关远征', icon: 'trophy' },
  ...ruleIds.map((rule): Achievement => ({
    id: `rule-${rule}`, group: '规则', name: MODIFIERS[rule].name,
    detail: '用这项规则完成八境远征', icon: MODIFIERS[rule].icon,
  })),
  { id: 'all-rules', group: '规则', name: '四途归星', detail: '用四项远征规则各通关一次', icon: 'trophy' },
  { id: 'no-fall', group: '战斗', name: '踏空如履', detail: '完成一局远征且全程零坠落', icon: 'jump' },
  { id: 'combo-8', group: '战斗', name: '八连不绝', detail: '在通关的一局中打出至少 8 连击', icon: 'blade' },
  { id: 'awaken-3', group: '战斗', name: '星火三燃', detail: '在通关的一局中释放至少 3 次觉醒', icon: 'star' },
];

function availableStorage(): StorageAccess | null {
  try { return globalThis.localStorage ?? null; } catch { return null; }
}

function earnedInRun(result: GameResult, mode: AchievementMode): string[] {
  const cooperative = mode.kind === 'coop';
  const rooms = cooperative ? COOP_ROOM_COUNT : EXPEDITION_ROOM_COUNT;
  if (!result.won || result.roomsCleared !== rooms || !Number.isFinite(result.time) || result.time <= 0) return [];

  const ids: string[] = [];
  if (mode.kind === 'solo') ids.push('solo-win');
  if (mode.kind === 'race') ids.push('race-win');
  if (mode.kind === 'coop' && mode.players >= 2) ids.push('coop-win');
  if (mode.kind === 'coop' && mode.players === 4) ids.push('four-win');
  if (mode.kind === 'solo' || mode.kind === 'previous') {
    for (const goal of speedGoals) if (result.time <= goal.minutes * 60) ids.push(goal.id);
  }
  const character = result.character ?? (cooperative ? undefined : 'traveller');
  if (character && CHARACTER_IDS.includes(character)) ids.push(`hero-${character}`);
  if (!cooperative && ruleIds.includes(result.modifier)) ids.push(`rule-${result.modifier}`);
  if (result.deaths === 0) ids.push('no-fall');
  if (result.maxCombo >= 8) ids.push('combo-8');
  if (result.overdriveCount >= 3) ids.push('awaken-3');
  return ids;
}

/** Separate keys let simultaneous tabs unlock different badges without overwriting one another. */
export class ExpeditionAchievements {
  private earned = new Set<string>();

  constructor(history: readonly RunRecord[] = [], private storage: StorageAccess | null = availableStorage()) {
    try { if (storage?.getItem(historyImported) === '1') return; } catch { /* Local records are still usable. */ }
    const awarded = this.unlock(history.flatMap(({result}) => earnedInRun(result, { kind:'previous' })));
    try {
      if (awarded.every(badge => storage?.getItem(prefix + badge.id) === '1')) storage?.setItem(historyImported, '1');
    } catch { /* Retry the import on a later visit if storage could not be updated. */ }
  }

  get unlocked(): ReadonlySet<string> {
    if (this.storage) for (const {id} of ACHIEVEMENTS) {
      try { if (this.storage.getItem(prefix + id) === '1') this.earned.add(id); } catch { break; }
    }
    return new Set(this.earned);
  }

  complete(result: GameResult, mode: AchievementMode): Achievement[] {
    const earned = earnedInRun(result, mode);
    return earned.length ? this.unlock(earned) : [];
  }

  private unlock(incoming: string[]): Achievement[] {
    const prior = this.unlocked;
    const next = new Set([...prior, ...incoming]);
    if (heroIds.every(id => next.has(id))) next.add('all-heroes');
    if (rules.every(id => next.has(id))) next.add('all-rules');
    const awarded = ACHIEVEMENTS.filter(({id}) => next.has(id) && !prior.has(id));
    for (const {id} of awarded) {
      this.earned.add(id);
      try { this.storage?.setItem(prefix + id, '1'); } catch { /* Keep badge for this browser session. */ }
    }
    return awarded;
  }
}

export function heroAchievementCount(unlocked: ReadonlySet<string>): number {
  return heroIds.filter(id => unlocked.has(id)).length;
}
