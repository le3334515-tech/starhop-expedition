import { COOP_CHARACTERS } from '../coop-characters';
import type { CoopCharacterId, CoopSeat } from '../coop-transport';
import type { PartyTraveller } from '../coop-play';
import { drawArtHero } from './actor-art';
import { artImage } from './art-assets';
import { drawArtSlash } from './effect-art';
import { rangedWeaponPose, type RangedWeaponPose } from './hero-weapon-pose';
import { attackProgress, attackSheetFrame, SHEET_RELEASE_END } from './weapon-motion';
import { WEAPONS, type Hero, type Projectile, type Vec } from './types';
import { drawHeldVariant, drawMoonfireCast, drawTigerGauntlet, drawWillowCut, isVariantWeapon, strikeFlash } from './weapon-visuals';

export interface CoopFrame {
  people: readonly PartyTraveller[];
  seat: CoopSeat | null;
  shots: readonly Projectile[];
}
const kit = {
  blade: { file: 'coop-warrior', anchorX:81, anchorY:101, scale:1.20, contact:[4,2,4] },
  staff: { file: 'coop-staff', anchorX:69, anchorY:97, scale:1.04, contact:[4,4,9] },
  spear: { file: 'coop-huntress', anchorX:75, anchorY:97, scale:1.42, contact:[3,3,2] },
  monk: { file: 'coop-monk', anchorX:32, anchorY:84, scale:1.50, contact:[1,1,6] },
} as const;
const TAU = Math.PI * 2;
const weaponPalette = {
  blade: new Set([0xd2ddf7,0xb6cadf,0xc6d6f3]),
  staff: new Set([0x502d1c,0xdcddce,0xadadad,0x424242]),
  spear: new Set([0x5b737c,0x829ba1,0xb6c4c6,0xc6d9e3,0xecf1ec,0xd6e3e2,0xf9f9f9]),
};
const cleanCostumes = new WeakMap<HTMLImageElement, HTMLCanvasElement>();

function costumeWithoutWeapon(image: HTMLImageElement, role: 'blade' | 'staff' | 'spear'): HTMLCanvasElement {
  const cached = cleanCostumes.get(image);
  if (cached) return cached;
  const canvas = document.createElement('canvas');
  canvas.width=image.naturalWidth; canvas.height=image.naturalHeight;
  const ctx=canvas.getContext('2d')!;
  ctx.drawImage(image,0,0);
  const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);
  const colors=weaponPalette[role];
  const {data}=pixels;
  for (let i=0;i<data.length;i+=4) {
    const r=data[i], g=data[i+1], b=data[i+2];
    if (colors.has((r<<16)|(g<<8)|b) ||
        role==='spear' && r>170 && g>185 && b>=r-3 ||
        role==='blade' && r>185 && g>=r && b>g+4) data[i+3]=0;
  }
  ctx.putImageData(pixels,0,0);
  cleanCostumes.set(image,canvas);
  return canvas;
}

// The gauntlet wraps the actual knuckles in the monk's hand-painted sheets.
// Coordinates are taken before the sprite's anchor and 1.5x display scale.
const monkHand: Record<string, readonly (readonly [number,number])[]> = {
  idle:[[42,63],[43,63],[42,62],[42,62],[41,63],[42,63]],
  attack1:[[35,64],[53,59],[55,59],[55,59],[44,63],[42,63]],
  attack2:[[31,65],[51,59],[51,59],[46,65],[56,60],[56,60],[44,63],[42,63]],
  attack3:[[34,69],[30,64],[30,56],[29,56],[29,56],[43,52],[59,62],[59,62],[59,62],[59,62],[59,62],[44,63],[42,63]],
  run:[[32,66],[24,63],[21,58],[27,64],[38,69],[42,62],[43,58],[40,65]],
  jump:[[40,68],[40,68],[40,68]], fall:[[42,56],[42,56],[42,56]],
};

function variantGrip(c: CanvasRenderingContext2D, role: 'blade' | 'staff' | 'spear' | 'monk', pose:RangedWeaponPose): Vec {
  const raised=role==='staff' ? 8 : role==='spear' ? 5 : 0;
  const grip={x:pose.hand.x+(role==='staff' ? 3 : 0), y:pose.hand.y-raised};
  const trim = {blade:'#80564c',staff:'#a63f50',spear:'#6a9ea7',monk:'#be8058'};
  c.strokeStyle='#302f37'; c.lineWidth=4;
  c.beginPath(); c.moveTo(5,-27-raised); c.lineTo(pose.elbow.x,pose.elbow.y-raised); c.lineTo(grip.x,grip.y); c.stroke();
  c.strokeStyle=trim[role]; c.lineWidth=2; c.stroke();
  c.fillStyle='#d6ac85';
  c.fillRect(Math.round(grip.x)-1,Math.round(grip.y)-1,2,2);
  return grip;
}

export function drawCoopHero(ctx: CanvasRenderingContext2D, role: CoopCharacterId, hero: Hero, now: number, awakened: boolean) {
  if (role === 'wheel' || role === 'traveller') {
    const drawn = drawArtHero(ctx, hero, now, 1, awakened, role === 'wheel' ? 'jade' : 'classic');
    if (drawn && role === 'traveller') drawArtSlash(ctx, hero, now);
    return drawn;
  }
  const style = kit[role], timer = hero.attackTimer, step = Math.max(1, hero.attackStep);
  const variant = isVariantWeapon(hero.weapon);
  const {archetype, color, tuning}=WEAPONS[hero.weapon];
  const useAttackSheet = !variant || archetype==='fist';
  const progress = attackProgress(hero.weapon, step, timer);
  const attacking = timer > 0;
  let pose = 'idle', phase = hero.animation * 8;
  if (hero.hp <= 0) { pose = 'death'; phase = 8; }
  else if (hero.invincible > 1.07 && hero.invincible <= 1.31 && Math.abs(hero.vx) > 160) { pose = 'hurt'; phase = (1.31-hero.invincible)*10; }
  else if (attacking && useAttackSheet && progress < SHEET_RELEASE_END) { pose = `attack${role === 'staff' ? (step === 3 ? 2 : 1) : step}`; }
  else if (!hero.grounded && hero.dashTimer <= 0) { pose = hero.vy < 0 ? 'jump' : 'fall'; phase = Math.abs(hero.vy) > 100 ? 0 : 1; }
  else if (Math.abs(hero.vx) > 14 || hero.dashTimer > 0) { pose = 'run'; phase = hero.animation * 13; }
  const image = artImage(`actors/${style.file}-${pose}.png`);
  if (!image) return false;
  const tile = image.naturalHeight, count = Math.floor(image.naturalWidth / tile);
  const frame = pose.startsWith('attack') ? attackSheetFrame(progress, style.contact[step-1], count)
    : pose === 'death' ? count - 1 : Math.floor(Math.max(0, phase)) % count;
  const tint = COOP_CHARACTERS[role].color;
  ctx.save();
  ctx.translate(Math.round(hero.x+hero.w/2), Math.round(hero.y+hero.h));
  ctx.fillStyle = '#08171890';
  ctx.beginPath(); ctx.ellipse(0, 2, 15, 3, 0, 0, TAU); ctx.fill();
  if (awakened || hero.guardTimer > 0) {
    ctx.strokeStyle = tint; ctx.lineWidth = 1.5; ctx.globalAlpha *= .72;
    ctx.beginPath(); ctx.arc(0,-26,30, now*.85, now*.85+5.25); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  ctx.scale(hero.facing, 1);
  if (hero.invincible > 0 && Math.floor(now * 13) % 2 === 0) ctx.globalAlpha = .66;
  if (hero.hp <= 0) ctx.globalAlpha = .67;
  ctx.imageSmoothingEnabled = false;
  const wrist = variant ? rangedWeaponPose(hero, now) : null;
  if (attacking && wrist && !useAttackSheet) ctx.transform(1,0,wrist.lean,1,0,0);
  const {scale} = style;
  const art=variant && role!=='monk' ? costumeWithoutWeapon(image,role) : image;
  ctx.drawImage(art, frame * tile,0,tile,tile,-style.anchorX*scale,-style.anchorY*scale,tile*scale,tile*scale);
  ctx.filter = 'none';
  if (wrist && hero.hp>0) {
    const socket = hero.weapon==='ironGauntlet' ? (monkHand[pose]?.[frame] ?? monkHand.idle[0]) : null;
    const grip = socket ? {x:(socket[0]-style.anchorX)*scale,y:(socket[1]-style.anchorY)*scale}
      : variantGrip(ctx,role,wrist);
    drawHeldVariant(ctx,hero,grip,wrist.staffAngle,progress);
  }
  if (attacking && hero.hp > 0) {
    if (role === 'blade' && hero.weapon === 'blade') drawWillowCut(ctx, step, progress);
    if (role === 'staff' && hero.weapon === 'ember') drawMoonfireCast(ctx, step, progress);
  }
  if (attacking && hero.weapon === 'ironGauntlet') drawTigerGauntlet(ctx, step, progress);
  else if (attacking && archetype === 'fist') {
    const heavy = step === 3;
    ctx.globalAlpha *= strikeFlash(progress)*.74;
    ctx.strokeStyle = heavy ? '#f5c686' : '#e0bc95';
    ctx.lineWidth = heavy ? 3 : 1.45;
    const height = heavy ? -17 : step === 2 ? -22 : -27;
    ctx.beginPath(); ctx.ellipse(heavy ? 34 : 23,height,heavy ? 22 : 14,heavy ? 13 : 8,-.18,-1.25,1.35); ctx.stroke();
    ctx.fillStyle = '#efcea1';
    ctx.fillRect(Math.round(35+progress*10),height-7,3,2);
    if (heavy) ctx.fillRect(Math.round(49+progress*7),height-2,4,2);
  }
  if (attacking && archetype === 'spear') {
    const length = (step === 3 ? 88 : 67)*(tuning?.reach ?? 1);
    ctx.globalAlpha *= strikeFlash(progress) * .87;
    ctx.strokeStyle = variant ? color : tint; ctx.lineWidth = step === 3 ? 4 : 2;
    ctx.beginPath(); ctx.moveTo(14, -23); ctx.lineTo(length, -24); ctx.stroke();
    ctx.strokeStyle = '#e0e8df'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(26, -21); ctx.lineTo(length+8,-24); ctx.stroke();
  }
  ctx.restore(); return true;
}

export function drawTravellerBadge(ctx: CanvasRenderingContext2D, p: PartyTraveller, hero: Hero, local: boolean) {
  if (!p.role) return;
  const character = COOP_CHARACTERS[p.role], y = Math.round(hero.y) - (p.role === 'staff' ? 20 : character.gender === '女' ? 24 : 14);
  const x = Math.round(hero.x+hero.w/2);
  ctx.save(); ctx.font = '10px sans-serif'; ctx.textAlign = 'center';
  const label = hero.hp > 0 ? (local ? `${character.name} · 你` : character.name) : p.aid > 0 ? '救援中' : '倒地';
  const size = Math.ceil(ctx.measureText(label).width) + 12;
  ctx.fillStyle = '#0c2526e8'; ctx.fillRect(x-size/2,y-12,size,15);
  ctx.fillStyle = character.color; ctx.fillRect(x-size/2,y+2,size,1);
  ctx.fillText(label,x,y-1);
  if (p.aid > 0) { ctx.fillStyle = '#f6d38d'; ctx.fillRect(x-size/2,y+3,size*Math.min(1,p.aid/1.15),2); }
  ctx.restore();
}
