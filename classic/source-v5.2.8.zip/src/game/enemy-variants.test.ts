import { describe, expect, it } from 'vitest';
import { GameEngine } from './engine';
import { createRoom, isSafeFloorPoint } from './levels';
import { REGIONAL_ENEMIES } from './enemy-catalog';
import { enemyDamageMultiplier, updateEnemyVariant, type EnemyVariantContext } from './enemy-variants';
import { judgmentArea, quakeOrigin, QUAKE_LIFE, QUAKE_SPEED } from './court-attacks';
import type { Enemy, GameState } from './types';

function fixture(id: string) {
  const game = new GameEngine(); game.start({ seed: 42, modifier: 'standard', weapon: 'blade' });
  const s = game.state; const profile = REGIONAL_ENEMIES[id];
  const flying = profile.skin === 'eye';
  s.room.platforms = [{ x: 0, y: 448, w: s.room.width, h: 120, kind: 'ground' }]; s.room.hazards = [];
  s.hero.x = 600; s.hero.y = 412;
  const enemy: Enemy = { id: 91, kind: flying ? 'bat' : 'sentry', x: 350, y: flying ? 284 : 448 - profile.height, w: 32, h: profile.height,
    vx: 0, vy: 0, hp: profile.hp, maxHp: profile.hp, facing: 1, timer: 0, hurt: 0, dead: false, originX: 350, originY: flying ? 284 : 448 - profile.height,
    attackCooldown: 0, variant: id, skin: profile.skin, aiMode: 'patrol', aiTimer: 0, aiCount: 0 };
  s.enemies = [enemy]; let nextId = 10000;
  const ctx: EnemyVariantContext = { nextProjectileId: () => ++nextId, hitEnemy: (e, amount) => { e.hp -= amount; if (e.hp <= 0) e.dead = true; }, burst() {}, sound() {} };
  return { s, enemy, ctx };
}
function advance(s: GameState, e: Enemy, ctx: EnemyVariantContext, seconds: number) {
  for (let frame = 0; frame < Math.ceil(seconds * 120); frame++) {
    e.timer += 1 / 120; e.attackCooldown -= 1 / 120; e.hurt = Math.max(0, e.hurt - 1 / 120);
    updateEnemyVariant(e, s, 1 / 120, ctx);
  }
}

describe('regional enemy variety and fair attack rules', () => {
  it('gives seven realms distinct three-enemy rosters and six genuine sprite families', () => {
    const rosters = new Set<string>(); const skins = new Set<string>();
    for (let room = 0; room < 7; room++) {
      const content = createRoom(42, room);
      expect(new Set(content.enemies.map(e => e.variant)).size).toBe(content.room.theme === 5 ? 4 : 3);
      rosters.add([...new Set(content.enemies.map(e => e.variant))].sort().join('|'));
      content.enemies.forEach(e => { expect(REGIONAL_ENEMIES[e.variant!]).toBeDefined(); skins.add(e.skin!); });
    }
    expect(rosters.size).toBe(7); expect(skins.size).toBe(6);
  });

  it('preserves deterministic routes and safely grounded spawns for every regional roster', () => {
    for (let room = 0; room < 7; room++) for (let seed = 1; seed <= 35; seed++) {
      const a = createRoom(seed, room), b = createRoom(seed, room);
      expect(a).toEqual(b);
      for (const e of a.enemies) {
        expect(e.hp).toBeGreaterThanOrEqual(3); expect(e.hp).toBeLessThanOrEqual(8.5);
        if (e.kind !== 'bat') { expect(isSafeFloorPoint(a.room, e.x, e.w)).toBe(true); expect(e.y + e.h).toBe(448); }
      }
    }
  });

  it.each(Object.keys(REGIONAL_ENEMIES))('%s warns before releasing its distinct attack', id => {
    const { s, enemy: e, ctx } = fixture(id); const profile = REGIONAL_ENEMIES[id];
    advance(s, e, ctx, profile.warning * .7);
    expect(e.aiMode).toBe('windup'); expect(s.projectiles).toHaveLength(0); expect(e.aiCount ?? 0).toBe(0);
    advance(s, e, ctx, profile.warning * .5 + .1);
    expect(e.aiCount).toBeGreaterThanOrEqual(1);
    if (id !== 'forge-bulwark' && !['rush', 'leap', 'blink', 'dive'].includes(profile.ability)) expect(s.projectiles.length).toBeGreaterThan(0);
    expect(Number.isFinite(e.x) && Number.isFinite(e.y)).toBe(true);
  });

  it('makes shield skeletons block frontal hits but expose their rear and recovery', () => {
    const { s, enemy: e } = fixture('crypt-bulwark'); s.hero.x = 450;
    expect(enemyDamageMultiplier(e, s.hero)).toBe(.35);
    s.hero.x = 260; expect(enemyDamageMultiplier(e, s.hero)).toBe(1);
    s.hero.x = 450; e.aiMode = 'recover'; expect(enemyDamageMultiplier(e, s.hero)).toBe(1);
    e.aiMode = 'patrol'; s.hero.attackStep = 3; expect(enemyDamageMultiplier(e, s.hero)).toBe(1);
  });

  it('does not fire through a narrow solid wall, but permits one-way platforms', () => {
    const blocked = fixture('tide-mage');
    blocked.s.room.platforms.push({ x: 444, y: 0, w: 5, h: 448, kind: 'stone' });
    advance(blocked.s, blocked.enemy, blocked.ctx, 3);
    expect(blocked.s.projectiles).toHaveLength(0);
    blocked.s.room.platforms.at(-1)!.oneWay = true;
    advance(blocked.s, blocked.enemy, blocked.ctx, 1);
    expect(blocked.s.projectiles.length).toBeGreaterThan(0);
  });

  it('locks the astral rift at its warned location so a moving player can evade it', () => {
    const { s, enemy: e, ctx } = fixture('astral-seer');
    advance(s, e, ctx, .2); const target = e.targetX;
    s.hero.x = 900; advance(s, e, ctx, .7);
    const rift = s.projectiles.find(p => p.kind === 'rift');
    expect(rift).toBeDefined(); expect(rift!.x + rift!.w / 2).toBe(target);
    expect(rift!.delay).toBeGreaterThan(.5);
  });

  it('gives the forge bomber actual ballistic gravity independent of its survival', () => {
    const { s, enemy: e, ctx } = fixture('forge-bomber'); advance(s, e, ctx, 1);
    const bomb = s.projectiles[0]; expect(bomb.gravity).toBe(380); expect(bomb.vy).toBeLessThan(0);
  });

  it('releases two jumpable shield waves on opposite sides from the warned floor', () => {
    const { s, enemy, ctx } = fixture('court-vanguard');
    advance(s, enemy, ctx, .4);
    const origins = [-1,1].map(side => quakeOrigin(enemy, side));
    expect(s.projectiles).toHaveLength(0);
    advance(s, enemy, ctx, .5);
    expect(s.projectiles).toHaveLength(2);
    s.projectiles.forEach((p, i) => {
      expect(p).toMatchObject({ ...origins[i], kind: 'shockwave', style: 'court-quake', life: QUAKE_LIFE, vx: [-1,1][i] * QUAKE_SPEED });
      expect(p.y + p.h).toBe(448);
    });
    enemy.aiMode = 'patrol';
    expect(enemyDamageMultiplier(enemy, s.hero)).toBe(.55);
    s.hero.x = 280;
    expect(enemyDamageMultiplier(enemy, s.hero)).toBe(1);
  });

  it('locks the execution blade before the player sidesteps and leaves a recovery opening', () => {
    const { s, enemy, ctx } = fixture('court-executioner');
    advance(s, enemy, ctx, .25);
    const marked = judgmentArea(enemy);
    expect(s.projectiles).toHaveLength(0);
    s.hero.x += 180;
    advance(s, enemy, ctx, 1);
    expect(s.projectiles).toHaveLength(1);
    expect(s.projectiles[0]).toMatchObject({ ...marked, kind: 'rift', style: 'court-cleave', vx: 0, vy: 0 });
    expect(s.hero.x).toBeGreaterThan(marked.x + marked.w);
    advance(s, enemy, ctx, .3);
    expect(enemy.aiMode).toBe('recover');
  });

  it('leaves legacy enemies without variants to the original engine implementation', () => {
    const { s, enemy: e, ctx } = fixture('bamboo-sprout'); delete e.variant;
    expect(updateEnemyVariant(e, s, 1 / 60, ctx)).toBe(false);
  });
});
