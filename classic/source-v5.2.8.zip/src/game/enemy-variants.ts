import type { Enemy, GameState, Hero, Projectile, SoundName } from './types';
import { enemyProfile, type RegionalEnemyProfile } from './enemy-catalog';
import { emitCourtAttack } from './court-attacks';

export interface EnemyVariantContext {
  nextProjectileId: () => number;
  hitEnemy: (enemy: Enemy, damage: number) => void;
  burst: (x: number, y: number, color: string, count: number, speed: number) => void;
  sound: (name: SoundName) => void;
}
const clamp = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n));
const approach = (n: number, target: number, amount: number) => n < target ? Math.min(target, n + amount) : Math.max(target, n - amount);
const aim = new WeakMap<Enemy, { x: number; y: number }>();

function clearSight(e: Enemy, state: GameState): boolean {
  const x = e.x + e.w / 2, y = e.y + e.h / 2;
  const dx = state.hero.x + 14 - x, dy = state.hero.y + 18 - y;
  for (const platform of state.room.platforms) {
    if (platform.oneWay || platform.kind === 'spring') continue;
    let near = 0, far = 1, intersects = true;
    for (const [origin, delta, low, high] of [[x, dx, platform.x, platform.x + platform.w], [y, dy, platform.y + 2, platform.y + platform.h]]) {
      if (Math.abs(delta) < .001) { if (origin <= low || origin >= high) intersects = false; }
      else {
        const entry = (low - origin) / delta, exit = (high - origin) / delta;
        near = Math.max(near, Math.min(entry, exit)); far = Math.min(far, Math.max(entry, exit));
      }
    }
    if (intersects && near <= far && far > .01 && near < .99) return false;
  }
  return true;
}

function shoot(e: Enemy, state: GameState, ctx: EnemyVariantContext, angle: number, speed: number, style?: Projectile['style'], size = 12): Projectile {
  const p: Projectile = { id: ctx.nextProjectileId(), kind: 'enemy', x: e.x + e.w / 2 - size / 2, y: e.y + e.h / 2 - size / 2,
    w: size, h: size, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, damage: 1, life: 4, owner: 'enemy', hitIds: [], style, color: enemyProfile(e)?.color };
  state.projectiles.push(p); return p;
}

function fire(e: Enemy, s: GameState, profile: RegionalEnemyProfile, ctx: EnemyVariantContext): number {
  const target = aim.get(e) ?? { x: s.hero.x + 14, y: s.hero.y + 18 };
  const angle = Math.atan2(target.y - e.y - e.h / 2, target.x - e.x - e.w / 2);
  const direction = e.facing || 1;
  e.aiCount = (e.aiCount ?? 0) + 1;
  ctx.burst(e.x + e.w / 2, e.y + e.h / 2, profile.color, 9, 110);
  switch (profile.ability) {
    case 'shieldquake':
    case 'judgment':
      s.projectiles.push(...emitCourtAttack(e, ctx.nextProjectileId));
      ctx.burst(e.x + e.w / 2, e.y + e.h - 4, profile.color, 16, 110);
      ctx.sound(profile.ability === 'shieldquake' ? 'guardBreak' : 'heavy');
      return profile.ability === 'shieldquake' ? .46 : .42;
    case 'needle': {
      const distance = Math.hypot(target.x - e.x, target.y - e.y);
      const speed = e.variant === 'gale-archer' ? 285 : 240;
      const count = e.variant === 'astral-archer' ? 3 : 2;
      for (let i = 0; i < count; i++) {
        const needle = shoot(e, s, ctx, angle, speed, 'reflected', 9);
        needle.delay = i * .18;
        needle.life = Math.max(1.1, distance / speed + .7);
      }
      ctx.sound('fire'); return .36;
    }
    case 'groundwave': {
      const wave = shoot(e, s, ctx, direction > 0 ? 0 : Math.PI, e.variant === 'tide-shell' ? 175 : 210, 'reflected', 16);
      wave.kind = 'shockwave'; wave.w = 24; wave.h = 17; wave.y = 448 - wave.h; wave.life = 1.6;
      return .32;
    }
    case 'starfall': {
      const shard = shoot(e, s, ctx, Math.PI / 2, 205, 'charged', 16);
      shard.x = target.x - 8; shard.y = Math.max(38, target.y - 175); shard.gravity = 125; shard.life = 1.4;
      ctx.sound('fire'); return .35;
    }
    case 'hop':
      e.vy = -315; e.vx = direction * 125;
      shoot(e, s, ctx, angle, 165, 'reflected', 10);
      return .5;
    case 'rush': e.vx = direction * 280; return .34;
    case 'leap': e.vy = -365; e.vx = direction * 215; return .54;
    case 'blink': e.vx = direction * 350; return .24;
    case 'dive': {
      const speed = e.variant === 'gale-wing' ? 285 : 230;
      e.vx = Math.cos(angle) * speed; e.vy = Math.sin(angle) * speed;
      return .58;
    }
    case 'guard':
      if (e.variant === 'forge-bulwark') {
        e.vx = direction * 240;
        return .55;
      }
      e.vx = direction * 115;
      shoot(e, s, ctx, direction > 0 ? 0 : Math.PI, 205, undefined, 16);
      return .35;
    case 'fan':
      for (const offset of [-.2, 0, .2]) shoot(e, s, ctx, angle + offset, 185, 'charged', 12);
      ctx.sound('fire'); return .22;
    case 'hex':
      for (const offset of [-.27, 0, .27]) shoot(e, s, ctx, angle + offset, 170, 'ink', 14);
      ctx.sound('fire'); return .3;
    case 'tide':
      for (const offset of [-.14, 0, .14]) shoot(e, s, ctx, angle + offset, 215, 'reflected', 15);
      ctx.sound('fire'); return .24;
    case 'orbit':
      for (const offset of [-.36, .36]) shoot(e, s, ctx, angle + offset, 175, 'reflected', 13);
      e.vx = -direction * 115; ctx.sound('fire'); return .35;
    case 'bomb': {
      const projectile = shoot(e, s, ctx, angle, 205, 'charged', 22);
      const time = clamp(Math.abs(target.x - e.x) / 205, .45, 1.8);
      projectile.vx = (target.x - e.x - e.w / 2) / time;
      projectile.vy = (target.y - e.y - e.h / 2 - .5 * 380 * time * time) / time;
      projectile.gravity = 380;
      ctx.sound('fire'); return .3;
    }
    case 'burst':
      for (let n = 0; n < 6; n++) shoot(e, s, ctx, angle + n * Math.PI / 3, 160, 'charged', 13);
      ctx.sound('fire'); return .32;
    case 'rift':
      s.projectiles.push({ id: ctx.nextProjectileId(), kind: 'rift', x: clamp(target.x - 18, 30, s.room.width - 66), y: 292, w: 36, h: 156,
        vx: 0, vy: 0, life: 1.15, damage: 1, owner: 'enemy', hitIds: [], delay: .65, style: 'ink' });
      for (const offset of [-.18, .18]) shoot(e, s, ctx, angle + offset, 190, 'ink', 12);
      ctx.sound('fire'); return .32;
  }
}

function moveGround(e: Enemy, s: GameState, dt: number, ctx: EnemyVariantContext): void {
  // Ground fighters do not charge blindly off ledges or spawn a new blocker in a pit.
  const moving = Math.sign(e.vx), next = e.x + e.w / 2 + moving * (e.w / 2 + 9);
  const supported = s.room.platforms.some(p => p.kind === 'ground' && next >= p.x + 3 && next <= p.x + p.w - 3);
  const dangerous = s.room.hazards.some(h => h.kind === 'spikes' && next > h.x - 14 && next < h.x + h.w + 14);
  if (e.y + e.h > 438 && e.vy >= 0 && (!supported || dangerous)) e.vx = 0;
  e.x = clamp(e.x + e.vx * dt, 20, s.room.width - e.w - 20);
  const bottom = e.y + e.h;
  e.vy = Math.min(650, e.vy + 1260 * dt); e.y += e.vy * dt;
  for (const platform of s.room.platforms) if (e.x + e.w > platform.x && e.x < platform.x + platform.w && e.vy >= 0 && bottom <= platform.y + 4 && e.y + e.h >= platform.y) {
    e.y = platform.y - e.h; e.vy = 0;
  }
  if (e.y > 600) ctx.hitEnemy(e, 1000);
}

/** Called after the engine ticks common enemy timers. Unknown/legacy fixtures
 * return false so their original behavior and tests remain intact. */
export function updateEnemyVariant(e: Enemy, s: GameState, dt: number, ctx: EnemyVariantContext): boolean {
  const profile = enemyProfile(e); if (!profile) return false;
  const dx = s.hero.x + 14 - e.x - e.w / 2;
  const factor = s.modifier === 'haste' ? 1.15 : 1;
  const realmDepth = Math.min(6, s.roomIndex);
  const pursuit = 1 + .03 * realmDepth;
  e.aiMode ??= 'patrol'; e.aiTimer = Math.max(0, (e.aiTimer ?? 0) - dt * factor);
  if (e.aiMode === 'windup') {
    e.vx = approach(e.vx, 0, 900 * dt); e.vy = e.kind === 'bat' ? approach(e.vy, 0, 700 * dt) : e.vy;
    if (e.aiTimer <= 0) { e.aiMode = 'attack'; e.aiTimer = fire(e, s, profile, ctx); }
  } else if (e.aiMode === 'attack') {
    if (e.aiTimer <= 0) {
      e.aiMode = 'recover'; e.aiTimer = profile.ability === 'blink' && (e.aiCount ?? 0) % 2 === 1 ? .22 : .6 * (1 - .04 * realmDepth);
      if (profile.ability === 'blink' && (e.aiCount ?? 0) % 2 === 1) e.attackCooldown = .25;
    }
  } else if (e.aiMode === 'recover') {
    e.vx = approach(e.vx, 0, 700 * dt);
    if (e.aiTimer <= 0) e.aiMode = 'patrol';
  } else {
    if (Math.abs(dx) > 3) e.facing = dx > 0 ? 1 : -1;
    if (e.kind === 'bat') {
      const engaged = Math.abs(dx) < 500;
      const targetX = engaged ? s.hero.x + (e.x < s.hero.x ? -155 : 155) : e.originX;
      const targetY = clamp(e.originY + Math.sin(e.timer * 2 + e.id) * 25, 140, 360);
      e.vx = approach(e.vx, clamp((targetX - e.x) * 1.3, -95, 95) * pursuit, 300 * dt);
      e.vy = approach(e.vy, clamp((targetY - e.y) * 1.7, -95, 95), 330 * dt);
    } else {
      const pursuer = ['hop', 'rush', 'leap', 'blink', 'guard', 'shieldquake', 'judgment'].includes(profile.ability);
      const speed = e.variant === 'forge-bulwark' ? 52 : profile.ability === 'guard' ? 26 : profile.ability === 'blink' ? 55 : 42;
      const desired = pursuer && Math.abs(dx) < 480 && Math.abs(dx) > 85 ? e.facing * speed * factor * pursuit : 0;
      if (e.hurt <= 0) e.vx = approach(e.vx, desired, 600 * dt);
    }
    if (e.attackCooldown <= 0 && e.hurt <= 0 && Math.abs(dx) < profile.range && Math.abs(s.hero.y - e.y) < 300 && clearSight(e, s)) {
      e.aiMode = 'windup'; e.aiTimer = profile.warning;
      e.attackCooldown = profile.interval;
      const target = { x: s.hero.x + s.hero.w / 2, y: s.hero.y + s.hero.h / 2 };
      aim.set(e, target); e.targetX = target.x;
      e.facing = dx >= 0 ? 1 : -1;
    }
  }
  if (e.kind === 'bat') {
    e.x = clamp(e.x + e.vx * dt, 20, s.room.width - e.w - 20);
    e.y = clamp(e.y + e.vy * dt, 85, 443 - e.h);
  } else moveGround(e, s, dt, ctx);
  return true;
}

/** Heavy third strikes, rear hits and the guardian's recovery bypass its shield.
 * The engine deliberately applies this only to direct hits, never to burning. */
export function enemyDamageMultiplier(e: Enemy, hero: Hero): number {
  const ability = enemyProfile(e)?.ability;
  if ((ability !== 'guard' && ability !== 'shieldquake') || e.aiMode === 'attack' || e.aiMode === 'recover' || hero.attackStep === 3) return 1;
  const frontal = (hero.x + hero.w / 2 - e.x - e.w / 2) * (e.facing || 1) >= 0;
  return frontal ? (ability === 'shieldquake' ? .55 : .35) : 1;
}
